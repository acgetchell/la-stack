#!/usr/bin/env bash
set -euo pipefail

for angle_phase in after before; do
    CRITERION_HOME="target/angle-sparse-287/confirmation/$angle_phase" \
        "target/angle-sparse-287/$angle_phase" \
        'angle_d[3-6]/dense.*/borrowed_slice|angle_d6/dense.*/prepared_vector|angle_d6/.*/stable_control|angle_d6/.*/borrowed_slice|angle_d[3-5]/near_parallel/borrowed_slice' \
        --bench --sample-size 50 --warm-up-time 0.5 --measurement-time 1.5 \
        --noplot > "target/angle-sparse-287/confirm-$angle_phase.log" 2>&1
done
