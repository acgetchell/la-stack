#!/usr/bin/env bash
set -euo pipefail

for angle_phase in "$@"; do
    CRITERION_HOME="target/angle-sparse-287/measurements/$angle_phase" \
        "target/angle-sparse-287/$angle_phase" \
        'angle_d[3-6]/.*/borrowed_slice|angle_d6/.*/(prepared_vector|stable_control)' \
        --bench --sample-size 50 --warm-up-time 0.5 --measurement-time 1.5 \
        --noplot > "target/angle-sparse-287/$angle_phase.log" 2>&1
done
