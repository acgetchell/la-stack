Evidence for la-stack issues #247 and #248

Final comparisons:
  data/upstream: issue-before is the baseline; new is the optimized library.
  data/downstream: private-final is the private kernel; new is the final adapter.
  data/downstream-repeat: adopted-repeat is the final adapter; new is private.
  data/control-3d: control-3d is the final adapter; new is private (200 samples).
  All other final measurements contain 100 samples. Confidence levels are 95%.

Exploratory comparisons:
  initial-* datasets use the library before zero-product FMA elision.
  intermediate-* datasets use the final library with the earlier iterator adapter.
  rust-1.99-regression contains the original short diagnostic reproduction.
  Failed candidates are retained; use final datasets for the acceptance decision.
  The shared-output-directory pilot was invalid and is excluded from these data.

Source/provenance:
  source.patch applies source, test, and benchmark changes to la-stack base
  2095d18a2fb0b7ee02882cda9b86943a1ee53ebc. initial-candidate.patch captures the
  earlier library. adoption.patch and flat-sampling.patch apply to Delaunay base
  2f2f01451815f0b3fdd6bce02c9f25e5af146d98. Both private and adopted realization
  binaries use the sampling patch in final comparisons. The private code does
  not use the adoption patch. Lockfiles, binary hashes, and build flags are retained.

Profiles and diagnostic logs describe intermediate investigation steps. The
outlined-iterator profile uses the intermediate adapter with the final library.
No binaries, build caches, or credentials are included.

CSV validation/export (run from the la-stack repository root):
  uv run --locked --project "$PWD" <extracted>/compare.py <data-directory> <baseline-label>
Append "reverse" for adopted-first runs. Append "reverse 200" for control-3d.
The exporter checks sample counts, positive finite measurements, and complete
95% confidence intervals. It reports every case in the selected baseline.

The accompanying Markdown study owns interpretation, limitations, and commands.
