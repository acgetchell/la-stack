"""Run from the repository root; validate Criterion data and print its CSV."""

import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path.cwd() / "scripts"))
from criterion_measurements import positive_number, read_object, validate_measurement
from research_repo_tools.criterion import parse_estimate

root = Path(sys.argv[1])
baseline = sys.argv[2]
reverse = len(sys.argv) > 3 and sys.argv[3] == "reverse"
sample_count = int(sys.argv[4]) if len(sys.argv) > 4 else 100


def validate_study_measurement(directory: Path) -> None:
    if sample_count == 100:
        validate_measurement(directory)
        return
    samples = read_object(directory / "sample.json")
    for field in ("iters", "times"):
        values = samples.get(field)
        if not isinstance(values, list) or len(values) != sample_count:
            raise ValueError(f"{directory}: {field} must contain {sample_count} samples")
        for value in values:
            positive_number(value)
    payload = (directory / "estimates.json").read_bytes()
    for statistic in ("mean", "median"):
        estimate = parse_estimate(payload, statistic=statistic)
        if estimate.lower is None or estimate.upper is None or estimate.confidence_level != 0.95:
            raise ValueError(f"{directory}: expected a complete 95% confidence interval")

writer = csv.writer(sys.stdout, lineterminator="\n")
writer.writerow([
    "case", "before_mean_ns", "after_mean_ns", "before_median_ns", "after_median_ns",
    "before_mean_lower_ns", "before_mean_upper_ns", "after_mean_lower_ns",
    "after_mean_upper_ns", "mean_change_percent", "criterion_change_lower_percent",
    "criterion_change_upper_percent",
])
for directory in sorted(root.rglob(baseline)):
    if not directory.is_dir() or not (directory / "estimates.json").is_file():
        continue
    other = directory.parent / "new"
    validate_study_measurement(directory)
    validate_study_measurement(other)
    before = json.loads((directory / "estimates.json").read_text())
    after = json.loads((other / "estimates.json").read_text())
    change = json.loads((directory.parent / "change/estimates.json").read_text())["mean"]
    lower = change["confidence_interval"]["lower_bound"]
    upper = change["confidence_interval"]["upper_bound"]
    if reverse:
        before, after = after, before
        lower, upper = 1 / (1 + upper) - 1, 1 / (1 + lower) - 1
    case = json.loads((directory / "benchmark.json").read_text())["full_id"]
    writer.writerow([
        case, before["mean"]["point_estimate"], after["mean"]["point_estimate"],
        before["median"]["point_estimate"], after["median"]["point_estimate"],
        before["mean"]["confidence_interval"]["lower_bound"],
        before["mean"]["confidence_interval"]["upper_bound"],
        after["mean"]["confidence_interval"]["lower_bound"],
        after["mean"]["confidence_interval"]["upper_bound"],
        100 * (after["mean"]["point_estimate"] / before["mean"]["point_estimate"] - 1),
        100 * lower, 100 * upper,
    ])
