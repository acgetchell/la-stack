# Exact solve normalization experiment

Date: 2026-10-18. Repository baseline:
`99b060307476fb3df0f25fad5bab67dfdff0f5b2`.

The baseline library was unchanged. The pre-existing staged `pyproject.toml`
dprint tool-pin edit was preserved throughout. No branch, index, commit, or
remote changes were made. The candidate changes are retained in `source.patch`;
the exact solver snapshots and compiled benchmark executables are also retained.

Environment: Apple M4 Max, aarch64-apple-darwin, macOS 27.0.1 (26A434),
Rust 1.99.1 (58cf8f9c3), LLVM 23.1.1, Criterion 0.8.2. Cargo's existing bench
profile uses fat LTO and one codegen unit. No feature, dependency, harness, or
fixture changes were made. `harness-hashes.txt` records SHA-256 input hashes.

## Correctness gates

Before either implementation was measured, its relevant tests passed:

```sh
cargo test --locked --release --features bench,exact --lib \
  --test proptest_exact --test proptest_rational \
  --test rational_structured_solve --test exact_conversion_boundaries \
  --test exact_bench_config --test rational_allocations
```

The candidate runs additionally set `PROPTEST_CASES=64` and
`PROPTEST_RNG_SEED=285001` for reproducible property exploration. Benchmark
fixtures also perform independent exact checks before timed closures.
`before-tests.log`, `after-tests.log`, and the retained prototype log hold the
results. The original implementation passed 728 tests; each candidate passed 744.

Allocation evidence was collected separately from timing, using the existing
counting-allocator test executable:

```sh
cargo test --locked --release --features bench,exact \
  --test rational_allocations -- --nocapture
```

The baseline allocation pass directly invoked its already-built test executable
before it was rebuilt for the candidate. Counts are checked for repeatability
by the existing tests. Reported bytes are cumulative allocation traffic per
complete solve, not peak memory usage.

## Timing commands

Both revisions were built with the same command:

```sh
cargo bench --locked --features bench,exact \
  --bench exact --bench rational_solve --no-run
```

The resulting binaries were copied to `before-exact`, `before-rational-solve`,
`after-exact`, and `after-rational-solve` so they could be rerun without source
or version-control changes. Each invocation passes Criterion's required
`--bench` switch. `CRITERION_HOME` is an absolute path within this directory.

`measure.sh` contains the exact filters and settings for the broad 47-case
comparison: 30 samples, 1 second warm-up, 2 seconds measurement, no plots.
The first before run invoked those two binary commands directly; subsequent
runs use the script. No builds, tests, or other task workloads ran concurrently
with timing. Normal host activity remains uncontrolled.

```sh
bash target/exact-normalization-20261018/measure.sh before before
bash target/exact-normalization-20261018/measure.sh after after
```

The first candidate, which retained the full final-pivot denominator, was
rejected after a wide-input regression. Its complete timings, source, test log,
allocation log, and binaries are retained under `fixed-denominator` names.
The `after` label is reserved for the revised implementation that grows the
shared denominator only as needed.

`repeat.sh` repeats 21 cases with identical sampling settings: the D=4/D=5
headline solves, small D=8 rational input, 1024-bit D=4/D=8 rational input, and
all 16 structured controls. Reversing execution order checks for timing drift:

```sh
bash target/exact-normalization-20261018/repeat.sh after after-repeat
bash target/exact-normalization-20261018/repeat.sh before before-repeat
```

## Summary generation

The report uses arithmetic means and marginal 95% confidence intervals from
Criterion's `estimates.json`, not the terminal slope estimate. Ratios of means
are descriptive; they are not paired confidence intervals for a speedup.
Random-corpus rows time a batch of 50 inputs, not a single solve.

```sh
rg --files --hidden --no-ignore target/exact-normalization-20261018/criterion \
  | rg '/(before|after|before-repeat|after-repeat)/estimates.json$' \
  | xargs jq -n -f target/exact-normalization-20261018/compare.jq \
  > target/exact-normalization-20261018/comparison.json
```

Raw samples and confidence intervals remain under `criterion/`. Current-source
results from the earlier repository assessment were not used as the baseline.

## Final validation and control follow-up

After implementation and benchmark iteration, these required repository checks
passed:

```sh
just markdown-fix
just markdown-ci
just ci
```

`just check` had also passed during iteration. The full CI log records 1,020
Rust tests, 181 Python tests, both doctest configurations, static analysis,
documentation builds, benchmark compilation, and examples.

After CI completed, `control.sh` ran the unchanged rational diagonal D=8
control in before/after/after/before order with 100 samples, 1 second warm-up,
and 5 seconds measurement per run. This additional check targets its small
positive movement in the shorter runs; it does not replace or hide them.
