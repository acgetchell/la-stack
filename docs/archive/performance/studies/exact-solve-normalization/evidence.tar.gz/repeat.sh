#!/usr/bin/env bash
set -euo pipefail

# Repeat the headline cases, 1024-bit cases, and every structured control.
# Run after-repeat before before-repeat to reverse the first pass's order.
evidence_dir="$PWD/target/exact-normalization-20261018"
export CRITERION_HOME="$evidence_dir/criterion"
variant="${1:?before or after}"
baseline="${2:?saved baseline name}"
"$evidence_dir/$variant-exact" --bench \
  '^exact_d[45]/solve_exact$|^rational_input_d8/solve_row_cleared_bareiss$|^rational_input_wide1024_d[48]/solve_row_cleared_bareiss$' \
  --sample-size 30 --warm-up-time 1 --measurement-time 2 --noplot \
  --save-baseline "$baseline" > "$evidence_dir/$baseline-exact.log" 2>&1
"$evidence_dir/$variant-rational-solve" --bench \
  '^rational_solve/(diagonal|permuted_upper|sparse|dense)/(rational|dyadic)_d[48]/prepared$' \
  --sample-size 30 --warm-up-time 1 --measurement-time 2 --noplot \
  --save-baseline "$baseline" > "$evidence_dir/$baseline-structured.log" 2>&1
