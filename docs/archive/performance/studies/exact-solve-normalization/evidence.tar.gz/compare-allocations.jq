[$before[0][] | select(.operation == "solve") as $b
 | $after[0][]
 | select(.operation == "solve" and .kind == $b.kind and .dimension == $b.dimension)
 | {kind, dimension, before_count: $b.count, after_count: .count,
    before_bytes: $b.bytes, after_bytes: .bytes}]
| sort_by(.kind, .dimension)
