#!/usr/bin/env bash
set -euo pipefail

# Resolve the small diagonal D=8 control movement with longer, interleaved runs.
evidence_dir="$PWD/target/exact-normalization-20261018"
export CRITERION_HOME="$evidence_dir/criterion"
for run in before-control-a after-control-a after-control-b before-control-b; do
  variant="${run%%-*}"
  "$evidence_dir/$variant-rational-solve" --bench \
    '^rational_solve/diagonal/rational_d8/prepared$' \
    --sample-size 100 --warm-up-time 1 --measurement-time 5 --noplot \
    --save-baseline "$run" > "$evidence_dir/$run.log" 2>&1
done
