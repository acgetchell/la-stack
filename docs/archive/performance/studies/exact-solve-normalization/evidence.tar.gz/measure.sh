#!/usr/bin/env bash
set -euo pipefail

# Run from the repository root. The first argument selects the retained
# binary pair (before or after); the second names the saved Criterion baseline.
evidence_dir="$PWD/target/exact-normalization-20261018"
export CRITERION_HOME="$evidence_dir/criterion"
variant="${1:?before or after}"
baseline="${2:?saved baseline name}"
"$evidence_dir/$variant-exact" --bench \
  '^exact_d[2-5]/solve_exact(_f64_result|_rounded_f64)?$|^exact_(random_corpus_d[2-5]|near_singular_3x3|large_entries_3x3|hilbert_[45]x[45])/solve_exact$|^rational_input_d[2-8]/solve_row_cleared_bareiss$|^rational_input_wide(256|1024)_d[48]/solve_row_cleared_bareiss$' \
  --sample-size 30 --warm-up-time 1 --measurement-time 2 --noplot \
  --save-baseline "$baseline" > "$evidence_dir/$baseline-exact.log" 2>&1
"$evidence_dir/$variant-rational-solve" --bench \
  '^rational_solve/(diagonal|permuted_upper|sparse|dense)/(rational|dyadic)_d[48]/prepared$' \
  --sample-size 30 --warm-up-time 1 --measurement-time 2 --noplot \
  --save-baseline "$baseline" > "$evidence_dir/$baseline-structured.log" 2>&1
