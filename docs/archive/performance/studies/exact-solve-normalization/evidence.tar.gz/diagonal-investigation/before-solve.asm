
target/exact-normalization-20261018/before-rational-solve:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100062240 <<la_stack::rational::RationalMatrix<8>>::solve>:
100062240:     	stp	x28, x27, [sp, #-0x60]!
100062244:     	stp	x26, x25, [sp, #0x10]
100062248:     	stp	x24, x23, [sp, #0x20]
10006224c:     	stp	x22, x21, [sp, #0x30]
100062250:     	stp	x20, x19, [sp, #0x40]
100062254:     	stp	x29, x30, [sp, #0x50]
100062258:     	add	x29, sp, #0x50
10006225c:     	sub	sp, sp, #0x1, lsl #12   ; =0x1000
100062260:     	ldr	xzr, [sp]
100062264:     	sub	sp, sp, #0x8b0
100062268:     	ldr	xzr, [sp]
10006226c:     	mov	x27, x2
100062270:     	mov	x28, x1
100062274:     	str	xzr, [sp, #0xd10]
100062278:     	str	xzr, [sp, #0x1580]
10006227c:     	add	x8, sp, #0xb00
100062280:     	str	xzr, [sp, #0xa00]
100062284:     	str	xzr, [sp, #0x100]
100062288:     	stur	xzr, [x29, #-0xa0]
10006228c:     	stur	xzr, [x29, #-0x100]
100062290:     	str	xzr, [sp, #0x17c0]
100062294:     	str	xzr, [sp, #0x1780]
100062298:     	strb	wzr, [sp, #0xcf0]
10006229c:     	strb	wzr, [x8, #0xa70]
1000622a0:     	strb	wzr, [x8, #0xa60]
1000622a4:     	strb	wzr, [x8, #0xa50]
1000622a8:     	strb	wzr, [x8, #0xa40]
1000622ac:     	strb	wzr, [x8, #0xa30]
1000622b0:     	strb	wzr, [x8, #0xa20]
1000622b4:     	strb	wzr, [x8, #0xa10]
1000622b8:     	ldrb	w8, [x1, #0x18]
1000622bc:     	cmp	w8, #0x1
1000622c0:     	str	x1, [sp, #0xf0]
1000622c4:     	str	x0, [sp]
1000622c8:     	str	x2, [sp, #0x40]
1000622cc:     	b.eq	0x1000622dc <<la_stack::rational::RationalMatrix<8>>::solve+0x9c>
1000622d0:     	add	x9, sp, #0xcf0
1000622d4:     	add	x10, sp, #0xd10
1000622d8:     	b	0x1000623a8 <<la_stack::rational::RationalMatrix<8>>::solve+0x168>
1000622dc:     	ldrb	w9, [x28, #0x58]
1000622e0:     	cmp	w9, #0x1
1000622e4:     	b.ne	0x100062344 <<la_stack::rational::RationalMatrix<8>>::solve+0x104>
1000622e8:     	ldrb	w9, [x28, #0x98]
1000622ec:     	cmp	w9, #0x1
1000622f0:     	b.ne	0x100062358 <<la_stack::rational::RationalMatrix<8>>::solve+0x118>
1000622f4:     	ldrb	w9, [x28, #0xd8]
1000622f8:     	cmp	w9, #0x1
1000622fc:     	b.ne	0x100062368 <<la_stack::rational::RationalMatrix<8>>::solve+0x128>
100062300:     	ldrb	w9, [x28, #0x118]
100062304:     	cmp	w9, #0x1
100062308:     	b.ne	0x100062378 <<la_stack::rational::RationalMatrix<8>>::solve+0x138>
10006230c:     	ldrb	w9, [x28, #0x158]
100062310:     	cmp	w9, #0x1
100062314:     	b.ne	0x100062388 <<la_stack::rational::RationalMatrix<8>>::solve+0x148>
100062318:     	ldrb	w9, [x28, #0x198]
10006231c:     	cmp	w9, #0x1
100062320:     	b.ne	0x100062398 <<la_stack::rational::RationalMatrix<8>>::solve+0x158>
100062324:     	ldrb	w9, [x28, #0x1d8]
100062328:     	cmp	w9, #0x1
10006232c:     	b.eq	0x100062a8c <<la_stack::rational::RationalMatrix<8>>::solve+0x84c>
100062330:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062334:     	add	x9, x9, #0x510
100062338:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
10006233c:     	add	x10, x10, #0x780
100062340:     	b	0x1000623a8 <<la_stack::rational::RationalMatrix<8>>::solve+0x168>
100062344:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062348:     	add	x9, x9, #0x570
10006234c:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100062350:     	add	x10, x10, #0x580
100062354:     	b	0x1000623a8 <<la_stack::rational::RationalMatrix<8>>::solve+0x168>
100062358:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
10006235c:     	add	x9, x9, #0x560
100062360:     	add	x10, sp, #0xa00
100062364:     	b	0x1000623a8 <<la_stack::rational::RationalMatrix<8>>::solve+0x168>
100062368:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
10006236c:     	add	x9, x9, #0x550
100062370:     	add	x10, sp, #0x100
100062374:     	b	0x1000623a8 <<la_stack::rational::RationalMatrix<8>>::solve+0x168>
100062378:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
10006237c:     	add	x9, x9, #0x540
100062380:     	sub	x10, x29, #0xa0
100062384:     	b	0x1000623a8 <<la_stack::rational::RationalMatrix<8>>::solve+0x168>
100062388:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
10006238c:     	add	x9, x9, #0x530
100062390:     	sub	x10, x29, #0x100
100062394:     	b	0x1000623a8 <<la_stack::rational::RationalMatrix<8>>::solve+0x168>
100062398:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
10006239c:     	add	x9, x9, #0x520
1000623a0:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
1000623a4:     	add	x10, x10, #0x7c0
1000623a8:     	ldrb	w11, [x9]
1000623ac:     	tbnz	w11, #0x0, 0x100062a8c <<la_stack::rational::RationalMatrix<8>>::solve+0x84c>
1000623b0:     	mov	w11, #0x1               ; =1
1000623b4:     	strb	w11, [x9]
1000623b8:     	str	xzr, [x10]
1000623bc:     	ldrb	w9, [x28, #0x218]
1000623c0:     	cmp	w9, #0x1
1000623c4:     	b.ne	0x100062430 <<la_stack::rational::RationalMatrix<8>>::solve+0x1f0>
1000623c8:     	ldrb	w9, [x28, #0x258]
1000623cc:     	cmp	w9, #0x1
1000623d0:     	b.ne	0x10006243c <<la_stack::rational::RationalMatrix<8>>::solve+0x1fc>
1000623d4:     	ldrb	w9, [x28, #0x298]
1000623d8:     	cmp	w9, #0x1
1000623dc:     	b.ne	0x100062450 <<la_stack::rational::RationalMatrix<8>>::solve+0x210>
1000623e0:     	ldrb	w9, [x28, #0x2d8]
1000623e4:     	cmp	w9, #0x1
1000623e8:     	b.ne	0x100062460 <<la_stack::rational::RationalMatrix<8>>::solve+0x220>
1000623ec:     	ldrb	w9, [x28, #0x318]
1000623f0:     	cmp	w9, #0x1
1000623f4:     	b.ne	0x100062470 <<la_stack::rational::RationalMatrix<8>>::solve+0x230>
1000623f8:     	ldrb	w9, [x28, #0x358]
1000623fc:     	cmp	w9, #0x1
100062400:     	b.ne	0x100062480 <<la_stack::rational::RationalMatrix<8>>::solve+0x240>
100062404:     	ldrb	w9, [x28, #0x398]
100062408:     	cmp	w9, #0x1
10006240c:     	b.ne	0x100062490 <<la_stack::rational::RationalMatrix<8>>::solve+0x250>
100062410:     	ldrb	w9, [x28, #0x3d8]
100062414:     	cmp	w9, #0x1
100062418:     	b.eq	0x100062a8c <<la_stack::rational::RationalMatrix<8>>::solve+0x84c>
10006241c:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062420:     	add	x9, x9, #0x510
100062424:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100062428:     	add	x10, x10, #0x780
10006242c:     	b	0x1000624a0 <<la_stack::rational::RationalMatrix<8>>::solve+0x260>
100062430:     	add	x9, sp, #0xcf0
100062434:     	add	x10, sp, #0xd10
100062438:     	b	0x1000624a0 <<la_stack::rational::RationalMatrix<8>>::solve+0x260>
10006243c:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062440:     	add	x9, x9, #0x570
100062444:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100062448:     	add	x10, x10, #0x580
10006244c:     	b	0x1000624a0 <<la_stack::rational::RationalMatrix<8>>::solve+0x260>
100062450:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062454:     	add	x9, x9, #0x560
100062458:     	add	x10, sp, #0xa00
10006245c:     	b	0x1000624a0 <<la_stack::rational::RationalMatrix<8>>::solve+0x260>
100062460:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062464:     	add	x9, x9, #0x550
100062468:     	add	x10, sp, #0x100
10006246c:     	b	0x1000624a0 <<la_stack::rational::RationalMatrix<8>>::solve+0x260>
100062470:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062474:     	add	x9, x9, #0x540
100062478:     	sub	x10, x29, #0xa0
10006247c:     	b	0x1000624a0 <<la_stack::rational::RationalMatrix<8>>::solve+0x260>
100062480:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062484:     	add	x9, x9, #0x530
100062488:     	sub	x10, x29, #0x100
10006248c:     	b	0x1000624a0 <<la_stack::rational::RationalMatrix<8>>::solve+0x260>
100062490:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062494:     	add	x9, x9, #0x520
100062498:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
10006249c:     	add	x10, x10, #0x7c0
1000624a0:     	ldrb	w11, [x9]
1000624a4:     	tbnz	w11, #0x0, 0x100062a8c <<la_stack::rational::RationalMatrix<8>>::solve+0x84c>
1000624a8:     	mov	w11, #0x1               ; =1
1000624ac:     	strb	w11, [x9]
1000624b0:     	str	x11, [x10]
1000624b4:     	ldrb	w9, [x28, #0x418]
1000624b8:     	cmp	w9, #0x1
1000624bc:     	b.ne	0x100062528 <<la_stack::rational::RationalMatrix<8>>::solve+0x2e8>
1000624c0:     	ldrb	w9, [x28, #0x458]
1000624c4:     	cmp	w9, #0x1
1000624c8:     	b.ne	0x100062534 <<la_stack::rational::RationalMatrix<8>>::solve+0x2f4>
1000624cc:     	ldrb	w9, [x28, #0x498]
1000624d0:     	cmp	w9, #0x1
1000624d4:     	b.ne	0x100062548 <<la_stack::rational::RationalMatrix<8>>::solve+0x308>
1000624d8:     	ldrb	w9, [x28, #0x4d8]
1000624dc:     	cmp	w9, #0x1
1000624e0:     	b.ne	0x100062558 <<la_stack::rational::RationalMatrix<8>>::solve+0x318>
1000624e4:     	ldrb	w9, [x28, #0x518]
1000624e8:     	cmp	w9, #0x1
1000624ec:     	b.ne	0x100062568 <<la_stack::rational::RationalMatrix<8>>::solve+0x328>
1000624f0:     	ldrb	w9, [x28, #0x558]
1000624f4:     	cmp	w9, #0x1
1000624f8:     	b.ne	0x100062578 <<la_stack::rational::RationalMatrix<8>>::solve+0x338>
1000624fc:     	ldrb	w9, [x28, #0x598]
100062500:     	cmp	w9, #0x1
100062504:     	b.ne	0x100062588 <<la_stack::rational::RationalMatrix<8>>::solve+0x348>
100062508:     	ldrb	w9, [x28, #0x5d8]
10006250c:     	cmp	w9, #0x1
100062510:     	b.eq	0x100062a8c <<la_stack::rational::RationalMatrix<8>>::solve+0x84c>
100062514:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062518:     	add	x9, x9, #0x510
10006251c:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100062520:     	add	x10, x10, #0x780
100062524:     	b	0x100062598 <<la_stack::rational::RationalMatrix<8>>::solve+0x358>
100062528:     	add	x9, sp, #0xcf0
10006252c:     	add	x10, sp, #0xd10
100062530:     	b	0x100062598 <<la_stack::rational::RationalMatrix<8>>::solve+0x358>
100062534:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062538:     	add	x9, x9, #0x570
10006253c:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100062540:     	add	x10, x10, #0x580
100062544:     	b	0x100062598 <<la_stack::rational::RationalMatrix<8>>::solve+0x358>
100062548:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
10006254c:     	add	x9, x9, #0x560
100062550:     	add	x10, sp, #0xa00
100062554:     	b	0x100062598 <<la_stack::rational::RationalMatrix<8>>::solve+0x358>
100062558:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
10006255c:     	add	x9, x9, #0x550
100062560:     	add	x10, sp, #0x100
100062564:     	b	0x100062598 <<la_stack::rational::RationalMatrix<8>>::solve+0x358>
100062568:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
10006256c:     	add	x9, x9, #0x540
100062570:     	sub	x10, x29, #0xa0
100062574:     	b	0x100062598 <<la_stack::rational::RationalMatrix<8>>::solve+0x358>
100062578:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
10006257c:     	add	x9, x9, #0x530
100062580:     	sub	x10, x29, #0x100
100062584:     	b	0x100062598 <<la_stack::rational::RationalMatrix<8>>::solve+0x358>
100062588:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
10006258c:     	add	x9, x9, #0x520
100062590:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100062594:     	add	x10, x10, #0x7c0
100062598:     	ldrb	w11, [x9]
10006259c:     	tbnz	w11, #0x0, 0x100062a8c <<la_stack::rational::RationalMatrix<8>>::solve+0x84c>
1000625a0:     	mov	w11, #0x1               ; =1
1000625a4:     	strb	w11, [x9]
1000625a8:     	mov	w9, #0x2                ; =2
1000625ac:     	str	x9, [x10]
1000625b0:     	ldrb	w9, [x28, #0x618]
1000625b4:     	cmp	w9, #0x1
1000625b8:     	b.ne	0x100062624 <<la_stack::rational::RationalMatrix<8>>::solve+0x3e4>
1000625bc:     	ldrb	w9, [x28, #0x658]
1000625c0:     	cmp	w9, #0x1
1000625c4:     	b.ne	0x100062630 <<la_stack::rational::RationalMatrix<8>>::solve+0x3f0>
1000625c8:     	ldrb	w9, [x28, #0x698]
1000625cc:     	cmp	w9, #0x1
1000625d0:     	b.ne	0x100062644 <<la_stack::rational::RationalMatrix<8>>::solve+0x404>
1000625d4:     	ldrb	w9, [x28, #0x6d8]
1000625d8:     	cmp	w9, #0x1
1000625dc:     	b.ne	0x100062654 <<la_stack::rational::RationalMatrix<8>>::solve+0x414>
1000625e0:     	ldrb	w9, [x28, #0x718]
1000625e4:     	cmp	w9, #0x1
1000625e8:     	b.ne	0x100062664 <<la_stack::rational::RationalMatrix<8>>::solve+0x424>
1000625ec:     	ldrb	w9, [x28, #0x758]
1000625f0:     	cmp	w9, #0x1
1000625f4:     	b.ne	0x100062674 <<la_stack::rational::RationalMatrix<8>>::solve+0x434>
1000625f8:     	ldrb	w9, [x28, #0x798]
1000625fc:     	cmp	w9, #0x1
100062600:     	b.ne	0x100062684 <<la_stack::rational::RationalMatrix<8>>::solve+0x444>
100062604:     	ldrb	w9, [x28, #0x7d8]
100062608:     	cmp	w9, #0x1
10006260c:     	b.eq	0x100062a8c <<la_stack::rational::RationalMatrix<8>>::solve+0x84c>
100062610:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062614:     	add	x9, x9, #0x510
100062618:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
10006261c:     	add	x10, x10, #0x780
100062620:     	b	0x100062694 <<la_stack::rational::RationalMatrix<8>>::solve+0x454>
100062624:     	add	x9, sp, #0xcf0
100062628:     	add	x10, sp, #0xd10
10006262c:     	b	0x100062694 <<la_stack::rational::RationalMatrix<8>>::solve+0x454>
100062630:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062634:     	add	x9, x9, #0x570
100062638:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
10006263c:     	add	x10, x10, #0x580
100062640:     	b	0x100062694 <<la_stack::rational::RationalMatrix<8>>::solve+0x454>
100062644:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062648:     	add	x9, x9, #0x560
10006264c:     	add	x10, sp, #0xa00
100062650:     	b	0x100062694 <<la_stack::rational::RationalMatrix<8>>::solve+0x454>
100062654:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062658:     	add	x9, x9, #0x550
10006265c:     	add	x10, sp, #0x100
100062660:     	b	0x100062694 <<la_stack::rational::RationalMatrix<8>>::solve+0x454>
100062664:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062668:     	add	x9, x9, #0x540
10006266c:     	sub	x10, x29, #0xa0
100062670:     	b	0x100062694 <<la_stack::rational::RationalMatrix<8>>::solve+0x454>
100062674:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062678:     	add	x9, x9, #0x530
10006267c:     	sub	x10, x29, #0x100
100062680:     	b	0x100062694 <<la_stack::rational::RationalMatrix<8>>::solve+0x454>
100062684:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062688:     	add	x9, x9, #0x520
10006268c:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100062690:     	add	x10, x10, #0x7c0
100062694:     	ldrb	w11, [x9]
100062698:     	tbnz	w11, #0x0, 0x100062a8c <<la_stack::rational::RationalMatrix<8>>::solve+0x84c>
10006269c:     	mov	w11, #0x1               ; =1
1000626a0:     	strb	w11, [x9]
1000626a4:     	mov	w9, #0x3                ; =3
1000626a8:     	str	x9, [x10]
1000626ac:     	ldrb	w9, [x28, #0x818]
1000626b0:     	cmp	w9, #0x1
1000626b4:     	b.ne	0x100062720 <<la_stack::rational::RationalMatrix<8>>::solve+0x4e0>
1000626b8:     	ldrb	w9, [x28, #0x858]
1000626bc:     	cmp	w9, #0x1
1000626c0:     	b.ne	0x10006272c <<la_stack::rational::RationalMatrix<8>>::solve+0x4ec>
1000626c4:     	ldrb	w9, [x28, #0x898]
1000626c8:     	cmp	w9, #0x1
1000626cc:     	b.ne	0x100062740 <<la_stack::rational::RationalMatrix<8>>::solve+0x500>
1000626d0:     	ldrb	w9, [x28, #0x8d8]
1000626d4:     	cmp	w9, #0x1
1000626d8:     	b.ne	0x100062750 <<la_stack::rational::RationalMatrix<8>>::solve+0x510>
1000626dc:     	ldrb	w9, [x28, #0x918]
1000626e0:     	cmp	w9, #0x1
1000626e4:     	b.ne	0x100062760 <<la_stack::rational::RationalMatrix<8>>::solve+0x520>
1000626e8:     	ldrb	w9, [x28, #0x958]
1000626ec:     	cmp	w9, #0x1
1000626f0:     	b.ne	0x100062770 <<la_stack::rational::RationalMatrix<8>>::solve+0x530>
1000626f4:     	ldrb	w9, [x28, #0x998]
1000626f8:     	cmp	w9, #0x1
1000626fc:     	b.ne	0x100062780 <<la_stack::rational::RationalMatrix<8>>::solve+0x540>
100062700:     	ldrb	w9, [x28, #0x9d8]
100062704:     	cmp	w9, #0x1
100062708:     	b.eq	0x100062a8c <<la_stack::rational::RationalMatrix<8>>::solve+0x84c>
10006270c:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062710:     	add	x9, x9, #0x510
100062714:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100062718:     	add	x10, x10, #0x780
10006271c:     	b	0x100062790 <<la_stack::rational::RationalMatrix<8>>::solve+0x550>
100062720:     	add	x9, sp, #0xcf0
100062724:     	add	x10, sp, #0xd10
100062728:     	b	0x100062790 <<la_stack::rational::RationalMatrix<8>>::solve+0x550>
10006272c:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062730:     	add	x9, x9, #0x570
100062734:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100062738:     	add	x10, x10, #0x580
10006273c:     	b	0x100062790 <<la_stack::rational::RationalMatrix<8>>::solve+0x550>
100062740:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062744:     	add	x9, x9, #0x560
100062748:     	add	x10, sp, #0xa00
10006274c:     	b	0x100062790 <<la_stack::rational::RationalMatrix<8>>::solve+0x550>
100062750:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062754:     	add	x9, x9, #0x550
100062758:     	add	x10, sp, #0x100
10006275c:     	b	0x100062790 <<la_stack::rational::RationalMatrix<8>>::solve+0x550>
100062760:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062764:     	add	x9, x9, #0x540
100062768:     	sub	x10, x29, #0xa0
10006276c:     	b	0x100062790 <<la_stack::rational::RationalMatrix<8>>::solve+0x550>
100062770:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062774:     	add	x9, x9, #0x530
100062778:     	sub	x10, x29, #0x100
10006277c:     	b	0x100062790 <<la_stack::rational::RationalMatrix<8>>::solve+0x550>
100062780:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062784:     	add	x9, x9, #0x520
100062788:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
10006278c:     	add	x10, x10, #0x7c0
100062790:     	ldrb	w11, [x9]
100062794:     	tbnz	w11, #0x0, 0x100062a8c <<la_stack::rational::RationalMatrix<8>>::solve+0x84c>
100062798:     	mov	w11, #0x1               ; =1
10006279c:     	strb	w11, [x9]
1000627a0:     	mov	w9, #0x4                ; =4
1000627a4:     	str	x9, [x10]
1000627a8:     	ldrb	w9, [x28, #0xa18]
1000627ac:     	cmp	w9, #0x1
1000627b0:     	b.ne	0x10006281c <<la_stack::rational::RationalMatrix<8>>::solve+0x5dc>
1000627b4:     	ldrb	w9, [x28, #0xa58]
1000627b8:     	cmp	w9, #0x1
1000627bc:     	b.ne	0x100062828 <<la_stack::rational::RationalMatrix<8>>::solve+0x5e8>
1000627c0:     	ldrb	w9, [x28, #0xa98]
1000627c4:     	cmp	w9, #0x1
1000627c8:     	b.ne	0x10006283c <<la_stack::rational::RationalMatrix<8>>::solve+0x5fc>
1000627cc:     	ldrb	w9, [x28, #0xad8]
1000627d0:     	cmp	w9, #0x1
1000627d4:     	b.ne	0x10006284c <<la_stack::rational::RationalMatrix<8>>::solve+0x60c>
1000627d8:     	ldrb	w9, [x28, #0xb18]
1000627dc:     	cmp	w9, #0x1
1000627e0:     	b.ne	0x10006285c <<la_stack::rational::RationalMatrix<8>>::solve+0x61c>
1000627e4:     	ldrb	w9, [x28, #0xb58]
1000627e8:     	cmp	w9, #0x1
1000627ec:     	b.ne	0x10006286c <<la_stack::rational::RationalMatrix<8>>::solve+0x62c>
1000627f0:     	ldrb	w9, [x28, #0xb98]
1000627f4:     	cmp	w9, #0x1
1000627f8:     	b.ne	0x10006287c <<la_stack::rational::RationalMatrix<8>>::solve+0x63c>
1000627fc:     	ldrb	w9, [x28, #0xbd8]
100062800:     	cmp	w9, #0x1
100062804:     	b.eq	0x100062a8c <<la_stack::rational::RationalMatrix<8>>::solve+0x84c>
100062808:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
10006280c:     	add	x9, x9, #0x510
100062810:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100062814:     	add	x10, x10, #0x780
100062818:     	b	0x10006288c <<la_stack::rational::RationalMatrix<8>>::solve+0x64c>
10006281c:     	add	x9, sp, #0xcf0
100062820:     	add	x10, sp, #0xd10
100062824:     	b	0x10006288c <<la_stack::rational::RationalMatrix<8>>::solve+0x64c>
100062828:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
10006282c:     	add	x9, x9, #0x570
100062830:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100062834:     	add	x10, x10, #0x580
100062838:     	b	0x10006288c <<la_stack::rational::RationalMatrix<8>>::solve+0x64c>
10006283c:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062840:     	add	x9, x9, #0x560
100062844:     	add	x10, sp, #0xa00
100062848:     	b	0x10006288c <<la_stack::rational::RationalMatrix<8>>::solve+0x64c>
10006284c:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062850:     	add	x9, x9, #0x550
100062854:     	add	x10, sp, #0x100
100062858:     	b	0x10006288c <<la_stack::rational::RationalMatrix<8>>::solve+0x64c>
10006285c:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062860:     	add	x9, x9, #0x540
100062864:     	sub	x10, x29, #0xa0
100062868:     	b	0x10006288c <<la_stack::rational::RationalMatrix<8>>::solve+0x64c>
10006286c:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062870:     	add	x9, x9, #0x530
100062874:     	sub	x10, x29, #0x100
100062878:     	b	0x10006288c <<la_stack::rational::RationalMatrix<8>>::solve+0x64c>
10006287c:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062880:     	add	x9, x9, #0x520
100062884:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100062888:     	add	x10, x10, #0x7c0
10006288c:     	ldrb	w11, [x9]
100062890:     	tbnz	w11, #0x0, 0x100062a8c <<la_stack::rational::RationalMatrix<8>>::solve+0x84c>
100062894:     	mov	w11, #0x1               ; =1
100062898:     	strb	w11, [x9]
10006289c:     	mov	w9, #0x5                ; =5
1000628a0:     	str	x9, [x10]
1000628a4:     	ldrb	w9, [x28, #0xc18]
1000628a8:     	cmp	w9, #0x1
1000628ac:     	b.ne	0x100062918 <<la_stack::rational::RationalMatrix<8>>::solve+0x6d8>
1000628b0:     	ldrb	w9, [x28, #0xc58]
1000628b4:     	cmp	w9, #0x1
1000628b8:     	b.ne	0x100062924 <<la_stack::rational::RationalMatrix<8>>::solve+0x6e4>
1000628bc:     	ldrb	w9, [x28, #0xc98]
1000628c0:     	cmp	w9, #0x1
1000628c4:     	b.ne	0x100062938 <<la_stack::rational::RationalMatrix<8>>::solve+0x6f8>
1000628c8:     	ldrb	w9, [x28, #0xcd8]
1000628cc:     	cmp	w9, #0x1
1000628d0:     	b.ne	0x100062948 <<la_stack::rational::RationalMatrix<8>>::solve+0x708>
1000628d4:     	ldrb	w9, [x28, #0xd18]
1000628d8:     	cmp	w9, #0x1
1000628dc:     	b.ne	0x100062958 <<la_stack::rational::RationalMatrix<8>>::solve+0x718>
1000628e0:     	ldrb	w9, [x28, #0xd58]
1000628e4:     	cmp	w9, #0x1
1000628e8:     	b.ne	0x100062968 <<la_stack::rational::RationalMatrix<8>>::solve+0x728>
1000628ec:     	ldrb	w9, [x28, #0xd98]
1000628f0:     	cmp	w9, #0x1
1000628f4:     	b.ne	0x100062978 <<la_stack::rational::RationalMatrix<8>>::solve+0x738>
1000628f8:     	ldrb	w9, [x28, #0xdd8]
1000628fc:     	cmp	w9, #0x1
100062900:     	b.eq	0x100062a8c <<la_stack::rational::RationalMatrix<8>>::solve+0x84c>
100062904:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062908:     	add	x9, x9, #0x510
10006290c:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100062910:     	add	x10, x10, #0x780
100062914:     	b	0x100062988 <<la_stack::rational::RationalMatrix<8>>::solve+0x748>
100062918:     	add	x9, sp, #0xcf0
10006291c:     	add	x10, sp, #0xd10
100062920:     	b	0x100062988 <<la_stack::rational::RationalMatrix<8>>::solve+0x748>
100062924:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062928:     	add	x9, x9, #0x570
10006292c:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100062930:     	add	x10, x10, #0x580
100062934:     	b	0x100062988 <<la_stack::rational::RationalMatrix<8>>::solve+0x748>
100062938:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
10006293c:     	add	x9, x9, #0x560
100062940:     	add	x10, sp, #0xa00
100062944:     	b	0x100062988 <<la_stack::rational::RationalMatrix<8>>::solve+0x748>
100062948:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
10006294c:     	add	x9, x9, #0x550
100062950:     	add	x10, sp, #0x100
100062954:     	b	0x100062988 <<la_stack::rational::RationalMatrix<8>>::solve+0x748>
100062958:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
10006295c:     	add	x9, x9, #0x540
100062960:     	sub	x10, x29, #0xa0
100062964:     	b	0x100062988 <<la_stack::rational::RationalMatrix<8>>::solve+0x748>
100062968:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
10006296c:     	add	x9, x9, #0x530
100062970:     	sub	x10, x29, #0x100
100062974:     	b	0x100062988 <<la_stack::rational::RationalMatrix<8>>::solve+0x748>
100062978:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
10006297c:     	add	x9, x9, #0x520
100062980:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100062984:     	add	x10, x10, #0x7c0
100062988:     	ldrb	w11, [x9]
10006298c:     	tbnz	w11, #0x0, 0x100062a8c <<la_stack::rational::RationalMatrix<8>>::solve+0x84c>
100062990:     	mov	w11, #0x1               ; =1
100062994:     	strb	w11, [x9]
100062998:     	mov	w9, #0x6                ; =6
10006299c:     	str	x9, [x10]
1000629a0:     	ldrb	w9, [x28, #0xe18]
1000629a4:     	cmp	w9, #0x1
1000629a8:     	b.ne	0x100062a14 <<la_stack::rational::RationalMatrix<8>>::solve+0x7d4>
1000629ac:     	ldrb	w9, [x28, #0xe58]
1000629b0:     	cmp	w9, #0x1
1000629b4:     	b.ne	0x100062a20 <<la_stack::rational::RationalMatrix<8>>::solve+0x7e0>
1000629b8:     	ldrb	w9, [x28, #0xe98]
1000629bc:     	cmp	w9, #0x1
1000629c0:     	b.ne	0x100062a34 <<la_stack::rational::RationalMatrix<8>>::solve+0x7f4>
1000629c4:     	ldrb	w9, [x28, #0xed8]
1000629c8:     	cmp	w9, #0x1
1000629cc:     	b.ne	0x100062a44 <<la_stack::rational::RationalMatrix<8>>::solve+0x804>
1000629d0:     	ldrb	w9, [x28, #0xf18]
1000629d4:     	cmp	w9, #0x1
1000629d8:     	b.ne	0x100062a54 <<la_stack::rational::RationalMatrix<8>>::solve+0x814>
1000629dc:     	ldrb	w9, [x28, #0xf58]
1000629e0:     	cmp	w9, #0x1
1000629e4:     	b.ne	0x100062a64 <<la_stack::rational::RationalMatrix<8>>::solve+0x824>
1000629e8:     	ldrb	w9, [x28, #0xf98]
1000629ec:     	cmp	w9, #0x1
1000629f0:     	b.ne	0x100062a74 <<la_stack::rational::RationalMatrix<8>>::solve+0x834>
1000629f4:     	ldrb	w9, [x28, #0xfd8]
1000629f8:     	cmp	w9, #0x1
1000629fc:     	b.eq	0x100062a8c <<la_stack::rational::RationalMatrix<8>>::solve+0x84c>
100062a00:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062a04:     	add	x9, x9, #0x510
100062a08:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100062a0c:     	add	x10, x10, #0x780
100062a10:     	b	0x100062a84 <<la_stack::rational::RationalMatrix<8>>::solve+0x844>
100062a14:     	add	x9, sp, #0xcf0
100062a18:     	add	x10, sp, #0xd10
100062a1c:     	b	0x100062a84 <<la_stack::rational::RationalMatrix<8>>::solve+0x844>
100062a20:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062a24:     	add	x9, x9, #0x570
100062a28:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100062a2c:     	add	x10, x10, #0x580
100062a30:     	b	0x100062a84 <<la_stack::rational::RationalMatrix<8>>::solve+0x844>
100062a34:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062a38:     	add	x9, x9, #0x560
100062a3c:     	add	x10, sp, #0xa00
100062a40:     	b	0x100062a84 <<la_stack::rational::RationalMatrix<8>>::solve+0x844>
100062a44:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062a48:     	add	x9, x9, #0x550
100062a4c:     	add	x10, sp, #0x100
100062a50:     	b	0x100062a84 <<la_stack::rational::RationalMatrix<8>>::solve+0x844>
100062a54:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062a58:     	add	x9, x9, #0x540
100062a5c:     	sub	x10, x29, #0xa0
100062a60:     	b	0x100062a84 <<la_stack::rational::RationalMatrix<8>>::solve+0x844>
100062a64:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062a68:     	add	x9, x9, #0x530
100062a6c:     	sub	x10, x29, #0x100
100062a70:     	b	0x100062a84 <<la_stack::rational::RationalMatrix<8>>::solve+0x844>
100062a74:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062a78:     	add	x9, x9, #0x520
100062a7c:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100062a80:     	add	x10, x10, #0x7c0
100062a84:     	ldrb	w11, [x9]
100062a88:     	tbz	w11, #0x0, 0x100062dc0 <<la_stack::rational::RationalMatrix<8>>::solve+0xb80>
100062a8c:     	str	xzr, [sp, #0xd10]
100062a90:     	str	xzr, [sp, #0x1580]
100062a94:     	str	xzr, [sp, #0xa00]
100062a98:     	str	xzr, [sp, #0x100]
100062a9c:     	stur	xzr, [x29, #-0xa0]
100062aa0:     	stur	xzr, [x29, #-0x100]
100062aa4:     	str	xzr, [sp, #0x17c0]
100062aa8:     	str	xzr, [sp, #0x1780]
100062aac:     	strb	wzr, [sp, #0xcf0]
100062ab0:     	add	x9, sp, #0xb00
100062ab4:     	strb	wzr, [x9, #0xa70]
100062ab8:     	strb	wzr, [x9, #0xa60]
100062abc:     	strb	wzr, [x9, #0xa50]
100062ac0:     	strb	wzr, [x9, #0xa40]
100062ac4:     	strb	wzr, [x9, #0xa30]
100062ac8:     	strb	wzr, [x9, #0xa20]
100062acc:     	strb	wzr, [x9, #0xa10]
100062ad0:     	ldrb	w9, [x28, #0x1d8]
100062ad4:     	cmp	w9, #0x1
100062ad8:     	b.ne	0x100062b54 <<la_stack::rational::RationalMatrix<8>>::solve+0x914>
100062adc:     	ldrb	w9, [x28, #0x198]
100062ae0:     	cmp	w9, #0x1
100062ae4:     	b.ne	0x100062b70 <<la_stack::rational::RationalMatrix<8>>::solve+0x930>
100062ae8:     	ldrb	w9, [x28, #0x158]
100062aec:     	cmp	w9, #0x1
100062af0:     	b.ne	0x100062b8c <<la_stack::rational::RationalMatrix<8>>::solve+0x94c>
100062af4:     	ldrb	w9, [x28, #0x118]
100062af8:     	cmp	w9, #0x1
100062afc:     	b.ne	0x100062ba4 <<la_stack::rational::RationalMatrix<8>>::solve+0x964>
100062b00:     	ldrb	w9, [x28, #0xd8]
100062b04:     	cmp	w9, #0x1
100062b08:     	b.ne	0x100062bbc <<la_stack::rational::RationalMatrix<8>>::solve+0x97c>
100062b0c:     	ldrb	w9, [x28, #0x98]
100062b10:     	cmp	w9, #0x1
100062b14:     	b.ne	0x100062c90 <<la_stack::rational::RationalMatrix<8>>::solve+0xa50>
100062b18:     	ldrb	w11, [x28, #0x58]
100062b1c:     	cmp	w11, #0x1
100062b20:     	add	x9, sp, #0xd10
100062b24:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100062b28:     	add	x10, x10, #0x580
100062b2c:     	csel	x10, x10, x9, ne
100062b30:     	add	x9, sp, #0xcf0
100062b34:     	add	x12, sp, #0x1, lsl #12  ; =0x1000
100062b38:     	add	x12, x12, #0x570
100062b3c:     	csel	x9, x12, x9, ne
100062b40:     	cmp	w8, #0x1
100062b44:     	b.ne	0x100062bc8 <<la_stack::rational::RationalMatrix<8>>::solve+0x988>
100062b48:     	cmp	w11, #0x1
100062b4c:     	b.eq	0x100063bbc <<la_stack::rational::RationalMatrix<8>>::solve+0x197c>
100062b50:     	b	0x100062bc8 <<la_stack::rational::RationalMatrix<8>>::solve+0x988>
100062b54:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062b58:     	add	x9, x9, #0x510
100062b5c:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100062b60:     	add	x10, x10, #0x780
100062b64:     	ldrb	w8, [x9]
100062b68:     	tbz	w8, #0x0, 0x100062bd0 <<la_stack::rational::RationalMatrix<8>>::solve+0x990>
100062b6c:     	b	0x100063bbc <<la_stack::rational::RationalMatrix<8>>::solve+0x197c>
100062b70:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062b74:     	add	x9, x9, #0x520
100062b78:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100062b7c:     	add	x10, x10, #0x7c0
100062b80:     	ldrb	w8, [x9]
100062b84:     	tbz	w8, #0x0, 0x100062bd0 <<la_stack::rational::RationalMatrix<8>>::solve+0x990>
100062b88:     	b	0x100063bbc <<la_stack::rational::RationalMatrix<8>>::solve+0x197c>
100062b8c:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062b90:     	add	x9, x9, #0x530
100062b94:     	sub	x10, x29, #0x100
100062b98:     	ldrb	w8, [x9]
100062b9c:     	tbz	w8, #0x0, 0x100062bd0 <<la_stack::rational::RationalMatrix<8>>::solve+0x990>
100062ba0:     	b	0x100063bbc <<la_stack::rational::RationalMatrix<8>>::solve+0x197c>
100062ba4:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062ba8:     	add	x9, x9, #0x540
100062bac:     	sub	x10, x29, #0xa0
100062bb0:     	ldrb	w8, [x9]
100062bb4:     	tbz	w8, #0x0, 0x100062bd0 <<la_stack::rational::RationalMatrix<8>>::solve+0x990>
100062bb8:     	b	0x100063bbc <<la_stack::rational::RationalMatrix<8>>::solve+0x197c>
100062bbc:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062bc0:     	add	x9, x9, #0x550
100062bc4:     	add	x10, sp, #0x100
100062bc8:     	ldrb	w8, [x9]
100062bcc:     	tbnz	w8, #0x0, 0x100063bbc <<la_stack::rational::RationalMatrix<8>>::solve+0x197c>
100062bd0:     	mov	w8, #0x1                ; =1
100062bd4:     	strb	w8, [x9]
100062bd8:     	str	xzr, [x10]
100062bdc:     	ldrb	w8, [x28, #0x3d8]
100062be0:     	cmp	w8, #0x1
100062be4:     	b.ne	0x100062c48 <<la_stack::rational::RationalMatrix<8>>::solve+0xa08>
100062be8:     	ldrb	w8, [x28, #0x398]
100062bec:     	cmp	w8, #0x1
100062bf0:     	b.ne	0x100062c5c <<la_stack::rational::RationalMatrix<8>>::solve+0xa1c>
100062bf4:     	ldrb	w8, [x28, #0x358]
100062bf8:     	cmp	w8, #0x1
100062bfc:     	b.ne	0x100062c70 <<la_stack::rational::RationalMatrix<8>>::solve+0xa30>
100062c00:     	ldrb	w8, [x28, #0x318]
100062c04:     	cmp	w8, #0x1
100062c08:     	b.ne	0x100062c80 <<la_stack::rational::RationalMatrix<8>>::solve+0xa40>
100062c0c:     	ldrb	w8, [x28, #0x2d8]
100062c10:     	cmp	w8, #0x1
100062c14:     	b.ne	0x100062ca8 <<la_stack::rational::RationalMatrix<8>>::solve+0xa68>
100062c18:     	ldrb	w8, [x28, #0x298]
100062c1c:     	cmp	w8, #0x1
100062c20:     	b.ne	0x100062cb8 <<la_stack::rational::RationalMatrix<8>>::solve+0xa78>
100062c24:     	ldrb	w8, [x28, #0x258]
100062c28:     	cmp	w8, #0x1
100062c2c:     	b.ne	0x100062cc8 <<la_stack::rational::RationalMatrix<8>>::solve+0xa88>
100062c30:     	ldrb	w8, [x28, #0x218]
100062c34:     	cmp	w8, #0x1
100062c38:     	b.eq	0x100063bbc <<la_stack::rational::RationalMatrix<8>>::solve+0x197c>
100062c3c:     	add	x8, sp, #0xcf0
100062c40:     	add	x9, sp, #0xd10
100062c44:     	b	0x100062cd8 <<la_stack::rational::RationalMatrix<8>>::solve+0xa98>
100062c48:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100062c4c:     	add	x8, x8, #0x510
100062c50:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062c54:     	add	x9, x9, #0x780
100062c58:     	b	0x100062cd8 <<la_stack::rational::RationalMatrix<8>>::solve+0xa98>
100062c5c:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100062c60:     	add	x8, x8, #0x520
100062c64:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062c68:     	add	x9, x9, #0x7c0
100062c6c:     	b	0x100062cd8 <<la_stack::rational::RationalMatrix<8>>::solve+0xa98>
100062c70:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100062c74:     	add	x8, x8, #0x530
100062c78:     	sub	x9, x29, #0x100
100062c7c:     	b	0x100062cd8 <<la_stack::rational::RationalMatrix<8>>::solve+0xa98>
100062c80:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100062c84:     	add	x8, x8, #0x540
100062c88:     	sub	x9, x29, #0xa0
100062c8c:     	b	0x100062cd8 <<la_stack::rational::RationalMatrix<8>>::solve+0xa98>
100062c90:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062c94:     	add	x9, x9, #0x560
100062c98:     	add	x10, sp, #0xa00
100062c9c:     	ldrb	w8, [x9]
100062ca0:     	tbz	w8, #0x0, 0x100062bd0 <<la_stack::rational::RationalMatrix<8>>::solve+0x990>
100062ca4:     	b	0x100063bbc <<la_stack::rational::RationalMatrix<8>>::solve+0x197c>
100062ca8:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100062cac:     	add	x8, x8, #0x550
100062cb0:     	add	x9, sp, #0x100
100062cb4:     	b	0x100062cd8 <<la_stack::rational::RationalMatrix<8>>::solve+0xa98>
100062cb8:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100062cbc:     	add	x8, x8, #0x560
100062cc0:     	add	x9, sp, #0xa00
100062cc4:     	b	0x100062cd8 <<la_stack::rational::RationalMatrix<8>>::solve+0xa98>
100062cc8:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100062ccc:     	add	x8, x8, #0x570
100062cd0:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062cd4:     	add	x9, x9, #0x580
100062cd8:     	ldrb	w10, [x8]
100062cdc:     	tbnz	w10, #0x0, 0x100063bbc <<la_stack::rational::RationalMatrix<8>>::solve+0x197c>
100062ce0:     	mov	w10, #0x1               ; =1
100062ce4:     	strb	w10, [x8]
100062ce8:     	str	x10, [x9]
100062cec:     	ldrb	w8, [x28, #0x5d8]
100062cf0:     	cmp	w8, #0x1
100062cf4:     	b.ne	0x100062d58 <<la_stack::rational::RationalMatrix<8>>::solve+0xb18>
100062cf8:     	ldrb	w8, [x28, #0x598]
100062cfc:     	cmp	w8, #0x1
100062d00:     	b.ne	0x100062d6c <<la_stack::rational::RationalMatrix<8>>::solve+0xb2c>
100062d04:     	ldrb	w8, [x28, #0x558]
100062d08:     	cmp	w8, #0x1
100062d0c:     	b.ne	0x100062d80 <<la_stack::rational::RationalMatrix<8>>::solve+0xb40>
100062d10:     	ldrb	w8, [x28, #0x518]
100062d14:     	cmp	w8, #0x1
100062d18:     	b.ne	0x100062d90 <<la_stack::rational::RationalMatrix<8>>::solve+0xb50>
100062d1c:     	ldrb	w8, [x28, #0x4d8]
100062d20:     	cmp	w8, #0x1
100062d24:     	b.ne	0x100062da0 <<la_stack::rational::RationalMatrix<8>>::solve+0xb60>
100062d28:     	ldrb	w8, [x28, #0x498]
100062d2c:     	cmp	w8, #0x1
100062d30:     	b.ne	0x100062db0 <<la_stack::rational::RationalMatrix<8>>::solve+0xb70>
100062d34:     	ldrb	w8, [x28, #0x458]
100062d38:     	cmp	w8, #0x1
100062d3c:     	b.ne	0x100062ddc <<la_stack::rational::RationalMatrix<8>>::solve+0xb9c>
100062d40:     	ldrb	w8, [x28, #0x418]
100062d44:     	cmp	w8, #0x1
100062d48:     	b.eq	0x100063bbc <<la_stack::rational::RationalMatrix<8>>::solve+0x197c>
100062d4c:     	add	x8, sp, #0xcf0
100062d50:     	add	x9, sp, #0xd10
100062d54:     	b	0x100062dec <<la_stack::rational::RationalMatrix<8>>::solve+0xbac>
100062d58:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100062d5c:     	add	x8, x8, #0x510
100062d60:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062d64:     	add	x9, x9, #0x780
100062d68:     	b	0x100062dec <<la_stack::rational::RationalMatrix<8>>::solve+0xbac>
100062d6c:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100062d70:     	add	x8, x8, #0x520
100062d74:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062d78:     	add	x9, x9, #0x7c0
100062d7c:     	b	0x100062dec <<la_stack::rational::RationalMatrix<8>>::solve+0xbac>
100062d80:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100062d84:     	add	x8, x8, #0x530
100062d88:     	sub	x9, x29, #0x100
100062d8c:     	b	0x100062dec <<la_stack::rational::RationalMatrix<8>>::solve+0xbac>
100062d90:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100062d94:     	add	x8, x8, #0x540
100062d98:     	sub	x9, x29, #0xa0
100062d9c:     	b	0x100062dec <<la_stack::rational::RationalMatrix<8>>::solve+0xbac>
100062da0:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100062da4:     	add	x8, x8, #0x550
100062da8:     	add	x9, sp, #0x100
100062dac:     	b	0x100062dec <<la_stack::rational::RationalMatrix<8>>::solve+0xbac>
100062db0:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100062db4:     	add	x8, x8, #0x560
100062db8:     	add	x9, sp, #0xa00
100062dbc:     	b	0x100062dec <<la_stack::rational::RationalMatrix<8>>::solve+0xbac>
100062dc0:     	mov	w11, #0x1               ; =1
100062dc4:     	mov	w8, #0x1                ; =1
100062dc8:     	str	w8, [sp, #0xd0]
100062dcc:     	strb	w11, [x9]
100062dd0:     	mov	w8, #0x7                ; =7
100062dd4:     	str	x8, [x10]
100062dd8:     	b	0x1000632f4 <<la_stack::rational::RationalMatrix<8>>::solve+0x10b4>
100062ddc:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100062de0:     	add	x8, x8, #0x570
100062de4:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062de8:     	add	x9, x9, #0x580
100062dec:     	ldrb	w10, [x8]
100062df0:     	tbnz	w10, #0x0, 0x100063bbc <<la_stack::rational::RationalMatrix<8>>::solve+0x197c>
100062df4:     	mov	w10, #0x1               ; =1
100062df8:     	strb	w10, [x8]
100062dfc:     	mov	w8, #0x2                ; =2
100062e00:     	str	x8, [x9]
100062e04:     	ldrb	w8, [x28, #0x7d8]
100062e08:     	cmp	w8, #0x1
100062e0c:     	b.ne	0x100062e70 <<la_stack::rational::RationalMatrix<8>>::solve+0xc30>
100062e10:     	ldrb	w8, [x28, #0x798]
100062e14:     	cmp	w8, #0x1
100062e18:     	b.ne	0x100062e84 <<la_stack::rational::RationalMatrix<8>>::solve+0xc44>
100062e1c:     	ldrb	w8, [x28, #0x758]
100062e20:     	cmp	w8, #0x1
100062e24:     	b.ne	0x100062e98 <<la_stack::rational::RationalMatrix<8>>::solve+0xc58>
100062e28:     	ldrb	w8, [x28, #0x718]
100062e2c:     	cmp	w8, #0x1
100062e30:     	b.ne	0x100062ea8 <<la_stack::rational::RationalMatrix<8>>::solve+0xc68>
100062e34:     	ldrb	w8, [x28, #0x6d8]
100062e38:     	cmp	w8, #0x1
100062e3c:     	b.ne	0x100062eb8 <<la_stack::rational::RationalMatrix<8>>::solve+0xc78>
100062e40:     	ldrb	w8, [x28, #0x698]
100062e44:     	cmp	w8, #0x1
100062e48:     	b.ne	0x100062ec8 <<la_stack::rational::RationalMatrix<8>>::solve+0xc88>
100062e4c:     	ldrb	w8, [x28, #0x658]
100062e50:     	cmp	w8, #0x1
100062e54:     	b.ne	0x100062ed8 <<la_stack::rational::RationalMatrix<8>>::solve+0xc98>
100062e58:     	ldrb	w8, [x28, #0x618]
100062e5c:     	cmp	w8, #0x1
100062e60:     	b.eq	0x100063bbc <<la_stack::rational::RationalMatrix<8>>::solve+0x197c>
100062e64:     	add	x8, sp, #0xcf0
100062e68:     	add	x9, sp, #0xd10
100062e6c:     	b	0x100062ee8 <<la_stack::rational::RationalMatrix<8>>::solve+0xca8>
100062e70:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100062e74:     	add	x8, x8, #0x510
100062e78:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062e7c:     	add	x9, x9, #0x780
100062e80:     	b	0x100062ee8 <<la_stack::rational::RationalMatrix<8>>::solve+0xca8>
100062e84:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100062e88:     	add	x8, x8, #0x520
100062e8c:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062e90:     	add	x9, x9, #0x7c0
100062e94:     	b	0x100062ee8 <<la_stack::rational::RationalMatrix<8>>::solve+0xca8>
100062e98:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100062e9c:     	add	x8, x8, #0x530
100062ea0:     	sub	x9, x29, #0x100
100062ea4:     	b	0x100062ee8 <<la_stack::rational::RationalMatrix<8>>::solve+0xca8>
100062ea8:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100062eac:     	add	x8, x8, #0x540
100062eb0:     	sub	x9, x29, #0xa0
100062eb4:     	b	0x100062ee8 <<la_stack::rational::RationalMatrix<8>>::solve+0xca8>
100062eb8:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100062ebc:     	add	x8, x8, #0x550
100062ec0:     	add	x9, sp, #0x100
100062ec4:     	b	0x100062ee8 <<la_stack::rational::RationalMatrix<8>>::solve+0xca8>
100062ec8:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100062ecc:     	add	x8, x8, #0x560
100062ed0:     	add	x9, sp, #0xa00
100062ed4:     	b	0x100062ee8 <<la_stack::rational::RationalMatrix<8>>::solve+0xca8>
100062ed8:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100062edc:     	add	x8, x8, #0x570
100062ee0:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062ee4:     	add	x9, x9, #0x580
100062ee8:     	ldrb	w10, [x8]
100062eec:     	tbnz	w10, #0x0, 0x100063bbc <<la_stack::rational::RationalMatrix<8>>::solve+0x197c>
100062ef0:     	mov	w10, #0x1               ; =1
100062ef4:     	strb	w10, [x8]
100062ef8:     	mov	w8, #0x3                ; =3
100062efc:     	str	x8, [x9]
100062f00:     	ldrb	w8, [x28, #0x9d8]
100062f04:     	cmp	w8, #0x1
100062f08:     	b.ne	0x100062f6c <<la_stack::rational::RationalMatrix<8>>::solve+0xd2c>
100062f0c:     	ldrb	w8, [x28, #0x998]
100062f10:     	cmp	w8, #0x1
100062f14:     	b.ne	0x100062f80 <<la_stack::rational::RationalMatrix<8>>::solve+0xd40>
100062f18:     	ldrb	w8, [x28, #0x958]
100062f1c:     	cmp	w8, #0x1
100062f20:     	b.ne	0x100062f94 <<la_stack::rational::RationalMatrix<8>>::solve+0xd54>
100062f24:     	ldrb	w8, [x28, #0x918]
100062f28:     	cmp	w8, #0x1
100062f2c:     	b.ne	0x100062fa4 <<la_stack::rational::RationalMatrix<8>>::solve+0xd64>
100062f30:     	ldrb	w8, [x28, #0x8d8]
100062f34:     	cmp	w8, #0x1
100062f38:     	b.ne	0x100062fb4 <<la_stack::rational::RationalMatrix<8>>::solve+0xd74>
100062f3c:     	ldrb	w8, [x28, #0x898]
100062f40:     	cmp	w8, #0x1
100062f44:     	b.ne	0x100062fc4 <<la_stack::rational::RationalMatrix<8>>::solve+0xd84>
100062f48:     	ldrb	w8, [x28, #0x858]
100062f4c:     	cmp	w8, #0x1
100062f50:     	b.ne	0x100062fd4 <<la_stack::rational::RationalMatrix<8>>::solve+0xd94>
100062f54:     	ldrb	w8, [x28, #0x818]
100062f58:     	cmp	w8, #0x1
100062f5c:     	b.eq	0x100063bbc <<la_stack::rational::RationalMatrix<8>>::solve+0x197c>
100062f60:     	add	x8, sp, #0xcf0
100062f64:     	add	x9, sp, #0xd10
100062f68:     	b	0x100062fe4 <<la_stack::rational::RationalMatrix<8>>::solve+0xda4>
100062f6c:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100062f70:     	add	x8, x8, #0x510
100062f74:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062f78:     	add	x9, x9, #0x780
100062f7c:     	b	0x100062fe4 <<la_stack::rational::RationalMatrix<8>>::solve+0xda4>
100062f80:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100062f84:     	add	x8, x8, #0x520
100062f88:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062f8c:     	add	x9, x9, #0x7c0
100062f90:     	b	0x100062fe4 <<la_stack::rational::RationalMatrix<8>>::solve+0xda4>
100062f94:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100062f98:     	add	x8, x8, #0x530
100062f9c:     	sub	x9, x29, #0x100
100062fa0:     	b	0x100062fe4 <<la_stack::rational::RationalMatrix<8>>::solve+0xda4>
100062fa4:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100062fa8:     	add	x8, x8, #0x540
100062fac:     	sub	x9, x29, #0xa0
100062fb0:     	b	0x100062fe4 <<la_stack::rational::RationalMatrix<8>>::solve+0xda4>
100062fb4:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100062fb8:     	add	x8, x8, #0x550
100062fbc:     	add	x9, sp, #0x100
100062fc0:     	b	0x100062fe4 <<la_stack::rational::RationalMatrix<8>>::solve+0xda4>
100062fc4:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100062fc8:     	add	x8, x8, #0x560
100062fcc:     	add	x9, sp, #0xa00
100062fd0:     	b	0x100062fe4 <<la_stack::rational::RationalMatrix<8>>::solve+0xda4>
100062fd4:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100062fd8:     	add	x8, x8, #0x570
100062fdc:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100062fe0:     	add	x9, x9, #0x580
100062fe4:     	ldrb	w10, [x8]
100062fe8:     	tbnz	w10, #0x0, 0x100063bbc <<la_stack::rational::RationalMatrix<8>>::solve+0x197c>
100062fec:     	mov	w10, #0x1               ; =1
100062ff0:     	strb	w10, [x8]
100062ff4:     	mov	w8, #0x4                ; =4
100062ff8:     	str	x8, [x9]
100062ffc:     	ldrb	w8, [x28, #0xbd8]
100063000:     	cmp	w8, #0x1
100063004:     	b.ne	0x100063068 <<la_stack::rational::RationalMatrix<8>>::solve+0xe28>
100063008:     	ldrb	w8, [x28, #0xb98]
10006300c:     	cmp	w8, #0x1
100063010:     	b.ne	0x10006307c <<la_stack::rational::RationalMatrix<8>>::solve+0xe3c>
100063014:     	ldrb	w8, [x28, #0xb58]
100063018:     	cmp	w8, #0x1
10006301c:     	b.ne	0x100063090 <<la_stack::rational::RationalMatrix<8>>::solve+0xe50>
100063020:     	ldrb	w8, [x28, #0xb18]
100063024:     	cmp	w8, #0x1
100063028:     	b.ne	0x1000630a0 <<la_stack::rational::RationalMatrix<8>>::solve+0xe60>
10006302c:     	ldrb	w8, [x28, #0xad8]
100063030:     	cmp	w8, #0x1
100063034:     	b.ne	0x1000630b0 <<la_stack::rational::RationalMatrix<8>>::solve+0xe70>
100063038:     	ldrb	w8, [x28, #0xa98]
10006303c:     	cmp	w8, #0x1
100063040:     	b.ne	0x1000630c0 <<la_stack::rational::RationalMatrix<8>>::solve+0xe80>
100063044:     	ldrb	w8, [x28, #0xa58]
100063048:     	cmp	w8, #0x1
10006304c:     	b.ne	0x1000630d0 <<la_stack::rational::RationalMatrix<8>>::solve+0xe90>
100063050:     	ldrb	w8, [x28, #0xa18]
100063054:     	cmp	w8, #0x1
100063058:     	b.eq	0x100063bbc <<la_stack::rational::RationalMatrix<8>>::solve+0x197c>
10006305c:     	add	x8, sp, #0xcf0
100063060:     	add	x9, sp, #0xd10
100063064:     	b	0x1000630e0 <<la_stack::rational::RationalMatrix<8>>::solve+0xea0>
100063068:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
10006306c:     	add	x8, x8, #0x510
100063070:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100063074:     	add	x9, x9, #0x780
100063078:     	b	0x1000630e0 <<la_stack::rational::RationalMatrix<8>>::solve+0xea0>
10006307c:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100063080:     	add	x8, x8, #0x520
100063084:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100063088:     	add	x9, x9, #0x7c0
10006308c:     	b	0x1000630e0 <<la_stack::rational::RationalMatrix<8>>::solve+0xea0>
100063090:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100063094:     	add	x8, x8, #0x530
100063098:     	sub	x9, x29, #0x100
10006309c:     	b	0x1000630e0 <<la_stack::rational::RationalMatrix<8>>::solve+0xea0>
1000630a0:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000630a4:     	add	x8, x8, #0x540
1000630a8:     	sub	x9, x29, #0xa0
1000630ac:     	b	0x1000630e0 <<la_stack::rational::RationalMatrix<8>>::solve+0xea0>
1000630b0:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000630b4:     	add	x8, x8, #0x550
1000630b8:     	add	x9, sp, #0x100
1000630bc:     	b	0x1000630e0 <<la_stack::rational::RationalMatrix<8>>::solve+0xea0>
1000630c0:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000630c4:     	add	x8, x8, #0x560
1000630c8:     	add	x9, sp, #0xa00
1000630cc:     	b	0x1000630e0 <<la_stack::rational::RationalMatrix<8>>::solve+0xea0>
1000630d0:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000630d4:     	add	x8, x8, #0x570
1000630d8:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
1000630dc:     	add	x9, x9, #0x580
1000630e0:     	ldrb	w10, [x8]
1000630e4:     	tbnz	w10, #0x0, 0x100063bbc <<la_stack::rational::RationalMatrix<8>>::solve+0x197c>
1000630e8:     	mov	w10, #0x1               ; =1
1000630ec:     	strb	w10, [x8]
1000630f0:     	mov	w8, #0x5                ; =5
1000630f4:     	str	x8, [x9]
1000630f8:     	ldrb	w8, [x28, #0xdd8]
1000630fc:     	cmp	w8, #0x1
100063100:     	b.ne	0x100063164 <<la_stack::rational::RationalMatrix<8>>::solve+0xf24>
100063104:     	ldrb	w8, [x28, #0xd98]
100063108:     	cmp	w8, #0x1
10006310c:     	b.ne	0x100063178 <<la_stack::rational::RationalMatrix<8>>::solve+0xf38>
100063110:     	ldrb	w8, [x28, #0xd58]
100063114:     	cmp	w8, #0x1
100063118:     	b.ne	0x10006318c <<la_stack::rational::RationalMatrix<8>>::solve+0xf4c>
10006311c:     	ldrb	w8, [x28, #0xd18]
100063120:     	cmp	w8, #0x1
100063124:     	b.ne	0x10006319c <<la_stack::rational::RationalMatrix<8>>::solve+0xf5c>
100063128:     	ldrb	w8, [x28, #0xcd8]
10006312c:     	cmp	w8, #0x1
100063130:     	b.ne	0x1000631ac <<la_stack::rational::RationalMatrix<8>>::solve+0xf6c>
100063134:     	ldrb	w8, [x28, #0xc98]
100063138:     	cmp	w8, #0x1
10006313c:     	b.ne	0x1000631bc <<la_stack::rational::RationalMatrix<8>>::solve+0xf7c>
100063140:     	ldrb	w8, [x28, #0xc58]
100063144:     	cmp	w8, #0x1
100063148:     	b.ne	0x1000631cc <<la_stack::rational::RationalMatrix<8>>::solve+0xf8c>
10006314c:     	ldrb	w8, [x28, #0xc18]
100063150:     	cmp	w8, #0x1
100063154:     	b.eq	0x100063bbc <<la_stack::rational::RationalMatrix<8>>::solve+0x197c>
100063158:     	add	x8, sp, #0xcf0
10006315c:     	add	x9, sp, #0xd10
100063160:     	b	0x1000631dc <<la_stack::rational::RationalMatrix<8>>::solve+0xf9c>
100063164:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100063168:     	add	x8, x8, #0x510
10006316c:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100063170:     	add	x9, x9, #0x780
100063174:     	b	0x1000631dc <<la_stack::rational::RationalMatrix<8>>::solve+0xf9c>
100063178:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
10006317c:     	add	x8, x8, #0x520
100063180:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100063184:     	add	x9, x9, #0x7c0
100063188:     	b	0x1000631dc <<la_stack::rational::RationalMatrix<8>>::solve+0xf9c>
10006318c:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100063190:     	add	x8, x8, #0x530
100063194:     	sub	x9, x29, #0x100
100063198:     	b	0x1000631dc <<la_stack::rational::RationalMatrix<8>>::solve+0xf9c>
10006319c:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000631a0:     	add	x8, x8, #0x540
1000631a4:     	sub	x9, x29, #0xa0
1000631a8:     	b	0x1000631dc <<la_stack::rational::RationalMatrix<8>>::solve+0xf9c>
1000631ac:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000631b0:     	add	x8, x8, #0x550
1000631b4:     	add	x9, sp, #0x100
1000631b8:     	b	0x1000631dc <<la_stack::rational::RationalMatrix<8>>::solve+0xf9c>
1000631bc:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000631c0:     	add	x8, x8, #0x560
1000631c4:     	add	x9, sp, #0xa00
1000631c8:     	b	0x1000631dc <<la_stack::rational::RationalMatrix<8>>::solve+0xf9c>
1000631cc:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000631d0:     	add	x8, x8, #0x570
1000631d4:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
1000631d8:     	add	x9, x9, #0x580
1000631dc:     	ldrb	w10, [x8]
1000631e0:     	tbnz	w10, #0x0, 0x100063bbc <<la_stack::rational::RationalMatrix<8>>::solve+0x197c>
1000631e4:     	mov	w10, #0x1               ; =1
1000631e8:     	strb	w10, [x8]
1000631ec:     	mov	w8, #0x6                ; =6
1000631f0:     	str	x8, [x9]
1000631f4:     	ldrb	w8, [x28, #0xfd8]
1000631f8:     	cmp	w8, #0x1
1000631fc:     	b.ne	0x100063260 <<la_stack::rational::RationalMatrix<8>>::solve+0x1020>
100063200:     	ldrb	w8, [x28, #0xf98]
100063204:     	cmp	w8, #0x1
100063208:     	b.ne	0x100063274 <<la_stack::rational::RationalMatrix<8>>::solve+0x1034>
10006320c:     	ldrb	w8, [x28, #0xf58]
100063210:     	cmp	w8, #0x1
100063214:     	b.ne	0x100063288 <<la_stack::rational::RationalMatrix<8>>::solve+0x1048>
100063218:     	ldrb	w8, [x28, #0xf18]
10006321c:     	cmp	w8, #0x1
100063220:     	b.ne	0x100063298 <<la_stack::rational::RationalMatrix<8>>::solve+0x1058>
100063224:     	ldrb	w8, [x28, #0xed8]
100063228:     	cmp	w8, #0x1
10006322c:     	b.ne	0x1000632a8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1068>
100063230:     	ldrb	w8, [x28, #0xe98]
100063234:     	cmp	w8, #0x1
100063238:     	b.ne	0x1000632b8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1078>
10006323c:     	ldrb	w8, [x28, #0xe58]
100063240:     	cmp	w8, #0x1
100063244:     	b.ne	0x1000632c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1088>
100063248:     	ldrb	w8, [x28, #0xe18]
10006324c:     	cmp	w8, #0x1
100063250:     	b.eq	0x100063bbc <<la_stack::rational::RationalMatrix<8>>::solve+0x197c>
100063254:     	add	x8, sp, #0xcf0
100063258:     	add	x9, sp, #0xd10
10006325c:     	b	0x1000632d8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1098>
100063260:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100063264:     	add	x8, x8, #0x510
100063268:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
10006326c:     	add	x9, x9, #0x780
100063270:     	b	0x1000632d8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1098>
100063274:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100063278:     	add	x8, x8, #0x520
10006327c:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100063280:     	add	x9, x9, #0x7c0
100063284:     	b	0x1000632d8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1098>
100063288:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
10006328c:     	add	x8, x8, #0x530
100063290:     	sub	x9, x29, #0x100
100063294:     	b	0x1000632d8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1098>
100063298:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
10006329c:     	add	x8, x8, #0x540
1000632a0:     	sub	x9, x29, #0xa0
1000632a4:     	b	0x1000632d8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1098>
1000632a8:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000632ac:     	add	x8, x8, #0x550
1000632b0:     	add	x9, sp, #0x100
1000632b4:     	b	0x1000632d8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1098>
1000632b8:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000632bc:     	add	x8, x8, #0x560
1000632c0:     	add	x9, sp, #0xa00
1000632c4:     	b	0x1000632d8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1098>
1000632c8:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000632cc:     	add	x8, x8, #0x570
1000632d0:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
1000632d4:     	add	x9, x9, #0x580
1000632d8:     	ldrb	w10, [x8]
1000632dc:     	tbnz	w10, #0x0, 0x100063bbc <<la_stack::rational::RationalMatrix<8>>::solve+0x197c>
1000632e0:     	str	wzr, [sp, #0xd0]
1000632e4:     	mov	w10, #0x1               ; =1
1000632e8:     	strb	w10, [x8]
1000632ec:     	mov	w8, #0x7                ; =7
1000632f0:     	str	x8, [x9]
1000632f4:     	ldr	x8, [sp, #0xd10]
1000632f8:     	ldr	x9, [sp, #0x1580]
1000632fc:     	ldr	x10, [sp, #0xa00]
100063300:     	ldr	x11, [sp, #0x100]
100063304:     	ldur	x12, [x29, #-0xa0]
100063308:     	ldur	x13, [x29, #-0x100]
10006330c:     	ldr	x14, [sp, #0x17c0]
100063310:     	ldr	x15, [sp, #0x1780]
100063314:     	mov	x25, #0x0               ; =0
100063318:     	mov	x16, #0x0               ; =0
10006331c:     	str	x8, [sp, #0xb00]
100063320:     	str	x9, [sp, #0xb08]
100063324:     	str	x10, [sp, #0xb10]
100063328:     	str	x11, [sp, #0xb18]
10006332c:     	str	x12, [sp, #0xb20]
100063330:     	str	x13, [sp, #0xb28]
100063334:     	str	x14, [sp, #0xb30]
100063338:     	str	x15, [sp, #0xb38]
10006333c:     	mov	x8, #-0x1               ; =-1
100063340:     	str	x8, [sp, #0xd10]
100063344:     	str	xzr, [sp, #0xd18]
100063348:     	adrp	x9, 0x100227000 <criterion::plot::plotters_backend::summary::COMPARISON_COLORS+0x385>
10006334c:     	add	x9, x9, #0x650
100063350:     	ldr	q0, [x9]
100063354:     	adrp	x9, 0x10021b000 <dyld_stub_binder+0x10021b000>
100063358:     	add	x9, x9, #0x108
10006335c:     	ldp	q1, q2, [x9]
100063360:     	str	q0, [sp, #0xd20]
100063364:     	str	q1, [sp, #0xd30]
100063368:     	str	q2, [sp, #0xd40]
10006336c:     	str	x8, [sp, #0xd50]
100063370:     	str	xzr, [sp, #0xd58]
100063374:     	str	q0, [sp, #0xd60]
100063378:     	str	q1, [sp, #0xd70]
10006337c:     	str	q2, [sp, #0xd80]
100063380:     	str	x8, [sp, #0xd90]
100063384:     	str	xzr, [sp, #0xd98]
100063388:     	str	q2, [sp, #0xdc0]
10006338c:     	str	q0, [sp, #0xda0]
100063390:     	str	q1, [sp, #0xdb0]
100063394:     	str	x8, [sp, #0xdd0]
100063398:     	str	xzr, [sp, #0xdd8]
10006339c:     	str	q2, [sp, #0xe00]
1000633a0:     	str	q0, [sp, #0xde0]
1000633a4:     	str	q1, [sp, #0xdf0]
1000633a8:     	str	x8, [sp, #0xe10]
1000633ac:     	str	xzr, [sp, #0xe18]
1000633b0:     	str	q2, [sp, #0xe40]
1000633b4:     	str	q0, [sp, #0xe20]
1000633b8:     	str	q1, [sp, #0xe30]
1000633bc:     	str	x8, [sp, #0xe50]
1000633c0:     	str	xzr, [sp, #0xe58]
1000633c4:     	str	q2, [sp, #0xe80]
1000633c8:     	str	q0, [sp, #0xe60]
1000633cc:     	str	q1, [sp, #0xe70]
1000633d0:     	str	x8, [sp, #0xe90]
1000633d4:     	str	xzr, [sp, #0xe98]
1000633d8:     	str	q2, [sp, #0xec0]
1000633dc:     	str	q0, [sp, #0xea0]
1000633e0:     	str	q1, [sp, #0xeb0]
1000633e4:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
1000633e8:     	add	x9, x9, #0x7c0
1000633ec:     	add	x9, x9, #0x10
1000633f0:     	str	x8, [sp, #0xed0]
1000633f4:     	str	xzr, [sp, #0xed8]
1000633f8:     	sub	x8, x29, #0xa0
1000633fc:     	add	x8, x8, #0x10
100063400:     	stp	x8, x9, [sp, #0xb0]
100063404:     	str	q2, [sp, #0xf00]
100063408:     	str	q0, [sp, #0xee0]
10006340c:     	str	q1, [sp, #0xef0]
100063410:     	b	0x100063440 <<la_stack::rational::RationalMatrix<8>>::solve+0x1200>
100063414:     	ldr	x16, [sp, #0xc0]
100063418:     	add	x16, x16, #0x1
10006341c:     	ldr	q0, [sp, #0xa00]
100063420:     	ldr	q1, [sp, #0xa10]
100063424:     	stp	q0, q1, [x19]
100063428:     	ldr	q0, [sp, #0xa20]
10006342c:     	ldr	q1, [sp, #0xa30]
100063430:     	stp	q0, q1, [x19, #0x20]
100063434:     	add	x25, x25, #0x40
100063438:     	cmp	x16, #0x8
10006343c:     	b.eq	0x100063b9c <<la_stack::rational::RationalMatrix<8>>::solve+0x195c>
100063440:     	eor	x8, x16, #0x7
100063444:     	ldr	w9, [sp, #0xd0]
100063448:     	cmp	w9, #0x0
10006344c:     	csel	x9, x8, x16, ne
100063450:     	add	x8, sp, #0xb00
100063454:     	str	x9, [sp, #0xe0]
100063458:     	ldr	x19, [x8, x9, lsl #3]
10006345c:     	cmp	x19, #0x8
100063460:     	b.hs	0x1000650e8 <<la_stack::rational::RationalMatrix<8>>::solve+0x2ea8>
100063464:     	add	x27, x27, x19, lsl #6
100063468:     	ldrb	w21, [x27, #0x18]
10006346c:     	ldr	x8, [x27]
100063470:     	ldr	x28, [x27, #0x10]
100063474:     	cmn	x8, #0x1
100063478:     	b.eq	0x10006349c <<la_stack::rational::RationalMatrix<8>>::solve+0x125c>
10006347c:     	cbz	x28, 0x1000634a8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1268>
100063480:     	ldr	x22, [x27, #0x8]
100063484:     	cmp	x28, #0x1
100063488:     	b.ne	0x1000634b4 <<la_stack::rational::RationalMatrix<8>>::solve+0x1274>
10006348c:     	ldr	x28, [x22]
100063490:     	mov	x24, #-0x1              ; =-1
100063494:     	mov	w20, #0x1               ; =1
100063498:     	b	0x1000634e0 <<la_stack::rational::RationalMatrix<8>>::solve+0x12a0>
10006349c:     	ldr	x20, [x27, #0x8]
1000634a0:     	mov	x24, #-0x1              ; =-1
1000634a4:     	b	0x1000634e0 <<la_stack::rational::RationalMatrix<8>>::solve+0x12a0>
1000634a8:     	mov	x24, #-0x1              ; =-1
1000634ac:     	mov	x20, x28
1000634b0:     	b	0x1000634e0 <<la_stack::rational::RationalMatrix<8>>::solve+0x12a0>
1000634b4:     	mov	x26, x16
1000634b8:     	lsl	x23, x28, #3
1000634bc:     	mov	x0, x23
1000634c0:     	bl	0x100217924 <dyld_stub_binder+0x100217924>
1000634c4:     	cbz	x0, 0x100065100 <<la_stack::rational::RationalMatrix<8>>::solve+0x2ec0>
1000634c8:     	mov	x20, x0
1000634cc:     	mov	x1, x22
1000634d0:     	mov	x2, x23
1000634d4:     	bl	0x10021793c <dyld_stub_binder+0x10021793c>
1000634d8:     	mov	x24, x28
1000634dc:     	mov	x16, x26
1000634e0:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000634e4:     	add	x8, x8, #0x580
1000634e8:     	strb	w21, [x8, #0x218]
1000634ec:     	str	x24, [sp, #0x1780]
1000634f0:     	str	x20, [sp, #0x1788]
1000634f4:     	str	x28, [sp, #0x1790]
1000634f8:     	ldrb	w28, [x27, #0x38]
1000634fc:     	ldr	x8, [x27, #0x20]
100063500:     	ldr	x26, [x27, #0x30]
100063504:     	cmn	x8, #0x1
100063508:     	b.eq	0x10006352c <<la_stack::rational::RationalMatrix<8>>::solve+0x12ec>
10006350c:     	cbz	x26, 0x100063534 <<la_stack::rational::RationalMatrix<8>>::solve+0x12f4>
100063510:     	ldr	x22, [x27, #0x28]
100063514:     	cmp	x26, #0x1
100063518:     	b.ne	0x100063540 <<la_stack::rational::RationalMatrix<8>>::solve+0x1300>
10006351c:     	ldr	x26, [x22]
100063520:     	mov	x8, #-0x1               ; =-1
100063524:     	mov	w20, #0x1               ; =1
100063528:     	b	0x10006356c <<la_stack::rational::RationalMatrix<8>>::solve+0x132c>
10006352c:     	ldr	x20, [x27, #0x28]
100063530:     	b	0x10006356c <<la_stack::rational::RationalMatrix<8>>::solve+0x132c>
100063534:     	mov	x8, #-0x1               ; =-1
100063538:     	mov	x20, x26
10006353c:     	b	0x10006356c <<la_stack::rational::RationalMatrix<8>>::solve+0x132c>
100063540:     	mov	x27, x16
100063544:     	lsl	x23, x26, #3
100063548:     	mov	x0, x23
10006354c:     	bl	0x100217924 <dyld_stub_binder+0x100217924>
100063550:     	cbz	x0, 0x100065110 <<la_stack::rational::RationalMatrix<8>>::solve+0x2ed0>
100063554:     	mov	x20, x0
100063558:     	mov	x1, x22
10006355c:     	mov	x2, x23
100063560:     	bl	0x10021793c <dyld_stub_binder+0x10021793c>
100063564:     	mov	x8, x26
100063568:     	mov	x16, x27
10006356c:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100063570:     	add	x9, x9, #0x580
100063574:     	strb	w28, [x9, #0x258]
100063578:     	str	x8, [sp, #0x17c0]
10006357c:     	str	x20, [sp, #0x17c8]
100063580:     	str	x26, [sp, #0x17d0]
100063584:     	mov	w10, #0x8               ; =8
100063588:     	sub	x8, x10, x16
10006358c:     	ldr	w9, [sp, #0xd0]
100063590:     	cmp	w9, #0x0
100063594:     	csel	x1, x10, x16, ne
100063598:     	csel	x0, x8, xzr, ne
10006359c:     	cmp	x1, x0
1000635a0:     	b.lo	0x1000650c4 <<la_stack::rational::RationalMatrix<8>>::solve+0x2e84>
1000635a4:     	ldr	x28, [sp, #0xf0]
1000635a8:     	add	x19, x28, x19, lsl #9
1000635ac:     	ldr	x27, [sp, #0x40]
1000635b0:     	str	x16, [sp, #0xc0]
1000635b4:     	cbz	x16, 0x100063930 <<la_stack::rational::RationalMatrix<8>>::solve+0x16f0>
1000635b8:     	mov	x20, #0x0               ; =0
1000635bc:     	lsl	x8, x0, #6
1000635c0:     	add	x21, x19, x8
1000635c4:     	add	x9, sp, #0xd10
1000635c8:     	add	x22, x9, x8
1000635cc:     	b	0x1000635dc <<la_stack::rational::RationalMatrix<8>>::solve+0x139c>
1000635d0:     	add	x20, x20, #0x40
1000635d4:     	cmp	x25, x20
1000635d8:     	b.eq	0x100063924 <<la_stack::rational::RationalMatrix<8>>::solve+0x16e4>
1000635dc:     	add	x8, x21, x20
1000635e0:     	ldrb	w8, [x8, #0x18]
1000635e4:     	cmp	w8, #0x1
1000635e8:     	b.eq	0x1000635d0 <<la_stack::rational::RationalMatrix<8>>::solve+0x1390>
1000635ec:     	add	x8, x22, x20
1000635f0:     	ldrb	w8, [x8, #0x18]
1000635f4:     	cmp	w8, #0x1
1000635f8:     	b.eq	0x1000635d0 <<la_stack::rational::RationalMatrix<8>>::solve+0x1390>
1000635fc:     	sub	x0, x29, #0x100
100063600:     	add	x1, x21, x20
100063604:     	add	x2, x22, x20
100063608:     	bl	0x100092ea4 <<&num_bigint::bigint::BigInt as core::ops::arith::Mul>::mul>
10006360c:     	add	x8, x21, x20
100063610:     	add	x9, x22, x20
100063614:     	sub	x0, x29, #0xa0
100063618:     	add	x1, x8, #0x20
10006361c:     	add	x2, x9, #0x20
100063620:     	bl	0x100092ea4 <<&num_bigint::bigint::BigInt as core::ops::arith::Mul>::mul>
100063624:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100063628:     	add	x9, x9, #0x580
10006362c:     	ldrb	w8, [x9, #0x258]
100063630:     	ldrb	w23, [x9, #0x2f8]
100063634:     	cmp	w8, w23
100063638:     	b.ne	0x1000636e8 <<la_stack::rational::RationalMatrix<8>>::solve+0x14a8>
10006363c:     	cmp	w8, #0x1
100063640:     	b.ne	0x100063684 <<la_stack::rational::RationalMatrix<8>>::solve+0x1444>
100063644:     	ldp	q0, q1, [x29, #-0x100]
100063648:     	str	q0, [sp, #0x1580]
10006364c:     	str	q1, [sp, #0x1590]
100063650:     	mov	w23, #0x1               ; =1
100063654:     	mov	w24, #0x0               ; =0
100063658:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
10006365c:     	add	x0, x0, #0x780
100063660:     	add	x1, sp, #0x1, lsl #12   ; =0x1000
100063664:     	add	x1, x1, #0x580
100063668:     	bl	0x100093e94 <<num_bigint::bigint::BigInt as core::ops::arith::SubAssign>::sub_assign>
10006366c:     	ldur	x8, [x29, #-0xa0]
100063670:     	cmp	x8, #0x1
100063674:     	b.lt	0x1000635d0 <<la_stack::rational::RationalMatrix<8>>::solve+0x1390>
100063678:     	ldur	x0, [x29, #-0x98]
10006367c:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
100063680:     	b	0x1000635d0 <<la_stack::rational::RationalMatrix<8>>::solve+0x1390>
100063684:     	ldr	x8, [sp, #0x17c0]
100063688:     	ldr	x9, [sp, #0x17c8]
10006368c:     	ldr	x10, [sp, #0x17d0]
100063690:     	cmn	x8, #0x1
100063694:     	csel	x10, x9, x10, eq
100063698:     	ldp	x11, x12, [x29, #-0xa0]
10006369c:     	ldur	x13, [x29, #-0x90]
1000636a0:     	cmn	x11, #0x1
1000636a4:     	csel	x13, x12, x13, eq
1000636a8:     	cmp	x10, x13
1000636ac:     	b.ne	0x1000636e8 <<la_stack::rational::RationalMatrix<8>>::solve+0x14a8>
1000636b0:     	tst	w12, #0x1
1000636b4:     	ldr	x13, [sp, #0xb0]
1000636b8:     	mov	w14, #0x8               ; =8
1000636bc:     	csel	x13, x13, x14, ne
1000636c0:     	cmn	x11, #0x1
1000636c4:     	csel	x1, x13, x12, eq
1000636c8:     	tst	w9, #0x1
1000636cc:     	ldr	x11, [sp, #0xb8]
1000636d0:     	csel	x11, x11, x14, ne
1000636d4:     	cmn	x8, #0x1
1000636d8:     	csel	x0, x11, x9, eq
1000636dc:     	lsl	x2, x10, #3
1000636e0:     	bl	0x100217930 <dyld_stub_binder+0x100217930>
1000636e4:     	cbz	w0, 0x100063644 <<la_stack::rational::RationalMatrix<8>>::solve+0x1404>
1000636e8:     	ldr	q0, [sp, #0x1780]
1000636ec:     	str	q0, [sp, #0x100]
1000636f0:     	ldr	x8, [sp, #0x1790]
1000636f4:     	str	x8, [sp, #0x110]
1000636f8:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000636fc:     	add	x8, x8, #0x580
100063700:     	ldrb	w8, [x8, #0x218]
100063704:     	cmp	w8, #0x1
100063708:     	b.eq	0x10006371c <<la_stack::rational::RationalMatrix<8>>::solve+0x14dc>
10006370c:     	cmp	w23, #0x2
100063710:     	b.eq	0x10006377c <<la_stack::rational::RationalMatrix<8>>::solve+0x153c>
100063714:     	cmp	w23, #0x1
100063718:     	b.ne	0x100063788 <<la_stack::rational::RationalMatrix<8>>::solve+0x1548>
10006371c:     	mov	w24, #0x1               ; =1
100063720:     	mov	w23, #0x0               ; =0
100063724:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
100063728:     	add	x0, x0, #0x580
10006372c:     	add	x1, sp, #0x100
100063730:     	sub	x2, x29, #0xa0
100063734:     	bl	0x1000894c0 <<num_bigint::biguint::BigUint as core::ops::arith::Mul<&num_bigint::biguint::BigUint>>::mul>
100063738:     	ldr	x8, [sp, #0x1580]
10006373c:     	cmn	x8, #0x1
100063740:     	b.eq	0x100063770 <<la_stack::rational::RationalMatrix<8>>::solve+0x1530>
100063744:     	str	xzr, [sp, #0x1590]
100063748:     	cmp	x8, #0x2
10006374c:     	b.lo	0x100063774 <<la_stack::rational::RationalMatrix<8>>::solve+0x1534>
100063750:     	ldr	x0, [sp, #0x1588]
100063754:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
100063758:     	str	xzr, [sp, #0x1590]
10006375c:     	adrp	x8, 0x100227000 <criterion::plot::plotters_backend::summary::COMPARISON_COLORS+0x385>
100063760:     	add	x8, x8, #0x608
100063764:     	ldr	q0, [x8]
100063768:     	str	q0, [sp, #0x1580]
10006376c:     	b	0x100063774 <<la_stack::rational::RationalMatrix<8>>::solve+0x1534>
100063770:     	str	xzr, [sp, #0x1588]
100063774:     	mov	w8, #0x1                ; =1
100063778:     	b	0x1000637d8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1598>
10006377c:     	cbz	w8, 0x10006378c <<la_stack::rational::RationalMatrix<8>>::solve+0x154c>
100063780:     	mov	w26, #0x2               ; =2
100063784:     	b	0x100063790 <<la_stack::rational::RationalMatrix<8>>::solve+0x1550>
100063788:     	cbz	w8, 0x100063780 <<la_stack::rational::RationalMatrix<8>>::solve+0x1540>
10006378c:     	mov	w26, #0x0               ; =0
100063790:     	mov	w24, #0x1               ; =1
100063794:     	mov	w23, #0x0               ; =0
100063798:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
10006379c:     	add	x0, x0, #0x580
1000637a0:     	add	x1, sp, #0x100
1000637a4:     	sub	x2, x29, #0xa0
1000637a8:     	bl	0x1000894c0 <<num_bigint::biguint::BigUint as core::ops::arith::Mul<&num_bigint::biguint::BigUint>>::mul>
1000637ac:     	ldr	x8, [sp, #0x1580]
1000637b0:     	cmn	x8, #0x1
1000637b4:     	b.eq	0x1000637c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1588>
1000637b8:     	ldr	x8, [sp, #0x1590]
1000637bc:     	cmp	x8, #0x0
1000637c0:     	cset	w8, eq
1000637c4:     	b	0x1000637d0 <<la_stack::rational::RationalMatrix<8>>::solve+0x1590>
1000637c8:     	ldr	w8, [sp, #0x1588]
1000637cc:     	eor	w8, w8, #0x1
1000637d0:     	cmp	w8, #0x0
1000637d4:     	csinc	w8, w26, wzr, eq
1000637d8:     	ldr	q0, [sp, #0x1580]
1000637dc:     	str	q0, [sp, #0xa00]
1000637e0:     	ldr	x9, [sp, #0x1590]
1000637e4:     	str	x9, [sp, #0xa10]
1000637e8:     	strb	w8, [sp, #0xa18]
1000637ec:     	ldur	q0, [x29, #-0x100]
1000637f0:     	str	q0, [sp, #0xcf0]
1000637f4:     	ldur	x8, [x29, #-0xf0]
1000637f8:     	str	x8, [sp, #0xd00]
1000637fc:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100063800:     	add	x8, x8, #0x580
100063804:     	ldrb	w8, [x8, #0x298]
100063808:     	cmp	w8, #0x1
10006380c:     	b.eq	0x10006382c <<la_stack::rational::RationalMatrix<8>>::solve+0x15ec>
100063810:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100063814:     	add	x9, x9, #0x580
100063818:     	ldrb	w9, [x9, #0x258]
10006381c:     	cmp	w9, #0x2
100063820:     	b.eq	0x100063884 <<la_stack::rational::RationalMatrix<8>>::solve+0x1644>
100063824:     	cmp	w9, #0x1
100063828:     	b.ne	0x100063890 <<la_stack::rational::RationalMatrix<8>>::solve+0x1650>
10006382c:     	add	x0, sp, #0x100
100063830:     	add	x1, sp, #0xcf0
100063834:     	add	x2, sp, #0x1, lsl #12   ; =0x1000
100063838:     	add	x2, x2, #0x7c0
10006383c:     	bl	0x1000894c0 <<num_bigint::biguint::BigUint as core::ops::arith::Mul<&num_bigint::biguint::BigUint>>::mul>
100063840:     	ldr	x8, [sp, #0x100]
100063844:     	cmn	x8, #0x1
100063848:     	b.eq	0x100063878 <<la_stack::rational::RationalMatrix<8>>::solve+0x1638>
10006384c:     	str	xzr, [sp, #0x110]
100063850:     	cmp	x8, #0x2
100063854:     	b.lo	0x10006387c <<la_stack::rational::RationalMatrix<8>>::solve+0x163c>
100063858:     	ldr	x0, [sp, #0x108]
10006385c:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
100063860:     	str	xzr, [sp, #0x110]
100063864:     	adrp	x8, 0x100227000 <criterion::plot::plotters_backend::summary::COMPARISON_COLORS+0x385>
100063868:     	add	x8, x8, #0x608
10006386c:     	ldr	q0, [x8]
100063870:     	str	q0, [sp, #0x100]
100063874:     	b	0x10006387c <<la_stack::rational::RationalMatrix<8>>::solve+0x163c>
100063878:     	str	xzr, [sp, #0x108]
10006387c:     	mov	w8, #0x1                ; =1
100063880:     	b	0x1000638d8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1698>
100063884:     	cbz	w8, 0x100063894 <<la_stack::rational::RationalMatrix<8>>::solve+0x1654>
100063888:     	mov	w23, #0x2               ; =2
10006388c:     	b	0x100063898 <<la_stack::rational::RationalMatrix<8>>::solve+0x1658>
100063890:     	cbz	w8, 0x100063888 <<la_stack::rational::RationalMatrix<8>>::solve+0x1648>
100063894:     	mov	w23, #0x0               ; =0
100063898:     	add	x0, sp, #0x100
10006389c:     	add	x1, sp, #0xcf0
1000638a0:     	add	x2, sp, #0x1, lsl #12   ; =0x1000
1000638a4:     	add	x2, x2, #0x7c0
1000638a8:     	bl	0x1000894c0 <<num_bigint::biguint::BigUint as core::ops::arith::Mul<&num_bigint::biguint::BigUint>>::mul>
1000638ac:     	ldr	x8, [sp, #0x100]
1000638b0:     	cmn	x8, #0x1
1000638b4:     	b.eq	0x1000638c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1688>
1000638b8:     	ldr	x8, [sp, #0x110]
1000638bc:     	cmp	x8, #0x0
1000638c0:     	cset	w8, eq
1000638c4:     	b	0x1000638d0 <<la_stack::rational::RationalMatrix<8>>::solve+0x1690>
1000638c8:     	ldr	w8, [sp, #0x108]
1000638cc:     	eor	w8, w8, #0x1
1000638d0:     	cmp	w8, #0x0
1000638d4:     	csinc	w8, w23, wzr, eq
1000638d8:     	ldr	q0, [sp, #0x100]
1000638dc:     	str	q0, [sp, #0x1580]
1000638e0:     	ldr	x9, [sp, #0x110]
1000638e4:     	str	x9, [sp, #0x1590]
1000638e8:     	add	x9, sp, #0xb00
1000638ec:     	strb	w8, [x9, #0xa98]
1000638f0:     	add	x0, sp, #0x100
1000638f4:     	add	x1, sp, #0xa00
1000638f8:     	add	x2, sp, #0x1, lsl #12   ; =0x1000
1000638fc:     	add	x2, x2, #0x580
100063900:     	bl	0x1000814cc <<num_bigint::bigint::BigInt as core::ops::arith::Sub>::sub>
100063904:     	ldp	q0, q1, [sp, #0x100]
100063908:     	str	q0, [sp, #0x1780]
10006390c:     	str	q1, [sp, #0x1790]
100063910:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
100063914:     	add	x0, x0, #0x7c0
100063918:     	sub	x1, x29, #0xa0
10006391c:     	bl	0x1000931e8 <<num_bigint::bigint::BigInt as core::ops::arith::MulAssign>::mul_assign>
100063920:     	b	0x1000635d0 <<la_stack::rational::RationalMatrix<8>>::solve+0x1390>
100063924:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100063928:     	add	x8, x8, #0x580
10006392c:     	ldrb	w21, [x8, #0x218]
100063930:     	ldr	x8, [sp, #0xe0]
100063934:     	add	x20, x19, x8, lsl #6
100063938:     	ldr	q0, [sp, #0x1780]
10006393c:     	str	q0, [sp, #0xa00]
100063940:     	ldr	x8, [sp, #0x1790]
100063944:     	str	x8, [sp, #0xa10]
100063948:     	cmp	w21, #0x1
10006394c:     	b.eq	0x100063960 <<la_stack::rational::RationalMatrix<8>>::solve+0x1720>
100063950:     	ldrb	w8, [x20, #0x38]
100063954:     	cbz	w8, 0x1000639d0 <<la_stack::rational::RationalMatrix<8>>::solve+0x1790>
100063958:     	cmp	w8, #0x1
10006395c:     	b.ne	0x1000639dc <<la_stack::rational::RationalMatrix<8>>::solve+0x179c>
100063960:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
100063964:     	add	x0, x0, #0x580
100063968:     	add	x1, sp, #0xa00
10006396c:     	add	x2, x20, #0x20
100063970:     	bl	0x1000894c0 <<num_bigint::biguint::BigUint as core::ops::arith::Mul<&num_bigint::biguint::BigUint>>::mul>
100063974:     	ldr	x21, [sp, #0x1580]
100063978:     	cmn	x21, #0x1
10006397c:     	b.eq	0x100063998 <<la_stack::rational::RationalMatrix<8>>::solve+0x1758>
100063980:     	str	xzr, [sp, #0x1590]
100063984:     	ldr	x19, [sp, #0x1588]
100063988:     	cmp	x21, #0x2
10006398c:     	b.hs	0x1000639a4 <<la_stack::rational::RationalMatrix<8>>::solve+0x1764>
100063990:     	mov	w22, #0x1               ; =1
100063994:     	b	0x100063a28 <<la_stack::rational::RationalMatrix<8>>::solve+0x17e8>
100063998:     	mov	x19, #0x0               ; =0
10006399c:     	mov	w22, #0x1               ; =1
1000639a0:     	b	0x100063a28 <<la_stack::rational::RationalMatrix<8>>::solve+0x17e8>
1000639a4:     	mov	x0, x19
1000639a8:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
1000639ac:     	mov	x19, #0x0               ; =0
1000639b0:     	str	xzr, [sp, #0x1590]
1000639b4:     	adrp	x8, 0x100227000 <criterion::plot::plotters_backend::summary::COMPARISON_COLORS+0x385>
1000639b8:     	add	x8, x8, #0x608
1000639bc:     	ldr	q0, [x8]
1000639c0:     	str	q0, [sp, #0x1580]
1000639c4:     	mov	w22, #0x1               ; =1
1000639c8:     	mov	x21, #-0x1              ; =-1
1000639cc:     	b	0x100063a28 <<la_stack::rational::RationalMatrix<8>>::solve+0x17e8>
1000639d0:     	cbz	w21, 0x1000639e0 <<la_stack::rational::RationalMatrix<8>>::solve+0x17a0>
1000639d4:     	mov	w22, #0x0               ; =0
1000639d8:     	b	0x1000639e4 <<la_stack::rational::RationalMatrix<8>>::solve+0x17a4>
1000639dc:     	cbz	w21, 0x1000639d4 <<la_stack::rational::RationalMatrix<8>>::solve+0x1794>
1000639e0:     	mov	w22, #0x2               ; =2
1000639e4:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000639e8:     	add	x0, x0, #0x580
1000639ec:     	add	x1, sp, #0xa00
1000639f0:     	add	x2, x20, #0x20
1000639f4:     	bl	0x1000894c0 <<num_bigint::biguint::BigUint as core::ops::arith::Mul<&num_bigint::biguint::BigUint>>::mul>
1000639f8:     	ldr	x21, [sp, #0x1580]
1000639fc:     	cmn	x21, #0x1
100063a00:     	b.eq	0x100063a18 <<la_stack::rational::RationalMatrix<8>>::solve+0x17d8>
100063a04:     	ldr	x8, [sp, #0x1590]
100063a08:     	ldr	x19, [sp, #0x1588]
100063a0c:     	cmp	x8, #0x0
100063a10:     	cset	w8, eq
100063a14:     	b	0x100063a20 <<la_stack::rational::RationalMatrix<8>>::solve+0x17e0>
100063a18:     	ldr	x19, [sp, #0x1588]
100063a1c:     	eor	w8, w19, #0x1
100063a20:     	cmp	w8, #0x0
100063a24:     	csinc	w22, w22, wzr, eq
100063a28:     	ldr	x23, [sp, #0x1590]
100063a2c:     	ldr	q0, [sp, #0x17c0]
100063a30:     	str	q0, [sp, #0x100]
100063a34:     	ldr	x8, [sp, #0x17d0]
100063a38:     	str	x8, [sp, #0x110]
100063a3c:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100063a40:     	add	x8, x8, #0x580
100063a44:     	ldrb	w8, [x8, #0x258]
100063a48:     	cmp	w8, #0x1
100063a4c:     	b.eq	0x100063a64 <<la_stack::rational::RationalMatrix<8>>::solve+0x1824>
100063a50:     	ldrb	w9, [x20, #0x18]
100063a54:     	cmp	w9, #0x2
100063a58:     	b.eq	0x100063ab8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1878>
100063a5c:     	cmp	w9, #0x1
100063a60:     	b.ne	0x100063ac4 <<la_stack::rational::RationalMatrix<8>>::solve+0x1884>
100063a64:     	add	x0, sp, #0xa00
100063a68:     	add	x1, sp, #0x100
100063a6c:     	mov	x2, x20
100063a70:     	bl	0x1000894c0 <<num_bigint::biguint::BigUint as core::ops::arith::Mul<&num_bigint::biguint::BigUint>>::mul>
100063a74:     	ldr	x8, [sp, #0xa00]
100063a78:     	cmn	x8, #0x1
100063a7c:     	b.eq	0x100063aac <<la_stack::rational::RationalMatrix<8>>::solve+0x186c>
100063a80:     	str	xzr, [sp, #0xa10]
100063a84:     	cmp	x8, #0x2
100063a88:     	b.lo	0x100063ab0 <<la_stack::rational::RationalMatrix<8>>::solve+0x1870>
100063a8c:     	ldr	x0, [sp, #0xa08]
100063a90:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
100063a94:     	str	xzr, [sp, #0xa10]
100063a98:     	adrp	x8, 0x100227000 <criterion::plot::plotters_backend::summary::COMPARISON_COLORS+0x385>
100063a9c:     	add	x8, x8, #0x608
100063aa0:     	ldr	q0, [x8]
100063aa4:     	str	q0, [sp, #0xa00]
100063aa8:     	b	0x100063ab0 <<la_stack::rational::RationalMatrix<8>>::solve+0x1870>
100063aac:     	str	xzr, [sp, #0xa08]
100063ab0:     	mov	w8, #0x1                ; =1
100063ab4:     	b	0x100063b08 <<la_stack::rational::RationalMatrix<8>>::solve+0x18c8>
100063ab8:     	cbz	w8, 0x100063ac8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1888>
100063abc:     	mov	w24, #0x2               ; =2
100063ac0:     	b	0x100063acc <<la_stack::rational::RationalMatrix<8>>::solve+0x188c>
100063ac4:     	cbz	w8, 0x100063abc <<la_stack::rational::RationalMatrix<8>>::solve+0x187c>
100063ac8:     	mov	w24, #0x0               ; =0
100063acc:     	add	x0, sp, #0xa00
100063ad0:     	add	x1, sp, #0x100
100063ad4:     	mov	x2, x20
100063ad8:     	bl	0x1000894c0 <<num_bigint::biguint::BigUint as core::ops::arith::Mul<&num_bigint::biguint::BigUint>>::mul>
100063adc:     	ldr	x8, [sp, #0xa00]
100063ae0:     	cmn	x8, #0x1
100063ae4:     	b.eq	0x100063af8 <<la_stack::rational::RationalMatrix<8>>::solve+0x18b8>
100063ae8:     	ldr	x8, [sp, #0xa10]
100063aec:     	cmp	x8, #0x0
100063af0:     	cset	w8, eq
100063af4:     	b	0x100063b00 <<la_stack::rational::RationalMatrix<8>>::solve+0x18c0>
100063af8:     	ldr	w8, [sp, #0xa08]
100063afc:     	eor	w8, w8, #0x1
100063b00:     	cmp	w8, #0x0
100063b04:     	csinc	w8, w24, wzr, eq
100063b08:     	ldr	q0, [sp, #0xa00]
100063b0c:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100063b10:     	add	x10, x10, #0x580
100063b14:     	stur	q0, [x10, #0x20]
100063b18:     	ldr	x9, [sp, #0xa10]
100063b1c:     	stur	x9, [x10, #0x30]
100063b20:     	str	x21, [sp, #0x1580]
100063b24:     	str	x19, [sp, #0x1588]
100063b28:     	str	x23, [sp, #0x1590]
100063b2c:     	add	x9, sp, #0xb00
100063b30:     	strb	w22, [x9, #0xa98]
100063b34:     	strb	w8, [x9, #0xab8]
100063b38:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
100063b3c:     	add	x0, x0, #0x580
100063b40:     	bl	0x1000671d8 <<num_rational::Ratio<num_bigint::bigint::BigInt>>::reduce>
100063b44:     	ldr	q0, [sp, #0x1580]
100063b48:     	ldr	q1, [sp, #0x1590]
100063b4c:     	str	q0, [sp, #0xa00]
100063b50:     	str	q1, [sp, #0xa10]
100063b54:     	ldr	q0, [sp, #0x15a0]
100063b58:     	ldr	q1, [sp, #0x15b0]
100063b5c:     	str	q0, [sp, #0xa20]
100063b60:     	str	q1, [sp, #0xa30]
100063b64:     	add	x8, sp, #0xd10
100063b68:     	ldr	x9, [sp, #0xe0]
100063b6c:     	add	x19, x8, x9, lsl #6
100063b70:     	ldr	x8, [x19]
100063b74:     	cmp	x8, #0x1
100063b78:     	b.lt	0x100063b84 <<la_stack::rational::RationalMatrix<8>>::solve+0x1944>
100063b7c:     	ldr	x0, [x19, #0x8]
100063b80:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
100063b84:     	ldr	x8, [x19, #0x20]
100063b88:     	cmp	x8, #0x1
100063b8c:     	b.lt	0x100063414 <<la_stack::rational::RationalMatrix<8>>::solve+0x11d4>
100063b90:     	ldr	x0, [x19, #0x28]
100063b94:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
100063b98:     	b	0x100063414 <<la_stack::rational::RationalMatrix<8>>::solve+0x11d4>
100063b9c:     	ldr	x19, [sp, #0xd10]
100063ba0:     	add	x0, sp, #0x200
100063ba4:     	add	x8, sp, #0xd10
100063ba8:     	add	x1, x8, #0x8
100063bac:     	mov	w2, #0x1f8              ; =504
100063bb0:     	bl	0x10021793c <dyld_stub_binder+0x10021793c>
100063bb4:     	cmn	x19, #0x2
100063bb8:     	b.ne	0x1000650a8 <<la_stack::rational::RationalMatrix<8>>::solve+0x2e68>
100063bbc:     	add	x19, x28, #0x200
100063bc0:     	str	x28, [sp, #0xd20]
100063bc4:     	str	x19, [sp, #0xd28]
100063bc8:     	mov	w21, #0x1               ; =1
100063bcc:     	str	x21, [sp, #0xd10]
100063bd0:     	str	x27, [sp, #0xd18]
100063bd4:     	add	x0, sp, #0x200
100063bd8:     	add	x1, sp, #0xd10
100063bdc:     	bl	0x100047f88 <la_stack::rational::common_denominator::<core::iter::adapters::chain::Chain<core::slice::iter::Iter<num_rational::Ratio<num_bigint::bigint::BigInt>>, core::iter::sources::once::Once<&num_rational::Ratio<num_bigint::bigint::BigInt>>>>>
100063be0:     	ldr	x8, [sp, #0x200]
100063be4:     	str	x8, [sp, #0xe0]
100063be8:     	ldr	x8, [sp, #0x208]
100063bec:     	str	x8, [sp, #0xd0]
100063bf0:     	ldr	q0, [sp, #0x210]
100063bf4:     	str	q0, [sp, #0xb00]
100063bf8:     	str	q0, [sp, #0xa00]
100063bfc:     	str	q0, [sp, #0x1580]
100063c00:     	stur	q0, [x29, #-0xa0]
100063c04:     	add	x26, x28, #0x400
100063c08:     	add	x9, x27, #0x40
100063c0c:     	str	x19, [sp, #0xd20]
100063c10:     	str	x26, [sp, #0xd28]
100063c14:     	str	x21, [sp, #0xd10]
100063c18:     	add	x8, x27, #0x40
100063c1c:     	str	x8, [sp, #0x38]
100063c20:     	str	x9, [sp, #0xd18]
100063c24:     	mov	w24, #0x0               ; =0
100063c28:     	mov	x22, x28
100063c2c:     	mov	w28, #0x0               ; =0
100063c30:     	mov	w23, #0x0               ; =0
100063c34:     	mov	w19, #0x0               ; =0
100063c38:     	add	x0, sp, #0x200
100063c3c:     	add	x1, sp, #0xd10
100063c40:     	mov	w20, #0x1               ; =1
100063c44:     	bl	0x100047f88 <la_stack::rational::common_denominator::<core::iter::adapters::chain::Chain<core::slice::iter::Iter<num_rational::Ratio<num_bigint::bigint::BigInt>>, core::iter::sources::once::Once<&num_rational::Ratio<num_bigint::bigint::BigInt>>>>>
100063c48:     	ldr	x8, [sp, #0x200]
100063c4c:     	str	x8, [sp, #0xc0]
100063c50:     	ldr	x8, [sp, #0x208]
100063c54:     	str	x8, [sp, #0xa8]
100063c58:     	ldr	q0, [sp, #0x210]
100063c5c:     	str	q0, [sp, #0x1580]
100063c60:     	stur	q0, [x29, #-0x100]
100063c64:     	add	x25, x22, #0x600
100063c68:     	add	x9, x27, #0x80
100063c6c:     	str	x26, [sp, #0xd20]
100063c70:     	str	x25, [sp, #0xd28]
100063c74:     	mov	w24, #0x1               ; =1
100063c78:     	str	x24, [sp, #0xd10]
100063c7c:     	add	x8, x27, #0x80
100063c80:     	str	x8, [sp, #0x30]
100063c84:     	str	x9, [sp, #0xd18]
100063c88:     	mov	w21, #0x0               ; =0
100063c8c:     	mov	w28, #0x0               ; =0
100063c90:     	mov	w23, #0x0               ; =0
100063c94:     	mov	w19, #0x0               ; =0
100063c98:     	add	x0, sp, #0x200
100063c9c:     	add	x1, sp, #0xd10
100063ca0:     	mov	w20, #0x1               ; =1
100063ca4:     	bl	0x100047f88 <la_stack::rational::common_denominator::<core::iter::adapters::chain::Chain<core::slice::iter::Iter<num_rational::Ratio<num_bigint::bigint::BigInt>>, core::iter::sources::once::Once<&num_rational::Ratio<num_bigint::bigint::BigInt>>>>>
100063ca8:     	ldr	x9, [sp, #0x200]
100063cac:     	ldr	x8, [sp, #0x208]
100063cb0:     	stp	x8, x9, [sp, #0x98]
100063cb4:     	ldr	q0, [sp, #0x210]
100063cb8:     	str	q0, [sp, #0x1580]
100063cbc:     	str	q0, [sp, #0x17c0]
100063cc0:     	add	x26, x22, #0x800
100063cc4:     	add	x9, x27, #0xc0
100063cc8:     	str	x25, [sp, #0xd20]
100063ccc:     	str	x26, [sp, #0xd28]
100063cd0:     	mov	w28, #0x1               ; =1
100063cd4:     	str	x28, [sp, #0xd10]
100063cd8:     	add	x8, x27, #0xc0
100063cdc:     	str	x8, [sp, #0x28]
100063ce0:     	str	x9, [sp, #0xd18]
100063ce4:     	mov	w21, #0x0               ; =0
100063ce8:     	mov	w24, #0x0               ; =0
100063cec:     	mov	w23, #0x0               ; =0
100063cf0:     	mov	w19, #0x0               ; =0
100063cf4:     	add	x0, sp, #0x200
100063cf8:     	add	x1, sp, #0xd10
100063cfc:     	mov	w20, #0x1               ; =1
100063d00:     	bl	0x100047f88 <la_stack::rational::common_denominator::<core::iter::adapters::chain::Chain<core::slice::iter::Iter<num_rational::Ratio<num_bigint::bigint::BigInt>>, core::iter::sources::once::Once<&num_rational::Ratio<num_bigint::bigint::BigInt>>>>>
100063d04:     	ldr	x8, [sp, #0x200]
100063d08:     	str	x8, [sp, #0x80]
100063d0c:     	ldr	x8, [sp, #0x208]
100063d10:     	str	x8, [sp, #0x70]
100063d14:     	ldr	q0, [sp, #0x210]
100063d18:     	str	q0, [sp, #0x1580]
100063d1c:     	str	q0, [sp, #0x1780]
100063d20:     	add	x25, x22, #0xa00
100063d24:     	add	x9, x27, #0x100
100063d28:     	str	x26, [sp, #0xd20]
100063d2c:     	str	x25, [sp, #0xd28]
100063d30:     	mov	w23, #0x1               ; =1
100063d34:     	str	x23, [sp, #0xd10]
100063d38:     	add	x8, x27, #0x100
100063d3c:     	str	x8, [sp, #0x20]
100063d40:     	str	x9, [sp, #0xd18]
100063d44:     	mov	w21, #0x0               ; =0
100063d48:     	mov	w24, #0x0               ; =0
100063d4c:     	mov	w28, #0x0               ; =0
100063d50:     	mov	w19, #0x0               ; =0
100063d54:     	add	x0, sp, #0x200
100063d58:     	add	x1, sp, #0xd10
100063d5c:     	mov	w20, #0x1               ; =1
100063d60:     	bl	0x100047f88 <la_stack::rational::common_denominator::<core::iter::adapters::chain::Chain<core::slice::iter::Iter<num_rational::Ratio<num_bigint::bigint::BigInt>>, core::iter::sources::once::Once<&num_rational::Ratio<num_bigint::bigint::BigInt>>>>>
100063d64:     	ldr	x9, [sp, #0x200]
100063d68:     	ldr	x8, [sp, #0x208]
100063d6c:     	stp	x8, x9, [sp, #0x60]
100063d70:     	ldr	q0, [sp, #0x210]
100063d74:     	str	q0, [sp, #0x1580]
100063d78:     	str	q0, [sp, #0xcf0]
100063d7c:     	add	x26, x22, #0xc00
100063d80:     	add	x9, x27, #0x140
100063d84:     	str	x25, [sp, #0xd20]
100063d88:     	str	x26, [sp, #0xd28]
100063d8c:     	mov	w19, #0x1               ; =1
100063d90:     	str	x19, [sp, #0xd10]
100063d94:     	add	x8, x27, #0x140
100063d98:     	str	x8, [sp, #0x18]
100063d9c:     	str	x9, [sp, #0xd18]
100063da0:     	mov	w21, #0x0               ; =0
100063da4:     	mov	w24, #0x0               ; =0
100063da8:     	mov	w28, #0x0               ; =0
100063dac:     	mov	w23, #0x0               ; =0
100063db0:     	add	x0, sp, #0x200
100063db4:     	add	x1, sp, #0xd10
100063db8:     	mov	w20, #0x1               ; =1
100063dbc:     	bl	0x100047f88 <la_stack::rational::common_denominator::<core::iter::adapters::chain::Chain<core::slice::iter::Iter<num_rational::Ratio<num_bigint::bigint::BigInt>>, core::iter::sources::once::Once<&num_rational::Ratio<num_bigint::bigint::BigInt>>>>>
100063dc0:     	ldr	x9, [sp, #0x200]
100063dc4:     	ldr	x8, [sp, #0x208]
100063dc8:     	stp	x8, x9, [sp, #0x50]
100063dcc:     	ldr	q0, [sp, #0x210]
100063dd0:     	str	q0, [sp, #0x1580]
100063dd4:     	str	q0, [sp, #0x1570]
100063dd8:     	add	x25, x22, #0xe00
100063ddc:     	add	x9, x27, #0x180
100063de0:     	str	x26, [sp, #0xd20]
100063de4:     	str	x25, [sp, #0xd28]
100063de8:     	mov	w8, #0x1                ; =1
100063dec:     	str	x8, [sp, #0xd10]
100063df0:     	add	x8, x27, #0x180
100063df4:     	str	x8, [sp, #0x10]
100063df8:     	str	x9, [sp, #0xd18]
100063dfc:     	mov	w21, #0x0               ; =0
100063e00:     	mov	w24, #0x0               ; =0
100063e04:     	mov	w28, #0x0               ; =0
100063e08:     	mov	w23, #0x0               ; =0
100063e0c:     	mov	w19, #0x0               ; =0
100063e10:     	mov	w20, #0x0               ; =0
100063e14:     	add	x0, sp, #0x200
100063e18:     	add	x1, sp, #0xd10
100063e1c:     	bl	0x100047f88 <la_stack::rational::common_denominator::<core::iter::adapters::chain::Chain<core::slice::iter::Iter<num_rational::Ratio<num_bigint::bigint::BigInt>>, core::iter::sources::once::Once<&num_rational::Ratio<num_bigint::bigint::BigInt>>>>>
100063e20:     	ldr	x9, [sp, #0x200]
100063e24:     	ldr	x8, [sp, #0x208]
100063e28:     	stp	x9, x8, [sp, #0xb0]
100063e2c:     	ldr	q0, [sp, #0x210]
100063e30:     	str	q0, [sp, #0x1580]
100063e34:     	str	q0, [sp, #0x1560]
100063e38:     	add	x8, x22, #0x1, lsl #12  ; =0x1000
100063e3c:     	add	x9, x27, #0x1c0
100063e40:     	str	x25, [sp, #0xd20]
100063e44:     	str	x8, [sp, #0xd28]
100063e48:     	mov	w20, #0x1               ; =1
100063e4c:     	str	x20, [sp, #0xd10]
100063e50:     	add	x8, x27, #0x1c0
100063e54:     	str	x8, [sp, #0x8]
100063e58:     	str	x9, [sp, #0xd18]
100063e5c:     	mov	w21, #0x0               ; =0
100063e60:     	mov	w24, #0x0               ; =0
100063e64:     	mov	w28, #0x0               ; =0
100063e68:     	mov	w23, #0x0               ; =0
100063e6c:     	mov	w19, #0x0               ; =0
100063e70:     	add	x26, sp, #0x200
100063e74:     	add	x25, sp, #0xd10
100063e78:     	add	x0, sp, #0x200
100063e7c:     	add	x1, sp, #0xd10
100063e80:     	bl	0x100047f88 <la_stack::rational::common_denominator::<core::iter::adapters::chain::Chain<core::slice::iter::Iter<num_rational::Ratio<num_bigint::bigint::BigInt>>, core::iter::sources::once::Once<&num_rational::Ratio<num_bigint::bigint::BigInt>>>>>
100063e84:     	mov	x23, #0x0               ; =0
100063e88:     	mov	x19, #0x0               ; =0
100063e8c:     	mov	x10, #0x0               ; =0
100063e90:     	ldr	x9, [sp, #0xe0]
100063e94:     	ldr	x8, [sp, #0xd0]
100063e98:     	stp	x9, x8, [sp, #0x100]
100063e9c:     	ldr	x8, [sp, #0x200]
100063ea0:     	ldr	x9, [sp, #0x208]
100063ea4:     	ldr	q0, [sp, #0x210]
100063ea8:     	str	q0, [sp, #0xd10]
100063eac:     	ldur	q0, [x29, #-0xa0]
100063eb0:     	str	q0, [sp, #0x110]
100063eb4:     	ldr	x11, [sp, #0xc0]
100063eb8:     	str	x11, [sp, #0x120]
100063ebc:     	ldr	x11, [sp, #0xa8]
100063ec0:     	str	x11, [sp, #0x128]
100063ec4:     	ldur	q0, [x29, #-0x100]
100063ec8:     	str	q0, [sp, #0x130]
100063ecc:     	ldr	x11, [sp, #0xa0]
100063ed0:     	str	x11, [sp, #0x140]
100063ed4:     	ldr	x11, [sp, #0x98]
100063ed8:     	str	x11, [sp, #0x148]
100063edc:     	ldr	q0, [sp, #0x17c0]
100063ee0:     	str	q0, [sp, #0x150]
100063ee4:     	ldr	x11, [sp, #0x80]
100063ee8:     	str	x11, [sp, #0x160]
100063eec:     	ldr	x11, [sp, #0x70]
100063ef0:     	str	x11, [sp, #0x168]
100063ef4:     	ldr	q0, [sp, #0x1780]
100063ef8:     	str	q0, [sp, #0x170]
100063efc:     	ldr	x11, [sp, #0x68]
100063f00:     	str	x11, [sp, #0x180]
100063f04:     	ldr	x11, [sp, #0x60]
100063f08:     	str	x11, [sp, #0x188]
100063f0c:     	ldr	q0, [sp, #0xcf0]
100063f10:     	str	q0, [sp, #0x190]
100063f14:     	ldr	x11, [sp, #0x58]
100063f18:     	str	x11, [sp, #0x1a0]
100063f1c:     	ldr	x11, [sp, #0x50]
100063f20:     	str	x11, [sp, #0x1a8]
100063f24:     	ldr	q0, [sp, #0x1570]
100063f28:     	str	q0, [sp, #0x1b0]
100063f2c:     	ldr	x11, [sp, #0xb0]
100063f30:     	str	x11, [sp, #0x1c0]
100063f34:     	ldr	x11, [sp, #0xb8]
100063f38:     	str	x11, [sp, #0x1c8]
100063f3c:     	ldr	q0, [sp, #0x1560]
100063f40:     	str	q0, [sp, #0x1d0]
100063f44:     	stp	x8, x9, [sp, #0x1e0]
100063f48:     	ldr	q0, [sp, #0xd10]
100063f4c:     	add	x22, x25, #0x80
100063f50:     	add	x24, sp, #0x100
100063f54:     	str	q0, [sp, #0x1f0]
100063f58:     	str	x10, [sp, #0xe0]
100063f5c:     	ldr	x21, [sp, #0xf0]
100063f60:     	add	x20, x21, x19
100063f64:     	add	x0, sp, #0x200
100063f68:     	add	x1, x21, x19
100063f6c:     	add	x2, x24, x23
100063f70:     	bl	0x100164f00 <la_stack::rational::integer_at_scale>
100063f74:     	ldr	x8, [sp, #0x200]
100063f78:     	str	x8, [sp, #0xd0]
100063f7c:     	ldr	x8, [sp, #0x208]
100063f80:     	str	x8, [sp, #0xc0]
100063f84:     	ldur	q0, [x26, #0x10]
100063f88:     	str	q0, [sp, #0x1580]
100063f8c:     	stur	q0, [x29, #-0xa0]
100063f90:     	add	x0, sp, #0x200
100063f94:     	add	x1, x20, #0x40
100063f98:     	add	x2, x24, x23
100063f9c:     	bl	0x100164f00 <la_stack::rational::integer_at_scale>
100063fa0:     	ldr	x9, [sp, #0x200]
100063fa4:     	ldr	x8, [sp, #0x208]
100063fa8:     	stp	x8, x9, [sp, #0xb0]
100063fac:     	ldur	q0, [x26, #0x10]
100063fb0:     	str	q0, [sp, #0x1580]
100063fb4:     	stur	q0, [x29, #-0x100]
100063fb8:     	add	x26, x21, x19
100063fbc:     	mov	w28, #0x1               ; =1
100063fc0:     	mov	w21, #0x0               ; =0
100063fc4:     	mov	w20, #0x0               ; =0
100063fc8:     	mov	w25, #0x0               ; =0
100063fcc:     	add	x0, sp, #0x200
100063fd0:     	add	x1, x26, #0x80
100063fd4:     	add	x2, x24, x23
100063fd8:     	add	x27, sp, #0x100
100063fdc:     	mov	w24, #0x1               ; =1
100063fe0:     	bl	0x100164f00 <la_stack::rational::integer_at_scale>
100063fe4:     	ldr	x9, [sp, #0x200]
100063fe8:     	ldr	x8, [sp, #0x208]
100063fec:     	stp	x8, x9, [sp, #0xa0]
100063ff0:     	add	x8, sp, #0x200
100063ff4:     	ldur	q0, [x8, #0x10]
100063ff8:     	str	q0, [sp, #0x1580]
100063ffc:     	str	q0, [sp, #0x17c0]
100064000:     	mov	w21, #0x1               ; =1
100064004:     	mov	w28, #0x0               ; =0
100064008:     	mov	w20, #0x0               ; =0
10006400c:     	mov	w25, #0x0               ; =0
100064010:     	add	x0, sp, #0x200
100064014:     	add	x1, x26, #0xc0
100064018:     	add	x2, x27, x23
10006401c:     	bl	0x100164f00 <la_stack::rational::integer_at_scale>
100064020:     	ldr	x8, [sp, #0x200]
100064024:     	str	x8, [sp, #0x98]
100064028:     	ldr	x8, [sp, #0x208]
10006402c:     	str	x8, [sp, #0x80]
100064030:     	add	x8, sp, #0x200
100064034:     	ldur	q0, [x8, #0x10]
100064038:     	str	q0, [sp, #0x1580]
10006403c:     	str	q0, [sp, #0x1780]
100064040:     	ldr	x8, [sp, #0xf0]
100064044:     	add	x26, x8, x19
100064048:     	mov	w20, #0x1               ; =1
10006404c:     	mov	w28, #0x0               ; =0
100064050:     	mov	w21, #0x0               ; =0
100064054:     	mov	w25, #0x0               ; =0
100064058:     	add	x0, sp, #0x200
10006405c:     	add	x1, x26, #0x100
100064060:     	add	x2, x27, x23
100064064:     	bl	0x100164f00 <la_stack::rational::integer_at_scale>
100064068:     	ldr	x9, [sp, #0x200]
10006406c:     	ldr	x8, [sp, #0x208]
100064070:     	stp	x8, x9, [sp, #0x68]
100064074:     	add	x8, sp, #0x200
100064078:     	ldur	q0, [x8, #0x10]
10006407c:     	str	q0, [sp, #0x1580]
100064080:     	str	q0, [sp, #0xcf0]
100064084:     	mov	w25, #0x1               ; =1
100064088:     	mov	w28, #0x0               ; =0
10006408c:     	mov	w21, #0x0               ; =0
100064090:     	mov	w20, #0x0               ; =0
100064094:     	add	x0, sp, #0x200
100064098:     	add	x1, x26, #0x140
10006409c:     	add	x2, x27, x23
1000640a0:     	bl	0x100164f00 <la_stack::rational::integer_at_scale>
1000640a4:     	ldr	x9, [sp, #0x200]
1000640a8:     	ldr	x8, [sp, #0x208]
1000640ac:     	stp	x9, x8, [sp, #0x58]
1000640b0:     	add	x8, sp, #0x200
1000640b4:     	ldur	q0, [x8, #0x10]
1000640b8:     	str	q0, [sp, #0x1580]
1000640bc:     	str	q0, [sp, #0x1570]
1000640c0:     	ldr	x8, [sp, #0xf0]
1000640c4:     	add	x26, x8, x19
1000640c8:     	mov	w28, #0x0               ; =0
1000640cc:     	mov	w21, #0x0               ; =0
1000640d0:     	mov	w20, #0x0               ; =0
1000640d4:     	mov	w25, #0x0               ; =0
1000640d8:     	mov	w24, #0x0               ; =0
1000640dc:     	add	x0, sp, #0x200
1000640e0:     	add	x1, x26, #0x180
1000640e4:     	add	x2, x27, x23
1000640e8:     	bl	0x100164f00 <la_stack::rational::integer_at_scale>
1000640ec:     	ldr	x9, [sp, #0x200]
1000640f0:     	ldr	x8, [sp, #0x208]
1000640f4:     	stp	x9, x8, [sp, #0x48]
1000640f8:     	add	x8, sp, #0x200
1000640fc:     	ldur	q0, [x8, #0x10]
100064100:     	str	q0, [sp, #0x1580]
100064104:     	str	q0, [sp, #0x1560]
100064108:     	mov	w24, #0x1               ; =1
10006410c:     	mov	w28, #0x0               ; =0
100064110:     	mov	w21, #0x0               ; =0
100064114:     	mov	w20, #0x0               ; =0
100064118:     	mov	w25, #0x0               ; =0
10006411c:     	add	x0, sp, #0x200
100064120:     	add	x1, x26, #0x1c0
100064124:     	add	x2, x27, x23
100064128:     	bl	0x100164f00 <la_stack::rational::integer_at_scale>
10006412c:     	ldr	x8, [sp, #0x200]
100064130:     	ldr	x9, [sp, #0x208]
100064134:     	add	x10, sp, #0x200
100064138:     	ldur	q0, [x10, #0x10]
10006413c:     	str	q0, [sp, #0x200]
100064140:     	ldur	q0, [x29, #-0xa0]
100064144:     	str	q0, [sp, #0x1580]
100064148:     	ldur	q0, [x29, #-0x100]
10006414c:     	str	q0, [sp, #0xb00]
100064150:     	ldr	q0, [sp, #0x17c0]
100064154:     	str	q0, [sp, #0xa00]
100064158:     	ldr	q0, [sp, #0x1780]
10006415c:     	str	q0, [sp, #0x1550]
100064160:     	ldr	q0, [sp, #0xcf0]
100064164:     	str	q0, [sp, #0x1540]
100064168:     	ldr	q0, [sp, #0x1570]
10006416c:     	str	q0, [sp, #0x1530]
100064170:     	ldr	q0, [sp, #0x1560]
100064174:     	str	q0, [sp, #0x1520]
100064178:     	ldr	q0, [sp, #0x200]
10006417c:     	str	q0, [sp, #0x1510]
100064180:     	ldr	x11, [sp, #0xd0]
100064184:     	ldr	x10, [sp, #0xc0]
100064188:     	stp	x11, x10, [x22, #-0x80]
10006418c:     	ldr	q0, [sp, #0x1580]
100064190:     	stur	q0, [x22, #-0x70]
100064194:     	ldp	x10, x11, [sp, #0xb0]
100064198:     	stp	x11, x10, [x22, #-0x60]
10006419c:     	ldr	q0, [sp, #0xb00]
1000641a0:     	stur	q0, [x22, #-0x50]
1000641a4:     	ldp	x10, x11, [sp, #0xa0]
1000641a8:     	stp	x11, x10, [x22, #-0x40]
1000641ac:     	ldr	q0, [sp, #0xa00]
1000641b0:     	stur	q0, [x22, #-0x30]
1000641b4:     	ldr	x11, [sp, #0x98]
1000641b8:     	ldr	x10, [sp, #0x80]
1000641bc:     	stp	x11, x10, [x22, #-0x20]
1000641c0:     	ldr	q0, [sp, #0x1550]
1000641c4:     	stur	q0, [x22, #-0x10]
1000641c8:     	ldp	x10, x11, [sp, #0x68]
1000641cc:     	stp	x11, x10, [x22]
1000641d0:     	ldr	q0, [sp, #0x1540]
1000641d4:     	str	q0, [x22, #0x10]
1000641d8:     	ldp	x11, x10, [sp, #0x58]
1000641dc:     	stp	x11, x10, [x22, #0x20]
1000641e0:     	ldr	q0, [sp, #0x1530]
1000641e4:     	str	q0, [x22, #0x30]
1000641e8:     	ldp	x11, x10, [sp, #0x48]
1000641ec:     	stp	x11, x10, [x22, #0x40]
1000641f0:     	ldr	q0, [sp, #0x1520]
1000641f4:     	str	q0, [x22, #0x50]
1000641f8:     	stp	x8, x9, [x22, #0x60]
1000641fc:     	ldr	x10, [sp, #0xe0]
100064200:     	add	x10, x10, #0x1
100064204:     	add	x19, x19, #0x200
100064208:     	ldr	q0, [sp, #0x1510]
10006420c:     	str	q0, [x22, #0x70]
100064210:     	add	x22, x22, #0x100
100064214:     	add	x23, x23, #0x20
100064218:     	cmp	x19, #0x1, lsl #12      ; =0x1000
10006421c:     	add	x26, sp, #0x200
100064220:     	add	x24, sp, #0x100
100064224:     	b.ne	0x100063f58 <<la_stack::rational::RationalMatrix<8>>::solve+0x1d18>
100064228:     	add	x0, sp, #0x200
10006422c:     	add	x1, sp, #0xd10
100064230:     	mov	w2, #0x800              ; =2048
100064234:     	bl	0x10021793c <dyld_stub_binder+0x10021793c>
100064238:     	add	x24, sp, #0x100
10006423c:     	add	x0, sp, #0xd10
100064240:     	add	x2, sp, #0x100
100064244:     	ldr	x1, [sp, #0x40]
100064248:     	bl	0x100164f00 <la_stack::rational::integer_at_scale>
10006424c:     	ldr	x8, [sp, #0xd10]
100064250:     	str	x8, [sp, #0xf0]
100064254:     	ldr	x8, [sp, #0xd18]
100064258:     	str	x8, [sp, #0xe0]
10006425c:     	ldr	q0, [sp, #0xd20]
100064260:     	str	q0, [sp, #0x1580]
100064264:     	stur	q0, [x29, #-0xa0]
100064268:     	mov	w23, #0x1               ; =1
10006426c:     	mov	w19, #0x0               ; =0
100064270:     	mov	w28, #0x0               ; =0
100064274:     	mov	w27, #0x0               ; =0
100064278:     	mov	w20, #0x0               ; =0
10006427c:     	add	x0, sp, #0xd10
100064280:     	add	x2, x24, #0x20
100064284:     	mov	w22, #0x1               ; =1
100064288:     	ldr	x1, [sp, #0x38]
10006428c:     	bl	0x100164f00 <la_stack::rational::integer_at_scale>
100064290:     	ldr	x8, [sp, #0xd10]
100064294:     	str	x8, [sp, #0xd0]
100064298:     	ldr	x8, [sp, #0xd18]
10006429c:     	str	x8, [sp, #0xc0]
1000642a0:     	ldr	q0, [sp, #0xd20]
1000642a4:     	str	q0, [sp, #0x1580]
1000642a8:     	stur	q0, [x29, #-0x100]
1000642ac:     	add	x24, sp, #0x100
1000642b0:     	mov	w19, #0x1               ; =1
1000642b4:     	mov	w23, #0x0               ; =0
1000642b8:     	mov	w28, #0x0               ; =0
1000642bc:     	mov	w27, #0x0               ; =0
1000642c0:     	mov	w20, #0x0               ; =0
1000642c4:     	add	x0, sp, #0xd10
1000642c8:     	add	x2, x24, #0x40
1000642cc:     	mov	w22, #0x1               ; =1
1000642d0:     	ldr	x1, [sp, #0x30]
1000642d4:     	bl	0x100164f00 <la_stack::rational::integer_at_scale>
1000642d8:     	ldr	x9, [sp, #0xd10]
1000642dc:     	ldr	x8, [sp, #0xd18]
1000642e0:     	stp	x8, x9, [sp, #0xb0]
1000642e4:     	ldr	q0, [sp, #0xd20]
1000642e8:     	str	q0, [sp, #0x1580]
1000642ec:     	str	q0, [sp, #0x17c0]
1000642f0:     	mov	w28, #0x1               ; =1
1000642f4:     	mov	w23, #0x0               ; =0
1000642f8:     	mov	w19, #0x0               ; =0
1000642fc:     	mov	w27, #0x0               ; =0
100064300:     	mov	w20, #0x0               ; =0
100064304:     	add	x0, sp, #0xd10
100064308:     	add	x2, x24, #0x60
10006430c:     	mov	w22, #0x1               ; =1
100064310:     	ldr	x1, [sp, #0x28]
100064314:     	bl	0x100164f00 <la_stack::rational::integer_at_scale>
100064318:     	ldr	x9, [sp, #0xd10]
10006431c:     	ldr	x8, [sp, #0xd18]
100064320:     	stp	x8, x9, [sp, #0xa0]
100064324:     	ldr	q0, [sp, #0xd20]
100064328:     	str	q0, [sp, #0x1580]
10006432c:     	str	q0, [sp, #0x1780]
100064330:     	add	x24, sp, #0x100
100064334:     	mov	w27, #0x1               ; =1
100064338:     	mov	w23, #0x0               ; =0
10006433c:     	mov	w19, #0x0               ; =0
100064340:     	mov	w28, #0x0               ; =0
100064344:     	mov	w20, #0x0               ; =0
100064348:     	add	x0, sp, #0xd10
10006434c:     	add	x2, x24, #0x80
100064350:     	mov	w22, #0x1               ; =1
100064354:     	ldr	x1, [sp, #0x20]
100064358:     	bl	0x100164f00 <la_stack::rational::integer_at_scale>
10006435c:     	ldr	x8, [sp, #0xd10]
100064360:     	str	x8, [sp, #0x98]
100064364:     	ldr	x8, [sp, #0xd18]
100064368:     	str	x8, [sp, #0x80]
10006436c:     	ldr	q0, [sp, #0xd20]
100064370:     	str	q0, [sp, #0x1580]
100064374:     	str	q0, [sp, #0xcf0]
100064378:     	mov	w20, #0x1               ; =1
10006437c:     	mov	w23, #0x0               ; =0
100064380:     	mov	w19, #0x0               ; =0
100064384:     	mov	w28, #0x0               ; =0
100064388:     	mov	w27, #0x0               ; =0
10006438c:     	add	x0, sp, #0xd10
100064390:     	add	x2, x24, #0xa0
100064394:     	mov	w22, #0x1               ; =1
100064398:     	ldr	x1, [sp, #0x18]
10006439c:     	bl	0x100164f00 <la_stack::rational::integer_at_scale>
1000643a0:     	ldr	x9, [sp, #0xd10]
1000643a4:     	ldr	x8, [sp, #0xd18]
1000643a8:     	stp	x8, x9, [sp, #0x68]
1000643ac:     	ldr	q0, [sp, #0xd20]
1000643b0:     	str	q0, [sp, #0x1580]
1000643b4:     	str	q0, [sp, #0x1570]
1000643b8:     	add	x24, sp, #0x100
1000643bc:     	mov	w23, #0x0               ; =0
1000643c0:     	mov	w19, #0x0               ; =0
1000643c4:     	mov	w28, #0x0               ; =0
1000643c8:     	mov	w27, #0x0               ; =0
1000643cc:     	mov	w20, #0x0               ; =0
1000643d0:     	mov	w22, #0x0               ; =0
1000643d4:     	add	x0, sp, #0xd10
1000643d8:     	add	x2, x24, #0xc0
1000643dc:     	ldr	x1, [sp, #0x10]
1000643e0:     	bl	0x100164f00 <la_stack::rational::integer_at_scale>
1000643e4:     	ldr	x25, [sp, #0xd10]
1000643e8:     	ldr	x26, [sp, #0xd18]
1000643ec:     	ldr	q0, [sp, #0xd20]
1000643f0:     	str	q0, [sp, #0x1580]
1000643f4:     	str	q0, [sp, #0x1560]
1000643f8:     	mov	w22, #0x1               ; =1
1000643fc:     	mov	w23, #0x0               ; =0
100064400:     	mov	w19, #0x0               ; =0
100064404:     	mov	w28, #0x0               ; =0
100064408:     	mov	w27, #0x0               ; =0
10006440c:     	mov	w20, #0x0               ; =0
100064410:     	add	x21, sp, #0xd10
100064414:     	add	x0, sp, #0xd10
100064418:     	add	x2, x24, #0xe0
10006441c:     	ldr	x1, [sp, #0x8]
100064420:     	bl	0x100164f00 <la_stack::rational::integer_at_scale>
100064424:     	ldr	x8, [sp, #0xd10]
100064428:     	ldr	x9, [sp, #0xd18]
10006442c:     	ldr	q0, [sp, #0xd20]
100064430:     	str	q0, [sp, #0xd10]
100064434:     	ldr	x10, [sp, #0xf0]
100064438:     	str	x10, [sp, #0xa00]
10006443c:     	ldr	x10, [sp, #0xe0]
100064440:     	str	x10, [sp, #0xa08]
100064444:     	ldur	q0, [x29, #-0xa0]
100064448:     	str	q0, [sp, #0xa10]
10006444c:     	ldr	x10, [sp, #0xd0]
100064450:     	str	x10, [sp, #0xa20]
100064454:     	ldp	x10, x11, [sp, #0xb8]
100064458:     	str	x11, [sp, #0xa28]
10006445c:     	ldur	q0, [x29, #-0x100]
100064460:     	str	q0, [sp, #0xa30]
100064464:     	str	x10, [sp, #0xa40]
100064468:     	ldp	x10, x11, [sp, #0xa8]
10006446c:     	str	x11, [sp, #0xa48]
100064470:     	ldr	q0, [sp, #0x17c0]
100064474:     	str	q0, [sp, #0xa50]
100064478:     	str	x10, [sp, #0xa60]
10006447c:     	ldp	x10, x11, [sp, #0x98]
100064480:     	str	x11, [sp, #0xa68]
100064484:     	ldr	q0, [sp, #0x1780]
100064488:     	str	q0, [sp, #0xa70]
10006448c:     	str	x10, [sp, #0xa80]
100064490:     	ldr	x10, [sp, #0x80]
100064494:     	str	x10, [sp, #0xa88]
100064498:     	ldr	q0, [sp, #0xcf0]
10006449c:     	str	q0, [sp, #0xa90]
1000644a0:     	ldp	x10, x11, [sp, #0x68]
1000644a4:     	str	x11, [sp, #0xaa0]
1000644a8:     	str	x10, [sp, #0xaa8]
1000644ac:     	ldr	q0, [sp, #0x1570]
1000644b0:     	str	q0, [sp, #0xab0]
1000644b4:     	str	x25, [sp, #0xac0]
1000644b8:     	str	x26, [sp, #0xac8]
1000644bc:     	ldr	q0, [sp, #0x1560]
1000644c0:     	str	q0, [sp, #0xad0]
1000644c4:     	str	x8, [sp, #0xae0]
1000644c8:     	str	x9, [sp, #0xae8]
1000644cc:     	ldr	q0, [sp, #0xd10]
1000644d0:     	str	q0, [sp, #0xaf0]
1000644d4:     	add	x0, sp, #0xd10
1000644d8:     	add	x1, sp, #0x200
1000644dc:     	mov	w2, #0x800              ; =2048
1000644e0:     	bl	0x10021793c <dyld_stub_binder+0x10021793c>
1000644e4:     	mov	x24, #0x0               ; =0
1000644e8:     	mov	w9, #0x2                ; =2
1000644ec:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000644f0:     	add	x8, x8, #0x580
1000644f4:     	strb	w9, [x8, #0x298]
1000644f8:     	adrp	x8, 0x100218000 <dyld_stub_binder+0x100218000>
1000644fc:     	ldr	q0, [x8, #0x340]
100064500:     	str	q0, [sp, #0x80]
100064504:     	stur	q0, [x29, #-0x100]
100064508:     	stur	x22, [x29, #-0xf0]
10006450c:     	add	x9, x21, #0x20
100064510:     	add	x8, x21, #0x120
100064514:     	str	x8, [sp, #0x68]
100064518:     	mov	w8, #0x7                ; =7
10006451c:     	stp	x8, x9, [sp, #0xb0]
100064520:     	adrp	x8, 0x100218000 <dyld_stub_binder+0x100218000>
100064524:     	ldr	q0, [x8, #0x480]
100064528:     	str	q0, [sp, #0x70]
10006452c:     	add	x19, sp, #0xd10
100064530:     	b	0x100064574 <<la_stack::rational::RationalMatrix<8>>::solve+0x2334>
100064534:     	ldr	x1, [sp, #0xf0]
100064538:     	ldrb	w8, [x1, #0x18]
10006453c:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064540:     	add	x9, x9, #0x580
100064544:     	strb	w8, [x9, #0x298]
100064548:     	ldr	x8, [sp, #0xb8]
10006454c:     	add	x9, x8, #0x120
100064550:     	ldr	x8, [sp, #0x68]
100064554:     	add	x8, x8, #0x120
100064558:     	str	x8, [sp, #0x68]
10006455c:     	ldr	x8, [sp, #0xb0]
100064560:     	sub	x8, x8, #0x1
100064564:     	stp	x8, x9, [sp, #0xb0]
100064568:     	sub	x0, x29, #0x100
10006456c:     	bl	0x100090540 <<num_bigint::big_digit::BigDigits as core::clone::Clone>::clone_from>
100064570:     	ldr	x24, [sp, #0x60]
100064574:     	add	x10, x24, #0x1
100064578:     	add	x9, x19, x24, lsl #8
10006457c:     	add	x8, x9, x24, lsl #5
100064580:     	str	x8, [sp, #0xf0]
100064584:     	ldrb	w8, [x8, #0x18]
100064588:     	cmp	w8, #0x1
10006458c:     	sub	x21, x29, #0xa0
100064590:     	b.ne	0x1000647a4 <<la_stack::rational::RationalMatrix<8>>::solve+0x2564>
100064594:     	add	x8, x24, #0x1
100064598:     	cmp	x10, #0x8
10006459c:     	b.eq	0x100064f98 <<la_stack::rational::RationalMatrix<8>>::solve+0x2d58>
1000645a0:     	add	x10, x19, x8, lsl #8
1000645a4:     	add	x8, x10, x24, lsl #5
1000645a8:     	ldrb	w11, [x8, #0x18]
1000645ac:     	add	x8, x24, #0x1
1000645b0:     	cmp	w11, #0x1
1000645b4:     	b.ne	0x100064684 <<la_stack::rational::RationalMatrix<8>>::solve+0x2444>
1000645b8:     	add	x8, x24, #0x2
1000645bc:     	cmp	x8, #0x8
1000645c0:     	b.eq	0x100064f98 <<la_stack::rational::RationalMatrix<8>>::solve+0x2d58>
1000645c4:     	add	x10, x19, x8, lsl #8
1000645c8:     	add	x11, x10, x24, lsl #5
1000645cc:     	ldrb	w11, [x11, #0x18]
1000645d0:     	cmp	w11, #0x1
1000645d4:     	b.ne	0x100064684 <<la_stack::rational::RationalMatrix<8>>::solve+0x2444>
1000645d8:     	add	x8, x24, #0x3
1000645dc:     	cmp	x8, #0x8
1000645e0:     	b.eq	0x100064f98 <<la_stack::rational::RationalMatrix<8>>::solve+0x2d58>
1000645e4:     	add	x10, x19, x8, lsl #8
1000645e8:     	add	x11, x10, x24, lsl #5
1000645ec:     	ldrb	w11, [x11, #0x18]
1000645f0:     	cmp	w11, #0x1
1000645f4:     	b.ne	0x100064684 <<la_stack::rational::RationalMatrix<8>>::solve+0x2444>
1000645f8:     	add	x8, x24, #0x4
1000645fc:     	cmp	x8, #0x8
100064600:     	b.eq	0x100064f98 <<la_stack::rational::RationalMatrix<8>>::solve+0x2d58>
100064604:     	add	x10, x19, x8, lsl #8
100064608:     	add	x11, x10, x24, lsl #5
10006460c:     	ldrb	w11, [x11, #0x18]
100064610:     	cmp	w11, #0x1
100064614:     	b.ne	0x100064684 <<la_stack::rational::RationalMatrix<8>>::solve+0x2444>
100064618:     	add	x8, x24, #0x5
10006461c:     	cmp	x8, #0x8
100064620:     	b.eq	0x100064f98 <<la_stack::rational::RationalMatrix<8>>::solve+0x2d58>
100064624:     	add	x10, x19, x8, lsl #8
100064628:     	add	x11, x10, x24, lsl #5
10006462c:     	ldrb	w11, [x11, #0x18]
100064630:     	cmp	w11, #0x1
100064634:     	b.ne	0x100064684 <<la_stack::rational::RationalMatrix<8>>::solve+0x2444>
100064638:     	add	x8, x24, #0x6
10006463c:     	cmp	x8, #0x8
100064640:     	b.eq	0x100064f98 <<la_stack::rational::RationalMatrix<8>>::solve+0x2d58>
100064644:     	add	x10, x19, x8, lsl #8
100064648:     	add	x11, x10, x24, lsl #5
10006464c:     	ldrb	w11, [x11, #0x18]
100064650:     	cmp	w11, #0x1
100064654:     	b.ne	0x100064684 <<la_stack::rational::RationalMatrix<8>>::solve+0x2444>
100064658:     	add	x8, x24, #0x7
10006465c:     	cmp	x8, #0x8
100064660:     	b.eq	0x100064f98 <<la_stack::rational::RationalMatrix<8>>::solve+0x2d58>
100064664:     	add	x10, x19, x8, lsl #8
100064668:     	add	x11, x10, x24, lsl #5
10006466c:     	ldrb	w11, [x11, #0x18]
100064670:     	cmp	w11, #0x1
100064674:     	b.ne	0x100064684 <<la_stack::rational::RationalMatrix<8>>::solve+0x2444>
100064678:     	cbz	x24, 0x100064f98 <<la_stack::rational::RationalMatrix<8>>::solve+0x2d58>
10006467c:     	add	x8, x24, #0x8
100064680:     	add	x10, x19, x8, lsl #8
100064684:     	ldp	q0, q1, [x9, #0xc0]
100064688:     	str	q0, [sp, #0x1640]
10006468c:     	str	q1, [sp, #0x1650]
100064690:     	ldp	q0, q1, [x9, #0xe0]
100064694:     	str	q0, [sp, #0x1660]
100064698:     	str	q1, [sp, #0x1670]
10006469c:     	ldp	q0, q1, [x9, #0x80]
1000646a0:     	str	q0, [sp, #0x1600]
1000646a4:     	str	q1, [sp, #0x1610]
1000646a8:     	ldp	q0, q1, [x9, #0xa0]
1000646ac:     	str	q0, [sp, #0x1620]
1000646b0:     	str	q1, [sp, #0x1630]
1000646b4:     	ldp	q0, q1, [x9, #0x40]
1000646b8:     	str	q0, [sp, #0x15c0]
1000646bc:     	str	q1, [sp, #0x15d0]
1000646c0:     	ldp	q0, q1, [x9, #0x60]
1000646c4:     	str	q0, [sp, #0x15e0]
1000646c8:     	str	q1, [sp, #0x15f0]
1000646cc:     	ldp	q0, q1, [x9]
1000646d0:     	str	q0, [sp, #0x1580]
1000646d4:     	str	q1, [sp, #0x1590]
1000646d8:     	ldp	q0, q1, [x9, #0x20]
1000646dc:     	str	q0, [sp, #0x15a0]
1000646e0:     	str	q1, [sp, #0x15b0]
1000646e4:     	ldp	q0, q1, [x10]
1000646e8:     	ldp	q2, q3, [x10, #0x20]
1000646ec:     	ldp	q4, q5, [x10, #0x40]
1000646f0:     	ldp	q6, q7, [x10, #0x60]
1000646f4:     	ldp	q16, q17, [x10, #0x80]
1000646f8:     	ldp	q18, q19, [x10, #0xa0]
1000646fc:     	ldp	q20, q21, [x10, #0xc0]
100064700:     	ldp	q22, q23, [x10, #0xe0]
100064704:     	stp	q22, q23, [x9, #0xe0]
100064708:     	stp	q20, q21, [x9, #0xc0]
10006470c:     	stp	q18, q19, [x9, #0xa0]
100064710:     	stp	q16, q17, [x9, #0x80]
100064714:     	stp	q6, q7, [x9, #0x60]
100064718:     	stp	q4, q5, [x9, #0x40]
10006471c:     	stp	q2, q3, [x9, #0x20]
100064720:     	stp	q0, q1, [x9]
100064724:     	ldr	q0, [sp, #0x1640]
100064728:     	ldr	q1, [sp, #0x1650]
10006472c:     	stp	q0, q1, [x10, #0xc0]
100064730:     	ldr	q0, [sp, #0x1660]
100064734:     	ldr	q1, [sp, #0x1670]
100064738:     	stp	q0, q1, [x10, #0xe0]
10006473c:     	ldr	q0, [sp, #0x1600]
100064740:     	ldr	q1, [sp, #0x1610]
100064744:     	stp	q0, q1, [x10, #0x80]
100064748:     	ldr	q0, [sp, #0x1620]
10006474c:     	ldr	q1, [sp, #0x1630]
100064750:     	stp	q0, q1, [x10, #0xa0]
100064754:     	ldr	q0, [sp, #0x15c0]
100064758:     	ldr	q1, [sp, #0x15d0]
10006475c:     	stp	q0, q1, [x10, #0x40]
100064760:     	ldr	q0, [sp, #0x15e0]
100064764:     	ldr	q1, [sp, #0x15f0]
100064768:     	stp	q0, q1, [x10, #0x60]
10006476c:     	ldr	q0, [sp, #0x1580]
100064770:     	ldr	q1, [sp, #0x1590]
100064774:     	stp	q0, q1, [x10]
100064778:     	ldr	q0, [sp, #0x15a0]
10006477c:     	ldr	q1, [sp, #0x15b0]
100064780:     	stp	q0, q1, [x10, #0x20]
100064784:     	add	x10, sp, #0xa00
100064788:     	add	x9, x10, x24, lsl #5
10006478c:     	add	x8, x10, x8, lsl #5
100064790:     	ldp	q1, q0, [x9]
100064794:     	ldp	q3, q2, [x8]
100064798:     	stp	q3, q2, [x9]
10006479c:     	stp	q1, q0, [x8]
1000647a0:     	add	x10, x24, #0x1
1000647a4:     	cmp	x10, #0x8
1000647a8:     	b.eq	0x100064bc0 <<la_stack::rational::RationalMatrix<8>>::solve+0x2980>
1000647ac:     	add	x8, x24, #0x1
1000647b0:     	str	x8, [sp, #0x60]
1000647b4:     	lsl	x8, x24, #5
1000647b8:     	str	x8, [sp, #0xa8]
1000647bc:     	add	x8, x19, x8
1000647c0:     	stp	x24, x8, [sp, #0x98]
1000647c4:     	ldr	x21, [sp, #0x68]
1000647c8:     	add	x8, x24, #0x1
1000647cc:     	b	0x1000647f0 <<la_stack::rational::RationalMatrix<8>>::solve+0x25b0>
1000647d0:     	ldr	q0, [sp, #0x70]
1000647d4:     	str	q0, [x21]
1000647d8:     	add	x19, sp, #0xd10
1000647dc:     	ldr	x8, [sp, #0xc0]
1000647e0:     	ldr	x21, [sp, #0xd0]
1000647e4:     	add	x21, x21, #0x100
1000647e8:     	cmp	x8, #0x8
1000647ec:     	b.eq	0x100064534 <<la_stack::rational::RationalMatrix<8>>::solve+0x22f4>
1000647f0:     	mov	x9, x8
1000647f4:     	add	x8, x8, #0x1
1000647f8:     	str	x8, [sp, #0xc0]
1000647fc:     	str	x9, [sp, #0xe0]
100064800:     	add	x8, x19, x9, lsl #8
100064804:     	add	x19, x8, x24, lsl #5
100064808:     	ldp	x27, x22, [sp, #0xb0]
10006480c:     	str	x21, [sp, #0xd0]
100064810:     	b	0x100064830 <<la_stack::rational::RationalMatrix<8>>::solve+0x25f0>
100064814:     	stp	x26, x23, [x21]
100064818:     	add	x22, x22, #0x20
10006481c:     	str	x24, [x21, #0x10]
100064820:     	strb	w20, [x21, #0x18]
100064824:     	add	x21, x21, #0x20
100064828:     	subs	x27, x27, #0x1
10006482c:     	b.eq	0x1000649cc <<la_stack::rational::RationalMatrix<8>>::solve+0x278c>
100064830:     	add	x0, sp, #0xb00
100064834:     	ldr	x1, [sp, #0xf0]
100064838:     	mov	x2, x21
10006483c:     	bl	0x100092ea4 <<&num_bigint::bigint::BigInt as core::ops::arith::Mul>::mul>
100064840:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
100064844:     	add	x0, x0, #0x580
100064848:     	mov	x1, x19
10006484c:     	mov	x2, x22
100064850:     	bl	0x100092ea4 <<&num_bigint::bigint::BigInt as core::ops::arith::Mul>::mul>
100064854:     	sub	x0, x29, #0xa0
100064858:     	add	x1, sp, #0xb00
10006485c:     	add	x2, sp, #0x1, lsl #12   ; =0x1000
100064860:     	add	x2, x2, #0x580
100064864:     	bl	0x1000814cc <<num_bigint::bigint::BigInt as core::ops::arith::Sub>::sub>
100064868:     	sub	x8, x29, #0xa0
10006486c:     	str	x8, [sp, #0x17c8]
100064870:     	mov	x8, #-0x2               ; =-2
100064874:     	str	x8, [sp, #0x17c0]
100064878:     	sub	x9, x29, #0x100
10006487c:     	str	x9, [sp, #0xb08]
100064880:     	str	x8, [sp, #0xb00]
100064884:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
100064888:     	add	x0, x0, #0x580
10006488c:     	add	x1, sp, #0x1, lsl #12   ; =0x1000
100064890:     	add	x1, x1, #0x7c0
100064894:     	add	x2, sp, #0xb00
100064898:     	bl	0x10016dcb0 <num_bigint::biguint::division::div_rem_cow>
10006489c:     	ldr	x26, [sp, #0x1580]
1000648a0:     	ldr	x23, [sp, #0x1588]
1000648a4:     	ldr	x24, [sp, #0x1590]
1000648a8:     	ldr	x28, [sp, #0x1598]
1000648ac:     	ldr	x0, [sp, #0x15a0]
1000648b0:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000648b4:     	add	x8, x8, #0x580
1000648b8:     	ldrb	w8, [x8, #0x2f8]
1000648bc:     	cmp	w8, #0x1
1000648c0:     	b.ne	0x1000648e4 <<la_stack::rational::RationalMatrix<8>>::solve+0x26a4>
1000648c4:     	cmn	x26, #0x1
1000648c8:     	b.eq	0x100064918 <<la_stack::rational::RationalMatrix<8>>::solve+0x26d8>
1000648cc:     	cmp	x26, #0x2
1000648d0:     	b.hs	0x100064928 <<la_stack::rational::RationalMatrix<8>>::solve+0x26e8>
1000648d4:     	mov	x24, #0x0               ; =0
1000648d8:     	cmn	x28, #0x1
1000648dc:     	b.ne	0x100064950 <<la_stack::rational::RationalMatrix<8>>::solve+0x2710>
1000648e0:     	b	0x100064980 <<la_stack::rational::RationalMatrix<8>>::solve+0x2740>
1000648e4:     	eor	w9, w23, #0x1
1000648e8:     	cmp	x24, #0x0
1000648ec:     	cset	w10, eq
1000648f0:     	cmn	x26, #0x1
1000648f4:     	csel	w9, w9, w10, eq
1000648f8:     	tst	w9, #0x1
1000648fc:     	csinc	w25, w8, wzr, eq
100064900:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064904:     	add	x8, x8, #0x580
100064908:     	ldrb	w20, [x8, #0x298]
10006490c:     	cmp	x28, #0x1
100064910:     	b.ge	0x100064970 <<la_stack::rational::RationalMatrix<8>>::solve+0x2730>
100064914:     	b	0x100064990 <<la_stack::rational::RationalMatrix<8>>::solve+0x2750>
100064918:     	mov	x23, #0x0               ; =0
10006491c:     	cmn	x28, #0x1
100064920:     	b.ne	0x100064950 <<la_stack::rational::RationalMatrix<8>>::solve+0x2710>
100064924:     	b	0x100064980 <<la_stack::rational::RationalMatrix<8>>::solve+0x2740>
100064928:     	cmp	x26, #0x1
10006492c:     	b.lt	0x100064940 <<la_stack::rational::RationalMatrix<8>>::solve+0x2700>
100064930:     	mov	x20, x0
100064934:     	mov	x0, x23
100064938:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
10006493c:     	mov	x0, x20
100064940:     	mov	x23, #0x0               ; =0
100064944:     	mov	x26, #-0x1              ; =-1
100064948:     	cmn	x28, #0x1
10006494c:     	b.eq	0x100064980 <<la_stack::rational::RationalMatrix<8>>::solve+0x2740>
100064950:     	cmp	x28, #0x1
100064954:     	b.hi	0x100064978 <<la_stack::rational::RationalMatrix<8>>::solve+0x2738>
100064958:     	mov	w25, #0x1               ; =1
10006495c:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064960:     	add	x8, x8, #0x580
100064964:     	ldrb	w20, [x8, #0x298]
100064968:     	cmp	x28, #0x1
10006496c:     	b.lt	0x100064990 <<la_stack::rational::RationalMatrix<8>>::solve+0x2750>
100064970:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
100064974:     	b	0x100064990 <<la_stack::rational::RationalMatrix<8>>::solve+0x2750>
100064978:     	b.lt	0x100064980 <<la_stack::rational::RationalMatrix<8>>::solve+0x2740>
10006497c:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
100064980:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064984:     	add	x8, x8, #0x580
100064988:     	ldrb	w20, [x8, #0x298]
10006498c:     	mov	w25, #0x1               ; =1
100064990:     	mov	w8, #0x2                ; =2
100064994:     	sub	w8, w8, w25
100064998:     	cmp	w20, #0x0
10006499c:     	csel	w20, w8, w25, eq
1000649a0:     	ldur	x8, [x29, #-0xa0]
1000649a4:     	cmp	x8, #0x1
1000649a8:     	b.lt	0x1000649b4 <<la_stack::rational::RationalMatrix<8>>::solve+0x2774>
1000649ac:     	ldur	x0, [x29, #-0x98]
1000649b0:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
1000649b4:     	ldr	x8, [x21]
1000649b8:     	cmp	x8, #0x1
1000649bc:     	b.lt	0x100064814 <<la_stack::rational::RationalMatrix<8>>::solve+0x25d4>
1000649c0:     	ldr	x0, [x21, #0x8]
1000649c4:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
1000649c8:     	b	0x100064814 <<la_stack::rational::RationalMatrix<8>>::solve+0x25d4>
1000649cc:     	add	x20, sp, #0xa00
1000649d0:     	ldr	x21, [sp, #0xe0]
1000649d4:     	add	x19, x20, x21, lsl #5
1000649d8:     	add	x0, sp, #0xb00
1000649dc:     	ldr	x1, [sp, #0xf0]
1000649e0:     	mov	x2, x19
1000649e4:     	bl	0x100092ea4 <<&num_bigint::bigint::BigInt as core::ops::arith::Mul>::mul>
1000649e8:     	ldp	x9, x8, [sp, #0xa0]
1000649ec:     	add	x21, x9, x21, lsl #8
1000649f0:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000649f4:     	add	x0, x0, #0x580
1000649f8:     	add	x2, x20, x8
1000649fc:     	mov	x1, x21
100064a00:     	bl	0x100092ea4 <<&num_bigint::bigint::BigInt as core::ops::arith::Mul>::mul>
100064a04:     	sub	x0, x29, #0xa0
100064a08:     	add	x1, sp, #0xb00
100064a0c:     	add	x2, sp, #0x1, lsl #12   ; =0x1000
100064a10:     	add	x2, x2, #0x580
100064a14:     	bl	0x1000814cc <<num_bigint::bigint::BigInt as core::ops::arith::Sub>::sub>
100064a18:     	sub	x8, x29, #0xa0
100064a1c:     	str	x8, [sp, #0x17c8]
100064a20:     	mov	x8, #-0x2               ; =-2
100064a24:     	str	x8, [sp, #0x17c0]
100064a28:     	sub	x9, x29, #0x100
100064a2c:     	str	x9, [sp, #0xb08]
100064a30:     	str	x8, [sp, #0xb00]
100064a34:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
100064a38:     	add	x0, x0, #0x580
100064a3c:     	add	x1, sp, #0x1, lsl #12   ; =0x1000
100064a40:     	add	x1, x1, #0x7c0
100064a44:     	add	x2, sp, #0xb00
100064a48:     	bl	0x10016dcb0 <num_bigint::biguint::division::div_rem_cow>
100064a4c:     	ldr	x23, [sp, #0x1580]
100064a50:     	ldr	x22, [sp, #0x1588]
100064a54:     	ldr	x26, [sp, #0x1590]
100064a58:     	ldr	x24, [sp, #0x1598]
100064a5c:     	ldr	x0, [sp, #0x15a0]
100064a60:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064a64:     	add	x8, x8, #0x580
100064a68:     	ldrb	w8, [x8, #0x2f8]
100064a6c:     	cmp	w8, #0x1
100064a70:     	b.ne	0x100064a94 <<la_stack::rational::RationalMatrix<8>>::solve+0x2854>
100064a74:     	cmn	x23, #0x1
100064a78:     	b.eq	0x100064aa8 <<la_stack::rational::RationalMatrix<8>>::solve+0x2868>
100064a7c:     	cmp	x23, #0x2
100064a80:     	b.hs	0x100064adc <<la_stack::rational::RationalMatrix<8>>::solve+0x289c>
100064a84:     	mov	x26, #0x0               ; =0
100064a88:     	cmn	x24, #0x1
100064a8c:     	b.ne	0x100064b04 <<la_stack::rational::RationalMatrix<8>>::solve+0x28c4>
100064a90:     	b	0x100064b34 <<la_stack::rational::RationalMatrix<8>>::solve+0x28f4>
100064a94:     	cmn	x23, #0x1
100064a98:     	b.eq	0x100064ab8 <<la_stack::rational::RationalMatrix<8>>::solve+0x2878>
100064a9c:     	cmp	x26, #0x0
100064aa0:     	cset	w9, eq
100064aa4:     	b	0x100064abc <<la_stack::rational::RationalMatrix<8>>::solve+0x287c>
100064aa8:     	mov	x22, #0x0               ; =0
100064aac:     	cmn	x24, #0x1
100064ab0:     	b.ne	0x100064b04 <<la_stack::rational::RationalMatrix<8>>::solve+0x28c4>
100064ab4:     	b	0x100064b34 <<la_stack::rational::RationalMatrix<8>>::solve+0x28f4>
100064ab8:     	eor	w9, w22, #0x1
100064abc:     	tst	w9, #0x1
100064ac0:     	csinc	w27, w8, wzr, eq
100064ac4:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064ac8:     	add	x8, x8, #0x580
100064acc:     	ldrb	w25, [x8, #0x298]
100064ad0:     	cmp	x24, #0x1
100064ad4:     	b.ge	0x100064b24 <<la_stack::rational::RationalMatrix<8>>::solve+0x28e4>
100064ad8:     	b	0x100064b44 <<la_stack::rational::RationalMatrix<8>>::solve+0x2904>
100064adc:     	cmp	x23, #0x1
100064ae0:     	b.lt	0x100064af4 <<la_stack::rational::RationalMatrix<8>>::solve+0x28b4>
100064ae4:     	mov	x20, x0
100064ae8:     	mov	x0, x22
100064aec:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
100064af0:     	mov	x0, x20
100064af4:     	mov	x22, #0x0               ; =0
100064af8:     	mov	x23, #-0x1              ; =-1
100064afc:     	cmn	x24, #0x1
100064b00:     	b.eq	0x100064b34 <<la_stack::rational::RationalMatrix<8>>::solve+0x28f4>
100064b04:     	cmp	x24, #0x1
100064b08:     	b.hi	0x100064b2c <<la_stack::rational::RationalMatrix<8>>::solve+0x28ec>
100064b0c:     	mov	w27, #0x1               ; =1
100064b10:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064b14:     	add	x8, x8, #0x580
100064b18:     	ldrb	w25, [x8, #0x298]
100064b1c:     	cmp	x24, #0x1
100064b20:     	b.lt	0x100064b44 <<la_stack::rational::RationalMatrix<8>>::solve+0x2904>
100064b24:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
100064b28:     	b	0x100064b44 <<la_stack::rational::RationalMatrix<8>>::solve+0x2904>
100064b2c:     	b.lt	0x100064b34 <<la_stack::rational::RationalMatrix<8>>::solve+0x28f4>
100064b30:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
100064b34:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064b38:     	add	x8, x8, #0x580
100064b3c:     	ldrb	w25, [x8, #0x298]
100064b40:     	mov	w27, #0x1               ; =1
100064b44:     	mov	w8, #0x2                ; =2
100064b48:     	sub	w8, w8, w27
100064b4c:     	cmp	w25, #0x0
100064b50:     	csel	w20, w8, w27, eq
100064b54:     	ldur	x8, [x29, #-0xa0]
100064b58:     	cmp	x8, #0x1
100064b5c:     	b.lt	0x100064b68 <<la_stack::rational::RationalMatrix<8>>::solve+0x2928>
100064b60:     	ldur	x0, [x29, #-0x98]
100064b64:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
100064b68:     	ldr	x8, [x19]
100064b6c:     	cmp	x8, #0x1
100064b70:     	ldr	x24, [sp, #0x98]
100064b74:     	b.lt	0x100064b80 <<la_stack::rational::RationalMatrix<8>>::solve+0x2940>
100064b78:     	ldr	x0, [x19, #0x8]
100064b7c:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
100064b80:     	stp	x23, x22, [x19]
100064b84:     	str	x26, [x19, #0x10]
100064b88:     	strb	w20, [x19, #0x18]
100064b8c:     	mov	w8, #0x1                ; =1
100064b90:     	strb	w8, [x21, #0x18]
100064b94:     	ldr	x8, [x21]
100064b98:     	cmp	x8, #0x1
100064b9c:     	b.lt	0x1000647d0 <<la_stack::rational::RationalMatrix<8>>::solve+0x2590>
100064ba0:     	str	xzr, [x21, #0x10]
100064ba4:     	add	x19, sp, #0xd10
100064ba8:     	ldr	x8, [sp, #0xc0]
100064bac:     	ldr	x21, [sp, #0xd0]
100064bb0:     	add	x21, x21, #0x100
100064bb4:     	cmp	x8, #0x8
100064bb8:     	b.ne	0x1000647f0 <<la_stack::rational::RationalMatrix<8>>::solve+0x25b0>
100064bbc:     	b	0x100064534 <<la_stack::rational::RationalMatrix<8>>::solve+0x22f4>
100064bc0:     	ldur	x8, [x29, #-0x100]
100064bc4:     	cmp	x8, #0x0
100064bc8:     	b.le	0x100064bd4 <<la_stack::rational::RationalMatrix<8>>::solve+0x2994>
100064bcc:     	ldur	x0, [x29, #-0xf8]
100064bd0:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
100064bd4:     	mov	x28, #0x0               ; =0
100064bd8:     	mov	x8, #-0x1               ; =-1
100064bdc:     	str	x8, [sp, #0x1580]
100064be0:     	str	xzr, [sp, #0x1588]
100064be4:     	adrp	x9, 0x100227000 <criterion::plot::plotters_backend::summary::COMPARISON_COLORS+0x385>
100064be8:     	add	x9, x9, #0x650
100064bec:     	ldr	q0, [x9]
100064bf0:     	adrp	x9, 0x10021b000 <dyld_stub_binder+0x10021b000>
100064bf4:     	add	x9, x9, #0x108
100064bf8:     	ldp	q1, q2, [x9]
100064bfc:     	str	q0, [sp, #0x1590]
100064c00:     	str	q1, [sp, #0x15a0]
100064c04:     	str	q2, [sp, #0x15b0]
100064c08:     	str	x8, [sp, #0x15c0]
100064c0c:     	str	xzr, [sp, #0x15c8]
100064c10:     	str	q0, [sp, #0x15d0]
100064c14:     	str	q1, [sp, #0x15e0]
100064c18:     	str	q2, [sp, #0x15f0]
100064c1c:     	str	x8, [sp, #0x1600]
100064c20:     	str	xzr, [sp, #0x1608]
100064c24:     	str	q2, [sp, #0x1630]
100064c28:     	str	q0, [sp, #0x1610]
100064c2c:     	str	q1, [sp, #0x1620]
100064c30:     	str	x8, [sp, #0x1640]
100064c34:     	str	xzr, [sp, #0x1648]
100064c38:     	str	q2, [sp, #0x1670]
100064c3c:     	str	q0, [sp, #0x1650]
100064c40:     	str	q1, [sp, #0x1660]
100064c44:     	str	x8, [sp, #0x1680]
100064c48:     	str	xzr, [sp, #0x1688]
100064c4c:     	str	q2, [sp, #0x16b0]
100064c50:     	str	q0, [sp, #0x1690]
100064c54:     	str	q1, [sp, #0x16a0]
100064c58:     	str	x8, [sp, #0x16c0]
100064c5c:     	str	xzr, [sp, #0x16c8]
100064c60:     	str	q2, [sp, #0x16f0]
100064c64:     	str	q0, [sp, #0x16d0]
100064c68:     	str	q1, [sp, #0x16e0]
100064c6c:     	str	x8, [sp, #0x1700]
100064c70:     	str	xzr, [sp, #0x1708]
100064c74:     	str	q2, [sp, #0x1730]
100064c78:     	str	q0, [sp, #0x1710]
100064c7c:     	str	q1, [sp, #0x1720]
100064c80:     	add	x25, sp, #0x1, lsl #12  ; =0x1000
100064c84:     	add	x25, x25, #0x7c0
100064c88:     	str	x8, [sp, #0x1740]
100064c8c:     	str	xzr, [sp, #0x1748]
100064c90:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064c94:     	add	x8, x8, #0x580
100064c98:     	stp	q2, q1, [sp, #0xe0]
100064c9c:     	str	q2, [sp, #0x1770]
100064ca0:     	add	x19, x8, #0x200
100064ca4:     	add	x8, sp, #0xd10
100064ca8:     	add	x27, x8, #0x800
100064cac:     	mov	w8, #0x8                ; =8
100064cb0:     	adrp	x9, 0x100227000 <criterion::plot::plotters_backend::summary::COMPARISON_COLORS+0x385>
100064cb4:     	add	x9, x9, #0x640
100064cb8:     	ldp	q3, q2, [x9]
100064cbc:     	stp	q2, q3, [sp, #0xc0]
100064cc0:     	mov	w22, #0x1               ; =1
100064cc4:     	str	q0, [sp, #0x1750]
100064cc8:     	str	q1, [sp, #0x1760]
100064ccc:     	b	0x100064cec <<la_stack::rational::RationalMatrix<8>>::solve+0x2aac>
100064cd0:     	ldp	x27, x19, [sp, #0xa0]
100064cd4:     	sub	x19, x19, #0x40
100064cd8:     	sub	x27, x27, #0x120
100064cdc:     	ldr	x28, [sp, #0xb0]
100064ce0:     	add	x28, x28, #0x1
100064ce4:     	mov	x8, x23
100064ce8:     	cbz	x23, 0x100064ef4 <<la_stack::rational::RationalMatrix<8>>::solve+0x2cb4>
100064cec:     	sub	x11, x8, #0x1
100064cf0:     	add	x9, sp, #0xa00
100064cf4:     	sub	x10, x8, #0x1
100064cf8:     	stp	x28, x10, [sp, #0xb0]
100064cfc:     	add	x9, x9, x11, lsl #5
100064d00:     	ldp	x10, x11, [x9]
100064d04:     	ldr	q3, [x9, #0x10]
100064d08:     	ldp	q1, q2, [sp, #0xc0]
100064d0c:     	stp	q2, q1, [x9]
100064d10:     	str	x10, [sp, #0x1780]
100064d14:     	str	x11, [sp, #0x1788]
100064d18:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064d1c:     	add	x9, x9, #0x780
100064d20:     	ldp	q0, q1, [sp, #0xe0]
100064d24:     	stp	q3, q1, [x9, #0x10]
100064d28:     	stur	q0, [x9, #0x30]
100064d2c:     	stp	x27, x19, [sp, #0xa0]
100064d30:     	cmp	x8, #0x8
100064d34:     	b.lo	0x100064df4 <<la_stack::rational::RationalMatrix<8>>::solve+0x2bb4>
100064d38:     	add	x8, sp, #0xd10
100064d3c:     	ldr	x23, [sp, #0xb8]
100064d40:     	add	x8, x8, x23, lsl #8
100064d44:     	add	x8, x8, x23, lsl #5
100064d48:     	ldp	x20, x19, [x8]
100064d4c:     	ldr	q3, [x8, #0x10]
100064d50:     	ldp	q2, q1, [sp, #0xc0]
100064d54:     	stp	q1, q2, [x8]
100064d58:     	stp	x20, x19, [x29, #-0x100]
100064d5c:     	sub	x8, x29, #0x100
100064d60:     	ldp	q0, q1, [sp, #0xe0]
100064d64:     	stp	q3, q1, [x8, #0x10]
100064d68:     	stur	q0, [x8, #0x30]
100064d6c:     	add	x0, sp, #0xb00
100064d70:     	sub	x1, x29, #0x100
100064d74:     	bl	0x100089c78 <<num_rational::Ratio<num_bigint::bigint::BigInt> as core::clone::Clone>::clone>
100064d78:     	sub	x0, x29, #0xa0
100064d7c:     	add	x1, sp, #0x1, lsl #12   ; =0x1000
100064d80:     	add	x1, x1, #0x780
100064d84:     	add	x2, sp, #0xb00
100064d88:     	bl	0x100091054 <<num_rational::Ratio<num_bigint::bigint::BigInt> as core::ops::arith::Div>::div>
100064d8c:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064d90:     	add	x8, x8, #0x580
100064d94:     	add	x21, x8, x23, lsl #6
100064d98:     	ldr	x8, [x21]
100064d9c:     	cmp	x8, #0x1
100064da0:     	b.lt	0x100064dac <<la_stack::rational::RationalMatrix<8>>::solve+0x2b6c>
100064da4:     	ldr	x0, [x21, #0x8]
100064da8:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
100064dac:     	ldr	x8, [x21, #0x20]
100064db0:     	cmp	x8, #0x1
100064db4:     	b.lt	0x100064dc0 <<la_stack::rational::RationalMatrix<8>>::solve+0x2b80>
100064db8:     	ldr	x0, [x21, #0x28]
100064dbc:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
100064dc0:     	ldp	q0, q1, [x29, #-0xa0]
100064dc4:     	stp	q0, q1, [x21]
100064dc8:     	ldp	q0, q1, [x29, #-0x80]
100064dcc:     	stp	q0, q1, [x21, #0x20]
100064dd0:     	cmp	x20, #0x1
100064dd4:     	b.lt	0x100064cd0 <<la_stack::rational::RationalMatrix<8>>::solve+0x2a90>
100064dd8:     	mov	x0, x19
100064ddc:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
100064de0:     	b	0x100064cd0 <<la_stack::rational::RationalMatrix<8>>::solve+0x2a90>
100064de4:     	add	x19, x19, #0x40
100064de8:     	add	x27, x27, #0x20
100064dec:     	subs	x28, x28, #0x1
100064df0:     	b.eq	0x100064d38 <<la_stack::rational::RationalMatrix<8>>::solve+0x2af8>
100064df4:     	ldp	x23, x20, [x27]
100064df8:     	ldr	q3, [x27, #0x10]
100064dfc:     	ldp	q2, q1, [sp, #0xc0]
100064e00:     	stp	q1, q2, [x27]
100064e04:     	str	x23, [sp, #0x17c0]
100064e08:     	str	x20, [sp, #0x17c8]
100064e0c:     	ldp	q0, q1, [sp, #0xe0]
100064e10:     	stp	q3, q1, [x25, #0x10]
100064e14:     	stur	q0, [x25, #0x30]
100064e18:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064e1c:     	add	x8, x8, #0x580
100064e20:     	ldrb	w24, [x8, #0x258]
100064e24:     	ldr	x26, [sp, #0x17d0]
100064e28:     	cmn	x23, #0x1
100064e2c:     	b.eq	0x100064e4c <<la_stack::rational::RationalMatrix<8>>::solve+0x2c0c>
100064e30:     	cbz	x26, 0x100064e58 <<la_stack::rational::RationalMatrix<8>>::solve+0x2c18>
100064e34:     	cmp	x26, #0x1
100064e38:     	b.ne	0x100064e64 <<la_stack::rational::RationalMatrix<8>>::solve+0x2c24>
100064e3c:     	ldr	x26, [x20]
100064e40:     	mov	x8, #-0x1               ; =-1
100064e44:     	mov	w21, #0x1               ; =1
100064e48:     	b	0x100064e8c <<la_stack::rational::RationalMatrix<8>>::solve+0x2c4c>
100064e4c:     	mov	x8, #-0x1               ; =-1
100064e50:     	mov	x21, x20
100064e54:     	b	0x100064e8c <<la_stack::rational::RationalMatrix<8>>::solve+0x2c4c>
100064e58:     	mov	x8, #-0x1               ; =-1
100064e5c:     	mov	x21, x26
100064e60:     	b	0x100064e8c <<la_stack::rational::RationalMatrix<8>>::solve+0x2c4c>
100064e64:     	lsl	x22, x26, #3
100064e68:     	mov	x0, x22
100064e6c:     	bl	0x100217924 <dyld_stub_binder+0x100217924>
100064e70:     	cbz	x0, 0x1000650d8 <<la_stack::rational::RationalMatrix<8>>::solve+0x2e98>
100064e74:     	mov	x21, x0
100064e78:     	mov	x1, x20
100064e7c:     	mov	x2, x22
100064e80:     	bl	0x10021793c <dyld_stub_binder+0x10021793c>
100064e84:     	mov	x8, x26
100064e88:     	mov	w22, #0x1               ; =1
100064e8c:     	stp	x8, x21, [x29, #-0xa0]
100064e90:     	stur	x26, [x29, #-0x90]
100064e94:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064e98:     	add	x8, x8, #0x580
100064e9c:     	strb	w24, [x8, #0x2f8]
100064ea0:     	ldr	q0, [sp, #0x80]
100064ea4:     	stur	q0, [x29, #-0x80]
100064ea8:     	stur	x22, [x29, #-0x70]
100064eac:     	mov	w9, #0x2                ; =2
100064eb0:     	strb	w9, [x8, #0x318]
100064eb4:     	add	x0, sp, #0xb00
100064eb8:     	mov	x1, x19
100064ebc:     	bl	0x100089c78 <<num_rational::Ratio<num_bigint::bigint::BigInt> as core::clone::Clone>::clone>
100064ec0:     	sub	x0, x29, #0x100
100064ec4:     	sub	x1, x29, #0xa0
100064ec8:     	add	x2, sp, #0xb00
100064ecc:     	bl	0x1000896ec <<num_rational::Ratio<num_bigint::bigint::BigInt> as core::ops::arith::Mul>::mul>
100064ed0:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
100064ed4:     	add	x0, x0, #0x780
100064ed8:     	sub	x1, x29, #0x100
100064edc:     	bl	0x1000878a8 <<num_rational::Ratio<num_bigint::bigint::BigInt> as core::ops::arith::SubAssign>::sub_assign>
100064ee0:     	cmp	x23, #0x1
100064ee4:     	b.lt	0x100064de4 <<la_stack::rational::RationalMatrix<8>>::solve+0x2ba4>
100064ee8:     	mov	x0, x20
100064eec:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
100064ef0:     	b	0x100064de4 <<la_stack::rational::RationalMatrix<8>>::solve+0x2ba4>
100064ef4:     	sub	x23, x29, #0xa0
100064ef8:     	ldr	x21, [sp, #0x1580]
100064efc:     	add	x8, sp, #0xb00
100064f00:     	ldrb	w19, [x8, #0xa88]
100064f04:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064f08:     	add	x9, x9, #0x580
100064f0c:     	ldur	w8, [x9, #0x9]
100064f10:     	stur	w8, [x29, #-0xa0]
100064f14:     	ldr	w8, [sp, #0x158c]
100064f18:     	stur	w8, [x23, #0x3]
100064f1c:     	ldr	x24, [sp, #0x1590]
100064f20:     	ldrb	w20, [x9, #0x18]
100064f24:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064f28:     	add	x8, x8, #0x580
100064f2c:     	add	x0, sp, #0xb00
100064f30:     	add	x1, x8, #0x19
100064f34:     	mov	w2, #0x1e7              ; =487
100064f38:     	bl	0x10021793c <dyld_stub_binder+0x10021793c>
100064f3c:     	add	x0, sp, #0xa00
100064f40:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100064f44:     	add	x22, sp, #0xd10
100064f48:     	add	x0, sp, #0xd10
100064f4c:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100064f50:     	add	x0, x22, #0x100
100064f54:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100064f58:     	add	x0, x22, #0x200
100064f5c:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100064f60:     	add	x0, x22, #0x300
100064f64:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100064f68:     	add	x0, x22, #0x400
100064f6c:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100064f70:     	add	x0, x22, #0x500
100064f74:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100064f78:     	add	x0, x22, #0x600
100064f7c:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100064f80:     	add	x0, x22, #0x700
100064f84:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100064f88:     	cmn	x21, #0x2
100064f8c:     	b.ne	0x100065048 <<la_stack::rational::RationalMatrix<8>>::solve+0x2e08>
100064f90:     	sub	x21, x29, #0xa0
100064f94:     	b	0x100065000 <<la_stack::rational::RationalMatrix<8>>::solve+0x2dc0>
100064f98:     	ldur	x8, [x29, #-0x100]
100064f9c:     	cmp	x8, #0x1
100064fa0:     	b.lt	0x100064fac <<la_stack::rational::RationalMatrix<8>>::solve+0x2d6c>
100064fa4:     	ldur	x0, [x29, #-0xf8]
100064fa8:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
100064fac:     	add	x0, sp, #0xa00
100064fb0:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100064fb4:     	add	x19, sp, #0xd10
100064fb8:     	add	x0, sp, #0xd10
100064fbc:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100064fc0:     	add	x0, x19, #0x100
100064fc4:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100064fc8:     	add	x0, x19, #0x200
100064fcc:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100064fd0:     	add	x0, x19, #0x300
100064fd4:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100064fd8:     	add	x0, x19, #0x400
100064fdc:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100064fe0:     	add	x0, x19, #0x500
100064fe4:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100064fe8:     	add	x0, x19, #0x600
100064fec:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100064ff0:     	add	x0, x19, #0x700
100064ff4:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100064ff8:     	mov	w20, #0x0               ; =0
100064ffc:     	mov	w19, #0x3               ; =3
100065000:     	ldr	q0, [sp, #0xb00]
100065004:     	ldr	q1, [sp, #0xb10]
100065008:     	ldr	x9, [sp]
10006500c:     	stur	q0, [x9, #0x19]
100065010:     	ldur	w8, [x29, #-0xa0]
100065014:     	stur	w8, [x9, #0x9]
100065018:     	ldur	w8, [x21, #0x3]
10006501c:     	str	w8, [x9, #0xc]
100065020:     	stur	q1, [x9, #0x29]
100065024:     	add	x8, sp, #0xb00
100065028:     	ldur	x8, [x8, #0x1f]
10006502c:     	str	x8, [x9, #0x38]
100065030:     	strb	w19, [x9, #0x8]
100065034:     	str	x24, [x9, #0x10]
100065038:     	strb	w20, [x9, #0x18]
10006503c:     	mov	x8, #-0x2               ; =-2
100065040:     	str	x8, [x9]
100065044:     	b	0x10006507c <<la_stack::rational::RationalMatrix<8>>::solve+0x2e3c>
100065048:     	ldur	w8, [x29, #-0xa0]
10006504c:     	ldr	x22, [sp]
100065050:     	stur	w8, [x22, #0x9]
100065054:     	ldur	w8, [x23, #0x3]
100065058:     	str	w8, [x22, #0xc]
10006505c:     	add	x0, x22, #0x19
100065060:     	add	x1, sp, #0xb00
100065064:     	mov	w2, #0x1e7              ; =487
100065068:     	bl	0x10021793c <dyld_stub_binder+0x10021793c>
10006506c:     	str	x21, [x22]
100065070:     	strb	w19, [x22, #0x8]
100065074:     	str	x24, [x22, #0x10]
100065078:     	strb	w20, [x22, #0x18]
10006507c:     	add	x0, sp, #0x100
100065080:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100065084:     	add	sp, sp, #0x1, lsl #12   ; =0x1000
100065088:     	add	sp, sp, #0x8b0
10006508c:     	ldp	x29, x30, [sp, #0x50]
100065090:     	ldp	x20, x19, [sp, #0x40]
100065094:     	ldp	x22, x21, [sp, #0x30]
100065098:     	ldp	x24, x23, [sp, #0x20]
10006509c:     	ldp	x26, x25, [sp, #0x10]
1000650a0:     	ldp	x28, x27, [sp], #0x60
1000650a4:     	ret
1000650a8:     	ldr	x20, [sp]
1000650ac:     	add	x0, x20, #0x8
1000650b0:     	add	x1, sp, #0x200
1000650b4:     	mov	w2, #0x1f8              ; =504
1000650b8:     	bl	0x10021793c <dyld_stub_binder+0x10021793c>
1000650bc:     	str	x19, [x20]
1000650c0:     	b	0x100065084 <<la_stack::rational::RationalMatrix<8>>::solve+0x2e44>
1000650c4:     	adrp	x3, 0x1002bc000 <dyld_stub_binder+0x1002bc000>
1000650c8:     	add	x3, x3, #0x778
1000650cc:     	mov	w2, #0x8                ; =8
1000650d0:     	bl	0x100204934 <core::slice::index::slice_index_fail>
1000650d4:     	b	0x10006511c <<la_stack::rational::RationalMatrix<8>>::solve+0x2edc>
1000650d8:     	mov	w0, #0x8                ; =8
1000650dc:     	mov	x1, x22
1000650e0:     	bl	0x100203c1c <alloc::raw_vec::handle_error>
1000650e4:     	b	0x10006511c <<la_stack::rational::RationalMatrix<8>>::solve+0x2edc>
1000650e8:     	adrp	x2, 0x1002bc000 <dyld_stub_binder+0x1002bc000>
1000650ec:     	add	x2, x2, #0x760
1000650f0:     	mov	x0, x19
1000650f4:     	mov	w1, #0x8                ; =8
1000650f8:     	bl	0x1002049fc <core::panicking::panic_bounds_check>
1000650fc:     	b	0x10006511c <<la_stack::rational::RationalMatrix<8>>::solve+0x2edc>
100065100:     	mov	w0, #0x8                ; =8
100065104:     	mov	x1, x23
100065108:     	bl	0x100203c1c <alloc::raw_vec::handle_error>
10006510c:     	b	0x10006511c <<la_stack::rational::RationalMatrix<8>>::solve+0x2edc>
100065110:     	mov	w0, #0x8                ; =8
100065114:     	mov	x1, x23
100065118:     	bl	0x100203c1c <alloc::raw_vec::handle_error>
10006511c:     	brk	#0x1
100065120:     	mov	x22, x0
100065124:     	b	0x10006549c <<la_stack::rational::RationalMatrix<8>>::solve+0x325c>
100065128:     	mov	x22, x0
10006512c:     	cmp	x21, #0x1
100065130:     	b.lt	0x1000654ac <<la_stack::rational::RationalMatrix<8>>::solve+0x326c>
100065134:     	mov	x0, x19
100065138:     	b	0x1000654a8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3268>
10006513c:     	mov	x22, x0
100065140:     	mov	w23, #0x0               ; =0
100065144:     	b	0x100065480 <<la_stack::rational::RationalMatrix<8>>::solve+0x3240>
100065148:     	mov	x22, x0
10006514c:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
100065150:     	add	x0, x0, #0x580
100065154:     	bl	0x1000432d8 <core::ptr::drop_glue::<num_rational::Ratio<num_bigint::bigint::BigInt>>>
100065158:     	b	0x1000654ac <<la_stack::rational::RationalMatrix<8>>::solve+0x326c>
10006515c:     	mov	x22, x0
100065160:     	b	0x1000654ac <<la_stack::rational::RationalMatrix<8>>::solve+0x326c>
100065164:     	mov	x22, x0
100065168:     	b	0x100065188 <<la_stack::rational::RationalMatrix<8>>::solve+0x2f48>
10006516c:     	b	0x100065478 <<la_stack::rational::RationalMatrix<8>>::solve+0x3238>
100065170:     	mov	x22, x0
100065174:     	ldr	x8, [sp, #0xa00]
100065178:     	cmp	x8, #0x1
10006517c:     	b.lt	0x100065188 <<la_stack::rational::RationalMatrix<8>>::solve+0x2f48>
100065180:     	ldr	x0, [sp, #0xa08]
100065184:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
100065188:     	mov	w23, #0x0               ; =0
10006518c:     	mov	w24, #0x0               ; =0
100065190:     	b	0x1000651a8 <<la_stack::rational::RationalMatrix<8>>::solve+0x2f68>
100065194:     	mov	x22, x0
100065198:     	add	x0, sp, #0x200
10006519c:     	b	0x100065558 <<la_stack::rational::RationalMatrix<8>>::solve+0x3318>
1000651a0:     	b	0x100065478 <<la_stack::rational::RationalMatrix<8>>::solve+0x3238>
1000651a4:     	mov	x22, x0
1000651a8:     	ldur	x8, [x29, #-0xa0]
1000651ac:     	cmp	x8, #0x1
1000651b0:     	b.lt	0x1000651bc <<la_stack::rational::RationalMatrix<8>>::solve+0x2f7c>
1000651b4:     	ldur	x0, [x29, #-0x98]
1000651b8:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
1000651bc:     	cbnz	w24, 0x1000651cc <<la_stack::rational::RationalMatrix<8>>::solve+0x2f8c>
1000651c0:     	b	0x100065480 <<la_stack::rational::RationalMatrix<8>>::solve+0x3240>
1000651c4:     	mov	x22, x0
1000651c8:     	mov	w23, #0x1               ; =1
1000651cc:     	ldur	x8, [x29, #-0x100]
1000651d0:     	cmp	x8, #0x1
1000651d4:     	b.lt	0x100065480 <<la_stack::rational::RationalMatrix<8>>::solve+0x3240>
1000651d8:     	ldur	x0, [x29, #-0xf8]
1000651dc:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
1000651e0:     	b	0x100065480 <<la_stack::rational::RationalMatrix<8>>::solve+0x3240>
1000651e4:     	mov	x21, x0
1000651e8:     	ldr	x8, [sp, #0xf0]
1000651ec:     	cmp	x8, #0x1
1000651f0:     	b.lt	0x1000651fc <<la_stack::rational::RationalMatrix<8>>::solve+0x2fbc>
1000651f4:     	ldr	x0, [sp, #0xe0]
1000651f8:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
1000651fc:     	tbnz	w23, #0x0, 0x100065288 <<la_stack::rational::RationalMatrix<8>>::solve+0x3048>
100065200:     	ldr	x8, [sp, #0xd0]
100065204:     	cmp	x8, #0x1
100065208:     	b.lt	0x100065214 <<la_stack::rational::RationalMatrix<8>>::solve+0x2fd4>
10006520c:     	ldr	x0, [sp, #0xc0]
100065210:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
100065214:     	tbnz	w19, #0x0, 0x100065288 <<la_stack::rational::RationalMatrix<8>>::solve+0x3048>
100065218:     	ldr	x8, [sp, #0xb8]
10006521c:     	cmp	x8, #0x1
100065220:     	b.lt	0x10006522c <<la_stack::rational::RationalMatrix<8>>::solve+0x2fec>
100065224:     	ldr	x0, [sp, #0xb0]
100065228:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
10006522c:     	tbnz	w28, #0x0, 0x100065288 <<la_stack::rational::RationalMatrix<8>>::solve+0x3048>
100065230:     	ldr	x8, [sp, #0xa8]
100065234:     	cmp	x8, #0x1
100065238:     	b.lt	0x100065244 <<la_stack::rational::RationalMatrix<8>>::solve+0x3004>
10006523c:     	ldr	x0, [sp, #0xa0]
100065240:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
100065244:     	tbnz	w27, #0x0, 0x100065288 <<la_stack::rational::RationalMatrix<8>>::solve+0x3048>
100065248:     	ldr	x8, [sp, #0x98]
10006524c:     	cmp	x8, #0x1
100065250:     	b.lt	0x10006525c <<la_stack::rational::RationalMatrix<8>>::solve+0x301c>
100065254:     	ldr	x0, [sp, #0x80]
100065258:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
10006525c:     	tbnz	w20, #0x0, 0x100065288 <<la_stack::rational::RationalMatrix<8>>::solve+0x3048>
100065260:     	ldr	x8, [sp, #0x70]
100065264:     	cmp	x8, #0x1
100065268:     	b.lt	0x100065274 <<la_stack::rational::RationalMatrix<8>>::solve+0x3034>
10006526c:     	ldr	x0, [sp, #0x68]
100065270:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
100065274:     	cmp	x25, #0x0
100065278:     	csel	w8, wzr, w22, le
10006527c:     	cbz	w8, 0x100065288 <<la_stack::rational::RationalMatrix<8>>::solve+0x3048>
100065280:     	mov	x0, x26
100065284:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
100065288:     	add	x0, sp, #0x200
10006528c:     	mov	x22, x21
100065290:     	b	0x100065558 <<la_stack::rational::RationalMatrix<8>>::solve+0x3318>
100065294:     	ldp	x26, x25, [sp, #0xb0]
100065298:     	mov	x22, x0
10006529c:     	ldr	x8, [sp, #0xe0]
1000652a0:     	cmp	x8, #0x1
1000652a4:     	b.lt	0x1000652b0 <<la_stack::rational::RationalMatrix<8>>::solve+0x3070>
1000652a8:     	ldr	x0, [sp, #0xd0]
1000652ac:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
1000652b0:     	tbnz	w21, #0x0, 0x1000654b4 <<la_stack::rational::RationalMatrix<8>>::solve+0x3274>
1000652b4:     	ldr	x8, [sp, #0xc0]
1000652b8:     	cmp	x8, #0x1
1000652bc:     	b.lt	0x1000652c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3088>
1000652c0:     	ldr	x0, [sp, #0xa8]
1000652c4:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
1000652c8:     	tbnz	w24, #0x0, 0x1000654b4 <<la_stack::rational::RationalMatrix<8>>::solve+0x3274>
1000652cc:     	ldr	x8, [sp, #0xa0]
1000652d0:     	cmp	x8, #0x1
1000652d4:     	b.lt	0x1000652e0 <<la_stack::rational::RationalMatrix<8>>::solve+0x30a0>
1000652d8:     	ldr	x0, [sp, #0x98]
1000652dc:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
1000652e0:     	tbnz	w28, #0x0, 0x1000654b4 <<la_stack::rational::RationalMatrix<8>>::solve+0x3274>
1000652e4:     	ldr	x8, [sp, #0x80]
1000652e8:     	cmp	x8, #0x1
1000652ec:     	b.lt	0x1000652f8 <<la_stack::rational::RationalMatrix<8>>::solve+0x30b8>
1000652f0:     	ldr	x0, [sp, #0x70]
1000652f4:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
1000652f8:     	tbnz	w23, #0x0, 0x1000654b4 <<la_stack::rational::RationalMatrix<8>>::solve+0x3274>
1000652fc:     	ldr	x8, [sp, #0x68]
100065300:     	cmp	x8, #0x1
100065304:     	b.lt	0x100065310 <<la_stack::rational::RationalMatrix<8>>::solve+0x30d0>
100065308:     	ldr	x0, [sp, #0x60]
10006530c:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
100065310:     	tbnz	w19, #0x0, 0x1000654b4 <<la_stack::rational::RationalMatrix<8>>::solve+0x3274>
100065314:     	ldr	x8, [sp, #0x58]
100065318:     	cmp	x8, #0x1
10006531c:     	b.lt	0x100065328 <<la_stack::rational::RationalMatrix<8>>::solve+0x30e8>
100065320:     	ldr	x0, [sp, #0x50]
100065324:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
100065328:     	cmp	x26, #0x0
10006532c:     	csel	w8, wzr, w20, le
100065330:     	cbz	w8, 0x1000654b4 <<la_stack::rational::RationalMatrix<8>>::solve+0x3274>
100065334:     	mov	x0, x25
100065338:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
10006533c:     	mov	x0, x22
100065340:     	bl	0x1002176a8 <dyld_stub_binder+0x1002176a8>
100065344:     	b	0x100065534 <<la_stack::rational::RationalMatrix<8>>::solve+0x32f4>
100065348:     	mov	x22, x0
10006534c:     	sub	x0, x29, #0x100
100065350:     	b	0x1000654e4 <<la_stack::rational::RationalMatrix<8>>::solve+0x32a4>
100065354:     	mov	x22, x0
100065358:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
10006535c:     	add	x0, x0, #0x780
100065360:     	bl	0x1000432d8 <core::ptr::drop_glue::<num_rational::Ratio<num_bigint::bigint::BigInt>>>
100065364:     	sub	x0, x29, #0x100
100065368:     	b	0x1000654e4 <<la_stack::rational::RationalMatrix<8>>::solve+0x32a4>
10006536c:     	mov	x22, x0
100065370:     	b	0x100065444 <<la_stack::rational::RationalMatrix<8>>::solve+0x3204>
100065374:     	mov	x22, x0
100065378:     	mov	w28, #0x0               ; =0
10006537c:     	mov	w21, #0x0               ; =0
100065380:     	mov	w20, #0x0               ; =0
100065384:     	mov	w25, #0x0               ; =0
100065388:     	mov	w19, #0x1               ; =1
10006538c:     	mov	w24, #0x1               ; =1
100065390:     	b	0x1000653a0 <<la_stack::rational::RationalMatrix<8>>::solve+0x3160>
100065394:     	b	0x1000654cc <<la_stack::rational::RationalMatrix<8>>::solve+0x328c>
100065398:     	mov	x22, x0
10006539c:     	mov	w19, #0x0               ; =0
1000653a0:     	ldr	x8, [sp, #0xd0]
1000653a4:     	cmp	x8, #0x1
1000653a8:     	b.lt	0x1000653b4 <<la_stack::rational::RationalMatrix<8>>::solve+0x3174>
1000653ac:     	ldr	x0, [sp, #0xc0]
1000653b0:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
1000653b4:     	tbnz	w19, #0x0, 0x100065444 <<la_stack::rational::RationalMatrix<8>>::solve+0x3204>
1000653b8:     	ldr	x8, [sp, #0xb8]
1000653bc:     	cmp	x8, #0x1
1000653c0:     	b.lt	0x1000653cc <<la_stack::rational::RationalMatrix<8>>::solve+0x318c>
1000653c4:     	ldr	x0, [sp, #0xb0]
1000653c8:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
1000653cc:     	tbnz	w28, #0x0, 0x100065444 <<la_stack::rational::RationalMatrix<8>>::solve+0x3204>
1000653d0:     	ldr	x8, [sp, #0xa8]
1000653d4:     	cmp	x8, #0x1
1000653d8:     	b.lt	0x1000653e4 <<la_stack::rational::RationalMatrix<8>>::solve+0x31a4>
1000653dc:     	ldr	x0, [sp, #0xa0]
1000653e0:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
1000653e4:     	tbnz	w21, #0x0, 0x100065444 <<la_stack::rational::RationalMatrix<8>>::solve+0x3204>
1000653e8:     	ldr	x8, [sp, #0x98]
1000653ec:     	cmp	x8, #0x1
1000653f0:     	b.lt	0x1000653fc <<la_stack::rational::RationalMatrix<8>>::solve+0x31bc>
1000653f4:     	ldr	x0, [sp, #0x80]
1000653f8:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
1000653fc:     	tbnz	w20, #0x0, 0x100065444 <<la_stack::rational::RationalMatrix<8>>::solve+0x3204>
100065400:     	ldr	x8, [sp, #0x70]
100065404:     	cmp	x8, #0x1
100065408:     	b.lt	0x100065414 <<la_stack::rational::RationalMatrix<8>>::solve+0x31d4>
10006540c:     	ldr	x0, [sp, #0x68]
100065410:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
100065414:     	tbnz	w25, #0x0, 0x100065444 <<la_stack::rational::RationalMatrix<8>>::solve+0x3204>
100065418:     	ldr	x8, [sp, #0x58]
10006541c:     	cmp	x8, #0x1
100065420:     	b.lt	0x10006542c <<la_stack::rational::RationalMatrix<8>>::solve+0x31ec>
100065424:     	ldr	x0, [sp, #0x60]
100065428:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
10006542c:     	ldr	x8, [sp, #0x48]
100065430:     	cmp	x8, #0x0
100065434:     	csel	w8, wzr, w24, le
100065438:     	cbz	w8, 0x100065444 <<la_stack::rational::RationalMatrix<8>>::solve+0x3204>
10006543c:     	ldr	x0, [sp, #0x50]
100065440:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
100065444:     	ldr	x20, [sp, #0xe0]
100065448:     	cbz	x20, 0x10006555c <<la_stack::rational::RationalMatrix<8>>::solve+0x331c>
10006544c:     	add	x19, sp, #0xd10
100065450:     	mov	x0, x19
100065454:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100065458:     	add	x19, x19, #0x100
10006545c:     	subs	x20, x20, #0x1
100065460:     	b.ne	0x100065450 <<la_stack::rational::RationalMatrix<8>>::solve+0x3210>
100065464:     	b	0x10006555c <<la_stack::rational::RationalMatrix<8>>::solve+0x331c>
100065468:     	mov	x22, x0
10006546c:     	sub	x0, x29, #0xa0
100065470:     	bl	0x1000432d8 <core::ptr::drop_glue::<num_rational::Ratio<num_bigint::bigint::BigInt>>>
100065474:     	b	0x1000654d0 <<la_stack::rational::RationalMatrix<8>>::solve+0x3290>
100065478:     	mov	x22, x0
10006547c:     	mov	w23, #0x1               ; =1
100065480:     	ldr	x8, [sp, #0x17c0]
100065484:     	cmp	x8, #0x1
100065488:     	b.lt	0x100065494 <<la_stack::rational::RationalMatrix<8>>::solve+0x3254>
10006548c:     	ldr	x0, [sp, #0x17c8]
100065490:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
100065494:     	cbz	w23, 0x1000654ac <<la_stack::rational::RationalMatrix<8>>::solve+0x326c>
100065498:     	ldr	x24, [sp, #0x1780]
10006549c:     	cmp	x24, #0x1
1000654a0:     	b.lt	0x1000654ac <<la_stack::rational::RationalMatrix<8>>::solve+0x326c>
1000654a4:     	ldr	x0, [sp, #0x1788]
1000654a8:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
1000654ac:     	add	x0, sp, #0xd10
1000654b0:     	bl	0x100042dbc <core::ptr::drop_glue::<[num_rational::Ratio<num_bigint::bigint::BigInt>; 8]>>
1000654b4:     	mov	x0, x22
1000654b8:     	bl	0x1002176a8 <dyld_stub_binder+0x1002176a8>
1000654bc:     	b	0x100065534 <<la_stack::rational::RationalMatrix<8>>::solve+0x32f4>
1000654c0:     	b	0x100065514 <<la_stack::rational::RationalMatrix<8>>::solve+0x32d4>
1000654c4:     	b	0x1000654f8 <<la_stack::rational::RationalMatrix<8>>::solve+0x32b8>
1000654c8:     	b	0x100065534 <<la_stack::rational::RationalMatrix<8>>::solve+0x32f4>
1000654cc:     	mov	x22, x0
1000654d0:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000654d4:     	add	x0, x0, #0x7c0
1000654d8:     	bl	0x1000432d8 <core::ptr::drop_glue::<num_rational::Ratio<num_bigint::bigint::BigInt>>>
1000654dc:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000654e0:     	add	x0, x0, #0x780
1000654e4:     	bl	0x1000432d8 <core::ptr::drop_glue::<num_rational::Ratio<num_bigint::bigint::BigInt>>>
1000654e8:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000654ec:     	add	x0, x0, #0x580
1000654f0:     	bl	0x100042dbc <core::ptr::drop_glue::<[num_rational::Ratio<num_bigint::bigint::BigInt>; 8]>>
1000654f4:     	b	0x10006554c <<la_stack::rational::RationalMatrix<8>>::solve+0x330c>
1000654f8:     	mov	x22, x0
1000654fc:     	ldur	x8, [x29, #-0xa0]
100065500:     	cmp	x8, #0x1
100065504:     	b.lt	0x100065538 <<la_stack::rational::RationalMatrix<8>>::solve+0x32f8>
100065508:     	ldur	x0, [x29, #-0x98]
10006550c:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
100065510:     	b	0x100065538 <<la_stack::rational::RationalMatrix<8>>::solve+0x32f8>
100065514:     	mov	x22, x0
100065518:     	ldr	x8, [sp, #0xb00]
10006551c:     	cmp	x8, #0x1
100065520:     	b.lt	0x100065538 <<la_stack::rational::RationalMatrix<8>>::solve+0x32f8>
100065524:     	ldr	x0, [sp, #0xb08]
100065528:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
10006552c:     	b	0x100065538 <<la_stack::rational::RationalMatrix<8>>::solve+0x32f8>
100065530:     	b	0x100065534 <<la_stack::rational::RationalMatrix<8>>::solve+0x32f4>
100065534:     	mov	x22, x0
100065538:     	ldur	x8, [x29, #-0x100]
10006553c:     	cmp	x8, #0x1
100065540:     	b.lt	0x10006554c <<la_stack::rational::RationalMatrix<8>>::solve+0x330c>
100065544:     	ldur	x0, [x29, #-0xf8]
100065548:     	bl	0x100217888 <dyld_stub_binder+0x100217888>
10006554c:     	add	x0, sp, #0xa00
100065550:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100065554:     	add	x0, sp, #0xd10
100065558:     	bl	0x10004280c <core::ptr::drop_glue::<[[num_bigint::bigint::BigInt; 8]; 8]>>
10006555c:     	add	x0, sp, #0x100
100065560:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100065564:     	mov	x0, x22
100065568:     	bl	0x1002176a8 <dyld_stub_binder+0x1002176a8>
10006556c:     	nop
100065570:     	nop
100065574:     	nop
100065578:     	nop
10006557c:     	nop
