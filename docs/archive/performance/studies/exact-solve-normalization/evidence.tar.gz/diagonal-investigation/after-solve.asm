
target/exact-normalization-20261018/after-rational-solve:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100063c80 <<la_stack::rational::RationalMatrix<8>>::solve>:
100063c80:     	stp	x28, x27, [sp, #-0x60]!
100063c84:     	stp	x26, x25, [sp, #0x10]
100063c88:     	stp	x24, x23, [sp, #0x20]
100063c8c:     	stp	x22, x21, [sp, #0x30]
100063c90:     	stp	x20, x19, [sp, #0x40]
100063c94:     	stp	x29, x30, [sp, #0x50]
100063c98:     	add	x29, sp, #0x50
100063c9c:     	sub	sp, sp, #0x1, lsl #12   ; =0x1000
100063ca0:     	ldr	xzr, [sp]
100063ca4:     	sub	sp, sp, #0x910
100063ca8:     	ldr	xzr, [sp]
100063cac:     	mov	x28, x2
100063cb0:     	mov	x26, x1
100063cb4:     	str	xzr, [sp, #0xd10]
100063cb8:     	str	xzr, [sp, #0x16c0]
100063cbc:     	add	x8, sp, #0xae0
100063cc0:     	str	xzr, [sp, #0x15c0]
100063cc4:     	str	xzr, [sp, #0x9e0]
100063cc8:     	stp	x1, xzr, [sp, #0xd8]
100063ccc:     	stur	xzr, [x29, #-0xa0]
100063cd0:     	str	xzr, [sp, #0x1580]
100063cd4:     	str	xzr, [sp, #0xcd0]
100063cd8:     	strb	wzr, [sp, #0xcf0]
100063cdc:     	strb	wzr, [x8, #0xa90]
100063ce0:     	strb	wzr, [x8, #0xa80]
100063ce4:     	strb	wzr, [x8, #0xa70]
100063ce8:     	strb	wzr, [x8, #0xa60]
100063cec:     	strb	wzr, [x8, #0xa50]
100063cf0:     	strb	wzr, [x8, #0xa40]
100063cf4:     	strb	wzr, [x8, #0xa30]
100063cf8:     	ldrb	w8, [x1, #0x18]
100063cfc:     	cmp	w8, #0x1
100063d00:     	str	x2, [sp, #0x40]
100063d04:     	str	x0, [sp]
100063d08:     	b.eq	0x100063d18 <<la_stack::rational::RationalMatrix<8>>::solve+0x98>
100063d0c:     	add	x9, sp, #0xcf0
100063d10:     	add	x10, sp, #0xd10
100063d14:     	b	0x100063de4 <<la_stack::rational::RationalMatrix<8>>::solve+0x164>
100063d18:     	ldrb	w9, [x26, #0x58]
100063d1c:     	cmp	w9, #0x1
100063d20:     	b.ne	0x100063d7c <<la_stack::rational::RationalMatrix<8>>::solve+0xfc>
100063d24:     	ldrb	w9, [x26, #0x98]
100063d28:     	cmp	w9, #0x1
100063d2c:     	b.ne	0x100063d90 <<la_stack::rational::RationalMatrix<8>>::solve+0x110>
100063d30:     	ldrb	w9, [x26, #0xd8]
100063d34:     	cmp	w9, #0x1
100063d38:     	b.ne	0x100063da4 <<la_stack::rational::RationalMatrix<8>>::solve+0x124>
100063d3c:     	ldrb	w9, [x26, #0x118]
100063d40:     	cmp	w9, #0x1
100063d44:     	b.ne	0x100063db4 <<la_stack::rational::RationalMatrix<8>>::solve+0x134>
100063d48:     	ldrb	w9, [x26, #0x158]
100063d4c:     	cmp	w9, #0x1
100063d50:     	b.ne	0x100063dc4 <<la_stack::rational::RationalMatrix<8>>::solve+0x144>
100063d54:     	ldrb	w9, [x26, #0x198]
100063d58:     	cmp	w9, #0x1
100063d5c:     	b.ne	0x100063dd4 <<la_stack::rational::RationalMatrix<8>>::solve+0x154>
100063d60:     	ldrb	w9, [x26, #0x1d8]
100063d64:     	cmp	w9, #0x1
100063d68:     	b.eq	0x1000644c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x848>
100063d6c:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100063d70:     	add	x9, x9, #0x510
100063d74:     	add	x10, sp, #0xcd0
100063d78:     	b	0x100063de4 <<la_stack::rational::RationalMatrix<8>>::solve+0x164>
100063d7c:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100063d80:     	add	x9, x9, #0x570
100063d84:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100063d88:     	add	x10, x10, #0x6c0
100063d8c:     	b	0x100063de4 <<la_stack::rational::RationalMatrix<8>>::solve+0x164>
100063d90:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100063d94:     	add	x9, x9, #0x560
100063d98:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100063d9c:     	add	x10, x10, #0x5c0
100063da0:     	b	0x100063de4 <<la_stack::rational::RationalMatrix<8>>::solve+0x164>
100063da4:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100063da8:     	add	x9, x9, #0x550
100063dac:     	add	x10, sp, #0x9e0
100063db0:     	b	0x100063de4 <<la_stack::rational::RationalMatrix<8>>::solve+0x164>
100063db4:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100063db8:     	add	x9, x9, #0x540
100063dbc:     	add	x10, sp, #0xe0
100063dc0:     	b	0x100063de4 <<la_stack::rational::RationalMatrix<8>>::solve+0x164>
100063dc4:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100063dc8:     	add	x9, x9, #0x530
100063dcc:     	sub	x10, x29, #0xa0
100063dd0:     	b	0x100063de4 <<la_stack::rational::RationalMatrix<8>>::solve+0x164>
100063dd4:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100063dd8:     	add	x9, x9, #0x520
100063ddc:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100063de0:     	add	x10, x10, #0x580
100063de4:     	ldrb	w11, [x9]
100063de8:     	tbnz	w11, #0x0, 0x1000644c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x848>
100063dec:     	mov	w11, #0x1               ; =1
100063df0:     	strb	w11, [x9]
100063df4:     	str	xzr, [x10]
100063df8:     	ldrb	w9, [x26, #0x218]
100063dfc:     	cmp	w9, #0x1
100063e00:     	b.ne	0x100063e68 <<la_stack::rational::RationalMatrix<8>>::solve+0x1e8>
100063e04:     	ldrb	w9, [x26, #0x258]
100063e08:     	cmp	w9, #0x1
100063e0c:     	b.ne	0x100063e74 <<la_stack::rational::RationalMatrix<8>>::solve+0x1f4>
100063e10:     	ldrb	w9, [x26, #0x298]
100063e14:     	cmp	w9, #0x1
100063e18:     	b.ne	0x100063e88 <<la_stack::rational::RationalMatrix<8>>::solve+0x208>
100063e1c:     	ldrb	w9, [x26, #0x2d8]
100063e20:     	cmp	w9, #0x1
100063e24:     	b.ne	0x100063e9c <<la_stack::rational::RationalMatrix<8>>::solve+0x21c>
100063e28:     	ldrb	w9, [x26, #0x318]
100063e2c:     	cmp	w9, #0x1
100063e30:     	b.ne	0x100063eac <<la_stack::rational::RationalMatrix<8>>::solve+0x22c>
100063e34:     	ldrb	w9, [x26, #0x358]
100063e38:     	cmp	w9, #0x1
100063e3c:     	b.ne	0x100063ebc <<la_stack::rational::RationalMatrix<8>>::solve+0x23c>
100063e40:     	ldrb	w9, [x26, #0x398]
100063e44:     	cmp	w9, #0x1
100063e48:     	b.ne	0x100063ecc <<la_stack::rational::RationalMatrix<8>>::solve+0x24c>
100063e4c:     	ldrb	w9, [x26, #0x3d8]
100063e50:     	cmp	w9, #0x1
100063e54:     	b.eq	0x1000644c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x848>
100063e58:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100063e5c:     	add	x9, x9, #0x510
100063e60:     	add	x10, sp, #0xcd0
100063e64:     	b	0x100063edc <<la_stack::rational::RationalMatrix<8>>::solve+0x25c>
100063e68:     	add	x9, sp, #0xcf0
100063e6c:     	add	x10, sp, #0xd10
100063e70:     	b	0x100063edc <<la_stack::rational::RationalMatrix<8>>::solve+0x25c>
100063e74:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100063e78:     	add	x9, x9, #0x570
100063e7c:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100063e80:     	add	x10, x10, #0x6c0
100063e84:     	b	0x100063edc <<la_stack::rational::RationalMatrix<8>>::solve+0x25c>
100063e88:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100063e8c:     	add	x9, x9, #0x560
100063e90:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100063e94:     	add	x10, x10, #0x5c0
100063e98:     	b	0x100063edc <<la_stack::rational::RationalMatrix<8>>::solve+0x25c>
100063e9c:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100063ea0:     	add	x9, x9, #0x550
100063ea4:     	add	x10, sp, #0x9e0
100063ea8:     	b	0x100063edc <<la_stack::rational::RationalMatrix<8>>::solve+0x25c>
100063eac:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100063eb0:     	add	x9, x9, #0x540
100063eb4:     	add	x10, sp, #0xe0
100063eb8:     	b	0x100063edc <<la_stack::rational::RationalMatrix<8>>::solve+0x25c>
100063ebc:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100063ec0:     	add	x9, x9, #0x530
100063ec4:     	sub	x10, x29, #0xa0
100063ec8:     	b	0x100063edc <<la_stack::rational::RationalMatrix<8>>::solve+0x25c>
100063ecc:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100063ed0:     	add	x9, x9, #0x520
100063ed4:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100063ed8:     	add	x10, x10, #0x580
100063edc:     	ldrb	w11, [x9]
100063ee0:     	tbnz	w11, #0x0, 0x1000644c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x848>
100063ee4:     	mov	w11, #0x1               ; =1
100063ee8:     	strb	w11, [x9]
100063eec:     	str	x11, [x10]
100063ef0:     	ldrb	w9, [x26, #0x418]
100063ef4:     	cmp	w9, #0x1
100063ef8:     	b.ne	0x100063f60 <<la_stack::rational::RationalMatrix<8>>::solve+0x2e0>
100063efc:     	ldrb	w9, [x26, #0x458]
100063f00:     	cmp	w9, #0x1
100063f04:     	b.ne	0x100063f6c <<la_stack::rational::RationalMatrix<8>>::solve+0x2ec>
100063f08:     	ldrb	w9, [x26, #0x498]
100063f0c:     	cmp	w9, #0x1
100063f10:     	b.ne	0x100063f80 <<la_stack::rational::RationalMatrix<8>>::solve+0x300>
100063f14:     	ldrb	w9, [x26, #0x4d8]
100063f18:     	cmp	w9, #0x1
100063f1c:     	b.ne	0x100063f94 <<la_stack::rational::RationalMatrix<8>>::solve+0x314>
100063f20:     	ldrb	w9, [x26, #0x518]
100063f24:     	cmp	w9, #0x1
100063f28:     	b.ne	0x100063fa4 <<la_stack::rational::RationalMatrix<8>>::solve+0x324>
100063f2c:     	ldrb	w9, [x26, #0x558]
100063f30:     	cmp	w9, #0x1
100063f34:     	b.ne	0x100063fb4 <<la_stack::rational::RationalMatrix<8>>::solve+0x334>
100063f38:     	ldrb	w9, [x26, #0x598]
100063f3c:     	cmp	w9, #0x1
100063f40:     	b.ne	0x100063fc4 <<la_stack::rational::RationalMatrix<8>>::solve+0x344>
100063f44:     	ldrb	w9, [x26, #0x5d8]
100063f48:     	cmp	w9, #0x1
100063f4c:     	b.eq	0x1000644c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x848>
100063f50:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100063f54:     	add	x9, x9, #0x510
100063f58:     	add	x10, sp, #0xcd0
100063f5c:     	b	0x100063fd4 <<la_stack::rational::RationalMatrix<8>>::solve+0x354>
100063f60:     	add	x9, sp, #0xcf0
100063f64:     	add	x10, sp, #0xd10
100063f68:     	b	0x100063fd4 <<la_stack::rational::RationalMatrix<8>>::solve+0x354>
100063f6c:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100063f70:     	add	x9, x9, #0x570
100063f74:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100063f78:     	add	x10, x10, #0x6c0
100063f7c:     	b	0x100063fd4 <<la_stack::rational::RationalMatrix<8>>::solve+0x354>
100063f80:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100063f84:     	add	x9, x9, #0x560
100063f88:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100063f8c:     	add	x10, x10, #0x5c0
100063f90:     	b	0x100063fd4 <<la_stack::rational::RationalMatrix<8>>::solve+0x354>
100063f94:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100063f98:     	add	x9, x9, #0x550
100063f9c:     	add	x10, sp, #0x9e0
100063fa0:     	b	0x100063fd4 <<la_stack::rational::RationalMatrix<8>>::solve+0x354>
100063fa4:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100063fa8:     	add	x9, x9, #0x540
100063fac:     	add	x10, sp, #0xe0
100063fb0:     	b	0x100063fd4 <<la_stack::rational::RationalMatrix<8>>::solve+0x354>
100063fb4:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100063fb8:     	add	x9, x9, #0x530
100063fbc:     	sub	x10, x29, #0xa0
100063fc0:     	b	0x100063fd4 <<la_stack::rational::RationalMatrix<8>>::solve+0x354>
100063fc4:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100063fc8:     	add	x9, x9, #0x520
100063fcc:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100063fd0:     	add	x10, x10, #0x580
100063fd4:     	ldrb	w11, [x9]
100063fd8:     	tbnz	w11, #0x0, 0x1000644c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x848>
100063fdc:     	mov	w11, #0x1               ; =1
100063fe0:     	strb	w11, [x9]
100063fe4:     	mov	w9, #0x2                ; =2
100063fe8:     	str	x9, [x10]
100063fec:     	ldrb	w9, [x26, #0x618]
100063ff0:     	cmp	w9, #0x1
100063ff4:     	b.ne	0x10006405c <<la_stack::rational::RationalMatrix<8>>::solve+0x3dc>
100063ff8:     	ldrb	w9, [x26, #0x658]
100063ffc:     	cmp	w9, #0x1
100064000:     	b.ne	0x100064068 <<la_stack::rational::RationalMatrix<8>>::solve+0x3e8>
100064004:     	ldrb	w9, [x26, #0x698]
100064008:     	cmp	w9, #0x1
10006400c:     	b.ne	0x10006407c <<la_stack::rational::RationalMatrix<8>>::solve+0x3fc>
100064010:     	ldrb	w9, [x26, #0x6d8]
100064014:     	cmp	w9, #0x1
100064018:     	b.ne	0x100064090 <<la_stack::rational::RationalMatrix<8>>::solve+0x410>
10006401c:     	ldrb	w9, [x26, #0x718]
100064020:     	cmp	w9, #0x1
100064024:     	b.ne	0x1000640a0 <<la_stack::rational::RationalMatrix<8>>::solve+0x420>
100064028:     	ldrb	w9, [x26, #0x758]
10006402c:     	cmp	w9, #0x1
100064030:     	b.ne	0x1000640b0 <<la_stack::rational::RationalMatrix<8>>::solve+0x430>
100064034:     	ldrb	w9, [x26, #0x798]
100064038:     	cmp	w9, #0x1
10006403c:     	b.ne	0x1000640c0 <<la_stack::rational::RationalMatrix<8>>::solve+0x440>
100064040:     	ldrb	w9, [x26, #0x7d8]
100064044:     	cmp	w9, #0x1
100064048:     	b.eq	0x1000644c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x848>
10006404c:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064050:     	add	x9, x9, #0x510
100064054:     	add	x10, sp, #0xcd0
100064058:     	b	0x1000640d0 <<la_stack::rational::RationalMatrix<8>>::solve+0x450>
10006405c:     	add	x9, sp, #0xcf0
100064060:     	add	x10, sp, #0xd10
100064064:     	b	0x1000640d0 <<la_stack::rational::RationalMatrix<8>>::solve+0x450>
100064068:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
10006406c:     	add	x9, x9, #0x570
100064070:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100064074:     	add	x10, x10, #0x6c0
100064078:     	b	0x1000640d0 <<la_stack::rational::RationalMatrix<8>>::solve+0x450>
10006407c:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064080:     	add	x9, x9, #0x560
100064084:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100064088:     	add	x10, x10, #0x5c0
10006408c:     	b	0x1000640d0 <<la_stack::rational::RationalMatrix<8>>::solve+0x450>
100064090:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064094:     	add	x9, x9, #0x550
100064098:     	add	x10, sp, #0x9e0
10006409c:     	b	0x1000640d0 <<la_stack::rational::RationalMatrix<8>>::solve+0x450>
1000640a0:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
1000640a4:     	add	x9, x9, #0x540
1000640a8:     	add	x10, sp, #0xe0
1000640ac:     	b	0x1000640d0 <<la_stack::rational::RationalMatrix<8>>::solve+0x450>
1000640b0:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
1000640b4:     	add	x9, x9, #0x530
1000640b8:     	sub	x10, x29, #0xa0
1000640bc:     	b	0x1000640d0 <<la_stack::rational::RationalMatrix<8>>::solve+0x450>
1000640c0:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
1000640c4:     	add	x9, x9, #0x520
1000640c8:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
1000640cc:     	add	x10, x10, #0x580
1000640d0:     	ldrb	w11, [x9]
1000640d4:     	tbnz	w11, #0x0, 0x1000644c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x848>
1000640d8:     	mov	w11, #0x1               ; =1
1000640dc:     	strb	w11, [x9]
1000640e0:     	mov	w9, #0x3                ; =3
1000640e4:     	str	x9, [x10]
1000640e8:     	ldrb	w9, [x26, #0x818]
1000640ec:     	cmp	w9, #0x1
1000640f0:     	b.ne	0x100064158 <<la_stack::rational::RationalMatrix<8>>::solve+0x4d8>
1000640f4:     	ldrb	w9, [x26, #0x858]
1000640f8:     	cmp	w9, #0x1
1000640fc:     	b.ne	0x100064164 <<la_stack::rational::RationalMatrix<8>>::solve+0x4e4>
100064100:     	ldrb	w9, [x26, #0x898]
100064104:     	cmp	w9, #0x1
100064108:     	b.ne	0x100064178 <<la_stack::rational::RationalMatrix<8>>::solve+0x4f8>
10006410c:     	ldrb	w9, [x26, #0x8d8]
100064110:     	cmp	w9, #0x1
100064114:     	b.ne	0x10006418c <<la_stack::rational::RationalMatrix<8>>::solve+0x50c>
100064118:     	ldrb	w9, [x26, #0x918]
10006411c:     	cmp	w9, #0x1
100064120:     	b.ne	0x10006419c <<la_stack::rational::RationalMatrix<8>>::solve+0x51c>
100064124:     	ldrb	w9, [x26, #0x958]
100064128:     	cmp	w9, #0x1
10006412c:     	b.ne	0x1000641ac <<la_stack::rational::RationalMatrix<8>>::solve+0x52c>
100064130:     	ldrb	w9, [x26, #0x998]
100064134:     	cmp	w9, #0x1
100064138:     	b.ne	0x1000641bc <<la_stack::rational::RationalMatrix<8>>::solve+0x53c>
10006413c:     	ldrb	w9, [x26, #0x9d8]
100064140:     	cmp	w9, #0x1
100064144:     	b.eq	0x1000644c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x848>
100064148:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
10006414c:     	add	x9, x9, #0x510
100064150:     	add	x10, sp, #0xcd0
100064154:     	b	0x1000641cc <<la_stack::rational::RationalMatrix<8>>::solve+0x54c>
100064158:     	add	x9, sp, #0xcf0
10006415c:     	add	x10, sp, #0xd10
100064160:     	b	0x1000641cc <<la_stack::rational::RationalMatrix<8>>::solve+0x54c>
100064164:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064168:     	add	x9, x9, #0x570
10006416c:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100064170:     	add	x10, x10, #0x6c0
100064174:     	b	0x1000641cc <<la_stack::rational::RationalMatrix<8>>::solve+0x54c>
100064178:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
10006417c:     	add	x9, x9, #0x560
100064180:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100064184:     	add	x10, x10, #0x5c0
100064188:     	b	0x1000641cc <<la_stack::rational::RationalMatrix<8>>::solve+0x54c>
10006418c:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064190:     	add	x9, x9, #0x550
100064194:     	add	x10, sp, #0x9e0
100064198:     	b	0x1000641cc <<la_stack::rational::RationalMatrix<8>>::solve+0x54c>
10006419c:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
1000641a0:     	add	x9, x9, #0x540
1000641a4:     	add	x10, sp, #0xe0
1000641a8:     	b	0x1000641cc <<la_stack::rational::RationalMatrix<8>>::solve+0x54c>
1000641ac:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
1000641b0:     	add	x9, x9, #0x530
1000641b4:     	sub	x10, x29, #0xa0
1000641b8:     	b	0x1000641cc <<la_stack::rational::RationalMatrix<8>>::solve+0x54c>
1000641bc:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
1000641c0:     	add	x9, x9, #0x520
1000641c4:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
1000641c8:     	add	x10, x10, #0x580
1000641cc:     	ldrb	w11, [x9]
1000641d0:     	tbnz	w11, #0x0, 0x1000644c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x848>
1000641d4:     	mov	w11, #0x1               ; =1
1000641d8:     	strb	w11, [x9]
1000641dc:     	mov	w9, #0x4                ; =4
1000641e0:     	str	x9, [x10]
1000641e4:     	ldrb	w9, [x26, #0xa18]
1000641e8:     	cmp	w9, #0x1
1000641ec:     	b.ne	0x100064254 <<la_stack::rational::RationalMatrix<8>>::solve+0x5d4>
1000641f0:     	ldrb	w9, [x26, #0xa58]
1000641f4:     	cmp	w9, #0x1
1000641f8:     	b.ne	0x100064260 <<la_stack::rational::RationalMatrix<8>>::solve+0x5e0>
1000641fc:     	ldrb	w9, [x26, #0xa98]
100064200:     	cmp	w9, #0x1
100064204:     	b.ne	0x100064274 <<la_stack::rational::RationalMatrix<8>>::solve+0x5f4>
100064208:     	ldrb	w9, [x26, #0xad8]
10006420c:     	cmp	w9, #0x1
100064210:     	b.ne	0x100064288 <<la_stack::rational::RationalMatrix<8>>::solve+0x608>
100064214:     	ldrb	w9, [x26, #0xb18]
100064218:     	cmp	w9, #0x1
10006421c:     	b.ne	0x100064298 <<la_stack::rational::RationalMatrix<8>>::solve+0x618>
100064220:     	ldrb	w9, [x26, #0xb58]
100064224:     	cmp	w9, #0x1
100064228:     	b.ne	0x1000642a8 <<la_stack::rational::RationalMatrix<8>>::solve+0x628>
10006422c:     	ldrb	w9, [x26, #0xb98]
100064230:     	cmp	w9, #0x1
100064234:     	b.ne	0x1000642b8 <<la_stack::rational::RationalMatrix<8>>::solve+0x638>
100064238:     	ldrb	w9, [x26, #0xbd8]
10006423c:     	cmp	w9, #0x1
100064240:     	b.eq	0x1000644c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x848>
100064244:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064248:     	add	x9, x9, #0x510
10006424c:     	add	x10, sp, #0xcd0
100064250:     	b	0x1000642c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x648>
100064254:     	add	x9, sp, #0xcf0
100064258:     	add	x10, sp, #0xd10
10006425c:     	b	0x1000642c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x648>
100064260:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064264:     	add	x9, x9, #0x570
100064268:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
10006426c:     	add	x10, x10, #0x6c0
100064270:     	b	0x1000642c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x648>
100064274:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064278:     	add	x9, x9, #0x560
10006427c:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100064280:     	add	x10, x10, #0x5c0
100064284:     	b	0x1000642c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x648>
100064288:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
10006428c:     	add	x9, x9, #0x550
100064290:     	add	x10, sp, #0x9e0
100064294:     	b	0x1000642c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x648>
100064298:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
10006429c:     	add	x9, x9, #0x540
1000642a0:     	add	x10, sp, #0xe0
1000642a4:     	b	0x1000642c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x648>
1000642a8:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
1000642ac:     	add	x9, x9, #0x530
1000642b0:     	sub	x10, x29, #0xa0
1000642b4:     	b	0x1000642c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x648>
1000642b8:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
1000642bc:     	add	x9, x9, #0x520
1000642c0:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
1000642c4:     	add	x10, x10, #0x580
1000642c8:     	ldrb	w11, [x9]
1000642cc:     	tbnz	w11, #0x0, 0x1000644c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x848>
1000642d0:     	mov	w11, #0x1               ; =1
1000642d4:     	strb	w11, [x9]
1000642d8:     	mov	w9, #0x5                ; =5
1000642dc:     	str	x9, [x10]
1000642e0:     	ldrb	w9, [x26, #0xc18]
1000642e4:     	cmp	w9, #0x1
1000642e8:     	b.ne	0x100064350 <<la_stack::rational::RationalMatrix<8>>::solve+0x6d0>
1000642ec:     	ldrb	w9, [x26, #0xc58]
1000642f0:     	cmp	w9, #0x1
1000642f4:     	b.ne	0x10006435c <<la_stack::rational::RationalMatrix<8>>::solve+0x6dc>
1000642f8:     	ldrb	w9, [x26, #0xc98]
1000642fc:     	cmp	w9, #0x1
100064300:     	b.ne	0x100064370 <<la_stack::rational::RationalMatrix<8>>::solve+0x6f0>
100064304:     	ldrb	w9, [x26, #0xcd8]
100064308:     	cmp	w9, #0x1
10006430c:     	b.ne	0x100064384 <<la_stack::rational::RationalMatrix<8>>::solve+0x704>
100064310:     	ldrb	w9, [x26, #0xd18]
100064314:     	cmp	w9, #0x1
100064318:     	b.ne	0x100064394 <<la_stack::rational::RationalMatrix<8>>::solve+0x714>
10006431c:     	ldrb	w9, [x26, #0xd58]
100064320:     	cmp	w9, #0x1
100064324:     	b.ne	0x1000643a4 <<la_stack::rational::RationalMatrix<8>>::solve+0x724>
100064328:     	ldrb	w9, [x26, #0xd98]
10006432c:     	cmp	w9, #0x1
100064330:     	b.ne	0x1000643b4 <<la_stack::rational::RationalMatrix<8>>::solve+0x734>
100064334:     	ldrb	w9, [x26, #0xdd8]
100064338:     	cmp	w9, #0x1
10006433c:     	b.eq	0x1000644c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x848>
100064340:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064344:     	add	x9, x9, #0x510
100064348:     	add	x10, sp, #0xcd0
10006434c:     	b	0x1000643c4 <<la_stack::rational::RationalMatrix<8>>::solve+0x744>
100064350:     	add	x9, sp, #0xcf0
100064354:     	add	x10, sp, #0xd10
100064358:     	b	0x1000643c4 <<la_stack::rational::RationalMatrix<8>>::solve+0x744>
10006435c:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064360:     	add	x9, x9, #0x570
100064364:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100064368:     	add	x10, x10, #0x6c0
10006436c:     	b	0x1000643c4 <<la_stack::rational::RationalMatrix<8>>::solve+0x744>
100064370:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064374:     	add	x9, x9, #0x560
100064378:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
10006437c:     	add	x10, x10, #0x5c0
100064380:     	b	0x1000643c4 <<la_stack::rational::RationalMatrix<8>>::solve+0x744>
100064384:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064388:     	add	x9, x9, #0x550
10006438c:     	add	x10, sp, #0x9e0
100064390:     	b	0x1000643c4 <<la_stack::rational::RationalMatrix<8>>::solve+0x744>
100064394:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064398:     	add	x9, x9, #0x540
10006439c:     	add	x10, sp, #0xe0
1000643a0:     	b	0x1000643c4 <<la_stack::rational::RationalMatrix<8>>::solve+0x744>
1000643a4:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
1000643a8:     	add	x9, x9, #0x530
1000643ac:     	sub	x10, x29, #0xa0
1000643b0:     	b	0x1000643c4 <<la_stack::rational::RationalMatrix<8>>::solve+0x744>
1000643b4:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
1000643b8:     	add	x9, x9, #0x520
1000643bc:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
1000643c0:     	add	x10, x10, #0x580
1000643c4:     	ldrb	w11, [x9]
1000643c8:     	tbnz	w11, #0x0, 0x1000644c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x848>
1000643cc:     	mov	w11, #0x1               ; =1
1000643d0:     	strb	w11, [x9]
1000643d4:     	mov	w9, #0x6                ; =6
1000643d8:     	str	x9, [x10]
1000643dc:     	ldrb	w9, [x26, #0xe18]
1000643e0:     	cmp	w9, #0x1
1000643e4:     	b.ne	0x10006444c <<la_stack::rational::RationalMatrix<8>>::solve+0x7cc>
1000643e8:     	ldrb	w9, [x26, #0xe58]
1000643ec:     	cmp	w9, #0x1
1000643f0:     	b.ne	0x100064458 <<la_stack::rational::RationalMatrix<8>>::solve+0x7d8>
1000643f4:     	ldrb	w9, [x26, #0xe98]
1000643f8:     	cmp	w9, #0x1
1000643fc:     	b.ne	0x10006446c <<la_stack::rational::RationalMatrix<8>>::solve+0x7ec>
100064400:     	ldrb	w9, [x26, #0xed8]
100064404:     	cmp	w9, #0x1
100064408:     	b.ne	0x100064480 <<la_stack::rational::RationalMatrix<8>>::solve+0x800>
10006440c:     	ldrb	w9, [x26, #0xf18]
100064410:     	cmp	w9, #0x1
100064414:     	b.ne	0x100064490 <<la_stack::rational::RationalMatrix<8>>::solve+0x810>
100064418:     	ldrb	w9, [x26, #0xf58]
10006441c:     	cmp	w9, #0x1
100064420:     	b.ne	0x1000644a0 <<la_stack::rational::RationalMatrix<8>>::solve+0x820>
100064424:     	ldrb	w9, [x26, #0xf98]
100064428:     	cmp	w9, #0x1
10006442c:     	b.ne	0x1000644b0 <<la_stack::rational::RationalMatrix<8>>::solve+0x830>
100064430:     	ldrb	w9, [x26, #0xfd8]
100064434:     	cmp	w9, #0x1
100064438:     	b.eq	0x1000644c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x848>
10006443c:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064440:     	add	x9, x9, #0x510
100064444:     	add	x10, sp, #0xcd0
100064448:     	b	0x1000644c0 <<la_stack::rational::RationalMatrix<8>>::solve+0x840>
10006444c:     	add	x9, sp, #0xcf0
100064450:     	add	x10, sp, #0xd10
100064454:     	b	0x1000644c0 <<la_stack::rational::RationalMatrix<8>>::solve+0x840>
100064458:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
10006445c:     	add	x9, x9, #0x570
100064460:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100064464:     	add	x10, x10, #0x6c0
100064468:     	b	0x1000644c0 <<la_stack::rational::RationalMatrix<8>>::solve+0x840>
10006446c:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064470:     	add	x9, x9, #0x560
100064474:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100064478:     	add	x10, x10, #0x5c0
10006447c:     	b	0x1000644c0 <<la_stack::rational::RationalMatrix<8>>::solve+0x840>
100064480:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064484:     	add	x9, x9, #0x550
100064488:     	add	x10, sp, #0x9e0
10006448c:     	b	0x1000644c0 <<la_stack::rational::RationalMatrix<8>>::solve+0x840>
100064490:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064494:     	add	x9, x9, #0x540
100064498:     	add	x10, sp, #0xe0
10006449c:     	b	0x1000644c0 <<la_stack::rational::RationalMatrix<8>>::solve+0x840>
1000644a0:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
1000644a4:     	add	x9, x9, #0x530
1000644a8:     	sub	x10, x29, #0xa0
1000644ac:     	b	0x1000644c0 <<la_stack::rational::RationalMatrix<8>>::solve+0x840>
1000644b0:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
1000644b4:     	add	x9, x9, #0x520
1000644b8:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
1000644bc:     	add	x10, x10, #0x580
1000644c0:     	ldrb	w11, [x9]
1000644c4:     	tbz	w11, #0x0, 0x1000647fc <<la_stack::rational::RationalMatrix<8>>::solve+0xb7c>
1000644c8:     	str	xzr, [sp, #0xd10]
1000644cc:     	str	xzr, [sp, #0x16c0]
1000644d0:     	str	xzr, [sp, #0x15c0]
1000644d4:     	str	xzr, [sp, #0x9e0]
1000644d8:     	str	xzr, [sp, #0xe0]
1000644dc:     	stur	xzr, [x29, #-0xa0]
1000644e0:     	str	xzr, [sp, #0x1580]
1000644e4:     	str	xzr, [sp, #0xcd0]
1000644e8:     	strb	wzr, [sp, #0xcf0]
1000644ec:     	add	x9, sp, #0xae0
1000644f0:     	strb	wzr, [x9, #0xa90]
1000644f4:     	strb	wzr, [x9, #0xa80]
1000644f8:     	strb	wzr, [x9, #0xa70]
1000644fc:     	strb	wzr, [x9, #0xa60]
100064500:     	strb	wzr, [x9, #0xa50]
100064504:     	strb	wzr, [x9, #0xa40]
100064508:     	strb	wzr, [x9, #0xa30]
10006450c:     	ldrb	w9, [x26, #0x1d8]
100064510:     	cmp	w9, #0x1
100064514:     	b.ne	0x100064590 <<la_stack::rational::RationalMatrix<8>>::solve+0x910>
100064518:     	ldrb	w9, [x26, #0x198]
10006451c:     	cmp	w9, #0x1
100064520:     	b.ne	0x1000645a8 <<la_stack::rational::RationalMatrix<8>>::solve+0x928>
100064524:     	ldrb	w9, [x26, #0x158]
100064528:     	cmp	w9, #0x1
10006452c:     	b.ne	0x1000645c4 <<la_stack::rational::RationalMatrix<8>>::solve+0x944>
100064530:     	ldrb	w9, [x26, #0x118]
100064534:     	cmp	w9, #0x1
100064538:     	b.ne	0x1000645dc <<la_stack::rational::RationalMatrix<8>>::solve+0x95c>
10006453c:     	ldrb	w9, [x26, #0xd8]
100064540:     	cmp	w9, #0x1
100064544:     	b.ne	0x1000645f4 <<la_stack::rational::RationalMatrix<8>>::solve+0x974>
100064548:     	ldrb	w9, [x26, #0x98]
10006454c:     	cmp	w9, #0x1
100064550:     	b.ne	0x1000646c4 <<la_stack::rational::RationalMatrix<8>>::solve+0xa44>
100064554:     	ldrb	w11, [x26, #0x58]
100064558:     	cmp	w11, #0x1
10006455c:     	add	x9, sp, #0xd10
100064560:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100064564:     	add	x10, x10, #0x6c0
100064568:     	csel	x10, x10, x9, ne
10006456c:     	add	x9, sp, #0xcf0
100064570:     	add	x12, sp, #0x1, lsl #12  ; =0x1000
100064574:     	add	x12, x12, #0x570
100064578:     	csel	x9, x12, x9, ne
10006457c:     	cmp	w8, #0x1
100064580:     	b.ne	0x100064600 <<la_stack::rational::RationalMatrix<8>>::solve+0x980>
100064584:     	cmp	w11, #0x1
100064588:     	b.eq	0x1000655e8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1968>
10006458c:     	b	0x100064600 <<la_stack::rational::RationalMatrix<8>>::solve+0x980>
100064590:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064594:     	add	x9, x9, #0x510
100064598:     	add	x10, sp, #0xcd0
10006459c:     	ldrb	w8, [x9]
1000645a0:     	tbz	w8, #0x0, 0x100064608 <<la_stack::rational::RationalMatrix<8>>::solve+0x988>
1000645a4:     	b	0x1000655e8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1968>
1000645a8:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
1000645ac:     	add	x9, x9, #0x520
1000645b0:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
1000645b4:     	add	x10, x10, #0x580
1000645b8:     	ldrb	w8, [x9]
1000645bc:     	tbz	w8, #0x0, 0x100064608 <<la_stack::rational::RationalMatrix<8>>::solve+0x988>
1000645c0:     	b	0x1000655e8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1968>
1000645c4:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
1000645c8:     	add	x9, x9, #0x530
1000645cc:     	sub	x10, x29, #0xa0
1000645d0:     	ldrb	w8, [x9]
1000645d4:     	tbz	w8, #0x0, 0x100064608 <<la_stack::rational::RationalMatrix<8>>::solve+0x988>
1000645d8:     	b	0x1000655e8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1968>
1000645dc:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
1000645e0:     	add	x9, x9, #0x540
1000645e4:     	add	x10, sp, #0xe0
1000645e8:     	ldrb	w8, [x9]
1000645ec:     	tbz	w8, #0x0, 0x100064608 <<la_stack::rational::RationalMatrix<8>>::solve+0x988>
1000645f0:     	b	0x1000655e8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1968>
1000645f4:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
1000645f8:     	add	x9, x9, #0x550
1000645fc:     	add	x10, sp, #0x9e0
100064600:     	ldrb	w8, [x9]
100064604:     	tbnz	w8, #0x0, 0x1000655e8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1968>
100064608:     	mov	w8, #0x1                ; =1
10006460c:     	strb	w8, [x9]
100064610:     	str	xzr, [x10]
100064614:     	ldrb	w8, [x26, #0x3d8]
100064618:     	cmp	w8, #0x1
10006461c:     	b.ne	0x100064680 <<la_stack::rational::RationalMatrix<8>>::solve+0xa00>
100064620:     	ldrb	w8, [x26, #0x398]
100064624:     	cmp	w8, #0x1
100064628:     	b.ne	0x100064690 <<la_stack::rational::RationalMatrix<8>>::solve+0xa10>
10006462c:     	ldrb	w8, [x26, #0x358]
100064630:     	cmp	w8, #0x1
100064634:     	b.ne	0x1000646a4 <<la_stack::rational::RationalMatrix<8>>::solve+0xa24>
100064638:     	ldrb	w8, [x26, #0x318]
10006463c:     	cmp	w8, #0x1
100064640:     	b.ne	0x1000646b4 <<la_stack::rational::RationalMatrix<8>>::solve+0xa34>
100064644:     	ldrb	w8, [x26, #0x2d8]
100064648:     	cmp	w8, #0x1
10006464c:     	b.ne	0x1000646e0 <<la_stack::rational::RationalMatrix<8>>::solve+0xa60>
100064650:     	ldrb	w8, [x26, #0x298]
100064654:     	cmp	w8, #0x1
100064658:     	b.ne	0x1000646f0 <<la_stack::rational::RationalMatrix<8>>::solve+0xa70>
10006465c:     	ldrb	w8, [x26, #0x258]
100064660:     	cmp	w8, #0x1
100064664:     	b.ne	0x100064704 <<la_stack::rational::RationalMatrix<8>>::solve+0xa84>
100064668:     	ldrb	w8, [x26, #0x218]
10006466c:     	cmp	w8, #0x1
100064670:     	b.eq	0x1000655e8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1968>
100064674:     	add	x8, sp, #0xcf0
100064678:     	add	x9, sp, #0xd10
10006467c:     	b	0x100064714 <<la_stack::rational::RationalMatrix<8>>::solve+0xa94>
100064680:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064684:     	add	x8, x8, #0x510
100064688:     	add	x9, sp, #0xcd0
10006468c:     	b	0x100064714 <<la_stack::rational::RationalMatrix<8>>::solve+0xa94>
100064690:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064694:     	add	x8, x8, #0x520
100064698:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
10006469c:     	add	x9, x9, #0x580
1000646a0:     	b	0x100064714 <<la_stack::rational::RationalMatrix<8>>::solve+0xa94>
1000646a4:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000646a8:     	add	x8, x8, #0x530
1000646ac:     	sub	x9, x29, #0xa0
1000646b0:     	b	0x100064714 <<la_stack::rational::RationalMatrix<8>>::solve+0xa94>
1000646b4:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000646b8:     	add	x8, x8, #0x540
1000646bc:     	add	x9, sp, #0xe0
1000646c0:     	b	0x100064714 <<la_stack::rational::RationalMatrix<8>>::solve+0xa94>
1000646c4:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
1000646c8:     	add	x9, x9, #0x560
1000646cc:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
1000646d0:     	add	x10, x10, #0x5c0
1000646d4:     	ldrb	w8, [x9]
1000646d8:     	tbz	w8, #0x0, 0x100064608 <<la_stack::rational::RationalMatrix<8>>::solve+0x988>
1000646dc:     	b	0x1000655e8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1968>
1000646e0:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000646e4:     	add	x8, x8, #0x550
1000646e8:     	add	x9, sp, #0x9e0
1000646ec:     	b	0x100064714 <<la_stack::rational::RationalMatrix<8>>::solve+0xa94>
1000646f0:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000646f4:     	add	x8, x8, #0x560
1000646f8:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
1000646fc:     	add	x9, x9, #0x5c0
100064700:     	b	0x100064714 <<la_stack::rational::RationalMatrix<8>>::solve+0xa94>
100064704:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064708:     	add	x8, x8, #0x570
10006470c:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064710:     	add	x9, x9, #0x6c0
100064714:     	ldrb	w10, [x8]
100064718:     	tbnz	w10, #0x0, 0x1000655e8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1968>
10006471c:     	mov	w10, #0x1               ; =1
100064720:     	strb	w10, [x8]
100064724:     	str	x10, [x9]
100064728:     	ldrb	w8, [x26, #0x5d8]
10006472c:     	cmp	w8, #0x1
100064730:     	b.ne	0x100064794 <<la_stack::rational::RationalMatrix<8>>::solve+0xb14>
100064734:     	ldrb	w8, [x26, #0x598]
100064738:     	cmp	w8, #0x1
10006473c:     	b.ne	0x1000647a4 <<la_stack::rational::RationalMatrix<8>>::solve+0xb24>
100064740:     	ldrb	w8, [x26, #0x558]
100064744:     	cmp	w8, #0x1
100064748:     	b.ne	0x1000647b8 <<la_stack::rational::RationalMatrix<8>>::solve+0xb38>
10006474c:     	ldrb	w8, [x26, #0x518]
100064750:     	cmp	w8, #0x1
100064754:     	b.ne	0x1000647c8 <<la_stack::rational::RationalMatrix<8>>::solve+0xb48>
100064758:     	ldrb	w8, [x26, #0x4d8]
10006475c:     	cmp	w8, #0x1
100064760:     	b.ne	0x1000647d8 <<la_stack::rational::RationalMatrix<8>>::solve+0xb58>
100064764:     	ldrb	w8, [x26, #0x498]
100064768:     	cmp	w8, #0x1
10006476c:     	b.ne	0x1000647e8 <<la_stack::rational::RationalMatrix<8>>::solve+0xb68>
100064770:     	ldrb	w8, [x26, #0x458]
100064774:     	cmp	w8, #0x1
100064778:     	b.ne	0x100064818 <<la_stack::rational::RationalMatrix<8>>::solve+0xb98>
10006477c:     	ldrb	w8, [x26, #0x418]
100064780:     	cmp	w8, #0x1
100064784:     	b.eq	0x1000655e8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1968>
100064788:     	add	x8, sp, #0xcf0
10006478c:     	add	x9, sp, #0xd10
100064790:     	b	0x100064828 <<la_stack::rational::RationalMatrix<8>>::solve+0xba8>
100064794:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064798:     	add	x8, x8, #0x510
10006479c:     	add	x9, sp, #0xcd0
1000647a0:     	b	0x100064828 <<la_stack::rational::RationalMatrix<8>>::solve+0xba8>
1000647a4:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000647a8:     	add	x8, x8, #0x520
1000647ac:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
1000647b0:     	add	x9, x9, #0x580
1000647b4:     	b	0x100064828 <<la_stack::rational::RationalMatrix<8>>::solve+0xba8>
1000647b8:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000647bc:     	add	x8, x8, #0x530
1000647c0:     	sub	x9, x29, #0xa0
1000647c4:     	b	0x100064828 <<la_stack::rational::RationalMatrix<8>>::solve+0xba8>
1000647c8:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000647cc:     	add	x8, x8, #0x540
1000647d0:     	add	x9, sp, #0xe0
1000647d4:     	b	0x100064828 <<la_stack::rational::RationalMatrix<8>>::solve+0xba8>
1000647d8:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000647dc:     	add	x8, x8, #0x550
1000647e0:     	add	x9, sp, #0x9e0
1000647e4:     	b	0x100064828 <<la_stack::rational::RationalMatrix<8>>::solve+0xba8>
1000647e8:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000647ec:     	add	x8, x8, #0x560
1000647f0:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
1000647f4:     	add	x9, x9, #0x5c0
1000647f8:     	b	0x100064828 <<la_stack::rational::RationalMatrix<8>>::solve+0xba8>
1000647fc:     	mov	w11, #0x1               ; =1
100064800:     	mov	w8, #0x1                ; =1
100064804:     	str	w8, [sp, #0xc8]
100064808:     	strb	w11, [x9]
10006480c:     	mov	w8, #0x7                ; =7
100064810:     	str	x8, [x10]
100064814:     	b	0x100064d30 <<la_stack::rational::RationalMatrix<8>>::solve+0x10b0>
100064818:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
10006481c:     	add	x8, x8, #0x570
100064820:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064824:     	add	x9, x9, #0x6c0
100064828:     	ldrb	w10, [x8]
10006482c:     	tbnz	w10, #0x0, 0x1000655e8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1968>
100064830:     	mov	w10, #0x1               ; =1
100064834:     	strb	w10, [x8]
100064838:     	mov	w8, #0x2                ; =2
10006483c:     	str	x8, [x9]
100064840:     	ldrb	w8, [x26, #0x7d8]
100064844:     	cmp	w8, #0x1
100064848:     	b.ne	0x1000648ac <<la_stack::rational::RationalMatrix<8>>::solve+0xc2c>
10006484c:     	ldrb	w8, [x26, #0x798]
100064850:     	cmp	w8, #0x1
100064854:     	b.ne	0x1000648bc <<la_stack::rational::RationalMatrix<8>>::solve+0xc3c>
100064858:     	ldrb	w8, [x26, #0x758]
10006485c:     	cmp	w8, #0x1
100064860:     	b.ne	0x1000648d0 <<la_stack::rational::RationalMatrix<8>>::solve+0xc50>
100064864:     	ldrb	w8, [x26, #0x718]
100064868:     	cmp	w8, #0x1
10006486c:     	b.ne	0x1000648e0 <<la_stack::rational::RationalMatrix<8>>::solve+0xc60>
100064870:     	ldrb	w8, [x26, #0x6d8]
100064874:     	cmp	w8, #0x1
100064878:     	b.ne	0x1000648f0 <<la_stack::rational::RationalMatrix<8>>::solve+0xc70>
10006487c:     	ldrb	w8, [x26, #0x698]
100064880:     	cmp	w8, #0x1
100064884:     	b.ne	0x100064900 <<la_stack::rational::RationalMatrix<8>>::solve+0xc80>
100064888:     	ldrb	w8, [x26, #0x658]
10006488c:     	cmp	w8, #0x1
100064890:     	b.ne	0x100064914 <<la_stack::rational::RationalMatrix<8>>::solve+0xc94>
100064894:     	ldrb	w8, [x26, #0x618]
100064898:     	cmp	w8, #0x1
10006489c:     	b.eq	0x1000655e8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1968>
1000648a0:     	add	x8, sp, #0xcf0
1000648a4:     	add	x9, sp, #0xd10
1000648a8:     	b	0x100064924 <<la_stack::rational::RationalMatrix<8>>::solve+0xca4>
1000648ac:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000648b0:     	add	x8, x8, #0x510
1000648b4:     	add	x9, sp, #0xcd0
1000648b8:     	b	0x100064924 <<la_stack::rational::RationalMatrix<8>>::solve+0xca4>
1000648bc:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000648c0:     	add	x8, x8, #0x520
1000648c4:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
1000648c8:     	add	x9, x9, #0x580
1000648cc:     	b	0x100064924 <<la_stack::rational::RationalMatrix<8>>::solve+0xca4>
1000648d0:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000648d4:     	add	x8, x8, #0x530
1000648d8:     	sub	x9, x29, #0xa0
1000648dc:     	b	0x100064924 <<la_stack::rational::RationalMatrix<8>>::solve+0xca4>
1000648e0:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000648e4:     	add	x8, x8, #0x540
1000648e8:     	add	x9, sp, #0xe0
1000648ec:     	b	0x100064924 <<la_stack::rational::RationalMatrix<8>>::solve+0xca4>
1000648f0:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000648f4:     	add	x8, x8, #0x550
1000648f8:     	add	x9, sp, #0x9e0
1000648fc:     	b	0x100064924 <<la_stack::rational::RationalMatrix<8>>::solve+0xca4>
100064900:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064904:     	add	x8, x8, #0x560
100064908:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
10006490c:     	add	x9, x9, #0x5c0
100064910:     	b	0x100064924 <<la_stack::rational::RationalMatrix<8>>::solve+0xca4>
100064914:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064918:     	add	x8, x8, #0x570
10006491c:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064920:     	add	x9, x9, #0x6c0
100064924:     	ldrb	w10, [x8]
100064928:     	tbnz	w10, #0x0, 0x1000655e8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1968>
10006492c:     	mov	w10, #0x1               ; =1
100064930:     	strb	w10, [x8]
100064934:     	mov	w8, #0x3                ; =3
100064938:     	str	x8, [x9]
10006493c:     	ldrb	w8, [x26, #0x9d8]
100064940:     	cmp	w8, #0x1
100064944:     	b.ne	0x1000649a8 <<la_stack::rational::RationalMatrix<8>>::solve+0xd28>
100064948:     	ldrb	w8, [x26, #0x998]
10006494c:     	cmp	w8, #0x1
100064950:     	b.ne	0x1000649b8 <<la_stack::rational::RationalMatrix<8>>::solve+0xd38>
100064954:     	ldrb	w8, [x26, #0x958]
100064958:     	cmp	w8, #0x1
10006495c:     	b.ne	0x1000649cc <<la_stack::rational::RationalMatrix<8>>::solve+0xd4c>
100064960:     	ldrb	w8, [x26, #0x918]
100064964:     	cmp	w8, #0x1
100064968:     	b.ne	0x1000649dc <<la_stack::rational::RationalMatrix<8>>::solve+0xd5c>
10006496c:     	ldrb	w8, [x26, #0x8d8]
100064970:     	cmp	w8, #0x1
100064974:     	b.ne	0x1000649ec <<la_stack::rational::RationalMatrix<8>>::solve+0xd6c>
100064978:     	ldrb	w8, [x26, #0x898]
10006497c:     	cmp	w8, #0x1
100064980:     	b.ne	0x1000649fc <<la_stack::rational::RationalMatrix<8>>::solve+0xd7c>
100064984:     	ldrb	w8, [x26, #0x858]
100064988:     	cmp	w8, #0x1
10006498c:     	b.ne	0x100064a10 <<la_stack::rational::RationalMatrix<8>>::solve+0xd90>
100064990:     	ldrb	w8, [x26, #0x818]
100064994:     	cmp	w8, #0x1
100064998:     	b.eq	0x1000655e8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1968>
10006499c:     	add	x8, sp, #0xcf0
1000649a0:     	add	x9, sp, #0xd10
1000649a4:     	b	0x100064a20 <<la_stack::rational::RationalMatrix<8>>::solve+0xda0>
1000649a8:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000649ac:     	add	x8, x8, #0x510
1000649b0:     	add	x9, sp, #0xcd0
1000649b4:     	b	0x100064a20 <<la_stack::rational::RationalMatrix<8>>::solve+0xda0>
1000649b8:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000649bc:     	add	x8, x8, #0x520
1000649c0:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
1000649c4:     	add	x9, x9, #0x580
1000649c8:     	b	0x100064a20 <<la_stack::rational::RationalMatrix<8>>::solve+0xda0>
1000649cc:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000649d0:     	add	x8, x8, #0x530
1000649d4:     	sub	x9, x29, #0xa0
1000649d8:     	b	0x100064a20 <<la_stack::rational::RationalMatrix<8>>::solve+0xda0>
1000649dc:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000649e0:     	add	x8, x8, #0x540
1000649e4:     	add	x9, sp, #0xe0
1000649e8:     	b	0x100064a20 <<la_stack::rational::RationalMatrix<8>>::solve+0xda0>
1000649ec:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000649f0:     	add	x8, x8, #0x550
1000649f4:     	add	x9, sp, #0x9e0
1000649f8:     	b	0x100064a20 <<la_stack::rational::RationalMatrix<8>>::solve+0xda0>
1000649fc:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064a00:     	add	x8, x8, #0x560
100064a04:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064a08:     	add	x9, x9, #0x5c0
100064a0c:     	b	0x100064a20 <<la_stack::rational::RationalMatrix<8>>::solve+0xda0>
100064a10:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064a14:     	add	x8, x8, #0x570
100064a18:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064a1c:     	add	x9, x9, #0x6c0
100064a20:     	ldrb	w10, [x8]
100064a24:     	tbnz	w10, #0x0, 0x1000655e8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1968>
100064a28:     	mov	w10, #0x1               ; =1
100064a2c:     	strb	w10, [x8]
100064a30:     	mov	w8, #0x4                ; =4
100064a34:     	str	x8, [x9]
100064a38:     	ldrb	w8, [x26, #0xbd8]
100064a3c:     	cmp	w8, #0x1
100064a40:     	b.ne	0x100064aa4 <<la_stack::rational::RationalMatrix<8>>::solve+0xe24>
100064a44:     	ldrb	w8, [x26, #0xb98]
100064a48:     	cmp	w8, #0x1
100064a4c:     	b.ne	0x100064ab4 <<la_stack::rational::RationalMatrix<8>>::solve+0xe34>
100064a50:     	ldrb	w8, [x26, #0xb58]
100064a54:     	cmp	w8, #0x1
100064a58:     	b.ne	0x100064ac8 <<la_stack::rational::RationalMatrix<8>>::solve+0xe48>
100064a5c:     	ldrb	w8, [x26, #0xb18]
100064a60:     	cmp	w8, #0x1
100064a64:     	b.ne	0x100064ad8 <<la_stack::rational::RationalMatrix<8>>::solve+0xe58>
100064a68:     	ldrb	w8, [x26, #0xad8]
100064a6c:     	cmp	w8, #0x1
100064a70:     	b.ne	0x100064ae8 <<la_stack::rational::RationalMatrix<8>>::solve+0xe68>
100064a74:     	ldrb	w8, [x26, #0xa98]
100064a78:     	cmp	w8, #0x1
100064a7c:     	b.ne	0x100064af8 <<la_stack::rational::RationalMatrix<8>>::solve+0xe78>
100064a80:     	ldrb	w8, [x26, #0xa58]
100064a84:     	cmp	w8, #0x1
100064a88:     	b.ne	0x100064b0c <<la_stack::rational::RationalMatrix<8>>::solve+0xe8c>
100064a8c:     	ldrb	w8, [x26, #0xa18]
100064a90:     	cmp	w8, #0x1
100064a94:     	b.eq	0x1000655e8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1968>
100064a98:     	add	x8, sp, #0xcf0
100064a9c:     	add	x9, sp, #0xd10
100064aa0:     	b	0x100064b1c <<la_stack::rational::RationalMatrix<8>>::solve+0xe9c>
100064aa4:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064aa8:     	add	x8, x8, #0x510
100064aac:     	add	x9, sp, #0xcd0
100064ab0:     	b	0x100064b1c <<la_stack::rational::RationalMatrix<8>>::solve+0xe9c>
100064ab4:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064ab8:     	add	x8, x8, #0x520
100064abc:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064ac0:     	add	x9, x9, #0x580
100064ac4:     	b	0x100064b1c <<la_stack::rational::RationalMatrix<8>>::solve+0xe9c>
100064ac8:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064acc:     	add	x8, x8, #0x530
100064ad0:     	sub	x9, x29, #0xa0
100064ad4:     	b	0x100064b1c <<la_stack::rational::RationalMatrix<8>>::solve+0xe9c>
100064ad8:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064adc:     	add	x8, x8, #0x540
100064ae0:     	add	x9, sp, #0xe0
100064ae4:     	b	0x100064b1c <<la_stack::rational::RationalMatrix<8>>::solve+0xe9c>
100064ae8:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064aec:     	add	x8, x8, #0x550
100064af0:     	add	x9, sp, #0x9e0
100064af4:     	b	0x100064b1c <<la_stack::rational::RationalMatrix<8>>::solve+0xe9c>
100064af8:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064afc:     	add	x8, x8, #0x560
100064b00:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064b04:     	add	x9, x9, #0x5c0
100064b08:     	b	0x100064b1c <<la_stack::rational::RationalMatrix<8>>::solve+0xe9c>
100064b0c:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064b10:     	add	x8, x8, #0x570
100064b14:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064b18:     	add	x9, x9, #0x6c0
100064b1c:     	ldrb	w10, [x8]
100064b20:     	tbnz	w10, #0x0, 0x1000655e8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1968>
100064b24:     	mov	w10, #0x1               ; =1
100064b28:     	strb	w10, [x8]
100064b2c:     	mov	w8, #0x5                ; =5
100064b30:     	str	x8, [x9]
100064b34:     	ldrb	w8, [x26, #0xdd8]
100064b38:     	cmp	w8, #0x1
100064b3c:     	b.ne	0x100064ba0 <<la_stack::rational::RationalMatrix<8>>::solve+0xf20>
100064b40:     	ldrb	w8, [x26, #0xd98]
100064b44:     	cmp	w8, #0x1
100064b48:     	b.ne	0x100064bb0 <<la_stack::rational::RationalMatrix<8>>::solve+0xf30>
100064b4c:     	ldrb	w8, [x26, #0xd58]
100064b50:     	cmp	w8, #0x1
100064b54:     	b.ne	0x100064bc4 <<la_stack::rational::RationalMatrix<8>>::solve+0xf44>
100064b58:     	ldrb	w8, [x26, #0xd18]
100064b5c:     	cmp	w8, #0x1
100064b60:     	b.ne	0x100064bd4 <<la_stack::rational::RationalMatrix<8>>::solve+0xf54>
100064b64:     	ldrb	w8, [x26, #0xcd8]
100064b68:     	cmp	w8, #0x1
100064b6c:     	b.ne	0x100064be4 <<la_stack::rational::RationalMatrix<8>>::solve+0xf64>
100064b70:     	ldrb	w8, [x26, #0xc98]
100064b74:     	cmp	w8, #0x1
100064b78:     	b.ne	0x100064bf4 <<la_stack::rational::RationalMatrix<8>>::solve+0xf74>
100064b7c:     	ldrb	w8, [x26, #0xc58]
100064b80:     	cmp	w8, #0x1
100064b84:     	b.ne	0x100064c08 <<la_stack::rational::RationalMatrix<8>>::solve+0xf88>
100064b88:     	ldrb	w8, [x26, #0xc18]
100064b8c:     	cmp	w8, #0x1
100064b90:     	b.eq	0x1000655e8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1968>
100064b94:     	add	x8, sp, #0xcf0
100064b98:     	add	x9, sp, #0xd10
100064b9c:     	b	0x100064c18 <<la_stack::rational::RationalMatrix<8>>::solve+0xf98>
100064ba0:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064ba4:     	add	x8, x8, #0x510
100064ba8:     	add	x9, sp, #0xcd0
100064bac:     	b	0x100064c18 <<la_stack::rational::RationalMatrix<8>>::solve+0xf98>
100064bb0:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064bb4:     	add	x8, x8, #0x520
100064bb8:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064bbc:     	add	x9, x9, #0x580
100064bc0:     	b	0x100064c18 <<la_stack::rational::RationalMatrix<8>>::solve+0xf98>
100064bc4:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064bc8:     	add	x8, x8, #0x530
100064bcc:     	sub	x9, x29, #0xa0
100064bd0:     	b	0x100064c18 <<la_stack::rational::RationalMatrix<8>>::solve+0xf98>
100064bd4:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064bd8:     	add	x8, x8, #0x540
100064bdc:     	add	x9, sp, #0xe0
100064be0:     	b	0x100064c18 <<la_stack::rational::RationalMatrix<8>>::solve+0xf98>
100064be4:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064be8:     	add	x8, x8, #0x550
100064bec:     	add	x9, sp, #0x9e0
100064bf0:     	b	0x100064c18 <<la_stack::rational::RationalMatrix<8>>::solve+0xf98>
100064bf4:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064bf8:     	add	x8, x8, #0x560
100064bfc:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064c00:     	add	x9, x9, #0x5c0
100064c04:     	b	0x100064c18 <<la_stack::rational::RationalMatrix<8>>::solve+0xf98>
100064c08:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064c0c:     	add	x8, x8, #0x570
100064c10:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064c14:     	add	x9, x9, #0x6c0
100064c18:     	ldrb	w10, [x8]
100064c1c:     	tbnz	w10, #0x0, 0x1000655e8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1968>
100064c20:     	mov	w10, #0x1               ; =1
100064c24:     	strb	w10, [x8]
100064c28:     	mov	w8, #0x6                ; =6
100064c2c:     	str	x8, [x9]
100064c30:     	ldrb	w8, [x26, #0xfd8]
100064c34:     	cmp	w8, #0x1
100064c38:     	b.ne	0x100064c9c <<la_stack::rational::RationalMatrix<8>>::solve+0x101c>
100064c3c:     	ldrb	w8, [x26, #0xf98]
100064c40:     	cmp	w8, #0x1
100064c44:     	b.ne	0x100064cac <<la_stack::rational::RationalMatrix<8>>::solve+0x102c>
100064c48:     	ldrb	w8, [x26, #0xf58]
100064c4c:     	cmp	w8, #0x1
100064c50:     	b.ne	0x100064cc0 <<la_stack::rational::RationalMatrix<8>>::solve+0x1040>
100064c54:     	ldrb	w8, [x26, #0xf18]
100064c58:     	cmp	w8, #0x1
100064c5c:     	b.ne	0x100064cd0 <<la_stack::rational::RationalMatrix<8>>::solve+0x1050>
100064c60:     	ldrb	w8, [x26, #0xed8]
100064c64:     	cmp	w8, #0x1
100064c68:     	b.ne	0x100064ce0 <<la_stack::rational::RationalMatrix<8>>::solve+0x1060>
100064c6c:     	ldrb	w8, [x26, #0xe98]
100064c70:     	cmp	w8, #0x1
100064c74:     	b.ne	0x100064cf0 <<la_stack::rational::RationalMatrix<8>>::solve+0x1070>
100064c78:     	ldrb	w8, [x26, #0xe58]
100064c7c:     	cmp	w8, #0x1
100064c80:     	b.ne	0x100064d04 <<la_stack::rational::RationalMatrix<8>>::solve+0x1084>
100064c84:     	ldrb	w8, [x26, #0xe18]
100064c88:     	cmp	w8, #0x1
100064c8c:     	b.eq	0x1000655e8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1968>
100064c90:     	add	x8, sp, #0xcf0
100064c94:     	add	x9, sp, #0xd10
100064c98:     	b	0x100064d14 <<la_stack::rational::RationalMatrix<8>>::solve+0x1094>
100064c9c:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064ca0:     	add	x8, x8, #0x510
100064ca4:     	add	x9, sp, #0xcd0
100064ca8:     	b	0x100064d14 <<la_stack::rational::RationalMatrix<8>>::solve+0x1094>
100064cac:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064cb0:     	add	x8, x8, #0x520
100064cb4:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064cb8:     	add	x9, x9, #0x580
100064cbc:     	b	0x100064d14 <<la_stack::rational::RationalMatrix<8>>::solve+0x1094>
100064cc0:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064cc4:     	add	x8, x8, #0x530
100064cc8:     	sub	x9, x29, #0xa0
100064ccc:     	b	0x100064d14 <<la_stack::rational::RationalMatrix<8>>::solve+0x1094>
100064cd0:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064cd4:     	add	x8, x8, #0x540
100064cd8:     	add	x9, sp, #0xe0
100064cdc:     	b	0x100064d14 <<la_stack::rational::RationalMatrix<8>>::solve+0x1094>
100064ce0:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064ce4:     	add	x8, x8, #0x550
100064ce8:     	add	x9, sp, #0x9e0
100064cec:     	b	0x100064d14 <<la_stack::rational::RationalMatrix<8>>::solve+0x1094>
100064cf0:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064cf4:     	add	x8, x8, #0x560
100064cf8:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064cfc:     	add	x9, x9, #0x5c0
100064d00:     	b	0x100064d14 <<la_stack::rational::RationalMatrix<8>>::solve+0x1094>
100064d04:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100064d08:     	add	x8, x8, #0x570
100064d0c:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064d10:     	add	x9, x9, #0x6c0
100064d14:     	ldrb	w10, [x8]
100064d18:     	tbnz	w10, #0x0, 0x1000655e8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1968>
100064d1c:     	str	wzr, [sp, #0xc8]
100064d20:     	mov	w10, #0x1               ; =1
100064d24:     	strb	w10, [x8]
100064d28:     	mov	w8, #0x7                ; =7
100064d2c:     	str	x8, [x9]
100064d30:     	ldr	x8, [sp, #0xd10]
100064d34:     	ldr	x9, [sp, #0x16c0]
100064d38:     	ldr	x10, [sp, #0x15c0]
100064d3c:     	ldr	x11, [sp, #0x9e0]
100064d40:     	ldr	x12, [sp, #0xe0]
100064d44:     	ldur	x13, [x29, #-0xa0]
100064d48:     	ldr	x14, [sp, #0x1580]
100064d4c:     	ldr	x15, [sp, #0xcd0]
100064d50:     	mov	x25, #0x0               ; =0
100064d54:     	mov	x16, #0x0               ; =0
100064d58:     	str	x8, [sp, #0xae0]
100064d5c:     	str	x9, [sp, #0xae8]
100064d60:     	str	x10, [sp, #0xaf0]
100064d64:     	str	x11, [sp, #0xaf8]
100064d68:     	str	x12, [sp, #0xb00]
100064d6c:     	str	x13, [sp, #0xb08]
100064d70:     	str	x14, [sp, #0xb10]
100064d74:     	str	x15, [sp, #0xb18]
100064d78:     	mov	x8, #-0x1               ; =-1
100064d7c:     	str	x8, [sp, #0xd10]
100064d80:     	str	xzr, [sp, #0xd18]
100064d84:     	adrp	x9, 0x100229000 <core::num::imp::flt2dec::strategy::dragon::POW5TO256+0x5f90>
100064d88:     	add	x9, x9, #0xd10
100064d8c:     	ldr	q0, [x9]
100064d90:     	adrp	x9, 0x10021d000 <dyld_stub_binder+0x10021d000>
100064d94:     	add	x9, x9, #0x7c8
100064d98:     	ldp	q1, q2, [x9]
100064d9c:     	str	q0, [sp, #0xd20]
100064da0:     	str	q1, [sp, #0xd30]
100064da4:     	str	q2, [sp, #0xd40]
100064da8:     	str	x8, [sp, #0xd50]
100064dac:     	str	xzr, [sp, #0xd58]
100064db0:     	str	q0, [sp, #0xd60]
100064db4:     	str	q1, [sp, #0xd70]
100064db8:     	str	q2, [sp, #0xd80]
100064dbc:     	str	x8, [sp, #0xd90]
100064dc0:     	str	xzr, [sp, #0xd98]
100064dc4:     	str	q2, [sp, #0xdc0]
100064dc8:     	str	q0, [sp, #0xda0]
100064dcc:     	str	q1, [sp, #0xdb0]
100064dd0:     	str	x8, [sp, #0xdd0]
100064dd4:     	str	xzr, [sp, #0xdd8]
100064dd8:     	str	q2, [sp, #0xe00]
100064ddc:     	str	q0, [sp, #0xde0]
100064de0:     	str	q1, [sp, #0xdf0]
100064de4:     	str	x8, [sp, #0xe10]
100064de8:     	str	xzr, [sp, #0xe18]
100064dec:     	str	q2, [sp, #0xe40]
100064df0:     	str	q0, [sp, #0xe20]
100064df4:     	str	q1, [sp, #0xe30]
100064df8:     	str	x8, [sp, #0xe50]
100064dfc:     	str	xzr, [sp, #0xe58]
100064e00:     	str	q2, [sp, #0xe80]
100064e04:     	str	q0, [sp, #0xe60]
100064e08:     	str	q1, [sp, #0xe70]
100064e0c:     	str	x8, [sp, #0xe90]
100064e10:     	str	xzr, [sp, #0xe98]
100064e14:     	str	q2, [sp, #0xec0]
100064e18:     	str	q0, [sp, #0xea0]
100064e1c:     	str	q1, [sp, #0xeb0]
100064e20:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100064e24:     	add	x9, x9, #0x580
100064e28:     	add	x9, x9, #0x10
100064e2c:     	str	x8, [sp, #0xed0]
100064e30:     	str	xzr, [sp, #0xed8]
100064e34:     	add	x8, sp, #0xe0
100064e38:     	add	x8, x8, #0x10
100064e3c:     	stp	x8, x9, [sp, #0xb0]
100064e40:     	str	q2, [sp, #0xf00]
100064e44:     	str	q0, [sp, #0xee0]
100064e48:     	str	q1, [sp, #0xef0]
100064e4c:     	b	0x100064e7c <<la_stack::rational::RationalMatrix<8>>::solve+0x11fc>
100064e50:     	ldr	x16, [sp, #0xc0]
100064e54:     	add	x16, x16, #0x1
100064e58:     	ldr	q0, [sp, #0x15c0]
100064e5c:     	ldr	q1, [sp, #0x15d0]
100064e60:     	stp	q0, q1, [x19]
100064e64:     	ldr	q0, [sp, #0x15e0]
100064e68:     	ldr	q1, [sp, #0x15f0]
100064e6c:     	stp	q0, q1, [x19, #0x20]
100064e70:     	add	x25, x25, #0x40
100064e74:     	cmp	x16, #0x8
100064e78:     	b.eq	0x1000655c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1948>
100064e7c:     	eor	x8, x16, #0x7
100064e80:     	ldr	w9, [sp, #0xc8]
100064e84:     	cmp	w9, #0x0
100064e88:     	csel	x9, x8, x16, ne
100064e8c:     	add	x8, sp, #0xae0
100064e90:     	str	x9, [sp, #0xd0]
100064e94:     	ldr	x19, [x8, x9, lsl #3]
100064e98:     	cmp	x19, #0x8
100064e9c:     	b.hs	0x100067268 <<la_stack::rational::RationalMatrix<8>>::solve+0x35e8>
100064ea0:     	add	x27, x28, x19, lsl #6
100064ea4:     	ldrb	w21, [x27, #0x18]
100064ea8:     	ldr	x8, [x27]
100064eac:     	ldr	x24, [x27, #0x10]
100064eb0:     	cmn	x8, #0x1
100064eb4:     	b.eq	0x100064ed8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1258>
100064eb8:     	cbz	x24, 0x100064ee4 <<la_stack::rational::RationalMatrix<8>>::solve+0x1264>
100064ebc:     	ldr	x22, [x27, #0x8]
100064ec0:     	cmp	x24, #0x1
100064ec4:     	b.ne	0x100064ef0 <<la_stack::rational::RationalMatrix<8>>::solve+0x1270>
100064ec8:     	ldr	x24, [x22]
100064ecc:     	mov	x28, #-0x1              ; =-1
100064ed0:     	mov	w20, #0x1               ; =1
100064ed4:     	b	0x100064f1c <<la_stack::rational::RationalMatrix<8>>::solve+0x129c>
100064ed8:     	ldr	x20, [x27, #0x8]
100064edc:     	mov	x28, #-0x1              ; =-1
100064ee0:     	b	0x100064f1c <<la_stack::rational::RationalMatrix<8>>::solve+0x129c>
100064ee4:     	mov	x28, #-0x1              ; =-1
100064ee8:     	mov	x20, x24
100064eec:     	b	0x100064f1c <<la_stack::rational::RationalMatrix<8>>::solve+0x129c>
100064ef0:     	mov	x26, x16
100064ef4:     	lsl	x23, x24, #3
100064ef8:     	mov	x0, x23
100064efc:     	bl	0x100219fe4 <dyld_stub_binder+0x100219fe4>
100064f00:     	cbz	x0, 0x1000672e8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3668>
100064f04:     	mov	x20, x0
100064f08:     	mov	x1, x22
100064f0c:     	mov	x2, x23
100064f10:     	bl	0x100219ffc <dyld_stub_binder+0x100219ffc>
100064f14:     	mov	x28, x24
100064f18:     	mov	x16, x26
100064f1c:     	strb	w21, [sp, #0xce8]
100064f20:     	str	x28, [sp, #0xcd0]
100064f24:     	str	x20, [sp, #0xcd8]
100064f28:     	str	x24, [sp, #0xce0]
100064f2c:     	ldrb	w24, [x27, #0x38]
100064f30:     	ldr	x8, [x27, #0x20]
100064f34:     	ldr	x26, [x27, #0x30]
100064f38:     	cmn	x8, #0x1
100064f3c:     	b.eq	0x100064f60 <<la_stack::rational::RationalMatrix<8>>::solve+0x12e0>
100064f40:     	cbz	x26, 0x100064f68 <<la_stack::rational::RationalMatrix<8>>::solve+0x12e8>
100064f44:     	ldr	x22, [x27, #0x28]
100064f48:     	cmp	x26, #0x1
100064f4c:     	b.ne	0x100064f74 <<la_stack::rational::RationalMatrix<8>>::solve+0x12f4>
100064f50:     	ldr	x26, [x22]
100064f54:     	mov	x8, #-0x1               ; =-1
100064f58:     	mov	w20, #0x1               ; =1
100064f5c:     	b	0x100064fa0 <<la_stack::rational::RationalMatrix<8>>::solve+0x1320>
100064f60:     	ldr	x20, [x27, #0x28]
100064f64:     	b	0x100064fa0 <<la_stack::rational::RationalMatrix<8>>::solve+0x1320>
100064f68:     	mov	x8, #-0x1               ; =-1
100064f6c:     	mov	x20, x26
100064f70:     	b	0x100064fa0 <<la_stack::rational::RationalMatrix<8>>::solve+0x1320>
100064f74:     	mov	x27, x16
100064f78:     	lsl	x23, x26, #3
100064f7c:     	mov	x0, x23
100064f80:     	bl	0x100219fe4 <dyld_stub_binder+0x100219fe4>
100064f84:     	cbz	x0, 0x1000672f8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3678>
100064f88:     	mov	x20, x0
100064f8c:     	mov	x1, x22
100064f90:     	mov	x2, x23
100064f94:     	bl	0x100219ffc <dyld_stub_binder+0x100219ffc>
100064f98:     	mov	x8, x26
100064f9c:     	mov	x16, x27
100064fa0:     	add	x9, sp, #0xae0
100064fa4:     	strb	w24, [x9, #0xab8]
100064fa8:     	str	x8, [sp, #0x1580]
100064fac:     	str	x20, [sp, #0x1588]
100064fb0:     	str	x26, [sp, #0x1590]
100064fb4:     	mov	w10, #0x8               ; =8
100064fb8:     	sub	x8, x10, x16
100064fbc:     	ldr	w9, [sp, #0xc8]
100064fc0:     	cmp	w9, #0x0
100064fc4:     	csel	x1, x10, x16, ne
100064fc8:     	csel	x0, x8, xzr, ne
100064fcc:     	cmp	x1, x0
100064fd0:     	ldr	x28, [sp, #0x40]
100064fd4:     	b.lo	0x100067254 <<la_stack::rational::RationalMatrix<8>>::solve+0x35d4>
100064fd8:     	ldr	x26, [sp, #0xd8]
100064fdc:     	add	x19, x26, x19, lsl #9
100064fe0:     	str	x16, [sp, #0xc0]
100064fe4:     	cbz	x16, 0x100065350 <<la_stack::rational::RationalMatrix<8>>::solve+0x16d0>
100064fe8:     	mov	x20, #0x0               ; =0
100064fec:     	lsl	x8, x0, #6
100064ff0:     	add	x21, x19, x8
100064ff4:     	add	x9, sp, #0xd10
100064ff8:     	add	x22, x9, x8
100064ffc:     	b	0x10006500c <<la_stack::rational::RationalMatrix<8>>::solve+0x138c>
100065000:     	add	x20, x20, #0x40
100065004:     	cmp	x25, x20
100065008:     	b.eq	0x10006534c <<la_stack::rational::RationalMatrix<8>>::solve+0x16cc>
10006500c:     	add	x8, x21, x20
100065010:     	ldrb	w8, [x8, #0x18]
100065014:     	cmp	w8, #0x1
100065018:     	b.eq	0x100065000 <<la_stack::rational::RationalMatrix<8>>::solve+0x1380>
10006501c:     	add	x8, x22, x20
100065020:     	ldrb	w8, [x8, #0x18]
100065024:     	cmp	w8, #0x1
100065028:     	b.eq	0x100065000 <<la_stack::rational::RationalMatrix<8>>::solve+0x1380>
10006502c:     	sub	x0, x29, #0xa0
100065030:     	add	x1, x21, x20
100065034:     	add	x2, x22, x20
100065038:     	bl	0x1000952e4 <<&num_bigint::bigint::BigInt as core::ops::arith::Mul>::mul>
10006503c:     	add	x8, x21, x20
100065040:     	add	x9, x22, x20
100065044:     	add	x0, sp, #0xe0
100065048:     	add	x1, x8, #0x20
10006504c:     	add	x2, x9, #0x20
100065050:     	bl	0x1000952e4 <<&num_bigint::bigint::BigInt as core::ops::arith::Mul>::mul>
100065054:     	add	x8, sp, #0xae0
100065058:     	ldrb	w8, [x8, #0xab8]
10006505c:     	ldrb	w23, [sp, #0xf8]
100065060:     	cmp	w8, w23
100065064:     	b.ne	0x100065110 <<la_stack::rational::RationalMatrix<8>>::solve+0x1490>
100065068:     	cmp	w8, #0x1
10006506c:     	b.ne	0x1000650ac <<la_stack::rational::RationalMatrix<8>>::solve+0x142c>
100065070:     	ldp	q0, q1, [x29, #-0xa0]
100065074:     	str	q0, [sp, #0x16c0]
100065078:     	str	q1, [sp, #0x16d0]
10006507c:     	mov	w23, #0x1               ; =1
100065080:     	mov	w27, #0x0               ; =0
100065084:     	add	x0, sp, #0xcd0
100065088:     	add	x1, sp, #0x1, lsl #12   ; =0x1000
10006508c:     	add	x1, x1, #0x6c0
100065090:     	bl	0x100096568 <<num_bigint::bigint::BigInt as core::ops::arith::SubAssign>::sub_assign>
100065094:     	ldr	x8, [sp, #0xe0]
100065098:     	cmp	x8, #0x1
10006509c:     	b.lt	0x100065000 <<la_stack::rational::RationalMatrix<8>>::solve+0x1380>
1000650a0:     	ldr	x0, [sp, #0xe8]
1000650a4:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
1000650a8:     	b	0x100065000 <<la_stack::rational::RationalMatrix<8>>::solve+0x1380>
1000650ac:     	ldr	x8, [sp, #0x1580]
1000650b0:     	ldr	x9, [sp, #0x1588]
1000650b4:     	ldr	x10, [sp, #0x1590]
1000650b8:     	cmn	x8, #0x1
1000650bc:     	csel	x10, x9, x10, eq
1000650c0:     	ldp	x11, x12, [sp, #0xe0]
1000650c4:     	ldr	x13, [sp, #0xf0]
1000650c8:     	cmn	x11, #0x1
1000650cc:     	csel	x13, x12, x13, eq
1000650d0:     	cmp	x10, x13
1000650d4:     	b.ne	0x100065110 <<la_stack::rational::RationalMatrix<8>>::solve+0x1490>
1000650d8:     	tst	w12, #0x1
1000650dc:     	ldr	x13, [sp, #0xb0]
1000650e0:     	mov	w14, #0x8               ; =8
1000650e4:     	csel	x13, x13, x14, ne
1000650e8:     	cmn	x11, #0x1
1000650ec:     	csel	x1, x13, x12, eq
1000650f0:     	tst	w9, #0x1
1000650f4:     	ldr	x11, [sp, #0xb8]
1000650f8:     	csel	x11, x11, x14, ne
1000650fc:     	cmn	x8, #0x1
100065100:     	csel	x0, x11, x9, eq
100065104:     	lsl	x2, x10, #3
100065108:     	bl	0x100219ff0 <dyld_stub_binder+0x100219ff0>
10006510c:     	cbz	w0, 0x100065070 <<la_stack::rational::RationalMatrix<8>>::solve+0x13f0>
100065110:     	ldr	q0, [sp, #0xcd0]
100065114:     	str	q0, [sp, #0x9e0]
100065118:     	ldr	x8, [sp, #0xce0]
10006511c:     	str	x8, [sp, #0x9f0]
100065120:     	ldrb	w8, [sp, #0xce8]
100065124:     	cmp	w8, #0x1
100065128:     	b.eq	0x10006513c <<la_stack::rational::RationalMatrix<8>>::solve+0x14bc>
10006512c:     	cmp	w23, #0x2
100065130:     	b.eq	0x10006519c <<la_stack::rational::RationalMatrix<8>>::solve+0x151c>
100065134:     	cmp	w23, #0x1
100065138:     	b.ne	0x1000651a8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1528>
10006513c:     	mov	w27, #0x1               ; =1
100065140:     	mov	w23, #0x0               ; =0
100065144:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
100065148:     	add	x0, x0, #0x6c0
10006514c:     	add	x1, sp, #0x9e0
100065150:     	add	x2, sp, #0xe0
100065154:     	bl	0x10008b8f4 <<num_bigint::biguint::BigUint as core::ops::arith::Mul<&num_bigint::biguint::BigUint>>::mul>
100065158:     	ldr	x8, [sp, #0x16c0]
10006515c:     	cmn	x8, #0x1
100065160:     	b.eq	0x100065190 <<la_stack::rational::RationalMatrix<8>>::solve+0x1510>
100065164:     	str	xzr, [sp, #0x16d0]
100065168:     	cmp	x8, #0x2
10006516c:     	b.lo	0x100065194 <<la_stack::rational::RationalMatrix<8>>::solve+0x1514>
100065170:     	ldr	x0, [sp, #0x16c8]
100065174:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
100065178:     	str	xzr, [sp, #0x16d0]
10006517c:     	adrp	x8, 0x100229000 <core::num::imp::flt2dec::strategy::dragon::POW5TO256+0x5f90>
100065180:     	add	x8, x8, #0xcc8
100065184:     	ldr	q0, [x8]
100065188:     	str	q0, [sp, #0x16c0]
10006518c:     	b	0x100065194 <<la_stack::rational::RationalMatrix<8>>::solve+0x1514>
100065190:     	str	xzr, [sp, #0x16c8]
100065194:     	mov	w8, #0x1                ; =1
100065198:     	b	0x1000651f8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1578>
10006519c:     	cbz	w8, 0x1000651ac <<la_stack::rational::RationalMatrix<8>>::solve+0x152c>
1000651a0:     	mov	w24, #0x2               ; =2
1000651a4:     	b	0x1000651b0 <<la_stack::rational::RationalMatrix<8>>::solve+0x1530>
1000651a8:     	cbz	w8, 0x1000651a0 <<la_stack::rational::RationalMatrix<8>>::solve+0x1520>
1000651ac:     	mov	w24, #0x0               ; =0
1000651b0:     	mov	w27, #0x1               ; =1
1000651b4:     	mov	w23, #0x0               ; =0
1000651b8:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000651bc:     	add	x0, x0, #0x6c0
1000651c0:     	add	x1, sp, #0x9e0
1000651c4:     	add	x2, sp, #0xe0
1000651c8:     	bl	0x10008b8f4 <<num_bigint::biguint::BigUint as core::ops::arith::Mul<&num_bigint::biguint::BigUint>>::mul>
1000651cc:     	ldr	x8, [sp, #0x16c0]
1000651d0:     	cmn	x8, #0x1
1000651d4:     	b.eq	0x1000651e8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1568>
1000651d8:     	ldr	x8, [sp, #0x16d0]
1000651dc:     	cmp	x8, #0x0
1000651e0:     	cset	w8, eq
1000651e4:     	b	0x1000651f0 <<la_stack::rational::RationalMatrix<8>>::solve+0x1570>
1000651e8:     	ldr	w8, [sp, #0x16c8]
1000651ec:     	eor	w8, w8, #0x1
1000651f0:     	cmp	w8, #0x0
1000651f4:     	csinc	w8, w24, wzr, eq
1000651f8:     	ldr	q0, [sp, #0x16c0]
1000651fc:     	str	q0, [sp, #0x15c0]
100065200:     	ldr	x9, [sp, #0x16d0]
100065204:     	str	x9, [sp, #0x15d0]
100065208:     	add	x9, sp, #0xae0
10006520c:     	strb	w8, [x9, #0xaf8]
100065210:     	ldur	q0, [x29, #-0xa0]
100065214:     	str	q0, [sp, #0xcf0]
100065218:     	ldur	x8, [x29, #-0x90]
10006521c:     	str	x8, [sp, #0xd00]
100065220:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100065224:     	add	x8, x8, #0x6c0
100065228:     	ldrb	w8, [x8, #0x218]
10006522c:     	cmp	w8, #0x1
100065230:     	b.eq	0x10006524c <<la_stack::rational::RationalMatrix<8>>::solve+0x15cc>
100065234:     	add	x9, sp, #0xae0
100065238:     	ldrb	w9, [x9, #0xab8]
10006523c:     	cmp	w9, #0x2
100065240:     	b.eq	0x1000652a4 <<la_stack::rational::RationalMatrix<8>>::solve+0x1624>
100065244:     	cmp	w9, #0x1
100065248:     	b.ne	0x1000652b0 <<la_stack::rational::RationalMatrix<8>>::solve+0x1630>
10006524c:     	add	x0, sp, #0x9e0
100065250:     	add	x1, sp, #0xcf0
100065254:     	add	x2, sp, #0x1, lsl #12   ; =0x1000
100065258:     	add	x2, x2, #0x580
10006525c:     	bl	0x10008b8f4 <<num_bigint::biguint::BigUint as core::ops::arith::Mul<&num_bigint::biguint::BigUint>>::mul>
100065260:     	ldr	x8, [sp, #0x9e0]
100065264:     	cmn	x8, #0x1
100065268:     	b.eq	0x100065298 <<la_stack::rational::RationalMatrix<8>>::solve+0x1618>
10006526c:     	str	xzr, [sp, #0x9f0]
100065270:     	cmp	x8, #0x2
100065274:     	b.lo	0x10006529c <<la_stack::rational::RationalMatrix<8>>::solve+0x161c>
100065278:     	ldr	x0, [sp, #0x9e8]
10006527c:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
100065280:     	str	xzr, [sp, #0x9f0]
100065284:     	adrp	x8, 0x100229000 <core::num::imp::flt2dec::strategy::dragon::POW5TO256+0x5f90>
100065288:     	add	x8, x8, #0xcc8
10006528c:     	ldr	q0, [x8]
100065290:     	str	q0, [sp, #0x9e0]
100065294:     	b	0x10006529c <<la_stack::rational::RationalMatrix<8>>::solve+0x161c>
100065298:     	str	xzr, [sp, #0x9e8]
10006529c:     	mov	w8, #0x1                ; =1
1000652a0:     	b	0x1000652f8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1678>
1000652a4:     	cbz	w8, 0x1000652b4 <<la_stack::rational::RationalMatrix<8>>::solve+0x1634>
1000652a8:     	mov	w23, #0x2               ; =2
1000652ac:     	b	0x1000652b8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1638>
1000652b0:     	cbz	w8, 0x1000652a8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1628>
1000652b4:     	mov	w23, #0x0               ; =0
1000652b8:     	add	x0, sp, #0x9e0
1000652bc:     	add	x1, sp, #0xcf0
1000652c0:     	add	x2, sp, #0x1, lsl #12   ; =0x1000
1000652c4:     	add	x2, x2, #0x580
1000652c8:     	bl	0x10008b8f4 <<num_bigint::biguint::BigUint as core::ops::arith::Mul<&num_bigint::biguint::BigUint>>::mul>
1000652cc:     	ldr	x8, [sp, #0x9e0]
1000652d0:     	cmn	x8, #0x1
1000652d4:     	b.eq	0x1000652e8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1668>
1000652d8:     	ldr	x8, [sp, #0x9f0]
1000652dc:     	cmp	x8, #0x0
1000652e0:     	cset	w8, eq
1000652e4:     	b	0x1000652f0 <<la_stack::rational::RationalMatrix<8>>::solve+0x1670>
1000652e8:     	ldr	w8, [sp, #0x9e8]
1000652ec:     	eor	w8, w8, #0x1
1000652f0:     	cmp	w8, #0x0
1000652f4:     	csinc	w8, w23, wzr, eq
1000652f8:     	ldr	q0, [sp, #0x9e0]
1000652fc:     	str	q0, [sp, #0x16c0]
100065300:     	ldr	x9, [sp, #0x9f0]
100065304:     	str	x9, [sp, #0x16d0]
100065308:     	add	x9, sp, #0xae0
10006530c:     	strb	w8, [x9, #0xbf8]
100065310:     	add	x0, sp, #0x9e0
100065314:     	add	x1, sp, #0x1, lsl #12   ; =0x1000
100065318:     	add	x1, x1, #0x5c0
10006531c:     	add	x2, sp, #0x1, lsl #12   ; =0x1000
100065320:     	add	x2, x2, #0x6c0
100065324:     	bl	0x100083ec4 <<num_bigint::bigint::BigInt as core::ops::arith::Sub>::sub>
100065328:     	ldr	q0, [sp, #0x9e0]
10006532c:     	ldr	q1, [sp, #0x9f0]
100065330:     	str	q0, [sp, #0xcd0]
100065334:     	str	q1, [sp, #0xce0]
100065338:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
10006533c:     	add	x0, x0, #0x580
100065340:     	add	x1, sp, #0xe0
100065344:     	bl	0x100095628 <<num_bigint::bigint::BigInt as core::ops::arith::MulAssign>::mul_assign>
100065348:     	b	0x100065000 <<la_stack::rational::RationalMatrix<8>>::solve+0x1380>
10006534c:     	ldrb	w21, [sp, #0xce8]
100065350:     	ldr	x8, [sp, #0xd0]
100065354:     	add	x20, x19, x8, lsl #6
100065358:     	ldr	q0, [sp, #0xcd0]
10006535c:     	str	q0, [sp, #0x15c0]
100065360:     	ldr	x8, [sp, #0xce0]
100065364:     	str	x8, [sp, #0x15d0]
100065368:     	cmp	w21, #0x1
10006536c:     	b.eq	0x100065380 <<la_stack::rational::RationalMatrix<8>>::solve+0x1700>
100065370:     	ldrb	w8, [x20, #0x38]
100065374:     	cbz	w8, 0x1000653f4 <<la_stack::rational::RationalMatrix<8>>::solve+0x1774>
100065378:     	cmp	w8, #0x1
10006537c:     	b.ne	0x100065400 <<la_stack::rational::RationalMatrix<8>>::solve+0x1780>
100065380:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
100065384:     	add	x0, x0, #0x6c0
100065388:     	add	x1, sp, #0x1, lsl #12   ; =0x1000
10006538c:     	add	x1, x1, #0x5c0
100065390:     	add	x2, x20, #0x20
100065394:     	bl	0x10008b8f4 <<num_bigint::biguint::BigUint as core::ops::arith::Mul<&num_bigint::biguint::BigUint>>::mul>
100065398:     	ldr	x21, [sp, #0x16c0]
10006539c:     	cmn	x21, #0x1
1000653a0:     	b.eq	0x1000653bc <<la_stack::rational::RationalMatrix<8>>::solve+0x173c>
1000653a4:     	str	xzr, [sp, #0x16d0]
1000653a8:     	ldr	x19, [sp, #0x16c8]
1000653ac:     	cmp	x21, #0x2
1000653b0:     	b.hs	0x1000653c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1748>
1000653b4:     	mov	w22, #0x1               ; =1
1000653b8:     	b	0x100065450 <<la_stack::rational::RationalMatrix<8>>::solve+0x17d0>
1000653bc:     	mov	x19, #0x0               ; =0
1000653c0:     	mov	w22, #0x1               ; =1
1000653c4:     	b	0x100065450 <<la_stack::rational::RationalMatrix<8>>::solve+0x17d0>
1000653c8:     	mov	x0, x19
1000653cc:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
1000653d0:     	mov	x19, #0x0               ; =0
1000653d4:     	str	xzr, [sp, #0x16d0]
1000653d8:     	adrp	x8, 0x100229000 <core::num::imp::flt2dec::strategy::dragon::POW5TO256+0x5f90>
1000653dc:     	add	x8, x8, #0xcc8
1000653e0:     	ldr	q0, [x8]
1000653e4:     	str	q0, [sp, #0x16c0]
1000653e8:     	mov	w22, #0x1               ; =1
1000653ec:     	mov	x21, #-0x1              ; =-1
1000653f0:     	b	0x100065450 <<la_stack::rational::RationalMatrix<8>>::solve+0x17d0>
1000653f4:     	cbz	w21, 0x100065404 <<la_stack::rational::RationalMatrix<8>>::solve+0x1784>
1000653f8:     	mov	w22, #0x0               ; =0
1000653fc:     	b	0x100065408 <<la_stack::rational::RationalMatrix<8>>::solve+0x1788>
100065400:     	cbz	w21, 0x1000653f8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1778>
100065404:     	mov	w22, #0x2               ; =2
100065408:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
10006540c:     	add	x0, x0, #0x6c0
100065410:     	add	x1, sp, #0x1, lsl #12   ; =0x1000
100065414:     	add	x1, x1, #0x5c0
100065418:     	add	x2, x20, #0x20
10006541c:     	bl	0x10008b8f4 <<num_bigint::biguint::BigUint as core::ops::arith::Mul<&num_bigint::biguint::BigUint>>::mul>
100065420:     	ldr	x21, [sp, #0x16c0]
100065424:     	cmn	x21, #0x1
100065428:     	b.eq	0x100065440 <<la_stack::rational::RationalMatrix<8>>::solve+0x17c0>
10006542c:     	ldr	x8, [sp, #0x16d0]
100065430:     	ldr	x19, [sp, #0x16c8]
100065434:     	cmp	x8, #0x0
100065438:     	cset	w8, eq
10006543c:     	b	0x100065448 <<la_stack::rational::RationalMatrix<8>>::solve+0x17c8>
100065440:     	ldr	x19, [sp, #0x16c8]
100065444:     	eor	w8, w19, #0x1
100065448:     	cmp	w8, #0x0
10006544c:     	csinc	w22, w22, wzr, eq
100065450:     	ldr	x23, [sp, #0x16d0]
100065454:     	ldr	q0, [sp, #0x1580]
100065458:     	str	q0, [sp, #0x9e0]
10006545c:     	ldr	x8, [sp, #0x1590]
100065460:     	str	x8, [sp, #0x9f0]
100065464:     	add	x8, sp, #0xae0
100065468:     	ldrb	w8, [x8, #0xab8]
10006546c:     	cmp	w8, #0x1
100065470:     	b.eq	0x100065488 <<la_stack::rational::RationalMatrix<8>>::solve+0x1808>
100065474:     	ldrb	w9, [x20, #0x18]
100065478:     	cmp	w9, #0x2
10006547c:     	b.eq	0x1000654e0 <<la_stack::rational::RationalMatrix<8>>::solve+0x1860>
100065480:     	cmp	w9, #0x1
100065484:     	b.ne	0x1000654ec <<la_stack::rational::RationalMatrix<8>>::solve+0x186c>
100065488:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
10006548c:     	add	x0, x0, #0x5c0
100065490:     	add	x1, sp, #0x9e0
100065494:     	mov	x2, x20
100065498:     	bl	0x10008b8f4 <<num_bigint::biguint::BigUint as core::ops::arith::Mul<&num_bigint::biguint::BigUint>>::mul>
10006549c:     	ldr	x8, [sp, #0x15c0]
1000654a0:     	cmn	x8, #0x1
1000654a4:     	b.eq	0x1000654d4 <<la_stack::rational::RationalMatrix<8>>::solve+0x1854>
1000654a8:     	str	xzr, [sp, #0x15d0]
1000654ac:     	cmp	x8, #0x2
1000654b0:     	b.lo	0x1000654d8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1858>
1000654b4:     	ldr	x0, [sp, #0x15c8]
1000654b8:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
1000654bc:     	str	xzr, [sp, #0x15d0]
1000654c0:     	adrp	x8, 0x100229000 <core::num::imp::flt2dec::strategy::dragon::POW5TO256+0x5f90>
1000654c4:     	add	x8, x8, #0xcc8
1000654c8:     	ldr	q0, [x8]
1000654cc:     	str	q0, [sp, #0x15c0]
1000654d0:     	b	0x1000654d8 <<la_stack::rational::RationalMatrix<8>>::solve+0x1858>
1000654d4:     	str	xzr, [sp, #0x15c8]
1000654d8:     	mov	w8, #0x1                ; =1
1000654dc:     	b	0x100065534 <<la_stack::rational::RationalMatrix<8>>::solve+0x18b4>
1000654e0:     	cbz	w8, 0x1000654f0 <<la_stack::rational::RationalMatrix<8>>::solve+0x1870>
1000654e4:     	mov	w24, #0x2               ; =2
1000654e8:     	b	0x1000654f4 <<la_stack::rational::RationalMatrix<8>>::solve+0x1874>
1000654ec:     	cbz	w8, 0x1000654e4 <<la_stack::rational::RationalMatrix<8>>::solve+0x1864>
1000654f0:     	mov	w24, #0x0               ; =0
1000654f4:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000654f8:     	add	x0, x0, #0x5c0
1000654fc:     	add	x1, sp, #0x9e0
100065500:     	mov	x2, x20
100065504:     	bl	0x10008b8f4 <<num_bigint::biguint::BigUint as core::ops::arith::Mul<&num_bigint::biguint::BigUint>>::mul>
100065508:     	ldr	x8, [sp, #0x15c0]
10006550c:     	cmn	x8, #0x1
100065510:     	b.eq	0x100065524 <<la_stack::rational::RationalMatrix<8>>::solve+0x18a4>
100065514:     	ldr	x8, [sp, #0x15d0]
100065518:     	cmp	x8, #0x0
10006551c:     	cset	w8, eq
100065520:     	b	0x10006552c <<la_stack::rational::RationalMatrix<8>>::solve+0x18ac>
100065524:     	ldr	w8, [sp, #0x15c8]
100065528:     	eor	w8, w8, #0x1
10006552c:     	cmp	w8, #0x0
100065530:     	csinc	w8, w24, wzr, eq
100065534:     	ldr	q0, [sp, #0x15c0]
100065538:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
10006553c:     	add	x10, x10, #0x6c0
100065540:     	stur	q0, [x10, #0x20]
100065544:     	ldr	x9, [sp, #0x15d0]
100065548:     	stur	x9, [x10, #0x30]
10006554c:     	str	x21, [sp, #0x16c0]
100065550:     	str	x19, [sp, #0x16c8]
100065554:     	str	x23, [sp, #0x16d0]
100065558:     	add	x9, sp, #0xae0
10006555c:     	strb	w22, [x9, #0xbf8]
100065560:     	strb	w8, [x9, #0xc18]
100065564:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
100065568:     	add	x0, x0, #0x6c0
10006556c:     	bl	0x100069458 <<num_rational::Ratio<num_bigint::bigint::BigInt>>::reduce>
100065570:     	ldr	q0, [sp, #0x16c0]
100065574:     	ldr	q1, [sp, #0x16d0]
100065578:     	str	q0, [sp, #0x15c0]
10006557c:     	str	q1, [sp, #0x15d0]
100065580:     	ldr	q0, [sp, #0x16e0]
100065584:     	ldr	q1, [sp, #0x16f0]
100065588:     	str	q0, [sp, #0x15e0]
10006558c:     	str	q1, [sp, #0x15f0]
100065590:     	add	x8, sp, #0xd10
100065594:     	ldr	x9, [sp, #0xd0]
100065598:     	add	x19, x8, x9, lsl #6
10006559c:     	ldr	x8, [x19]
1000655a0:     	cmp	x8, #0x1
1000655a4:     	b.lt	0x1000655b0 <<la_stack::rational::RationalMatrix<8>>::solve+0x1930>
1000655a8:     	ldr	x0, [x19, #0x8]
1000655ac:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
1000655b0:     	ldr	x8, [x19, #0x20]
1000655b4:     	cmp	x8, #0x1
1000655b8:     	b.lt	0x100064e50 <<la_stack::rational::RationalMatrix<8>>::solve+0x11d0>
1000655bc:     	ldr	x0, [x19, #0x28]
1000655c0:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
1000655c4:     	b	0x100064e50 <<la_stack::rational::RationalMatrix<8>>::solve+0x11d0>
1000655c8:     	ldr	x19, [sp, #0xd10]
1000655cc:     	add	x0, sp, #0x1e0
1000655d0:     	add	x8, sp, #0xd10
1000655d4:     	add	x1, x8, #0x8
1000655d8:     	mov	w2, #0x1f8              ; =504
1000655dc:     	bl	0x100219ffc <dyld_stub_binder+0x100219ffc>
1000655e0:     	cmn	x19, #0x2
1000655e4:     	b.ne	0x100067238 <<la_stack::rational::RationalMatrix<8>>::solve+0x35b8>
1000655e8:     	add	x19, x26, #0x200
1000655ec:     	str	x26, [sp, #0xd20]
1000655f0:     	str	x19, [sp, #0xd28]
1000655f4:     	mov	w21, #0x1               ; =1
1000655f8:     	str	x21, [sp, #0xd10]
1000655fc:     	str	x28, [sp, #0xd18]
100065600:     	add	x0, sp, #0x1e0
100065604:     	add	x1, sp, #0xd10
100065608:     	bl	0x100047fd8 <la_stack::rational::common_denominator::<core::iter::adapters::chain::Chain<core::slice::iter::Iter<num_rational::Ratio<num_bigint::bigint::BigInt>>, core::iter::sources::once::Once<&num_rational::Ratio<num_bigint::bigint::BigInt>>>>>
10006560c:     	ldp	x9, x8, [sp, #0x1e0]
100065610:     	stp	x8, x9, [sp, #0xc8]
100065614:     	ldr	q0, [sp, #0x1f0]
100065618:     	str	q0, [sp, #0xae0]
10006561c:     	str	q0, [sp, #0x15c0]
100065620:     	str	q0, [sp, #0x16c0]
100065624:     	str	q0, [sp, #0x9e0]
100065628:     	add	x22, x26, #0x400
10006562c:     	add	x9, x28, #0x40
100065630:     	str	x19, [sp, #0xd20]
100065634:     	str	x22, [sp, #0xd28]
100065638:     	str	x21, [sp, #0xd10]
10006563c:     	add	x8, x28, #0x40
100065640:     	str	x8, [sp, #0x38]
100065644:     	str	x9, [sp, #0xd18]
100065648:     	mov	w24, #0x0               ; =0
10006564c:     	mov	w27, #0x0               ; =0
100065650:     	mov	w23, #0x0               ; =0
100065654:     	mov	w19, #0x0               ; =0
100065658:     	add	x0, sp, #0x1e0
10006565c:     	add	x1, sp, #0xd10
100065660:     	mov	w20, #0x1               ; =1
100065664:     	bl	0x100047fd8 <la_stack::rational::common_denominator::<core::iter::adapters::chain::Chain<core::slice::iter::Iter<num_rational::Ratio<num_bigint::bigint::BigInt>>, core::iter::sources::once::Once<&num_rational::Ratio<num_bigint::bigint::BigInt>>>>>
100065668:     	ldp	x9, x8, [sp, #0x1e0]
10006566c:     	str	x9, [sp, #0xc0]
100065670:     	str	x8, [sp, #0xa8]
100065674:     	ldr	q0, [sp, #0x1f0]
100065678:     	str	q0, [sp, #0x16c0]
10006567c:     	stur	q0, [x29, #-0xa0]
100065680:     	add	x25, x26, #0x600
100065684:     	add	x9, x28, #0x80
100065688:     	str	x22, [sp, #0xd20]
10006568c:     	str	x25, [sp, #0xd28]
100065690:     	mov	w24, #0x1               ; =1
100065694:     	str	x24, [sp, #0xd10]
100065698:     	add	x8, x28, #0x80
10006569c:     	str	x8, [sp, #0x30]
1000656a0:     	str	x9, [sp, #0xd18]
1000656a4:     	mov	w21, #0x0               ; =0
1000656a8:     	mov	w27, #0x0               ; =0
1000656ac:     	mov	w23, #0x0               ; =0
1000656b0:     	mov	w19, #0x0               ; =0
1000656b4:     	add	x0, sp, #0x1e0
1000656b8:     	add	x1, sp, #0xd10
1000656bc:     	mov	w20, #0x1               ; =1
1000656c0:     	bl	0x100047fd8 <la_stack::rational::common_denominator::<core::iter::adapters::chain::Chain<core::slice::iter::Iter<num_rational::Ratio<num_bigint::bigint::BigInt>>, core::iter::sources::once::Once<&num_rational::Ratio<num_bigint::bigint::BigInt>>>>>
1000656c4:     	ldp	x9, x8, [sp, #0x1e0]
1000656c8:     	stp	x8, x9, [sp, #0x98]
1000656cc:     	ldr	q0, [sp, #0x1f0]
1000656d0:     	str	q0, [sp, #0x16c0]
1000656d4:     	str	q0, [sp, #0x1580]
1000656d8:     	add	x22, x26, #0x800
1000656dc:     	add	x9, x28, #0xc0
1000656e0:     	str	x25, [sp, #0xd20]
1000656e4:     	str	x22, [sp, #0xd28]
1000656e8:     	mov	w27, #0x1               ; =1
1000656ec:     	str	x27, [sp, #0xd10]
1000656f0:     	add	x8, x28, #0xc0
1000656f4:     	str	x8, [sp, #0x28]
1000656f8:     	str	x9, [sp, #0xd18]
1000656fc:     	mov	w21, #0x0               ; =0
100065700:     	mov	w24, #0x0               ; =0
100065704:     	mov	w23, #0x0               ; =0
100065708:     	mov	w19, #0x0               ; =0
10006570c:     	add	x0, sp, #0x1e0
100065710:     	add	x1, sp, #0xd10
100065714:     	mov	w20, #0x1               ; =1
100065718:     	bl	0x100047fd8 <la_stack::rational::common_denominator::<core::iter::adapters::chain::Chain<core::slice::iter::Iter<num_rational::Ratio<num_bigint::bigint::BigInt>>, core::iter::sources::once::Once<&num_rational::Ratio<num_bigint::bigint::BigInt>>>>>
10006571c:     	ldp	x9, x8, [sp, #0x1e0]
100065720:     	stp	x8, x9, [sp, #0x78]
100065724:     	ldr	q0, [sp, #0x1f0]
100065728:     	str	q0, [sp, #0x16c0]
10006572c:     	str	q0, [sp, #0xcd0]
100065730:     	add	x25, x26, #0xa00
100065734:     	add	x9, x28, #0x100
100065738:     	str	x22, [sp, #0xd20]
10006573c:     	str	x25, [sp, #0xd28]
100065740:     	mov	w23, #0x1               ; =1
100065744:     	str	x23, [sp, #0xd10]
100065748:     	add	x8, x28, #0x100
10006574c:     	str	x8, [sp, #0x20]
100065750:     	str	x9, [sp, #0xd18]
100065754:     	mov	w21, #0x0               ; =0
100065758:     	mov	w24, #0x0               ; =0
10006575c:     	mov	w27, #0x0               ; =0
100065760:     	mov	w19, #0x0               ; =0
100065764:     	add	x0, sp, #0x1e0
100065768:     	add	x1, sp, #0xd10
10006576c:     	mov	w20, #0x1               ; =1
100065770:     	bl	0x100047fd8 <la_stack::rational::common_denominator::<core::iter::adapters::chain::Chain<core::slice::iter::Iter<num_rational::Ratio<num_bigint::bigint::BigInt>>, core::iter::sources::once::Once<&num_rational::Ratio<num_bigint::bigint::BigInt>>>>>
100065774:     	ldp	x9, x8, [sp, #0x1e0]
100065778:     	str	x9, [sp, #0x70]
10006577c:     	str	x8, [sp, #0x60]
100065780:     	ldr	q0, [sp, #0x1f0]
100065784:     	str	q0, [sp, #0x16c0]
100065788:     	str	q0, [sp, #0xcf0]
10006578c:     	add	x22, x26, #0xc00
100065790:     	add	x9, x28, #0x140
100065794:     	str	x25, [sp, #0xd20]
100065798:     	str	x22, [sp, #0xd28]
10006579c:     	mov	w19, #0x1               ; =1
1000657a0:     	str	x19, [sp, #0xd10]
1000657a4:     	add	x8, x28, #0x140
1000657a8:     	str	x8, [sp, #0x18]
1000657ac:     	str	x9, [sp, #0xd18]
1000657b0:     	mov	w21, #0x0               ; =0
1000657b4:     	mov	w24, #0x0               ; =0
1000657b8:     	mov	w27, #0x0               ; =0
1000657bc:     	mov	w23, #0x0               ; =0
1000657c0:     	add	x0, sp, #0x1e0
1000657c4:     	add	x1, sp, #0xd10
1000657c8:     	mov	w20, #0x1               ; =1
1000657cc:     	bl	0x100047fd8 <la_stack::rational::common_denominator::<core::iter::adapters::chain::Chain<core::slice::iter::Iter<num_rational::Ratio<num_bigint::bigint::BigInt>>, core::iter::sources::once::Once<&num_rational::Ratio<num_bigint::bigint::BigInt>>>>>
1000657d0:     	ldp	x9, x8, [sp, #0x1e0]
1000657d4:     	stp	x8, x9, [sp, #0x50]
1000657d8:     	ldr	q0, [sp, #0x1f0]
1000657dc:     	str	q0, [sp, #0x16c0]
1000657e0:     	str	q0, [sp, #0x1570]
1000657e4:     	add	x25, x26, #0xe00
1000657e8:     	add	x9, x28, #0x180
1000657ec:     	str	x22, [sp, #0xd20]
1000657f0:     	str	x25, [sp, #0xd28]
1000657f4:     	mov	w8, #0x1                ; =1
1000657f8:     	str	x8, [sp, #0xd10]
1000657fc:     	add	x8, x28, #0x180
100065800:     	str	x8, [sp, #0x10]
100065804:     	str	x9, [sp, #0xd18]
100065808:     	mov	w21, #0x0               ; =0
10006580c:     	mov	w24, #0x0               ; =0
100065810:     	mov	w27, #0x0               ; =0
100065814:     	mov	w23, #0x0               ; =0
100065818:     	mov	w19, #0x0               ; =0
10006581c:     	mov	w20, #0x0               ; =0
100065820:     	add	x0, sp, #0x1e0
100065824:     	add	x1, sp, #0xd10
100065828:     	bl	0x100047fd8 <la_stack::rational::common_denominator::<core::iter::adapters::chain::Chain<core::slice::iter::Iter<num_rational::Ratio<num_bigint::bigint::BigInt>>, core::iter::sources::once::Once<&num_rational::Ratio<num_bigint::bigint::BigInt>>>>>
10006582c:     	ldp	x9, x8, [sp, #0x1e0]
100065830:     	stp	x9, x8, [sp, #0xb0]
100065834:     	ldr	q0, [sp, #0x1f0]
100065838:     	str	q0, [sp, #0x16c0]
10006583c:     	str	q0, [sp, #0x1560]
100065840:     	add	x8, x26, #0x1, lsl #12  ; =0x1000
100065844:     	add	x9, x28, #0x1c0
100065848:     	str	x25, [sp, #0xd20]
10006584c:     	str	x8, [sp, #0xd28]
100065850:     	mov	w20, #0x1               ; =1
100065854:     	str	x20, [sp, #0xd10]
100065858:     	str	x9, [sp, #0x8]
10006585c:     	str	x9, [sp, #0xd18]
100065860:     	mov	w21, #0x0               ; =0
100065864:     	mov	w24, #0x0               ; =0
100065868:     	mov	w27, #0x0               ; =0
10006586c:     	mov	w23, #0x0               ; =0
100065870:     	mov	w19, #0x0               ; =0
100065874:     	add	x26, sp, #0x1e0
100065878:     	add	x25, sp, #0xd10
10006587c:     	add	x0, sp, #0x1e0
100065880:     	add	x1, sp, #0xd10
100065884:     	bl	0x100047fd8 <la_stack::rational::common_denominator::<core::iter::adapters::chain::Chain<core::slice::iter::Iter<num_rational::Ratio<num_bigint::bigint::BigInt>>, core::iter::sources::once::Once<&num_rational::Ratio<num_bigint::bigint::BigInt>>>>>
100065888:     	mov	x23, #0x0               ; =0
10006588c:     	mov	x19, #0x0               ; =0
100065890:     	mov	x10, #0x0               ; =0
100065894:     	ldp	x8, x9, [sp, #0xc8]
100065898:     	stp	x9, x8, [sp, #0xe0]
10006589c:     	ldp	x8, x9, [sp, #0x1e0]
1000658a0:     	ldr	q0, [sp, #0x1f0]
1000658a4:     	str	q0, [sp, #0xd10]
1000658a8:     	ldr	q0, [sp, #0x9e0]
1000658ac:     	str	q0, [sp, #0xf0]
1000658b0:     	ldr	x11, [sp, #0xc0]
1000658b4:     	str	x11, [sp, #0x100]
1000658b8:     	ldr	x11, [sp, #0xa8]
1000658bc:     	str	x11, [sp, #0x108]
1000658c0:     	ldur	q0, [x29, #-0xa0]
1000658c4:     	str	q0, [sp, #0x110]
1000658c8:     	ldr	x11, [sp, #0xa0]
1000658cc:     	str	x11, [sp, #0x120]
1000658d0:     	ldr	x11, [sp, #0x98]
1000658d4:     	str	x11, [sp, #0x128]
1000658d8:     	ldr	q0, [sp, #0x1580]
1000658dc:     	str	q0, [sp, #0x130]
1000658e0:     	ldr	x11, [sp, #0x80]
1000658e4:     	str	x11, [sp, #0x140]
1000658e8:     	ldr	x11, [sp, #0x78]
1000658ec:     	str	x11, [sp, #0x148]
1000658f0:     	ldr	q0, [sp, #0xcd0]
1000658f4:     	str	q0, [sp, #0x150]
1000658f8:     	ldr	x11, [sp, #0x70]
1000658fc:     	str	x11, [sp, #0x160]
100065900:     	ldr	x11, [sp, #0x60]
100065904:     	str	x11, [sp, #0x168]
100065908:     	ldr	q0, [sp, #0xcf0]
10006590c:     	str	q0, [sp, #0x170]
100065910:     	ldr	x11, [sp, #0x58]
100065914:     	str	x11, [sp, #0x180]
100065918:     	ldr	x11, [sp, #0x50]
10006591c:     	str	x11, [sp, #0x188]
100065920:     	ldr	q0, [sp, #0x1570]
100065924:     	str	q0, [sp, #0x190]
100065928:     	ldr	x11, [sp, #0xb0]
10006592c:     	str	x11, [sp, #0x1a0]
100065930:     	ldr	x11, [sp, #0xb8]
100065934:     	str	x11, [sp, #0x1a8]
100065938:     	ldr	q0, [sp, #0x1560]
10006593c:     	str	q0, [sp, #0x1b0]
100065940:     	stp	x8, x9, [sp, #0x1c0]
100065944:     	ldr	q0, [sp, #0xd10]
100065948:     	add	x22, x25, #0x80
10006594c:     	add	x24, sp, #0xe0
100065950:     	str	q0, [sp, #0x1d0]
100065954:     	str	x10, [sp, #0xd0]
100065958:     	ldr	x21, [sp, #0xd8]
10006595c:     	add	x20, x21, x19
100065960:     	add	x0, sp, #0x1e0
100065964:     	add	x1, x21, x19
100065968:     	add	x2, x24, x23
10006596c:     	bl	0x100167600 <la_stack::rational::integer_at_scale>
100065970:     	ldp	x9, x8, [sp, #0x1e0]
100065974:     	stp	x8, x9, [sp, #0xc0]
100065978:     	ldur	q0, [x26, #0x10]
10006597c:     	str	q0, [sp, #0x16c0]
100065980:     	str	q0, [sp, #0x9e0]
100065984:     	add	x0, sp, #0x1e0
100065988:     	add	x1, x20, #0x40
10006598c:     	add	x2, x24, x23
100065990:     	bl	0x100167600 <la_stack::rational::integer_at_scale>
100065994:     	ldp	x9, x8, [sp, #0x1e0]
100065998:     	stp	x8, x9, [sp, #0xb0]
10006599c:     	ldur	q0, [x26, #0x10]
1000659a0:     	str	q0, [sp, #0x16c0]
1000659a4:     	stur	q0, [x29, #-0xa0]
1000659a8:     	add	x26, x21, x19
1000659ac:     	mov	w27, #0x1               ; =1
1000659b0:     	mov	w21, #0x0               ; =0
1000659b4:     	mov	w20, #0x0               ; =0
1000659b8:     	mov	w25, #0x0               ; =0
1000659bc:     	add	x0, sp, #0x1e0
1000659c0:     	add	x1, x26, #0x80
1000659c4:     	add	x2, x24, x23
1000659c8:     	add	x28, sp, #0xe0
1000659cc:     	mov	w24, #0x1               ; =1
1000659d0:     	bl	0x100167600 <la_stack::rational::integer_at_scale>
1000659d4:     	ldp	x9, x8, [sp, #0x1e0]
1000659d8:     	stp	x8, x9, [sp, #0xa0]
1000659dc:     	add	x8, sp, #0x1e0
1000659e0:     	ldur	q0, [x8, #0x10]
1000659e4:     	str	q0, [sp, #0x16c0]
1000659e8:     	str	q0, [sp, #0x1580]
1000659ec:     	mov	w21, #0x1               ; =1
1000659f0:     	mov	w27, #0x0               ; =0
1000659f4:     	mov	w20, #0x0               ; =0
1000659f8:     	mov	w25, #0x0               ; =0
1000659fc:     	add	x0, sp, #0x1e0
100065a00:     	add	x1, x26, #0xc0
100065a04:     	add	x2, x28, x23
100065a08:     	bl	0x100167600 <la_stack::rational::integer_at_scale>
100065a0c:     	ldp	x9, x8, [sp, #0x1e0]
100065a10:     	str	x9, [sp, #0x98]
100065a14:     	str	x8, [sp, #0x80]
100065a18:     	add	x8, sp, #0x1e0
100065a1c:     	ldur	q0, [x8, #0x10]
100065a20:     	str	q0, [sp, #0x16c0]
100065a24:     	str	q0, [sp, #0xcd0]
100065a28:     	ldr	x8, [sp, #0xd8]
100065a2c:     	add	x26, x8, x19
100065a30:     	mov	w20, #0x1               ; =1
100065a34:     	mov	w27, #0x0               ; =0
100065a38:     	mov	w21, #0x0               ; =0
100065a3c:     	mov	w25, #0x0               ; =0
100065a40:     	add	x0, sp, #0x1e0
100065a44:     	add	x1, x26, #0x100
100065a48:     	add	x2, x28, x23
100065a4c:     	bl	0x100167600 <la_stack::rational::integer_at_scale>
100065a50:     	ldp	x9, x8, [sp, #0x1e0]
100065a54:     	stp	x8, x9, [sp, #0x70]
100065a58:     	add	x8, sp, #0x1e0
100065a5c:     	ldur	q0, [x8, #0x10]
100065a60:     	str	q0, [sp, #0x16c0]
100065a64:     	str	q0, [sp, #0xcf0]
100065a68:     	mov	w25, #0x1               ; =1
100065a6c:     	mov	w27, #0x0               ; =0
100065a70:     	mov	w21, #0x0               ; =0
100065a74:     	mov	w20, #0x0               ; =0
100065a78:     	add	x0, sp, #0x1e0
100065a7c:     	add	x1, x26, #0x140
100065a80:     	add	x2, x28, x23
100065a84:     	bl	0x100167600 <la_stack::rational::integer_at_scale>
100065a88:     	ldp	x9, x8, [sp, #0x1e0]
100065a8c:     	stp	x9, x8, [sp, #0x58]
100065a90:     	add	x8, sp, #0x1e0
100065a94:     	ldur	q0, [x8, #0x10]
100065a98:     	str	q0, [sp, #0x16c0]
100065a9c:     	str	q0, [sp, #0x1570]
100065aa0:     	ldr	x8, [sp, #0xd8]
100065aa4:     	add	x26, x8, x19
100065aa8:     	mov	w27, #0x0               ; =0
100065aac:     	mov	w21, #0x0               ; =0
100065ab0:     	mov	w20, #0x0               ; =0
100065ab4:     	mov	w25, #0x0               ; =0
100065ab8:     	mov	w24, #0x0               ; =0
100065abc:     	add	x0, sp, #0x1e0
100065ac0:     	add	x1, x26, #0x180
100065ac4:     	add	x2, x28, x23
100065ac8:     	bl	0x100167600 <la_stack::rational::integer_at_scale>
100065acc:     	ldp	x9, x8, [sp, #0x1e0]
100065ad0:     	stp	x9, x8, [sp, #0x48]
100065ad4:     	add	x8, sp, #0x1e0
100065ad8:     	ldur	q0, [x8, #0x10]
100065adc:     	str	q0, [sp, #0x16c0]
100065ae0:     	str	q0, [sp, #0x1560]
100065ae4:     	mov	w24, #0x1               ; =1
100065ae8:     	mov	w27, #0x0               ; =0
100065aec:     	mov	w21, #0x0               ; =0
100065af0:     	mov	w20, #0x0               ; =0
100065af4:     	mov	w25, #0x0               ; =0
100065af8:     	add	x0, sp, #0x1e0
100065afc:     	add	x1, x26, #0x1c0
100065b00:     	add	x2, x28, x23
100065b04:     	bl	0x100167600 <la_stack::rational::integer_at_scale>
100065b08:     	ldp	x8, x9, [sp, #0x1e0]
100065b0c:     	add	x10, sp, #0x1e0
100065b10:     	ldur	q0, [x10, #0x10]
100065b14:     	str	q0, [sp, #0x1e0]
100065b18:     	ldr	q0, [sp, #0x9e0]
100065b1c:     	str	q0, [sp, #0x16c0]
100065b20:     	ldur	q0, [x29, #-0xa0]
100065b24:     	str	q0, [sp, #0xae0]
100065b28:     	ldr	q0, [sp, #0x1580]
100065b2c:     	str	q0, [sp, #0x15c0]
100065b30:     	ldr	q0, [sp, #0xcd0]
100065b34:     	str	q0, [sp, #0x1550]
100065b38:     	ldr	q0, [sp, #0xcf0]
100065b3c:     	str	q0, [sp, #0x1540]
100065b40:     	ldr	q0, [sp, #0x1570]
100065b44:     	str	q0, [sp, #0x1530]
100065b48:     	ldr	q0, [sp, #0x1560]
100065b4c:     	str	q0, [sp, #0x1520]
100065b50:     	ldr	q0, [sp, #0x1e0]
100065b54:     	str	q0, [sp, #0x1510]
100065b58:     	ldp	x10, x11, [sp, #0xc0]
100065b5c:     	stp	x11, x10, [x22, #-0x80]
100065b60:     	ldr	q0, [sp, #0x16c0]
100065b64:     	stur	q0, [x22, #-0x70]
100065b68:     	ldp	x10, x11, [sp, #0xb0]
100065b6c:     	stp	x11, x10, [x22, #-0x60]
100065b70:     	ldr	q0, [sp, #0xae0]
100065b74:     	stur	q0, [x22, #-0x50]
100065b78:     	ldp	x10, x11, [sp, #0xa0]
100065b7c:     	stp	x11, x10, [x22, #-0x40]
100065b80:     	ldr	q0, [sp, #0x15c0]
100065b84:     	stur	q0, [x22, #-0x30]
100065b88:     	ldr	x11, [sp, #0x98]
100065b8c:     	ldr	x10, [sp, #0x80]
100065b90:     	stp	x11, x10, [x22, #-0x20]
100065b94:     	ldr	q0, [sp, #0x1550]
100065b98:     	stur	q0, [x22, #-0x10]
100065b9c:     	ldp	x10, x11, [sp, #0x70]
100065ba0:     	stp	x11, x10, [x22]
100065ba4:     	ldr	q0, [sp, #0x1540]
100065ba8:     	str	q0, [x22, #0x10]
100065bac:     	ldp	x11, x10, [sp, #0x58]
100065bb0:     	stp	x11, x10, [x22, #0x20]
100065bb4:     	ldr	q0, [sp, #0x1530]
100065bb8:     	str	q0, [x22, #0x30]
100065bbc:     	ldp	x11, x10, [sp, #0x48]
100065bc0:     	stp	x11, x10, [x22, #0x40]
100065bc4:     	ldr	q0, [sp, #0x1520]
100065bc8:     	str	q0, [x22, #0x50]
100065bcc:     	stp	x8, x9, [x22, #0x60]
100065bd0:     	ldr	x10, [sp, #0xd0]
100065bd4:     	add	x10, x10, #0x1
100065bd8:     	add	x19, x19, #0x200
100065bdc:     	ldr	q0, [sp, #0x1510]
100065be0:     	str	q0, [x22, #0x70]
100065be4:     	add	x22, x22, #0x100
100065be8:     	add	x23, x23, #0x20
100065bec:     	cmp	x19, #0x1, lsl #12      ; =0x1000
100065bf0:     	add	x26, sp, #0x1e0
100065bf4:     	add	x24, sp, #0xe0
100065bf8:     	b.ne	0x100065954 <<la_stack::rational::RationalMatrix<8>>::solve+0x1cd4>
100065bfc:     	add	x0, sp, #0x1e0
100065c00:     	add	x1, sp, #0xd10
100065c04:     	mov	w2, #0x800              ; =2048
100065c08:     	bl	0x100219ffc <dyld_stub_binder+0x100219ffc>
100065c0c:     	add	x21, sp, #0xe0
100065c10:     	add	x0, sp, #0xd10
100065c14:     	add	x2, sp, #0xe0
100065c18:     	ldr	x1, [sp, #0x40]
100065c1c:     	bl	0x100167600 <la_stack::rational::integer_at_scale>
100065c20:     	ldr	x9, [sp, #0xd10]
100065c24:     	ldr	x8, [sp, #0xd18]
100065c28:     	stp	x8, x9, [sp, #0xd0]
100065c2c:     	ldr	q0, [sp, #0xd20]
100065c30:     	str	q0, [sp, #0x16c0]
100065c34:     	stur	q0, [x29, #-0xa0]
100065c38:     	mov	w23, #0x1               ; =1
100065c3c:     	mov	w28, #0x0               ; =0
100065c40:     	mov	w27, #0x0               ; =0
100065c44:     	mov	w26, #0x0               ; =0
100065c48:     	mov	w20, #0x0               ; =0
100065c4c:     	add	x0, sp, #0xd10
100065c50:     	add	x2, x21, #0x20
100065c54:     	mov	w22, #0x1               ; =1
100065c58:     	ldr	x1, [sp, #0x38]
100065c5c:     	bl	0x100167600 <la_stack::rational::integer_at_scale>
100065c60:     	ldr	x9, [sp, #0xd10]
100065c64:     	ldr	x8, [sp, #0xd18]
100065c68:     	stp	x8, x9, [sp, #0xc0]
100065c6c:     	ldr	q0, [sp, #0xd20]
100065c70:     	str	q0, [sp, #0x16c0]
100065c74:     	str	q0, [sp, #0x1580]
100065c78:     	add	x21, sp, #0xe0
100065c7c:     	mov	w28, #0x1               ; =1
100065c80:     	mov	w23, #0x0               ; =0
100065c84:     	mov	w27, #0x0               ; =0
100065c88:     	mov	w26, #0x0               ; =0
100065c8c:     	mov	w20, #0x0               ; =0
100065c90:     	add	x0, sp, #0xd10
100065c94:     	add	x2, x21, #0x40
100065c98:     	mov	w22, #0x1               ; =1
100065c9c:     	ldr	x1, [sp, #0x30]
100065ca0:     	bl	0x100167600 <la_stack::rational::integer_at_scale>
100065ca4:     	ldr	x9, [sp, #0xd10]
100065ca8:     	ldr	x8, [sp, #0xd18]
100065cac:     	stp	x8, x9, [sp, #0xb0]
100065cb0:     	ldr	q0, [sp, #0xd20]
100065cb4:     	str	q0, [sp, #0x16c0]
100065cb8:     	str	q0, [sp, #0xcd0]
100065cbc:     	mov	w27, #0x1               ; =1
100065cc0:     	mov	w23, #0x0               ; =0
100065cc4:     	mov	w28, #0x0               ; =0
100065cc8:     	mov	w26, #0x0               ; =0
100065ccc:     	mov	w20, #0x0               ; =0
100065cd0:     	add	x0, sp, #0xd10
100065cd4:     	add	x2, x21, #0x60
100065cd8:     	mov	w22, #0x1               ; =1
100065cdc:     	ldr	x1, [sp, #0x28]
100065ce0:     	bl	0x100167600 <la_stack::rational::integer_at_scale>
100065ce4:     	ldr	x9, [sp, #0xd10]
100065ce8:     	ldr	x8, [sp, #0xd18]
100065cec:     	stp	x8, x9, [sp, #0xa0]
100065cf0:     	ldr	q0, [sp, #0xd20]
100065cf4:     	str	q0, [sp, #0x16c0]
100065cf8:     	str	q0, [sp, #0xcf0]
100065cfc:     	add	x21, sp, #0xe0
100065d00:     	mov	w26, #0x1               ; =1
100065d04:     	mov	w23, #0x0               ; =0
100065d08:     	mov	w28, #0x0               ; =0
100065d0c:     	mov	w27, #0x0               ; =0
100065d10:     	mov	w20, #0x0               ; =0
100065d14:     	add	x0, sp, #0xd10
100065d18:     	add	x2, x21, #0x80
100065d1c:     	mov	w22, #0x1               ; =1
100065d20:     	ldr	x1, [sp, #0x20]
100065d24:     	bl	0x100167600 <la_stack::rational::integer_at_scale>
100065d28:     	ldr	x8, [sp, #0xd10]
100065d2c:     	str	x8, [sp, #0x98]
100065d30:     	ldr	x8, [sp, #0xd18]
100065d34:     	str	x8, [sp, #0x80]
100065d38:     	ldr	q0, [sp, #0xd20]
100065d3c:     	str	q0, [sp, #0x16c0]
100065d40:     	str	q0, [sp, #0x1570]
100065d44:     	mov	w20, #0x1               ; =1
100065d48:     	mov	w23, #0x0               ; =0
100065d4c:     	mov	w28, #0x0               ; =0
100065d50:     	mov	w27, #0x0               ; =0
100065d54:     	mov	w26, #0x0               ; =0
100065d58:     	add	x0, sp, #0xd10
100065d5c:     	add	x2, x21, #0xa0
100065d60:     	mov	w22, #0x1               ; =1
100065d64:     	ldr	x1, [sp, #0x18]
100065d68:     	bl	0x100167600 <la_stack::rational::integer_at_scale>
100065d6c:     	ldr	x9, [sp, #0xd10]
100065d70:     	ldr	x8, [sp, #0xd18]
100065d74:     	stp	x8, x9, [sp, #0x70]
100065d78:     	ldr	q0, [sp, #0xd20]
100065d7c:     	str	q0, [sp, #0x16c0]
100065d80:     	str	q0, [sp, #0x1560]
100065d84:     	add	x21, sp, #0xe0
100065d88:     	mov	w23, #0x0               ; =0
100065d8c:     	mov	w28, #0x0               ; =0
100065d90:     	mov	w27, #0x0               ; =0
100065d94:     	mov	w26, #0x0               ; =0
100065d98:     	mov	w20, #0x0               ; =0
100065d9c:     	mov	w22, #0x0               ; =0
100065da0:     	add	x0, sp, #0xd10
100065da4:     	add	x2, x21, #0xc0
100065da8:     	ldr	x1, [sp, #0x10]
100065dac:     	bl	0x100167600 <la_stack::rational::integer_at_scale>
100065db0:     	ldr	x24, [sp, #0xd10]
100065db4:     	ldr	x19, [sp, #0xd18]
100065db8:     	ldr	q0, [sp, #0xd20]
100065dbc:     	str	q0, [sp, #0x16c0]
100065dc0:     	str	q0, [sp, #0x1550]
100065dc4:     	mov	w22, #0x1               ; =1
100065dc8:     	mov	w23, #0x0               ; =0
100065dcc:     	mov	w28, #0x0               ; =0
100065dd0:     	mov	w27, #0x0               ; =0
100065dd4:     	mov	w26, #0x0               ; =0
100065dd8:     	mov	w20, #0x0               ; =0
100065ddc:     	add	x25, sp, #0xd10
100065de0:     	add	x0, sp, #0xd10
100065de4:     	add	x2, x21, #0xe0
100065de8:     	ldr	x1, [sp, #0x8]
100065dec:     	bl	0x100167600 <la_stack::rational::integer_at_scale>
100065df0:     	ldr	x8, [sp, #0xd10]
100065df4:     	ldr	x9, [sp, #0xd18]
100065df8:     	ldr	q0, [sp, #0xd20]
100065dfc:     	str	q0, [sp, #0xd10]
100065e00:     	ldp	x10, x11, [sp, #0xd0]
100065e04:     	str	x11, [sp, #0x9e0]
100065e08:     	str	x10, [sp, #0x9e8]
100065e0c:     	ldur	q0, [x29, #-0xa0]
100065e10:     	str	q0, [sp, #0x9f0]
100065e14:     	ldp	x10, x11, [sp, #0xc0]
100065e18:     	str	x11, [sp, #0xa00]
100065e1c:     	str	x10, [sp, #0xa08]
100065e20:     	ldr	q0, [sp, #0x1580]
100065e24:     	str	q0, [sp, #0xa10]
100065e28:     	ldp	x10, x11, [sp, #0xb0]
100065e2c:     	str	x11, [sp, #0xa20]
100065e30:     	str	x10, [sp, #0xa28]
100065e34:     	ldr	q0, [sp, #0xcd0]
100065e38:     	str	q0, [sp, #0xa30]
100065e3c:     	ldp	x10, x11, [sp, #0xa0]
100065e40:     	str	x11, [sp, #0xa40]
100065e44:     	str	x10, [sp, #0xa48]
100065e48:     	ldr	q0, [sp, #0xcf0]
100065e4c:     	str	q0, [sp, #0xa50]
100065e50:     	ldr	x10, [sp, #0x98]
100065e54:     	str	x10, [sp, #0xa60]
100065e58:     	ldp	x10, x11, [sp, #0x78]
100065e5c:     	str	x11, [sp, #0xa68]
100065e60:     	ldr	q0, [sp, #0x1570]
100065e64:     	str	q0, [sp, #0xa70]
100065e68:     	str	x10, [sp, #0xa80]
100065e6c:     	ldr	x10, [sp, #0x70]
100065e70:     	str	x10, [sp, #0xa88]
100065e74:     	ldr	q0, [sp, #0x1560]
100065e78:     	str	q0, [sp, #0xa90]
100065e7c:     	str	x24, [sp, #0xaa0]
100065e80:     	str	x19, [sp, #0xaa8]
100065e84:     	ldr	q0, [sp, #0x1550]
100065e88:     	str	q0, [sp, #0xab0]
100065e8c:     	str	x8, [sp, #0xac0]
100065e90:     	str	x9, [sp, #0xac8]
100065e94:     	ldr	q0, [sp, #0xd10]
100065e98:     	str	q0, [sp, #0xad0]
100065e9c:     	add	x0, sp, #0xd10
100065ea0:     	add	x1, sp, #0x1e0
100065ea4:     	mov	w2, #0x800              ; =2048
100065ea8:     	bl	0x100219ffc <dyld_stub_binder+0x100219ffc>
100065eac:     	mov	x28, #0x0               ; =0
100065eb0:     	mov	w9, #0x2                ; =2
100065eb4:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100065eb8:     	add	x8, x8, #0x6c0
100065ebc:     	strb	w9, [x8, #0x218]
100065ec0:     	adrp	x8, 0x10021a000 <dyld_stub_binder+0x10021a000>
100065ec4:     	ldr	q0, [x8, #0xa00]
100065ec8:     	str	q0, [sp, #0x60]
100065ecc:     	stur	q0, [x29, #-0xa0]
100065ed0:     	stur	x22, [x29, #-0x90]
100065ed4:     	add	x9, x25, #0x20
100065ed8:     	add	x21, x25, #0x120
100065edc:     	mov	w8, #0x7                ; =7
100065ee0:     	stp	x8, x9, [sp, #0xb0]
100065ee4:     	add	x24, sp, #0x9e0
100065ee8:     	adrp	x8, 0x10021a000 <dyld_stub_binder+0x10021a000>
100065eec:     	ldr	q0, [x8, #0xb40]
100065ef0:     	str	q0, [sp, #0x80]
100065ef4:     	add	x19, sp, #0xd10
100065ef8:     	b	0x100065f34 <<la_stack::rational::RationalMatrix<8>>::solve+0x22b4>
100065efc:     	ldr	x1, [sp, #0xd8]
100065f00:     	ldrb	w8, [x1, #0x18]
100065f04:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
100065f08:     	add	x9, x9, #0x6c0
100065f0c:     	strb	w8, [x9, #0x218]
100065f10:     	ldp	x8, x10, [sp, #0xb0]
100065f14:     	add	x9, x10, #0x120
100065f18:     	ldr	x21, [sp, #0x78]
100065f1c:     	add	x21, x21, #0x120
100065f20:     	sub	x8, x8, #0x1
100065f24:     	stp	x8, x9, [sp, #0xb0]
100065f28:     	sub	x0, x29, #0xa0
100065f2c:     	bl	0x100092980 <<num_bigint::big_digit::BigDigits as core::clone::Clone>::clone_from>
100065f30:     	ldr	x28, [sp, #0x70]
100065f34:     	add	x12, x28, #0x1
100065f38:     	add	x9, x19, x28, lsl #8
100065f3c:     	add	x8, x9, x28, lsl #5
100065f40:     	str	x8, [sp, #0xd8]
100065f44:     	ldrb	w8, [x8, #0x18]
100065f48:     	cmp	w8, #0x1
100065f4c:     	b.ne	0x100066154 <<la_stack::rational::RationalMatrix<8>>::solve+0x24d4>
100065f50:     	cmp	x12, #0x8
100065f54:     	b.eq	0x100066860 <<la_stack::rational::RationalMatrix<8>>::solve+0x2be0>
100065f58:     	add	x10, x19, x12, lsl #8
100065f5c:     	add	x8, x10, x28, lsl #5
100065f60:     	ldrb	w11, [x8, #0x18]
100065f64:     	add	x8, x28, #0x1
100065f68:     	cmp	w11, #0x1
100065f6c:     	b.ne	0x10006603c <<la_stack::rational::RationalMatrix<8>>::solve+0x23bc>
100065f70:     	add	x8, x28, #0x2
100065f74:     	cmp	x8, #0x8
100065f78:     	b.eq	0x100066860 <<la_stack::rational::RationalMatrix<8>>::solve+0x2be0>
100065f7c:     	add	x10, x19, x8, lsl #8
100065f80:     	add	x11, x10, x28, lsl #5
100065f84:     	ldrb	w11, [x11, #0x18]
100065f88:     	cmp	w11, #0x1
100065f8c:     	b.ne	0x10006603c <<la_stack::rational::RationalMatrix<8>>::solve+0x23bc>
100065f90:     	add	x8, x28, #0x3
100065f94:     	cmp	x8, #0x8
100065f98:     	b.eq	0x100066860 <<la_stack::rational::RationalMatrix<8>>::solve+0x2be0>
100065f9c:     	add	x10, x19, x8, lsl #8
100065fa0:     	add	x11, x10, x28, lsl #5
100065fa4:     	ldrb	w11, [x11, #0x18]
100065fa8:     	cmp	w11, #0x1
100065fac:     	b.ne	0x10006603c <<la_stack::rational::RationalMatrix<8>>::solve+0x23bc>
100065fb0:     	add	x8, x28, #0x4
100065fb4:     	cmp	x8, #0x8
100065fb8:     	b.eq	0x100066860 <<la_stack::rational::RationalMatrix<8>>::solve+0x2be0>
100065fbc:     	add	x10, x19, x8, lsl #8
100065fc0:     	add	x11, x10, x28, lsl #5
100065fc4:     	ldrb	w11, [x11, #0x18]
100065fc8:     	cmp	w11, #0x1
100065fcc:     	b.ne	0x10006603c <<la_stack::rational::RationalMatrix<8>>::solve+0x23bc>
100065fd0:     	add	x8, x28, #0x5
100065fd4:     	cmp	x8, #0x8
100065fd8:     	b.eq	0x100066860 <<la_stack::rational::RationalMatrix<8>>::solve+0x2be0>
100065fdc:     	add	x10, x19, x8, lsl #8
100065fe0:     	add	x11, x10, x28, lsl #5
100065fe4:     	ldrb	w11, [x11, #0x18]
100065fe8:     	cmp	w11, #0x1
100065fec:     	b.ne	0x10006603c <<la_stack::rational::RationalMatrix<8>>::solve+0x23bc>
100065ff0:     	add	x8, x28, #0x6
100065ff4:     	cmp	x8, #0x8
100065ff8:     	b.eq	0x100066860 <<la_stack::rational::RationalMatrix<8>>::solve+0x2be0>
100065ffc:     	add	x10, x19, x8, lsl #8
100066000:     	add	x11, x10, x28, lsl #5
100066004:     	ldrb	w11, [x11, #0x18]
100066008:     	cmp	w11, #0x1
10006600c:     	b.ne	0x10006603c <<la_stack::rational::RationalMatrix<8>>::solve+0x23bc>
100066010:     	add	x8, x28, #0x7
100066014:     	cmp	x8, #0x8
100066018:     	b.eq	0x100066860 <<la_stack::rational::RationalMatrix<8>>::solve+0x2be0>
10006601c:     	add	x10, x19, x8, lsl #8
100066020:     	add	x11, x10, x28, lsl #5
100066024:     	ldrb	w11, [x11, #0x18]
100066028:     	cmp	w11, #0x1
10006602c:     	b.ne	0x10006603c <<la_stack::rational::RationalMatrix<8>>::solve+0x23bc>
100066030:     	cbz	x28, 0x100066860 <<la_stack::rational::RationalMatrix<8>>::solve+0x2be0>
100066034:     	add	x8, x28, #0x8
100066038:     	add	x10, x19, x8, lsl #8
10006603c:     	ldp	q0, q1, [x9, #0xc0]
100066040:     	str	q0, [sp, #0x1780]
100066044:     	str	q1, [sp, #0x1790]
100066048:     	ldp	q0, q1, [x9, #0xe0]
10006604c:     	str	q0, [sp, #0x17a0]
100066050:     	str	q1, [sp, #0x17b0]
100066054:     	ldp	q0, q1, [x9, #0x80]
100066058:     	str	q0, [sp, #0x1740]
10006605c:     	str	q1, [sp, #0x1750]
100066060:     	ldp	q0, q1, [x9, #0xa0]
100066064:     	str	q0, [sp, #0x1760]
100066068:     	str	q1, [sp, #0x1770]
10006606c:     	ldp	q0, q1, [x9, #0x40]
100066070:     	str	q0, [sp, #0x1700]
100066074:     	str	q1, [sp, #0x1710]
100066078:     	ldp	q0, q1, [x9, #0x60]
10006607c:     	str	q0, [sp, #0x1720]
100066080:     	str	q1, [sp, #0x1730]
100066084:     	ldp	q0, q1, [x9]
100066088:     	str	q0, [sp, #0x16c0]
10006608c:     	str	q1, [sp, #0x16d0]
100066090:     	ldp	q0, q1, [x9, #0x20]
100066094:     	str	q0, [sp, #0x16e0]
100066098:     	str	q1, [sp, #0x16f0]
10006609c:     	ldp	q0, q1, [x10]
1000660a0:     	ldp	q2, q3, [x10, #0x20]
1000660a4:     	ldp	q4, q5, [x10, #0x40]
1000660a8:     	ldp	q6, q7, [x10, #0x60]
1000660ac:     	ldp	q16, q17, [x10, #0x80]
1000660b0:     	ldp	q18, q19, [x10, #0xa0]
1000660b4:     	ldp	q20, q21, [x10, #0xc0]
1000660b8:     	ldp	q22, q23, [x10, #0xe0]
1000660bc:     	stp	q22, q23, [x9, #0xe0]
1000660c0:     	stp	q20, q21, [x9, #0xc0]
1000660c4:     	stp	q18, q19, [x9, #0xa0]
1000660c8:     	stp	q16, q17, [x9, #0x80]
1000660cc:     	stp	q6, q7, [x9, #0x60]
1000660d0:     	stp	q4, q5, [x9, #0x40]
1000660d4:     	stp	q2, q3, [x9, #0x20]
1000660d8:     	stp	q0, q1, [x9]
1000660dc:     	ldr	q0, [sp, #0x1780]
1000660e0:     	ldr	q1, [sp, #0x1790]
1000660e4:     	stp	q0, q1, [x10, #0xc0]
1000660e8:     	ldr	q0, [sp, #0x17a0]
1000660ec:     	ldr	q1, [sp, #0x17b0]
1000660f0:     	stp	q0, q1, [x10, #0xe0]
1000660f4:     	ldr	q0, [sp, #0x1740]
1000660f8:     	ldr	q1, [sp, #0x1750]
1000660fc:     	stp	q0, q1, [x10, #0x80]
100066100:     	ldr	q0, [sp, #0x1760]
100066104:     	ldr	q1, [sp, #0x1770]
100066108:     	stp	q0, q1, [x10, #0xa0]
10006610c:     	ldr	q0, [sp, #0x1700]
100066110:     	ldr	q1, [sp, #0x1710]
100066114:     	stp	q0, q1, [x10, #0x40]
100066118:     	ldr	q0, [sp, #0x1720]
10006611c:     	ldr	q1, [sp, #0x1730]
100066120:     	stp	q0, q1, [x10, #0x60]
100066124:     	ldr	q0, [sp, #0x16c0]
100066128:     	ldr	q1, [sp, #0x16d0]
10006612c:     	stp	q0, q1, [x10]
100066130:     	ldr	q0, [sp, #0x16e0]
100066134:     	ldr	q1, [sp, #0x16f0]
100066138:     	stp	q0, q1, [x10, #0x20]
10006613c:     	add	x9, x24, x28, lsl #5
100066140:     	add	x8, x24, x8, lsl #5
100066144:     	ldp	q1, q0, [x9]
100066148:     	ldp	q3, q2, [x8]
10006614c:     	stp	q3, q2, [x9]
100066150:     	stp	q1, q0, [x8]
100066154:     	cmp	x12, #0x8
100066158:     	b.eq	0x100066570 <<la_stack::rational::RationalMatrix<8>>::solve+0x28f0>
10006615c:     	add	x8, x28, #0x1
100066160:     	stp	x8, x21, [sp, #0x70]
100066164:     	lsl	x8, x28, #5
100066168:     	str	x8, [sp, #0xa8]
10006616c:     	add	x8, x19, x8
100066170:     	stp	x28, x8, [sp, #0x98]
100066174:     	add	x8, x28, #0x1
100066178:     	b	0x100066198 <<la_stack::rational::RationalMatrix<8>>::solve+0x2518>
10006617c:     	ldr	q0, [sp, #0x80]
100066180:     	str	q0, [x21]
100066184:     	add	x19, sp, #0xd10
100066188:     	ldp	x8, x21, [sp, #0xc0]
10006618c:     	add	x21, x21, #0x100
100066190:     	cmp	x8, #0x8
100066194:     	b.eq	0x100065efc <<la_stack::rational::RationalMatrix<8>>::solve+0x227c>
100066198:     	mov	x9, x8
10006619c:     	add	x8, x8, #0x1
1000661a0:     	stp	x8, x21, [sp, #0xc0]
1000661a4:     	str	x9, [sp, #0xd0]
1000661a8:     	add	x8, x19, x9, lsl #8
1000661ac:     	add	x19, x8, x28, lsl #5
1000661b0:     	ldp	x28, x22, [sp, #0xb0]
1000661b4:     	b	0x1000661d4 <<la_stack::rational::RationalMatrix<8>>::solve+0x2554>
1000661b8:     	stp	x26, x23, [x21]
1000661bc:     	add	x22, x22, #0x20
1000661c0:     	str	x24, [x21, #0x10]
1000661c4:     	strb	w20, [x21, #0x18]
1000661c8:     	add	x21, x21, #0x20
1000661cc:     	subs	x28, x28, #0x1
1000661d0:     	b.eq	0x100066378 <<la_stack::rational::RationalMatrix<8>>::solve+0x26f8>
1000661d4:     	add	x0, sp, #0xae0
1000661d8:     	ldr	x1, [sp, #0xd8]
1000661dc:     	mov	x2, x21
1000661e0:     	bl	0x1000952e4 <<&num_bigint::bigint::BigInt as core::ops::arith::Mul>::mul>
1000661e4:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000661e8:     	add	x0, x0, #0x6c0
1000661ec:     	mov	x1, x19
1000661f0:     	mov	x2, x22
1000661f4:     	bl	0x1000952e4 <<&num_bigint::bigint::BigInt as core::ops::arith::Mul>::mul>
1000661f8:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000661fc:     	add	x0, x0, #0x5c0
100066200:     	add	x1, sp, #0xae0
100066204:     	add	x2, sp, #0x1, lsl #12   ; =0x1000
100066208:     	add	x2, x2, #0x6c0
10006620c:     	bl	0x100083ec4 <<num_bigint::bigint::BigInt as core::ops::arith::Sub>::sub>
100066210:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100066214:     	add	x8, x8, #0x5c0
100066218:     	str	x8, [sp, #0x1588]
10006621c:     	mov	x8, #-0x2               ; =-2
100066220:     	str	x8, [sp, #0x1580]
100066224:     	sub	x9, x29, #0xa0
100066228:     	str	x9, [sp, #0xae8]
10006622c:     	str	x8, [sp, #0xae0]
100066230:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
100066234:     	add	x0, x0, #0x6c0
100066238:     	add	x1, sp, #0x1, lsl #12   ; =0x1000
10006623c:     	add	x1, x1, #0x580
100066240:     	add	x2, sp, #0xae0
100066244:     	bl	0x1001703b0 <num_bigint::biguint::division::div_rem_cow>
100066248:     	ldr	x26, [sp, #0x16c0]
10006624c:     	ldr	x23, [sp, #0x16c8]
100066250:     	ldr	x24, [sp, #0x16d0]
100066254:     	ldr	x27, [sp, #0x16d8]
100066258:     	ldr	x0, [sp, #0x16e0]
10006625c:     	add	x8, sp, #0xae0
100066260:     	ldrb	w8, [x8, #0xaf8]
100066264:     	cmp	w8, #0x1
100066268:     	b.ne	0x10006628c <<la_stack::rational::RationalMatrix<8>>::solve+0x260c>
10006626c:     	cmn	x26, #0x1
100066270:     	b.eq	0x1000662c0 <<la_stack::rational::RationalMatrix<8>>::solve+0x2640>
100066274:     	cmp	x26, #0x2
100066278:     	b.hs	0x1000662d0 <<la_stack::rational::RationalMatrix<8>>::solve+0x2650>
10006627c:     	mov	x24, #0x0               ; =0
100066280:     	cmn	x27, #0x1
100066284:     	b.ne	0x1000662f8 <<la_stack::rational::RationalMatrix<8>>::solve+0x2678>
100066288:     	b	0x100066328 <<la_stack::rational::RationalMatrix<8>>::solve+0x26a8>
10006628c:     	eor	w9, w23, #0x1
100066290:     	cmp	x24, #0x0
100066294:     	cset	w10, eq
100066298:     	cmn	x26, #0x1
10006629c:     	csel	w9, w9, w10, eq
1000662a0:     	tst	w9, #0x1
1000662a4:     	csinc	w25, w8, wzr, eq
1000662a8:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000662ac:     	add	x8, x8, #0x6c0
1000662b0:     	ldrb	w20, [x8, #0x218]
1000662b4:     	cmp	x27, #0x1
1000662b8:     	b.ge	0x100066318 <<la_stack::rational::RationalMatrix<8>>::solve+0x2698>
1000662bc:     	b	0x100066338 <<la_stack::rational::RationalMatrix<8>>::solve+0x26b8>
1000662c0:     	mov	x23, #0x0               ; =0
1000662c4:     	cmn	x27, #0x1
1000662c8:     	b.ne	0x1000662f8 <<la_stack::rational::RationalMatrix<8>>::solve+0x2678>
1000662cc:     	b	0x100066328 <<la_stack::rational::RationalMatrix<8>>::solve+0x26a8>
1000662d0:     	cmp	x26, #0x1
1000662d4:     	b.lt	0x1000662e8 <<la_stack::rational::RationalMatrix<8>>::solve+0x2668>
1000662d8:     	mov	x20, x0
1000662dc:     	mov	x0, x23
1000662e0:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
1000662e4:     	mov	x0, x20
1000662e8:     	mov	x23, #0x0               ; =0
1000662ec:     	mov	x26, #-0x1              ; =-1
1000662f0:     	cmn	x27, #0x1
1000662f4:     	b.eq	0x100066328 <<la_stack::rational::RationalMatrix<8>>::solve+0x26a8>
1000662f8:     	cmp	x27, #0x1
1000662fc:     	b.hi	0x100066320 <<la_stack::rational::RationalMatrix<8>>::solve+0x26a0>
100066300:     	mov	w25, #0x1               ; =1
100066304:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100066308:     	add	x8, x8, #0x6c0
10006630c:     	ldrb	w20, [x8, #0x218]
100066310:     	cmp	x27, #0x1
100066314:     	b.lt	0x100066338 <<la_stack::rational::RationalMatrix<8>>::solve+0x26b8>
100066318:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
10006631c:     	b	0x100066338 <<la_stack::rational::RationalMatrix<8>>::solve+0x26b8>
100066320:     	b.lt	0x100066328 <<la_stack::rational::RationalMatrix<8>>::solve+0x26a8>
100066324:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
100066328:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
10006632c:     	add	x8, x8, #0x6c0
100066330:     	ldrb	w20, [x8, #0x218]
100066334:     	mov	w25, #0x1               ; =1
100066338:     	mov	w8, #0x2                ; =2
10006633c:     	sub	w8, w8, w25
100066340:     	cmp	w20, #0x0
100066344:     	csel	w20, w8, w25, eq
100066348:     	ldr	x8, [sp, #0x15c0]
10006634c:     	cmp	x8, #0x1
100066350:     	b.lt	0x10006635c <<la_stack::rational::RationalMatrix<8>>::solve+0x26dc>
100066354:     	ldr	x0, [sp, #0x15c8]
100066358:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
10006635c:     	ldr	x8, [x21]
100066360:     	cmp	x8, #0x1
100066364:     	add	x25, sp, #0x9e0
100066368:     	b.lt	0x1000661b8 <<la_stack::rational::RationalMatrix<8>>::solve+0x2538>
10006636c:     	ldr	x0, [x21, #0x8]
100066370:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
100066374:     	b	0x1000661b8 <<la_stack::rational::RationalMatrix<8>>::solve+0x2538>
100066378:     	ldp	x20, x1, [sp, #0xd0]
10006637c:     	add	x19, x25, x20, lsl #5
100066380:     	add	x0, sp, #0xae0
100066384:     	mov	x2, x19
100066388:     	bl	0x1000952e4 <<&num_bigint::bigint::BigInt as core::ops::arith::Mul>::mul>
10006638c:     	ldp	x9, x8, [sp, #0xa0]
100066390:     	add	x21, x9, x20, lsl #8
100066394:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
100066398:     	add	x0, x0, #0x6c0
10006639c:     	add	x2, x25, x8
1000663a0:     	mov	x1, x21
1000663a4:     	bl	0x1000952e4 <<&num_bigint::bigint::BigInt as core::ops::arith::Mul>::mul>
1000663a8:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000663ac:     	add	x0, x0, #0x5c0
1000663b0:     	add	x1, sp, #0xae0
1000663b4:     	add	x2, sp, #0x1, lsl #12   ; =0x1000
1000663b8:     	add	x2, x2, #0x6c0
1000663bc:     	bl	0x100083ec4 <<num_bigint::bigint::BigInt as core::ops::arith::Sub>::sub>
1000663c0:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000663c4:     	add	x8, x8, #0x5c0
1000663c8:     	str	x8, [sp, #0x1588]
1000663cc:     	mov	x8, #-0x2               ; =-2
1000663d0:     	str	x8, [sp, #0x1580]
1000663d4:     	sub	x9, x29, #0xa0
1000663d8:     	str	x9, [sp, #0xae8]
1000663dc:     	str	x8, [sp, #0xae0]
1000663e0:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000663e4:     	add	x0, x0, #0x6c0
1000663e8:     	add	x1, sp, #0x1, lsl #12   ; =0x1000
1000663ec:     	add	x1, x1, #0x580
1000663f0:     	add	x2, sp, #0xae0
1000663f4:     	bl	0x1001703b0 <num_bigint::biguint::division::div_rem_cow>
1000663f8:     	ldr	x23, [sp, #0x16c0]
1000663fc:     	ldr	x22, [sp, #0x16c8]
100066400:     	ldr	x26, [sp, #0x16d0]
100066404:     	ldr	x24, [sp, #0x16d8]
100066408:     	ldr	x0, [sp, #0x16e0]
10006640c:     	add	x8, sp, #0xae0
100066410:     	ldrb	w8, [x8, #0xaf8]
100066414:     	cmp	w8, #0x1
100066418:     	b.ne	0x100066440 <<la_stack::rational::RationalMatrix<8>>::solve+0x27c0>
10006641c:     	cmn	x23, #0x1
100066420:     	ldr	x28, [sp, #0x98]
100066424:     	b.eq	0x100066458 <<la_stack::rational::RationalMatrix<8>>::solve+0x27d8>
100066428:     	cmp	x23, #0x2
10006642c:     	b.hs	0x10006648c <<la_stack::rational::RationalMatrix<8>>::solve+0x280c>
100066430:     	mov	x26, #0x0               ; =0
100066434:     	cmn	x24, #0x1
100066438:     	b.ne	0x1000664b4 <<la_stack::rational::RationalMatrix<8>>::solve+0x2834>
10006643c:     	b	0x1000664e4 <<la_stack::rational::RationalMatrix<8>>::solve+0x2864>
100066440:     	cmn	x23, #0x1
100066444:     	ldr	x28, [sp, #0x98]
100066448:     	b.eq	0x100066468 <<la_stack::rational::RationalMatrix<8>>::solve+0x27e8>
10006644c:     	cmp	x26, #0x0
100066450:     	cset	w9, eq
100066454:     	b	0x10006646c <<la_stack::rational::RationalMatrix<8>>::solve+0x27ec>
100066458:     	mov	x22, #0x0               ; =0
10006645c:     	cmn	x24, #0x1
100066460:     	b.ne	0x1000664b4 <<la_stack::rational::RationalMatrix<8>>::solve+0x2834>
100066464:     	b	0x1000664e4 <<la_stack::rational::RationalMatrix<8>>::solve+0x2864>
100066468:     	eor	w9, w22, #0x1
10006646c:     	tst	w9, #0x1
100066470:     	csinc	w27, w8, wzr, eq
100066474:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100066478:     	add	x8, x8, #0x6c0
10006647c:     	ldrb	w25, [x8, #0x218]
100066480:     	cmp	x24, #0x1
100066484:     	b.ge	0x1000664d4 <<la_stack::rational::RationalMatrix<8>>::solve+0x2854>
100066488:     	b	0x1000664f4 <<la_stack::rational::RationalMatrix<8>>::solve+0x2874>
10006648c:     	cmp	x23, #0x1
100066490:     	b.lt	0x1000664a4 <<la_stack::rational::RationalMatrix<8>>::solve+0x2824>
100066494:     	mov	x20, x0
100066498:     	mov	x0, x22
10006649c:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
1000664a0:     	mov	x0, x20
1000664a4:     	mov	x22, #0x0               ; =0
1000664a8:     	mov	x23, #-0x1              ; =-1
1000664ac:     	cmn	x24, #0x1
1000664b0:     	b.eq	0x1000664e4 <<la_stack::rational::RationalMatrix<8>>::solve+0x2864>
1000664b4:     	cmp	x24, #0x1
1000664b8:     	b.hi	0x1000664dc <<la_stack::rational::RationalMatrix<8>>::solve+0x285c>
1000664bc:     	mov	w27, #0x1               ; =1
1000664c0:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000664c4:     	add	x8, x8, #0x6c0
1000664c8:     	ldrb	w25, [x8, #0x218]
1000664cc:     	cmp	x24, #0x1
1000664d0:     	b.lt	0x1000664f4 <<la_stack::rational::RationalMatrix<8>>::solve+0x2874>
1000664d4:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
1000664d8:     	b	0x1000664f4 <<la_stack::rational::RationalMatrix<8>>::solve+0x2874>
1000664dc:     	b.lt	0x1000664e4 <<la_stack::rational::RationalMatrix<8>>::solve+0x2864>
1000664e0:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
1000664e4:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000664e8:     	add	x8, x8, #0x6c0
1000664ec:     	ldrb	w25, [x8, #0x218]
1000664f0:     	mov	w27, #0x1               ; =1
1000664f4:     	mov	w8, #0x2                ; =2
1000664f8:     	sub	w8, w8, w27
1000664fc:     	nop
100066500:     	cmp	w25, #0x0
100066504:     	csel	w20, w8, w27, eq
100066508:     	ldr	x8, [sp, #0x15c0]
10006650c:     	cmp	x8, #0x1
100066510:     	b.lt	0x10006651c <<la_stack::rational::RationalMatrix<8>>::solve+0x289c>
100066514:     	ldr	x0, [sp, #0x15c8]
100066518:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
10006651c:     	ldr	x8, [x19]
100066520:     	cmp	x8, #0x1
100066524:     	add	x24, sp, #0x9e0
100066528:     	b.lt	0x100066534 <<la_stack::rational::RationalMatrix<8>>::solve+0x28b4>
10006652c:     	ldr	x0, [x19, #0x8]
100066530:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
100066534:     	stp	x23, x22, [x19]
100066538:     	str	x26, [x19, #0x10]
10006653c:     	strb	w20, [x19, #0x18]
100066540:     	mov	w8, #0x1                ; =1
100066544:     	strb	w8, [x21, #0x18]
100066548:     	ldr	x8, [x21]
10006654c:     	cmp	x8, #0x1
100066550:     	b.lt	0x10006617c <<la_stack::rational::RationalMatrix<8>>::solve+0x24fc>
100066554:     	str	xzr, [x21, #0x10]
100066558:     	add	x19, sp, #0xd10
10006655c:     	ldp	x8, x21, [sp, #0xc0]
100066560:     	add	x21, x21, #0x100
100066564:     	cmp	x8, #0x8
100066568:     	b.ne	0x100066198 <<la_stack::rational::RationalMatrix<8>>::solve+0x2518>
10006656c:     	b	0x100065efc <<la_stack::rational::RationalMatrix<8>>::solve+0x227c>
100066570:     	ldur	x8, [x29, #-0xa0]
100066574:     	cmp	x8, #0x0
100066578:     	b.le	0x100066584 <<la_stack::rational::RationalMatrix<8>>::solve+0x2904>
10006657c:     	ldur	x0, [x29, #-0x98]
100066580:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
100066584:     	mov	x22, #0x0               ; =0
100066588:     	mov	x23, #0x0               ; =0
10006658c:     	mov	w9, #0x2                ; =2
100066590:     	add	x8, sp, #0xae0
100066594:     	strb	w9, [x8, #0xab8]
100066598:     	mov	w9, #0x1                ; =1
10006659c:     	ldr	q0, [sp, #0x60]
1000665a0:     	str	q0, [sp, #0x1580]
1000665a4:     	add	x8, sp, #0xae0
1000665a8:     	str	x9, [sp, #0x1590]
1000665ac:     	add	x8, x8, #0x10
1000665b0:     	str	x8, [sp, #0xd8]
1000665b4:     	add	x8, sp, #0x9e0
1000665b8:     	add	x27, x8, #0x100
1000665bc:     	add	x8, sp, #0xd10
1000665c0:     	add	x25, x8, #0x800
1000665c4:     	mov	w28, #0x8               ; =8
1000665c8:     	b	0x1000665e4 <<la_stack::rational::RationalMatrix<8>>::solve+0x2964>
1000665cc:     	sub	x27, x27, #0x20
1000665d0:     	sub	x25, x25, #0x120
1000665d4:     	add	x23, x23, #0x1
1000665d8:     	add	x22, x22, #0x20
1000665dc:     	mov	x28, x24
1000665e0:     	cbz	x24, 0x100066798 <<la_stack::rational::RationalMatrix<8>>::solve+0x2b18>
1000665e4:     	sub	x24, x28, #0x1
1000665e8:     	add	x8, sp, #0x9e0
1000665ec:     	add	x19, x8, x24, lsl #5
1000665f0:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
1000665f4:     	add	x0, x0, #0x5c0
1000665f8:     	add	x2, sp, #0x1, lsl #12   ; =0x1000
1000665fc:     	add	x2, x2, #0x580
100066600:     	mov	x1, x19
100066604:     	bl	0x1000952e4 <<&num_bigint::bigint::BigInt as core::ops::arith::Mul>::mul>
100066608:     	mov	x26, x23
10006660c:     	mov	x20, x25
100066610:     	mov	x21, x27
100066614:     	cmp	x28, #0x7
100066618:     	b.hi	0x100066654 <<la_stack::rational::RationalMatrix<8>>::solve+0x29d4>
10006661c:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
100066620:     	add	x0, x0, #0x6c0
100066624:     	mov	x1, x20
100066628:     	mov	x2, x21
10006662c:     	bl	0x1000952e4 <<&num_bigint::bigint::BigInt as core::ops::arith::Mul>::mul>
100066630:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
100066634:     	add	x0, x0, #0x5c0
100066638:     	add	x1, sp, #0x1, lsl #12   ; =0x1000
10006663c:     	add	x1, x1, #0x6c0
100066640:     	bl	0x100096568 <<num_bigint::bigint::BigInt as core::ops::arith::SubAssign>::sub_assign>
100066644:     	add	x21, x21, #0x20
100066648:     	add	x20, x20, #0x20
10006664c:     	subs	x26, x26, #0x1
100066650:     	b.ne	0x10006661c <<la_stack::rational::RationalMatrix<8>>::solve+0x299c>
100066654:     	ldr	q0, [sp, #0x15c0]
100066658:     	ldr	q1, [sp, #0x15d0]
10006665c:     	str	q0, [sp, #0x16c0]
100066660:     	str	q1, [sp, #0x16d0]
100066664:     	add	x8, sp, #0xd10
100066668:     	add	x8, x8, x24, lsl #8
10006666c:     	add	x8, x8, x24, lsl #5
100066670:     	ldp	q0, q1, [x8]
100066674:     	add	x21, sp, #0x1, lsl #12  ; =0x1000
100066678:     	add	x21, x21, #0x6c0
10006667c:     	stp	q0, q1, [x21, #0x20]
100066680:     	adrp	x9, 0x100229000 <core::num::imp::flt2dec::strategy::dragon::POW5TO256+0x5f90>
100066684:     	add	x9, x9, #0xd00
100066688:     	ldp	q0, q1, [x9]
10006668c:     	stp	q0, q1, [x8]
100066690:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
100066694:     	add	x0, x0, #0x6c0
100066698:     	bl	0x100069458 <<num_rational::Ratio<num_bigint::bigint::BigInt>>::reduce>
10006669c:     	ldr	x26, [sp, #0x16c0]
1000666a0:     	ldr	x20, [sp, #0x16c8]
1000666a4:     	ldp	q0, q1, [x21, #0x10]
1000666a8:     	str	q0, [sp, #0xcd0]
1000666ac:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
1000666b0:     	add	x10, x10, #0x6c0
1000666b4:     	ldur	q0, [x21, #0x30]
1000666b8:     	str	q0, [sp, #0xaf0]
1000666bc:     	str	q1, [sp, #0xae0]
1000666c0:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
1000666c4:     	add	x8, x8, #0x6c0
1000666c8:     	mov	w9, #0x2                ; =2
1000666cc:     	strb	w9, [x8, #0x18]
1000666d0:     	ldr	q0, [sp, #0x60]
1000666d4:     	str	q0, [sp, #0x16c0]
1000666d8:     	mov	w8, #0x1                ; =1
1000666dc:     	str	x8, [sp, #0x16d0]
1000666e0:     	ldrb	w8, [sp, #0xaf8]
1000666e4:     	cmp	w8, #0x2
1000666e8:     	b.ne	0x100066728 <<la_stack::rational::RationalMatrix<8>>::solve+0x2aa8>
1000666ec:     	ldr	x8, [sp, #0xae0]
1000666f0:     	cmn	x8, #0x1
1000666f4:     	b.eq	0x10006670c <<la_stack::rational::RationalMatrix<8>>::solve+0x2a8c>
1000666f8:     	ldr	x8, [sp, #0xaf0]
1000666fc:     	cmp	x8, #0x1
100066700:     	b.ne	0x100066728 <<la_stack::rational::RationalMatrix<8>>::solve+0x2aa8>
100066704:     	ldr	x8, [sp, #0xae8]
100066708:     	b	0x100066718 <<la_stack::rational::RationalMatrix<8>>::solve+0x2a98>
10006670c:     	ldr	w9, [sp, #0xae8]
100066710:     	ldr	x8, [sp, #0xd8]
100066714:     	tbz	w9, #0x0, 0x100066728 <<la_stack::rational::RationalMatrix<8>>::solve+0x2aa8>
100066718:     	ldur	x9, [x10, #0x10]
10006671c:     	ldr	x8, [x8]
100066720:     	cmp	x8, x9
100066724:     	b.eq	0x100066760 <<la_stack::rational::RationalMatrix<8>>::solve+0x2ae0>
100066728:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
10006672c:     	add	x0, x0, #0x580
100066730:     	add	x1, sp, #0xae0
100066734:     	bl	0x100095ffc <<num_bigint::bigint::BigInt as core::ops::arith::MulAssign<&num_bigint::bigint::BigInt>>::mul_assign>
100066738:     	cmp	x28, #0x8
10006673c:     	b.eq	0x100066760 <<la_stack::rational::RationalMatrix<8>>::solve+0x2ae0>
100066740:     	mov	x21, x27
100066744:     	mov	x28, x22
100066748:     	add	x1, sp, #0xae0
10006674c:     	mov	x0, x21
100066750:     	bl	0x100095ffc <<num_bigint::bigint::BigInt as core::ops::arith::MulAssign<&num_bigint::bigint::BigInt>>::mul_assign>
100066754:     	add	x21, x21, #0x20
100066758:     	subs	x28, x28, #0x20
10006675c:     	b.ne	0x100066748 <<la_stack::rational::RationalMatrix<8>>::solve+0x2ac8>
100066760:     	ldr	x8, [x19]
100066764:     	cmp	x8, #0x1
100066768:     	b.lt	0x100066774 <<la_stack::rational::RationalMatrix<8>>::solve+0x2af4>
10006676c:     	ldr	x0, [x19, #0x8]
100066770:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
100066774:     	stp	x26, x20, [x19]
100066778:     	ldr	q0, [sp, #0xcd0]
10006677c:     	str	q0, [x19, #0x10]
100066780:     	ldr	x8, [sp, #0xae0]
100066784:     	cmp	x8, #0x1
100066788:     	b.lt	0x1000665cc <<la_stack::rational::RationalMatrix<8>>::solve+0x294c>
10006678c:     	ldr	x0, [sp, #0xae8]
100066790:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
100066794:     	b	0x1000665cc <<la_stack::rational::RationalMatrix<8>>::solve+0x294c>
100066798:     	ldr	q0, [sp, #0xaa0]
10006679c:     	ldr	q1, [sp, #0xab0]
1000667a0:     	str	q0, [sp, #0x1680]
1000667a4:     	str	q1, [sp, #0x1690]
1000667a8:     	ldr	q0, [sp, #0xac0]
1000667ac:     	ldr	q1, [sp, #0xad0]
1000667b0:     	str	q0, [sp, #0x16a0]
1000667b4:     	str	q1, [sp, #0x16b0]
1000667b8:     	ldr	q0, [sp, #0xa60]
1000667bc:     	ldr	q1, [sp, #0xa70]
1000667c0:     	str	q0, [sp, #0x1640]
1000667c4:     	str	q1, [sp, #0x1650]
1000667c8:     	ldr	q0, [sp, #0xa80]
1000667cc:     	ldr	q1, [sp, #0xa90]
1000667d0:     	str	q0, [sp, #0x1660]
1000667d4:     	str	q1, [sp, #0x1670]
1000667d8:     	ldr	q0, [sp, #0xa20]
1000667dc:     	ldr	q1, [sp, #0xa30]
1000667e0:     	str	q0, [sp, #0x1600]
1000667e4:     	str	q1, [sp, #0x1610]
1000667e8:     	ldr	q0, [sp, #0xa40]
1000667ec:     	ldr	q1, [sp, #0xa50]
1000667f0:     	str	q0, [sp, #0x1620]
1000667f4:     	str	q1, [sp, #0x1630]
1000667f8:     	ldr	q0, [sp, #0x9e0]
1000667fc:     	ldr	q1, [sp, #0x9f0]
100066800:     	str	q0, [sp, #0x15c0]
100066804:     	str	q1, [sp, #0x15d0]
100066808:     	ldr	q0, [sp, #0xa00]
10006680c:     	ldr	q1, [sp, #0xa10]
100066810:     	str	q0, [sp, #0x15e0]
100066814:     	str	q1, [sp, #0x15f0]
100066818:     	add	x26, sp, #0xae0
10006681c:     	add	x8, sp, #0xae0
100066820:     	ldrb	w24, [x8, #0xab8]
100066824:     	ldr	x25, [sp, #0x1590]
100066828:     	ldr	x23, [sp, #0x1580]
10006682c:     	ldr	x20, [sp, #0x1588]
100066830:     	ldr	x27, [sp, #0x15c0]
100066834:     	ldr	x19, [sp, #0x15c8]
100066838:     	cmn	x23, #0x1
10006683c:     	b.eq	0x1000668cc <<la_stack::rational::RationalMatrix<8>>::solve+0x2c4c>
100066840:     	lsl	x21, x25, #3
100066844:     	cbz	x25, 0x100066b88 <<la_stack::rational::RationalMatrix<8>>::solve+0x2f08>
100066848:     	cmp	x25, #0x1
10006684c:     	b.ne	0x100066b94 <<la_stack::rational::RationalMatrix<8>>::solve+0x2f14>
100066850:     	ldr	x9, [x20]
100066854:     	mov	x8, #-0x1               ; =-1
100066858:     	mov	w22, #0x1               ; =1
10006685c:     	b	0x100066bbc <<la_stack::rational::RationalMatrix<8>>::solve+0x2f3c>
100066860:     	ldur	x8, [x29, #-0xa0]
100066864:     	cmp	x8, #0x1
100066868:     	b.lt	0x100066874 <<la_stack::rational::RationalMatrix<8>>::solve+0x2bf4>
10006686c:     	ldur	x0, [x29, #-0x98]
100066870:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
100066874:     	add	x0, sp, #0x9e0
100066878:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
10006687c:     	add	x19, sp, #0xd10
100066880:     	add	x0, sp, #0xd10
100066884:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100066888:     	add	x0, x19, #0x100
10006688c:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100066890:     	add	x0, x19, #0x200
100066894:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100066898:     	add	x0, x19, #0x300
10006689c:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
1000668a0:     	add	x0, x19, #0x400
1000668a4:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
1000668a8:     	add	x0, x19, #0x500
1000668ac:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
1000668b0:     	add	x0, x19, #0x600
1000668b4:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
1000668b8:     	add	x0, x19, #0x700
1000668bc:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
1000668c0:     	mov	w21, #0x0               ; =0
1000668c4:     	mov	w19, #0x3               ; =3
1000668c8:     	b	0x100067188 <<la_stack::rational::RationalMatrix<8>>::solve+0x3508>
1000668cc:     	str	x27, [sp, #0xae0]
1000668d0:     	str	x19, [sp, #0xae8]
1000668d4:     	ldr	q0, [sp, #0x9f0]
1000668d8:     	stur	q0, [x26, #0x10]
1000668dc:     	mov	x19, #-0x1              ; =-1
1000668e0:     	str	x19, [sp, #0xb00]
1000668e4:     	str	x20, [sp, #0xb08]
1000668e8:     	str	x25, [sp, #0xb10]
1000668ec:     	strb	w24, [sp, #0xb18]
1000668f0:     	mov	w28, #0x20              ; =32
1000668f4:     	mov	x22, #0x0               ; =0
1000668f8:     	add	x0, sp, #0xae0
1000668fc:     	bl	0x100069458 <<num_rational::Ratio<num_bigint::bigint::BigInt>>::reduce>
100066900:     	ldr	q0, [sp, #0xb00]
100066904:     	ldr	q1, [sp, #0xb10]
100066908:     	stur	q0, [x29, #-0x80]
10006690c:     	ldr	q2, [sp, #0xaf0]
100066910:     	ldr	q3, [sp, #0xae0]
100066914:     	str	q3, [sp, #0x16c0]
100066918:     	str	q2, [sp, #0x16d0]
10006691c:     	str	q0, [sp, #0x16e0]
100066920:     	str	q1, [sp, #0x16f0]
100066924:     	ldr	x8, [sp, #0x15e0]
100066928:     	ldr	x9, [sp, #0x15e8]
10006692c:     	str	x8, [sp, #0xae0]
100066930:     	str	x9, [sp, #0xae8]
100066934:     	ldr	q0, [sp, #0xa10]
100066938:     	stur	q0, [x26, #0x10]
10006693c:     	str	x19, [sp, #0xb00]
100066940:     	str	x20, [sp, #0xb08]
100066944:     	str	x25, [sp, #0xb10]
100066948:     	mov	w28, #0x40              ; =64
10006694c:     	mov	w22, #0x1               ; =1
100066950:     	strb	w24, [sp, #0xb18]
100066954:     	add	x0, sp, #0xae0
100066958:     	bl	0x100069458 <<num_rational::Ratio<num_bigint::bigint::BigInt>>::reduce>
10006695c:     	ldr	q0, [sp, #0xb00]
100066960:     	ldr	q1, [sp, #0xb10]
100066964:     	stur	q0, [x29, #-0x80]
100066968:     	ldr	q2, [sp, #0xaf0]
10006696c:     	ldr	q3, [sp, #0xae0]
100066970:     	str	q3, [sp, #0x1700]
100066974:     	str	q2, [sp, #0x1710]
100066978:     	str	q0, [sp, #0x1720]
10006697c:     	str	q1, [sp, #0x1730]
100066980:     	ldr	x8, [sp, #0x1600]
100066984:     	ldr	x9, [sp, #0x1608]
100066988:     	str	x8, [sp, #0xae0]
10006698c:     	str	x9, [sp, #0xae8]
100066990:     	ldr	q0, [sp, #0xa30]
100066994:     	stur	q0, [x26, #0x10]
100066998:     	str	x19, [sp, #0xb00]
10006699c:     	str	x20, [sp, #0xb08]
1000669a0:     	str	x25, [sp, #0xb10]
1000669a4:     	mov	w28, #0x60              ; =96
1000669a8:     	mov	w22, #0x2               ; =2
1000669ac:     	strb	w24, [sp, #0xb18]
1000669b0:     	add	x0, sp, #0xae0
1000669b4:     	bl	0x100069458 <<num_rational::Ratio<num_bigint::bigint::BigInt>>::reduce>
1000669b8:     	ldr	q0, [sp, #0xb00]
1000669bc:     	ldr	q1, [sp, #0xb10]
1000669c0:     	stur	q0, [x29, #-0x80]
1000669c4:     	ldr	q2, [sp, #0xaf0]
1000669c8:     	ldr	q3, [sp, #0xae0]
1000669cc:     	str	q3, [sp, #0x1740]
1000669d0:     	str	q2, [sp, #0x1750]
1000669d4:     	str	q0, [sp, #0x1760]
1000669d8:     	str	q1, [sp, #0x1770]
1000669dc:     	ldr	x8, [sp, #0x1620]
1000669e0:     	ldr	x9, [sp, #0x1628]
1000669e4:     	str	x8, [sp, #0xae0]
1000669e8:     	str	x9, [sp, #0xae8]
1000669ec:     	ldr	q0, [sp, #0xa50]
1000669f0:     	stur	q0, [x26, #0x10]
1000669f4:     	str	x19, [sp, #0xb00]
1000669f8:     	str	x20, [sp, #0xb08]
1000669fc:     	str	x25, [sp, #0xb10]
100066a00:     	mov	w28, #0x80              ; =128
100066a04:     	mov	w22, #0x3               ; =3
100066a08:     	strb	w24, [sp, #0xb18]
100066a0c:     	add	x0, sp, #0xae0
100066a10:     	bl	0x100069458 <<num_rational::Ratio<num_bigint::bigint::BigInt>>::reduce>
100066a14:     	ldr	q0, [sp, #0xb00]
100066a18:     	ldr	q1, [sp, #0xb10]
100066a1c:     	stur	q0, [x29, #-0x80]
100066a20:     	ldr	q2, [sp, #0xaf0]
100066a24:     	ldr	q3, [sp, #0xae0]
100066a28:     	str	q3, [sp, #0x1780]
100066a2c:     	str	q2, [sp, #0x1790]
100066a30:     	str	q0, [sp, #0x17a0]
100066a34:     	str	q1, [sp, #0x17b0]
100066a38:     	ldr	x8, [sp, #0x1640]
100066a3c:     	ldr	x9, [sp, #0x1648]
100066a40:     	str	x8, [sp, #0xae0]
100066a44:     	str	x9, [sp, #0xae8]
100066a48:     	ldr	q0, [sp, #0xa70]
100066a4c:     	stur	q0, [x26, #0x10]
100066a50:     	str	x19, [sp, #0xb00]
100066a54:     	str	x20, [sp, #0xb08]
100066a58:     	str	x25, [sp, #0xb10]
100066a5c:     	mov	w28, #0xa0              ; =160
100066a60:     	mov	w22, #0x4               ; =4
100066a64:     	strb	w24, [sp, #0xb18]
100066a68:     	add	x0, sp, #0xae0
100066a6c:     	bl	0x100069458 <<num_rational::Ratio<num_bigint::bigint::BigInt>>::reduce>
100066a70:     	ldr	q0, [sp, #0xb00]
100066a74:     	ldr	q1, [sp, #0xb10]
100066a78:     	stur	q0, [x29, #-0x80]
100066a7c:     	ldr	q2, [sp, #0xaf0]
100066a80:     	ldr	q3, [sp, #0xae0]
100066a84:     	str	q3, [sp, #0x17c0]
100066a88:     	str	q2, [sp, #0x17d0]
100066a8c:     	str	q0, [sp, #0x17e0]
100066a90:     	str	q1, [sp, #0x17f0]
100066a94:     	ldr	x8, [sp, #0x1660]
100066a98:     	ldr	x9, [sp, #0x1668]
100066a9c:     	str	x8, [sp, #0xae0]
100066aa0:     	str	x9, [sp, #0xae8]
100066aa4:     	ldr	q0, [sp, #0xa90]
100066aa8:     	stur	q0, [x26, #0x10]
100066aac:     	str	x19, [sp, #0xb00]
100066ab0:     	str	x20, [sp, #0xb08]
100066ab4:     	str	x25, [sp, #0xb10]
100066ab8:     	mov	w28, #0xc0              ; =192
100066abc:     	mov	w22, #0x5               ; =5
100066ac0:     	strb	w24, [sp, #0xb18]
100066ac4:     	add	x0, sp, #0xae0
100066ac8:     	bl	0x100069458 <<num_rational::Ratio<num_bigint::bigint::BigInt>>::reduce>
100066acc:     	ldr	q0, [sp, #0xb00]
100066ad0:     	ldr	q1, [sp, #0xb10]
100066ad4:     	stur	q0, [x29, #-0x80]
100066ad8:     	ldr	q2, [sp, #0xaf0]
100066adc:     	ldr	q3, [sp, #0xae0]
100066ae0:     	str	q3, [sp, #0x1800]
100066ae4:     	str	q2, [sp, #0x1810]
100066ae8:     	str	q0, [sp, #0x1820]
100066aec:     	str	q1, [sp, #0x1830]
100066af0:     	ldr	x8, [sp, #0x1680]
100066af4:     	ldr	x9, [sp, #0x1688]
100066af8:     	str	x8, [sp, #0xae0]
100066afc:     	str	x9, [sp, #0xae8]
100066b00:     	ldr	q0, [sp, #0xab0]
100066b04:     	stur	q0, [x26, #0x10]
100066b08:     	str	x19, [sp, #0xb00]
100066b0c:     	str	x20, [sp, #0xb08]
100066b10:     	str	x25, [sp, #0xb10]
100066b14:     	mov	w28, #0xe0              ; =224
100066b18:     	mov	w22, #0x6               ; =6
100066b1c:     	strb	w24, [sp, #0xb18]
100066b20:     	add	x0, sp, #0xae0
100066b24:     	bl	0x100069458 <<num_rational::Ratio<num_bigint::bigint::BigInt>>::reduce>
100066b28:     	ldr	q0, [sp, #0xb00]
100066b2c:     	ldr	q1, [sp, #0xb10]
100066b30:     	stur	q0, [x29, #-0x80]
100066b34:     	ldr	q2, [sp, #0xaf0]
100066b38:     	ldr	q3, [sp, #0xae0]
100066b3c:     	str	q3, [sp, #0x1840]
100066b40:     	str	q2, [sp, #0x1850]
100066b44:     	str	q0, [sp, #0x1860]
100066b48:     	str	q1, [sp, #0x1870]
100066b4c:     	ldr	x8, [sp, #0x16a0]
100066b50:     	ldr	x9, [sp, #0x16a8]
100066b54:     	str	x8, [sp, #0xae0]
100066b58:     	str	x9, [sp, #0xae8]
100066b5c:     	ldr	q0, [sp, #0x16b0]
100066b60:     	stur	q0, [x26, #0x10]
100066b64:     	str	x19, [sp, #0xb00]
100066b68:     	str	x20, [sp, #0xb08]
100066b6c:     	str	x25, [sp, #0xb10]
100066b70:     	mov	w28, #0x100             ; =256
100066b74:     	mov	w22, #0x7               ; =7
100066b78:     	strb	w24, [sp, #0xb18]
100066b7c:     	add	x0, sp, #0xae0
100066b80:     	bl	0x100069458 <<num_rational::Ratio<num_bigint::bigint::BigInt>>::reduce>
100066b84:     	b	0x1000670c0 <<la_stack::rational::RationalMatrix<8>>::solve+0x3440>
100066b88:     	mov	x8, #-0x1               ; =-1
100066b8c:     	mov	x22, x25
100066b90:     	b	0x100066bbc <<la_stack::rational::RationalMatrix<8>>::solve+0x2f3c>
100066b94:     	mov	x0, x21
100066b98:     	bl	0x100219fe4 <dyld_stub_binder+0x100219fe4>
100066b9c:     	mov	x22, x0
100066ba0:     	cbz	x0, 0x100067280 <<la_stack::rational::RationalMatrix<8>>::solve+0x3600>
100066ba4:     	mov	x0, x22
100066ba8:     	mov	x1, x20
100066bac:     	mov	x2, x21
100066bb0:     	bl	0x100219ffc <dyld_stub_binder+0x100219ffc>
100066bb4:     	mov	x8, x25
100066bb8:     	mov	x9, x25
100066bbc:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100066bc0:     	add	x10, x10, #0x5c0
100066bc4:     	str	x27, [sp, #0xae0]
100066bc8:     	str	x19, [sp, #0xae8]
100066bcc:     	ldur	q0, [x10, #0x10]
100066bd0:     	stur	q0, [x26, #0x10]
100066bd4:     	str	x8, [sp, #0xb00]
100066bd8:     	str	x22, [sp, #0xb08]
100066bdc:     	str	x9, [sp, #0xb10]
100066be0:     	strb	w24, [sp, #0xb18]
100066be4:     	mov	w28, #0x20              ; =32
100066be8:     	mov	x22, #0x0               ; =0
100066bec:     	add	x0, sp, #0xae0
100066bf0:     	bl	0x100069458 <<num_rational::Ratio<num_bigint::bigint::BigInt>>::reduce>
100066bf4:     	ldr	q0, [sp, #0xb00]
100066bf8:     	ldr	q1, [sp, #0xb10]
100066bfc:     	stur	q0, [x29, #-0x80]
100066c00:     	ldr	q2, [sp, #0xaf0]
100066c04:     	ldr	q3, [sp, #0xae0]
100066c08:     	str	q3, [sp, #0x16c0]
100066c0c:     	str	q2, [sp, #0x16d0]
100066c10:     	str	q0, [sp, #0x16e0]
100066c14:     	str	q1, [sp, #0x16f0]
100066c18:     	ldr	x27, [sp, #0x15e0]
100066c1c:     	ldr	x19, [sp, #0x15e8]
100066c20:     	cbz	x25, 0x100066c3c <<la_stack::rational::RationalMatrix<8>>::solve+0x2fbc>
100066c24:     	cmp	x25, #0x1
100066c28:     	b.ne	0x100066c48 <<la_stack::rational::RationalMatrix<8>>::solve+0x2fc8>
100066c2c:     	ldr	x9, [x20]
100066c30:     	mov	x8, #-0x1               ; =-1
100066c34:     	mov	w22, #0x1               ; =1
100066c38:     	b	0x100066c6c <<la_stack::rational::RationalMatrix<8>>::solve+0x2fec>
100066c3c:     	mov	x8, #-0x1               ; =-1
100066c40:     	mov	x22, x25
100066c44:     	b	0x100066c6c <<la_stack::rational::RationalMatrix<8>>::solve+0x2fec>
100066c48:     	mov	x0, x21
100066c4c:     	bl	0x100219fe4 <dyld_stub_binder+0x100219fe4>
100066c50:     	cbz	x0, 0x100067288 <<la_stack::rational::RationalMatrix<8>>::solve+0x3608>
100066c54:     	mov	x22, x0
100066c58:     	mov	x1, x20
100066c5c:     	mov	x2, x21
100066c60:     	bl	0x100219ffc <dyld_stub_binder+0x100219ffc>
100066c64:     	mov	x8, x25
100066c68:     	mov	x9, x25
100066c6c:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100066c70:     	add	x10, x10, #0x5c0
100066c74:     	str	x27, [sp, #0xae0]
100066c78:     	str	x19, [sp, #0xae8]
100066c7c:     	ldur	q0, [x10, #0x30]
100066c80:     	stur	q0, [x26, #0x10]
100066c84:     	str	x8, [sp, #0xb00]
100066c88:     	str	x22, [sp, #0xb08]
100066c8c:     	str	x9, [sp, #0xb10]
100066c90:     	strb	w24, [sp, #0xb18]
100066c94:     	mov	w28, #0x40              ; =64
100066c98:     	mov	w22, #0x1               ; =1
100066c9c:     	add	x0, sp, #0xae0
100066ca0:     	bl	0x100069458 <<num_rational::Ratio<num_bigint::bigint::BigInt>>::reduce>
100066ca4:     	ldr	q0, [sp, #0xb00]
100066ca8:     	ldr	q1, [sp, #0xb10]
100066cac:     	stur	q0, [x29, #-0x80]
100066cb0:     	ldr	q2, [sp, #0xaf0]
100066cb4:     	ldr	q3, [sp, #0xae0]
100066cb8:     	str	q3, [sp, #0x1700]
100066cbc:     	str	q2, [sp, #0x1710]
100066cc0:     	str	q0, [sp, #0x1720]
100066cc4:     	str	q1, [sp, #0x1730]
100066cc8:     	ldr	x27, [sp, #0x1600]
100066ccc:     	ldr	x19, [sp, #0x1608]
100066cd0:     	cbz	x25, 0x100066cec <<la_stack::rational::RationalMatrix<8>>::solve+0x306c>
100066cd4:     	cmp	x25, #0x1
100066cd8:     	b.ne	0x100066cf8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3078>
100066cdc:     	ldr	x9, [x20]
100066ce0:     	mov	x8, #-0x1               ; =-1
100066ce4:     	mov	w22, #0x1               ; =1
100066ce8:     	b	0x100066d1c <<la_stack::rational::RationalMatrix<8>>::solve+0x309c>
100066cec:     	mov	x8, #-0x1               ; =-1
100066cf0:     	mov	x22, x25
100066cf4:     	b	0x100066d1c <<la_stack::rational::RationalMatrix<8>>::solve+0x309c>
100066cf8:     	mov	x0, x21
100066cfc:     	bl	0x100219fe4 <dyld_stub_binder+0x100219fe4>
100066d00:     	cbz	x0, 0x100067294 <<la_stack::rational::RationalMatrix<8>>::solve+0x3614>
100066d04:     	mov	x22, x0
100066d08:     	mov	x1, x20
100066d0c:     	mov	x2, x21
100066d10:     	bl	0x100219ffc <dyld_stub_binder+0x100219ffc>
100066d14:     	mov	x8, x25
100066d18:     	mov	x9, x25
100066d1c:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100066d20:     	add	x10, x10, #0x5c0
100066d24:     	str	x27, [sp, #0xae0]
100066d28:     	str	x19, [sp, #0xae8]
100066d2c:     	ldur	q0, [x10, #0x50]
100066d30:     	stur	q0, [x26, #0x10]
100066d34:     	str	x8, [sp, #0xb00]
100066d38:     	str	x22, [sp, #0xb08]
100066d3c:     	str	x9, [sp, #0xb10]
100066d40:     	strb	w24, [sp, #0xb18]
100066d44:     	mov	w28, #0x60              ; =96
100066d48:     	mov	w22, #0x2               ; =2
100066d4c:     	add	x0, sp, #0xae0
100066d50:     	bl	0x100069458 <<num_rational::Ratio<num_bigint::bigint::BigInt>>::reduce>
100066d54:     	ldr	q0, [sp, #0xb00]
100066d58:     	ldr	q1, [sp, #0xb10]
100066d5c:     	stur	q0, [x29, #-0x80]
100066d60:     	ldr	q2, [sp, #0xaf0]
100066d64:     	ldr	q3, [sp, #0xae0]
100066d68:     	str	q3, [sp, #0x1740]
100066d6c:     	str	q2, [sp, #0x1750]
100066d70:     	str	q0, [sp, #0x1760]
100066d74:     	str	q1, [sp, #0x1770]
100066d78:     	ldr	x27, [sp, #0x1620]
100066d7c:     	ldr	x19, [sp, #0x1628]
100066d80:     	cbz	x25, 0x100066d9c <<la_stack::rational::RationalMatrix<8>>::solve+0x311c>
100066d84:     	cmp	x25, #0x1
100066d88:     	b.ne	0x100066da8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3128>
100066d8c:     	ldr	x9, [x20]
100066d90:     	mov	x8, #-0x1               ; =-1
100066d94:     	mov	w22, #0x1               ; =1
100066d98:     	b	0x100066dcc <<la_stack::rational::RationalMatrix<8>>::solve+0x314c>
100066d9c:     	mov	x8, #-0x1               ; =-1
100066da0:     	mov	x22, x25
100066da4:     	b	0x100066dcc <<la_stack::rational::RationalMatrix<8>>::solve+0x314c>
100066da8:     	mov	x0, x21
100066dac:     	bl	0x100219fe4 <dyld_stub_binder+0x100219fe4>
100066db0:     	cbz	x0, 0x1000672a0 <<la_stack::rational::RationalMatrix<8>>::solve+0x3620>
100066db4:     	mov	x22, x0
100066db8:     	mov	x1, x20
100066dbc:     	mov	x2, x21
100066dc0:     	bl	0x100219ffc <dyld_stub_binder+0x100219ffc>
100066dc4:     	mov	x8, x25
100066dc8:     	mov	x9, x25
100066dcc:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100066dd0:     	add	x10, x10, #0x5c0
100066dd4:     	str	x27, [sp, #0xae0]
100066dd8:     	str	x19, [sp, #0xae8]
100066ddc:     	ldur	q0, [x10, #0x70]
100066de0:     	stur	q0, [x26, #0x10]
100066de4:     	str	x8, [sp, #0xb00]
100066de8:     	str	x22, [sp, #0xb08]
100066dec:     	str	x9, [sp, #0xb10]
100066df0:     	strb	w24, [sp, #0xb18]
100066df4:     	mov	w28, #0x80              ; =128
100066df8:     	mov	w22, #0x3               ; =3
100066dfc:     	add	x0, sp, #0xae0
100066e00:     	bl	0x100069458 <<num_rational::Ratio<num_bigint::bigint::BigInt>>::reduce>
100066e04:     	ldr	q0, [sp, #0xb00]
100066e08:     	ldr	q1, [sp, #0xb10]
100066e0c:     	stur	q0, [x29, #-0x80]
100066e10:     	ldr	q2, [sp, #0xaf0]
100066e14:     	ldr	q3, [sp, #0xae0]
100066e18:     	str	q3, [sp, #0x1780]
100066e1c:     	str	q2, [sp, #0x1790]
100066e20:     	str	q0, [sp, #0x17a0]
100066e24:     	str	q1, [sp, #0x17b0]
100066e28:     	ldr	x27, [sp, #0x1640]
100066e2c:     	ldr	x19, [sp, #0x1648]
100066e30:     	cbz	x25, 0x100066e4c <<la_stack::rational::RationalMatrix<8>>::solve+0x31cc>
100066e34:     	cmp	x25, #0x1
100066e38:     	b.ne	0x100066e58 <<la_stack::rational::RationalMatrix<8>>::solve+0x31d8>
100066e3c:     	ldr	x9, [x20]
100066e40:     	mov	x8, #-0x1               ; =-1
100066e44:     	mov	w22, #0x1               ; =1
100066e48:     	b	0x100066e7c <<la_stack::rational::RationalMatrix<8>>::solve+0x31fc>
100066e4c:     	mov	x8, #-0x1               ; =-1
100066e50:     	mov	x22, x25
100066e54:     	b	0x100066e7c <<la_stack::rational::RationalMatrix<8>>::solve+0x31fc>
100066e58:     	mov	x0, x21
100066e5c:     	bl	0x100219fe4 <dyld_stub_binder+0x100219fe4>
100066e60:     	cbz	x0, 0x1000672ac <<la_stack::rational::RationalMatrix<8>>::solve+0x362c>
100066e64:     	mov	x22, x0
100066e68:     	mov	x1, x20
100066e6c:     	mov	x2, x21
100066e70:     	bl	0x100219ffc <dyld_stub_binder+0x100219ffc>
100066e74:     	mov	x8, x25
100066e78:     	mov	x9, x25
100066e7c:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100066e80:     	add	x10, x10, #0x5c0
100066e84:     	str	x27, [sp, #0xae0]
100066e88:     	str	x19, [sp, #0xae8]
100066e8c:     	ldur	q0, [x10, #0x90]
100066e90:     	stur	q0, [x26, #0x10]
100066e94:     	str	x8, [sp, #0xb00]
100066e98:     	str	x22, [sp, #0xb08]
100066e9c:     	str	x9, [sp, #0xb10]
100066ea0:     	strb	w24, [sp, #0xb18]
100066ea4:     	mov	w28, #0xa0              ; =160
100066ea8:     	mov	w22, #0x4               ; =4
100066eac:     	add	x0, sp, #0xae0
100066eb0:     	bl	0x100069458 <<num_rational::Ratio<num_bigint::bigint::BigInt>>::reduce>
100066eb4:     	ldr	q0, [sp, #0xb00]
100066eb8:     	ldr	q1, [sp, #0xb10]
100066ebc:     	stur	q0, [x29, #-0x80]
100066ec0:     	ldr	q2, [sp, #0xaf0]
100066ec4:     	ldr	q3, [sp, #0xae0]
100066ec8:     	str	q3, [sp, #0x17c0]
100066ecc:     	str	q2, [sp, #0x17d0]
100066ed0:     	str	q0, [sp, #0x17e0]
100066ed4:     	str	q1, [sp, #0x17f0]
100066ed8:     	ldr	x27, [sp, #0x1660]
100066edc:     	ldr	x19, [sp, #0x1668]
100066ee0:     	cbz	x25, 0x100066efc <<la_stack::rational::RationalMatrix<8>>::solve+0x327c>
100066ee4:     	cmp	x25, #0x1
100066ee8:     	b.ne	0x100066f08 <<la_stack::rational::RationalMatrix<8>>::solve+0x3288>
100066eec:     	ldr	x9, [x20]
100066ef0:     	mov	x8, #-0x1               ; =-1
100066ef4:     	mov	w22, #0x1               ; =1
100066ef8:     	b	0x100066f2c <<la_stack::rational::RationalMatrix<8>>::solve+0x32ac>
100066efc:     	mov	x8, #-0x1               ; =-1
100066f00:     	mov	x22, x25
100066f04:     	b	0x100066f2c <<la_stack::rational::RationalMatrix<8>>::solve+0x32ac>
100066f08:     	mov	x0, x21
100066f0c:     	bl	0x100219fe4 <dyld_stub_binder+0x100219fe4>
100066f10:     	cbz	x0, 0x1000672b8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3638>
100066f14:     	mov	x22, x0
100066f18:     	mov	x1, x20
100066f1c:     	mov	x2, x21
100066f20:     	bl	0x100219ffc <dyld_stub_binder+0x100219ffc>
100066f24:     	mov	x8, x25
100066f28:     	mov	x9, x25
100066f2c:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100066f30:     	add	x10, x10, #0x5c0
100066f34:     	str	x27, [sp, #0xae0]
100066f38:     	str	x19, [sp, #0xae8]
100066f3c:     	ldur	q0, [x10, #0xb0]
100066f40:     	stur	q0, [x26, #0x10]
100066f44:     	str	x8, [sp, #0xb00]
100066f48:     	str	x22, [sp, #0xb08]
100066f4c:     	str	x9, [sp, #0xb10]
100066f50:     	strb	w24, [sp, #0xb18]
100066f54:     	mov	w28, #0xc0              ; =192
100066f58:     	mov	w22, #0x5               ; =5
100066f5c:     	add	x0, sp, #0xae0
100066f60:     	bl	0x100069458 <<num_rational::Ratio<num_bigint::bigint::BigInt>>::reduce>
100066f64:     	ldr	q0, [sp, #0xb00]
100066f68:     	ldr	q1, [sp, #0xb10]
100066f6c:     	stur	q0, [x29, #-0x80]
100066f70:     	ldr	q2, [sp, #0xaf0]
100066f74:     	ldr	q3, [sp, #0xae0]
100066f78:     	str	q3, [sp, #0x1800]
100066f7c:     	str	q2, [sp, #0x1810]
100066f80:     	str	q0, [sp, #0x1820]
100066f84:     	str	q1, [sp, #0x1830]
100066f88:     	ldr	x27, [sp, #0x1680]
100066f8c:     	ldr	x19, [sp, #0x1688]
100066f90:     	cbz	x25, 0x100066fac <<la_stack::rational::RationalMatrix<8>>::solve+0x332c>
100066f94:     	cmp	x25, #0x1
100066f98:     	b.ne	0x100066fb8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3338>
100066f9c:     	ldr	x9, [x20]
100066fa0:     	mov	x8, #-0x1               ; =-1
100066fa4:     	mov	w22, #0x1               ; =1
100066fa8:     	b	0x100066fdc <<la_stack::rational::RationalMatrix<8>>::solve+0x335c>
100066fac:     	mov	x8, #-0x1               ; =-1
100066fb0:     	mov	x22, x25
100066fb4:     	b	0x100066fdc <<la_stack::rational::RationalMatrix<8>>::solve+0x335c>
100066fb8:     	mov	x0, x21
100066fbc:     	bl	0x100219fe4 <dyld_stub_binder+0x100219fe4>
100066fc0:     	cbz	x0, 0x1000672c4 <<la_stack::rational::RationalMatrix<8>>::solve+0x3644>
100066fc4:     	mov	x22, x0
100066fc8:     	mov	x1, x20
100066fcc:     	mov	x2, x21
100066fd0:     	bl	0x100219ffc <dyld_stub_binder+0x100219ffc>
100066fd4:     	mov	x8, x25
100066fd8:     	mov	x9, x25
100066fdc:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
100066fe0:     	add	x10, x10, #0x5c0
100066fe4:     	str	x27, [sp, #0xae0]
100066fe8:     	str	x19, [sp, #0xae8]
100066fec:     	ldur	q0, [x10, #0xd0]
100066ff0:     	stur	q0, [x26, #0x10]
100066ff4:     	str	x8, [sp, #0xb00]
100066ff8:     	str	x22, [sp, #0xb08]
100066ffc:     	str	x9, [sp, #0xb10]
100067000:     	strb	w24, [sp, #0xb18]
100067004:     	mov	w28, #0xe0              ; =224
100067008:     	mov	w22, #0x6               ; =6
10006700c:     	add	x0, sp, #0xae0
100067010:     	bl	0x100069458 <<num_rational::Ratio<num_bigint::bigint::BigInt>>::reduce>
100067014:     	ldr	q0, [sp, #0xb00]
100067018:     	ldr	q1, [sp, #0xb10]
10006701c:     	stur	q0, [x29, #-0x80]
100067020:     	ldr	q2, [sp, #0xaf0]
100067024:     	ldr	q3, [sp, #0xae0]
100067028:     	str	q3, [sp, #0x1840]
10006702c:     	str	q2, [sp, #0x1850]
100067030:     	str	q0, [sp, #0x1860]
100067034:     	str	q1, [sp, #0x1870]
100067038:     	ldr	x27, [sp, #0x16a0]
10006703c:     	ldr	x19, [sp, #0x16a8]
100067040:     	cbz	x25, 0x10006705c <<la_stack::rational::RationalMatrix<8>>::solve+0x33dc>
100067044:     	cmp	x25, #0x1
100067048:     	b.ne	0x100067068 <<la_stack::rational::RationalMatrix<8>>::solve+0x33e8>
10006704c:     	ldr	x25, [x20]
100067050:     	mov	x8, #-0x1               ; =-1
100067054:     	mov	w22, #0x1               ; =1
100067058:     	b	0x100067088 <<la_stack::rational::RationalMatrix<8>>::solve+0x3408>
10006705c:     	mov	x8, #-0x1               ; =-1
100067060:     	mov	x22, x25
100067064:     	b	0x100067088 <<la_stack::rational::RationalMatrix<8>>::solve+0x3408>
100067068:     	mov	x0, x21
10006706c:     	bl	0x100219fe4 <dyld_stub_binder+0x100219fe4>
100067070:     	cbz	x0, 0x1000672d0 <<la_stack::rational::RationalMatrix<8>>::solve+0x3650>
100067074:     	mov	x22, x0
100067078:     	mov	x1, x20
10006707c:     	mov	x2, x21
100067080:     	bl	0x100219ffc <dyld_stub_binder+0x100219ffc>
100067084:     	mov	x8, x25
100067088:     	add	x9, sp, #0x1, lsl #12   ; =0x1000
10006708c:     	add	x9, x9, #0x5c0
100067090:     	str	x27, [sp, #0xae0]
100067094:     	str	x19, [sp, #0xae8]
100067098:     	ldur	q0, [x9, #0xf0]
10006709c:     	stur	q0, [x26, #0x10]
1000670a0:     	str	x8, [sp, #0xb00]
1000670a4:     	str	x22, [sp, #0xb08]
1000670a8:     	str	x25, [sp, #0xb10]
1000670ac:     	strb	w24, [sp, #0xb18]
1000670b0:     	mov	w28, #0x100             ; =256
1000670b4:     	mov	w22, #0x7               ; =7
1000670b8:     	add	x0, sp, #0xae0
1000670bc:     	bl	0x100069458 <<num_rational::Ratio<num_bigint::bigint::BigInt>>::reduce>
1000670c0:     	ldr	q0, [sp, #0xb00]
1000670c4:     	ldr	q1, [sp, #0xb10]
1000670c8:     	stur	q0, [x29, #-0x80]
1000670cc:     	ldr	q2, [sp, #0xaf0]
1000670d0:     	ldr	q3, [sp, #0xae0]
1000670d4:     	str	q3, [sp, #0x1880]
1000670d8:     	str	q2, [sp, #0x1890]
1000670dc:     	str	q0, [sp, #0x18a0]
1000670e0:     	str	q1, [sp, #0x18b0]
1000670e4:     	ldr	x22, [sp, #0x16c0]
1000670e8:     	add	x8, sp, #0xae0
1000670ec:     	ldrb	w19, [x8, #0xbe8]
1000670f0:     	add	x10, sp, #0x1, lsl #12  ; =0x1000
1000670f4:     	add	x10, x10, #0x6c0
1000670f8:     	ldur	w8, [x10, #0x9]
1000670fc:     	ldr	w9, [sp, #0x16cc]
100067100:     	sub	x11, x29, #0xa0
100067104:     	stur	w9, [x11, #0x3]
100067108:     	stur	w8, [x29, #-0xa0]
10006710c:     	ldr	x28, [sp, #0x16d0]
100067110:     	add	x8, sp, #0x1, lsl #12   ; =0x1000
100067114:     	add	x8, x8, #0x6c0
100067118:     	ldrb	w21, [x10, #0x18]
10006711c:     	add	x0, sp, #0xae0
100067120:     	add	x1, x8, #0x19
100067124:     	mov	w2, #0x1e7              ; =487
100067128:     	bl	0x100219ffc <dyld_stub_binder+0x100219ffc>
10006712c:     	cmp	x23, #0x1
100067130:     	b.lt	0x10006713c <<la_stack::rational::RationalMatrix<8>>::solve+0x34bc>
100067134:     	mov	x0, x20
100067138:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
10006713c:     	add	x20, sp, #0xd10
100067140:     	add	x0, sp, #0xd10
100067144:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100067148:     	add	x0, x20, #0x100
10006714c:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100067150:     	add	x0, x20, #0x200
100067154:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100067158:     	add	x0, x20, #0x300
10006715c:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100067160:     	add	x0, x20, #0x400
100067164:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100067168:     	add	x0, x20, #0x500
10006716c:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100067170:     	add	x0, x20, #0x600
100067174:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100067178:     	add	x0, x20, #0x700
10006717c:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100067180:     	cmn	x22, #0x2
100067184:     	b.ne	0x1000671d4 <<la_stack::rational::RationalMatrix<8>>::solve+0x3554>
100067188:     	ldr	q0, [sp, #0xae0]
10006718c:     	ldr	q1, [sp, #0xaf0]
100067190:     	ldr	x9, [sp]
100067194:     	stur	q0, [x9, #0x19]
100067198:     	ldur	w8, [x29, #-0xa0]
10006719c:     	stur	w8, [x9, #0x9]
1000671a0:     	sub	x8, x29, #0xa0
1000671a4:     	ldur	w8, [x8, #0x3]
1000671a8:     	str	w8, [x9, #0xc]
1000671ac:     	stur	q1, [x9, #0x29]
1000671b0:     	add	x8, sp, #0xae0
1000671b4:     	ldur	x8, [x8, #0x1f]
1000671b8:     	str	x8, [x9, #0x38]
1000671bc:     	strb	w19, [x9, #0x8]
1000671c0:     	str	x28, [x9, #0x10]
1000671c4:     	strb	w21, [x9, #0x18]
1000671c8:     	mov	x8, #-0x2               ; =-2
1000671cc:     	str	x8, [x9]
1000671d0:     	b	0x10006720c <<la_stack::rational::RationalMatrix<8>>::solve+0x358c>
1000671d4:     	ldur	w8, [x29, #-0xa0]
1000671d8:     	ldr	x20, [sp]
1000671dc:     	stur	w8, [x20, #0x9]
1000671e0:     	sub	x8, x29, #0xa0
1000671e4:     	ldur	w8, [x8, #0x3]
1000671e8:     	str	w8, [x20, #0xc]
1000671ec:     	add	x0, x20, #0x19
1000671f0:     	add	x1, sp, #0xae0
1000671f4:     	mov	w2, #0x1e7              ; =487
1000671f8:     	bl	0x100219ffc <dyld_stub_binder+0x100219ffc>
1000671fc:     	str	x22, [x20]
100067200:     	strb	w19, [x20, #0x8]
100067204:     	str	x28, [x20, #0x10]
100067208:     	strb	w21, [x20, #0x18]
10006720c:     	add	x0, sp, #0xe0
100067210:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100067214:     	add	sp, sp, #0x1, lsl #12   ; =0x1000
100067218:     	add	sp, sp, #0x910
10006721c:     	ldp	x29, x30, [sp, #0x50]
100067220:     	ldp	x20, x19, [sp, #0x40]
100067224:     	ldp	x22, x21, [sp, #0x30]
100067228:     	ldp	x24, x23, [sp, #0x20]
10006722c:     	ldp	x26, x25, [sp, #0x10]
100067230:     	ldp	x28, x27, [sp], #0x60
100067234:     	ret
100067238:     	ldr	x20, [sp]
10006723c:     	add	x0, x20, #0x8
100067240:     	add	x1, sp, #0x1e0
100067244:     	mov	w2, #0x1f8              ; =504
100067248:     	bl	0x100219ffc <dyld_stub_binder+0x100219ffc>
10006724c:     	str	x19, [x20]
100067250:     	b	0x100067214 <<la_stack::rational::RationalMatrix<8>>::solve+0x3594>
100067254:     	adrp	x3, 0x1002c0000 <dyld_stub_binder+0x1002c0000>
100067258:     	add	x3, x3, #0x778
10006725c:     	mov	w2, #0x8                ; =8
100067260:     	bl	0x100206ff4 <core::slice::index::slice_index_fail>
100067264:     	b	0x100067304 <<la_stack::rational::RationalMatrix<8>>::solve+0x3684>
100067268:     	adrp	x2, 0x1002c0000 <dyld_stub_binder+0x1002c0000>
10006726c:     	add	x2, x2, #0x760
100067270:     	mov	x0, x19
100067274:     	mov	w1, #0x8                ; =8
100067278:     	bl	0x1002070bc <core::panicking::panic_bounds_check>
10006727c:     	b	0x100067304 <<la_stack::rational::RationalMatrix<8>>::solve+0x3684>
100067280:     	mov	w28, #0x20              ; =32
100067284:     	b	0x1000672d8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3658>
100067288:     	mov	w28, #0x40              ; =64
10006728c:     	mov	w22, #0x1               ; =1
100067290:     	b	0x1000672d8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3658>
100067294:     	mov	w28, #0x60              ; =96
100067298:     	mov	w22, #0x2               ; =2
10006729c:     	b	0x1000672d8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3658>
1000672a0:     	mov	w28, #0x80              ; =128
1000672a4:     	mov	w22, #0x3               ; =3
1000672a8:     	b	0x1000672d8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3658>
1000672ac:     	mov	w28, #0xa0              ; =160
1000672b0:     	mov	w22, #0x4               ; =4
1000672b4:     	b	0x1000672d8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3658>
1000672b8:     	mov	w28, #0xc0              ; =192
1000672bc:     	mov	w22, #0x5               ; =5
1000672c0:     	b	0x1000672d8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3658>
1000672c4:     	mov	w28, #0xe0              ; =224
1000672c8:     	mov	w22, #0x6               ; =6
1000672cc:     	b	0x1000672d8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3658>
1000672d0:     	mov	w28, #0x100             ; =256
1000672d4:     	mov	w22, #0x7               ; =7
1000672d8:     	mov	w0, #0x8                ; =8
1000672dc:     	mov	x1, x21
1000672e0:     	bl	0x1002062dc <alloc::raw_vec::handle_error>
1000672e4:     	b	0x100067304 <<la_stack::rational::RationalMatrix<8>>::solve+0x3684>
1000672e8:     	mov	w0, #0x8                ; =8
1000672ec:     	mov	x1, x23
1000672f0:     	bl	0x1002062dc <alloc::raw_vec::handle_error>
1000672f4:     	b	0x100067304 <<la_stack::rational::RationalMatrix<8>>::solve+0x3684>
1000672f8:     	mov	w0, #0x8                ; =8
1000672fc:     	mov	x1, x23
100067300:     	bl	0x1002062dc <alloc::raw_vec::handle_error>
100067304:     	brk	#0x1
100067308:     	mov	x22, x0
10006730c:     	b	0x1000676ec <<la_stack::rational::RationalMatrix<8>>::solve+0x3a6c>
100067310:     	mov	x22, x0
100067314:     	cmp	x21, #0x1
100067318:     	b.lt	0x1000676fc <<la_stack::rational::RationalMatrix<8>>::solve+0x3a7c>
10006731c:     	mov	x0, x19
100067320:     	b	0x1000676f8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3a78>
100067324:     	mov	x22, x0
100067328:     	mov	w23, #0x0               ; =0
10006732c:     	b	0x1000676d0 <<la_stack::rational::RationalMatrix<8>>::solve+0x3a50>
100067330:     	mov	x22, x0
100067334:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
100067338:     	add	x0, x0, #0x6c0
10006733c:     	bl	0x1000432d8 <core::ptr::drop_glue::<num_rational::Ratio<num_bigint::bigint::BigInt>>>
100067340:     	b	0x1000676fc <<la_stack::rational::RationalMatrix<8>>::solve+0x3a7c>
100067344:     	mov	x22, x0
100067348:     	b	0x1000676fc <<la_stack::rational::RationalMatrix<8>>::solve+0x3a7c>
10006734c:     	mov	x20, x0
100067350:     	cmp	x27, #0x1
100067354:     	b.lt	0x1000673f4 <<la_stack::rational::RationalMatrix<8>>::solve+0x3774>
100067358:     	mov	x0, x19
10006735c:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
100067360:     	b	0x1000673f4 <<la_stack::rational::RationalMatrix<8>>::solve+0x3774>
100067364:     	mov	x22, x0
100067368:     	b	0x100067388 <<la_stack::rational::RationalMatrix<8>>::solve+0x3708>
10006736c:     	b	0x1000676c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3a48>
100067370:     	mov	x22, x0
100067374:     	ldr	x8, [sp, #0x15c0]
100067378:     	cmp	x8, #0x1
10006737c:     	b.lt	0x100067388 <<la_stack::rational::RationalMatrix<8>>::solve+0x3708>
100067380:     	ldr	x0, [sp, #0x15c8]
100067384:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
100067388:     	mov	w23, #0x0               ; =0
10006738c:     	mov	w27, #0x0               ; =0
100067390:     	b	0x1000673a8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3728>
100067394:     	mov	x22, x0
100067398:     	add	x0, sp, #0x1e0
10006739c:     	b	0x1000677b4 <<la_stack::rational::RationalMatrix<8>>::solve+0x3b34>
1000673a0:     	b	0x1000676c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3a48>
1000673a4:     	mov	x22, x0
1000673a8:     	ldr	x8, [sp, #0xe0]
1000673ac:     	cmp	x8, #0x1
1000673b0:     	b.lt	0x1000673bc <<la_stack::rational::RationalMatrix<8>>::solve+0x373c>
1000673b4:     	ldr	x0, [sp, #0xe8]
1000673b8:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
1000673bc:     	cbnz	w27, 0x1000673cc <<la_stack::rational::RationalMatrix<8>>::solve+0x374c>
1000673c0:     	b	0x1000676d0 <<la_stack::rational::RationalMatrix<8>>::solve+0x3a50>
1000673c4:     	mov	x22, x0
1000673c8:     	mov	w23, #0x1               ; =1
1000673cc:     	ldur	x8, [x29, #-0xa0]
1000673d0:     	cmp	x8, #0x1
1000673d4:     	b.lt	0x1000676d0 <<la_stack::rational::RationalMatrix<8>>::solve+0x3a50>
1000673d8:     	ldur	x0, [x29, #-0x98]
1000673dc:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
1000673e0:     	b	0x1000676d0 <<la_stack::rational::RationalMatrix<8>>::solve+0x3a50>
1000673e4:     	b	0x1000673e8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3768>
1000673e8:     	mov	x20, x0
1000673ec:     	add	x0, sp, #0xae0
1000673f0:     	bl	0x1000432d8 <core::ptr::drop_glue::<num_rational::Ratio<num_bigint::bigint::BigInt>>>
1000673f4:     	add	x19, sp, #0x1, lsl #12  ; =0x1000
1000673f8:     	add	x19, x19, #0x5c0
1000673fc:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
100067400:     	add	x0, x0, #0x6c0
100067404:     	mov	x1, x22
100067408:     	bl	0x100043420 <core::ptr::drop_glue::<core::array::Guard<num_rational::Ratio<num_bigint::bigint::BigInt>>>>
10006740c:     	add	x0, x19, x28
100067410:     	add	x1, x19, #0x100
100067414:     	bl	0x100046988 <core::ptr::drop_glue::<core::array::drain::Drain<num_bigint::bigint::BigInt, <core::ops::try_trait::NeverShortCircuit<num_rational::Ratio<num_bigint::bigint::BigInt>>>::wrap_mut_1<num_bigint::bigint::BigInt, la_stack::exact::solve_big_int<2>::{closure#0}>::{closure#0}>>>
100067418:     	mov	w19, #0x1               ; =1
10006741c:     	mov	x22, x20
100067420:     	b	0x100067738 <<la_stack::rational::RationalMatrix<8>>::solve+0x3ab8>
100067424:     	mov	x21, x0
100067428:     	ldr	x8, [sp, #0xd8]
10006742c:     	cmp	x8, #0x1
100067430:     	b.lt	0x10006743c <<la_stack::rational::RationalMatrix<8>>::solve+0x37bc>
100067434:     	ldr	x0, [sp, #0xd0]
100067438:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
10006743c:     	tbnz	w23, #0x0, 0x1000674c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3848>
100067440:     	ldr	x8, [sp, #0xc8]
100067444:     	cmp	x8, #0x1
100067448:     	b.lt	0x100067454 <<la_stack::rational::RationalMatrix<8>>::solve+0x37d4>
10006744c:     	ldr	x0, [sp, #0xc0]
100067450:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
100067454:     	tbnz	w28, #0x0, 0x1000674c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3848>
100067458:     	ldr	x8, [sp, #0xb8]
10006745c:     	cmp	x8, #0x1
100067460:     	b.lt	0x10006746c <<la_stack::rational::RationalMatrix<8>>::solve+0x37ec>
100067464:     	ldr	x0, [sp, #0xb0]
100067468:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
10006746c:     	tbnz	w27, #0x0, 0x1000674c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3848>
100067470:     	ldr	x8, [sp, #0xa8]
100067474:     	cmp	x8, #0x1
100067478:     	b.lt	0x100067484 <<la_stack::rational::RationalMatrix<8>>::solve+0x3804>
10006747c:     	ldr	x0, [sp, #0xa0]
100067480:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
100067484:     	tbnz	w26, #0x0, 0x1000674c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3848>
100067488:     	ldr	x8, [sp, #0x98]
10006748c:     	cmp	x8, #0x1
100067490:     	b.lt	0x10006749c <<la_stack::rational::RationalMatrix<8>>::solve+0x381c>
100067494:     	ldr	x0, [sp, #0x80]
100067498:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
10006749c:     	tbnz	w20, #0x0, 0x1000674c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3848>
1000674a0:     	ldr	x8, [sp, #0x78]
1000674a4:     	cmp	x8, #0x1
1000674a8:     	b.lt	0x1000674b4 <<la_stack::rational::RationalMatrix<8>>::solve+0x3834>
1000674ac:     	ldr	x0, [sp, #0x70]
1000674b0:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
1000674b4:     	cmp	x24, #0x0
1000674b8:     	csel	w8, wzr, w22, le
1000674bc:     	cbz	w8, 0x1000674c8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3848>
1000674c0:     	mov	x0, x19
1000674c4:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
1000674c8:     	add	x0, sp, #0x1e0
1000674cc:     	mov	x22, x21
1000674d0:     	b	0x1000677b4 <<la_stack::rational::RationalMatrix<8>>::solve+0x3b34>
1000674d4:     	ldp	x26, x25, [sp, #0xb0]
1000674d8:     	mov	x22, x0
1000674dc:     	ldr	x8, [sp, #0xd0]
1000674e0:     	cmp	x8, #0x1
1000674e4:     	b.lt	0x1000674f0 <<la_stack::rational::RationalMatrix<8>>::solve+0x3870>
1000674e8:     	ldr	x0, [sp, #0xc8]
1000674ec:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
1000674f0:     	tbnz	w21, #0x0, 0x100067704 <<la_stack::rational::RationalMatrix<8>>::solve+0x3a84>
1000674f4:     	ldr	x8, [sp, #0xc0]
1000674f8:     	cmp	x8, #0x1
1000674fc:     	b.lt	0x100067508 <<la_stack::rational::RationalMatrix<8>>::solve+0x3888>
100067500:     	ldr	x0, [sp, #0xa8]
100067504:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
100067508:     	tbnz	w24, #0x0, 0x100067704 <<la_stack::rational::RationalMatrix<8>>::solve+0x3a84>
10006750c:     	ldr	x8, [sp, #0xa0]
100067510:     	cmp	x8, #0x1
100067514:     	b.lt	0x100067520 <<la_stack::rational::RationalMatrix<8>>::solve+0x38a0>
100067518:     	ldr	x0, [sp, #0x98]
10006751c:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
100067520:     	tbnz	w27, #0x0, 0x100067704 <<la_stack::rational::RationalMatrix<8>>::solve+0x3a84>
100067524:     	ldr	x8, [sp, #0x80]
100067528:     	cmp	x8, #0x1
10006752c:     	b.lt	0x100067538 <<la_stack::rational::RationalMatrix<8>>::solve+0x38b8>
100067530:     	ldr	x0, [sp, #0x78]
100067534:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
100067538:     	tbnz	w23, #0x0, 0x100067704 <<la_stack::rational::RationalMatrix<8>>::solve+0x3a84>
10006753c:     	ldr	x8, [sp, #0x70]
100067540:     	cmp	x8, #0x1
100067544:     	b.lt	0x100067550 <<la_stack::rational::RationalMatrix<8>>::solve+0x38d0>
100067548:     	ldr	x0, [sp, #0x60]
10006754c:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
100067550:     	tbnz	w19, #0x0, 0x100067704 <<la_stack::rational::RationalMatrix<8>>::solve+0x3a84>
100067554:     	ldr	x8, [sp, #0x58]
100067558:     	cmp	x8, #0x1
10006755c:     	b.lt	0x100067568 <<la_stack::rational::RationalMatrix<8>>::solve+0x38e8>
100067560:     	ldr	x0, [sp, #0x50]
100067564:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
100067568:     	cmp	x26, #0x0
10006756c:     	csel	w8, wzr, w20, le
100067570:     	cbz	w8, 0x100067704 <<la_stack::rational::RationalMatrix<8>>::solve+0x3a84>
100067574:     	mov	x0, x25
100067578:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
10006757c:     	mov	x0, x22
100067580:     	bl	0x100219d68 <dyld_stub_binder+0x100219d68>
100067584:     	b	0x1000676a0 <<la_stack::rational::RationalMatrix<8>>::solve+0x3a20>
100067588:     	b	0x100067790 <<la_stack::rational::RationalMatrix<8>>::solve+0x3b10>
10006758c:     	mov	x22, x0
100067590:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
100067594:     	add	x0, x0, #0x6c0
100067598:     	bl	0x1000432d8 <core::ptr::drop_glue::<num_rational::Ratio<num_bigint::bigint::BigInt>>>
10006759c:     	b	0x100067734 <<la_stack::rational::RationalMatrix<8>>::solve+0x3ab4>
1000675a0:     	mov	x22, x0
1000675a4:     	b	0x100067734 <<la_stack::rational::RationalMatrix<8>>::solve+0x3ab4>
1000675a8:     	mov	x22, x0
1000675ac:     	b	0x10006767c <<la_stack::rational::RationalMatrix<8>>::solve+0x39fc>
1000675b0:     	mov	x22, x0
1000675b4:     	mov	w27, #0x0               ; =0
1000675b8:     	mov	w21, #0x0               ; =0
1000675bc:     	mov	w20, #0x0               ; =0
1000675c0:     	mov	w25, #0x0               ; =0
1000675c4:     	mov	w19, #0x1               ; =1
1000675c8:     	mov	w24, #0x1               ; =1
1000675cc:     	b	0x1000675d8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3958>
1000675d0:     	mov	x22, x0
1000675d4:     	mov	w19, #0x0               ; =0
1000675d8:     	ldr	x8, [sp, #0xc8]
1000675dc:     	cmp	x8, #0x1
1000675e0:     	b.lt	0x1000675ec <<la_stack::rational::RationalMatrix<8>>::solve+0x396c>
1000675e4:     	ldr	x0, [sp, #0xc0]
1000675e8:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
1000675ec:     	tbnz	w19, #0x0, 0x10006767c <<la_stack::rational::RationalMatrix<8>>::solve+0x39fc>
1000675f0:     	ldr	x8, [sp, #0xb8]
1000675f4:     	cmp	x8, #0x1
1000675f8:     	b.lt	0x100067604 <<la_stack::rational::RationalMatrix<8>>::solve+0x3984>
1000675fc:     	ldr	x0, [sp, #0xb0]
100067600:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
100067604:     	tbnz	w27, #0x0, 0x10006767c <<la_stack::rational::RationalMatrix<8>>::solve+0x39fc>
100067608:     	ldr	x8, [sp, #0xa8]
10006760c:     	cmp	x8, #0x1
100067610:     	b.lt	0x10006761c <<la_stack::rational::RationalMatrix<8>>::solve+0x399c>
100067614:     	ldr	x0, [sp, #0xa0]
100067618:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
10006761c:     	tbnz	w21, #0x0, 0x10006767c <<la_stack::rational::RationalMatrix<8>>::solve+0x39fc>
100067620:     	ldr	x8, [sp, #0x98]
100067624:     	cmp	x8, #0x1
100067628:     	b.lt	0x100067634 <<la_stack::rational::RationalMatrix<8>>::solve+0x39b4>
10006762c:     	ldr	x0, [sp, #0x80]
100067630:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
100067634:     	tbnz	w20, #0x0, 0x10006767c <<la_stack::rational::RationalMatrix<8>>::solve+0x39fc>
100067638:     	ldr	x8, [sp, #0x78]
10006763c:     	cmp	x8, #0x1
100067640:     	b.lt	0x10006764c <<la_stack::rational::RationalMatrix<8>>::solve+0x39cc>
100067644:     	ldr	x0, [sp, #0x70]
100067648:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
10006764c:     	tbnz	w25, #0x0, 0x10006767c <<la_stack::rational::RationalMatrix<8>>::solve+0x39fc>
100067650:     	ldr	x8, [sp, #0x58]
100067654:     	cmp	x8, #0x1
100067658:     	b.lt	0x100067664 <<la_stack::rational::RationalMatrix<8>>::solve+0x39e4>
10006765c:     	ldr	x0, [sp, #0x60]
100067660:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
100067664:     	ldr	x8, [sp, #0x48]
100067668:     	cmp	x8, #0x0
10006766c:     	csel	w8, wzr, w24, le
100067670:     	cbz	w8, 0x10006767c <<la_stack::rational::RationalMatrix<8>>::solve+0x39fc>
100067674:     	ldr	x0, [sp, #0x50]
100067678:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
10006767c:     	ldr	x20, [sp, #0xd0]
100067680:     	cbz	x20, 0x1000677b8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3b38>
100067684:     	add	x19, sp, #0xd10
100067688:     	mov	x0, x19
10006768c:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
100067690:     	add	x19, x19, #0x100
100067694:     	subs	x20, x20, #0x1
100067698:     	b.ne	0x100067688 <<la_stack::rational::RationalMatrix<8>>::solve+0x3a08>
10006769c:     	b	0x1000677b8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3b38>
1000676a0:     	mov	x22, x0
1000676a4:     	ldr	x8, [sp, #0xae0]
1000676a8:     	cmp	x8, #0x0
1000676ac:     	b.le	0x1000676b8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3a38>
1000676b0:     	ldr	x0, [sp, #0xae8]
1000676b4:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
1000676b8:     	cmp	x26, #0x1
1000676bc:     	b.lt	0x100067734 <<la_stack::rational::RationalMatrix<8>>::solve+0x3ab4>
1000676c0:     	mov	x0, x20
1000676c4:     	b	0x100067730 <<la_stack::rational::RationalMatrix<8>>::solve+0x3ab0>
1000676c8:     	mov	x22, x0
1000676cc:     	mov	w23, #0x1               ; =1
1000676d0:     	ldr	x8, [sp, #0x1580]
1000676d4:     	cmp	x8, #0x1
1000676d8:     	b.lt	0x1000676e4 <<la_stack::rational::RationalMatrix<8>>::solve+0x3a64>
1000676dc:     	ldr	x0, [sp, #0x1588]
1000676e0:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
1000676e4:     	cbz	w23, 0x1000676fc <<la_stack::rational::RationalMatrix<8>>::solve+0x3a7c>
1000676e8:     	ldr	x28, [sp, #0xcd0]
1000676ec:     	cmp	x28, #0x1
1000676f0:     	b.lt	0x1000676fc <<la_stack::rational::RationalMatrix<8>>::solve+0x3a7c>
1000676f4:     	ldr	x0, [sp, #0xcd8]
1000676f8:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
1000676fc:     	add	x0, sp, #0xd10
100067700:     	bl	0x100042dbc <core::ptr::drop_glue::<[num_rational::Ratio<num_bigint::bigint::BigInt>; 8]>>
100067704:     	mov	x0, x22
100067708:     	bl	0x100219d68 <dyld_stub_binder+0x100219d68>
10006770c:     	b	0x100067790 <<la_stack::rational::RationalMatrix<8>>::solve+0x3b10>
100067710:     	b	0x100067770 <<la_stack::rational::RationalMatrix<8>>::solve+0x3af0>
100067714:     	b	0x100067754 <<la_stack::rational::RationalMatrix<8>>::solve+0x3ad4>
100067718:     	b	0x100067790 <<la_stack::rational::RationalMatrix<8>>::solve+0x3b10>
10006771c:     	mov	x22, x0
100067720:     	ldr	x8, [sp, #0x15c0]
100067724:     	cmp	x8, #0x1
100067728:     	b.lt	0x100067734 <<la_stack::rational::RationalMatrix<8>>::solve+0x3ab4>
10006772c:     	ldr	x0, [sp, #0x15c8]
100067730:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
100067734:     	mov	w19, #0x0               ; =0
100067738:     	ldr	x8, [sp, #0x1580]
10006773c:     	cmp	x8, #0x1
100067740:     	b.lt	0x10006774c <<la_stack::rational::RationalMatrix<8>>::solve+0x3acc>
100067744:     	ldr	x0, [sp, #0x1588]
100067748:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
10006774c:     	tbz	w19, #0x0, 0x1000677a8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3b28>
100067750:     	b	0x1000677b0 <<la_stack::rational::RationalMatrix<8>>::solve+0x3b30>
100067754:     	mov	x22, x0
100067758:     	ldr	x8, [sp, #0x15c0]
10006775c:     	cmp	x8, #0x1
100067760:     	b.lt	0x100067794 <<la_stack::rational::RationalMatrix<8>>::solve+0x3b14>
100067764:     	ldr	x0, [sp, #0x15c8]
100067768:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
10006776c:     	b	0x100067794 <<la_stack::rational::RationalMatrix<8>>::solve+0x3b14>
100067770:     	mov	x22, x0
100067774:     	ldr	x8, [sp, #0xae0]
100067778:     	cmp	x8, #0x1
10006777c:     	b.lt	0x100067794 <<la_stack::rational::RationalMatrix<8>>::solve+0x3b14>
100067780:     	ldr	x0, [sp, #0xae8]
100067784:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
100067788:     	b	0x100067794 <<la_stack::rational::RationalMatrix<8>>::solve+0x3b14>
10006778c:     	b	0x100067790 <<la_stack::rational::RationalMatrix<8>>::solve+0x3b10>
100067790:     	mov	x22, x0
100067794:     	ldur	x8, [x29, #-0xa0]
100067798:     	cmp	x8, #0x1
10006779c:     	b.lt	0x1000677a8 <<la_stack::rational::RationalMatrix<8>>::solve+0x3b28>
1000677a0:     	ldur	x0, [x29, #-0x98]
1000677a4:     	bl	0x100219f48 <dyld_stub_binder+0x100219f48>
1000677a8:     	add	x0, sp, #0x9e0
1000677ac:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
1000677b0:     	add	x0, sp, #0xd10
1000677b4:     	bl	0x10004280c <core::ptr::drop_glue::<[[num_bigint::bigint::BigInt; 8]; 8]>>
1000677b8:     	add	x0, sp, #0xe0
1000677bc:     	bl	0x100043214 <core::ptr::drop_glue::<[num_bigint::bigint::BigInt; 8]>>
1000677c0:     	mov	x0, x22
1000677c4:     	bl	0x100219d68 <dyld_stub_binder+0x100219d68>
1000677c8:     	nop
1000677cc:     	nop
1000677d0:     	nop
1000677d4:     	nop
1000677d8:     	nop
1000677dc:     	nop
1000677e0:     	nop
1000677e4:     	nop
1000677e8:     	nop
1000677ec:     	nop
1000677f0:     	nop
1000677f4:     	nop
1000677f8:     	nop
1000677fc:     	nop
