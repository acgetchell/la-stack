"""Analyze process-level block ratios, retaining all completed measurements."""

# Standalone retained experiment, not an importable repository package.
# ruff: noqa: INP001

import csv
import itertools
import json
import math
import random
import statistics
from pathlib import Path


def main() -> None:
    """Print all process means and a reproducible block-level comparison."""
    root = Path(__file__).resolve().parent
    runs: list[dict[str, object]] = []
    blocks: list[dict[str, object]] = []
    with (root / "runs.tsv").open() as source:
        manifest = list(csv.DictReader(source, delimiter="\t"))
    for row in manifest:
        run = f"block-{row['block']}-slot-{row['slot']}-{row['label']}"
        path = root / "criterion/rational_solve_diagonal_rational_d8/prepared" / run
        estimates = json.loads((path / "estimates.json").read_text())
        runs.append({**row, "mean_ns": estimates["mean"]["point_estimate"]})
    log_ratios: list[float] = []
    for block in range(1, 11):
        selected = [row for row in runs if int(str(row["block"])) == block]
        if len(selected) != 4:
            message = f"Incomplete block {block}"
            raise ValueError(message)
        means = {label: statistics.fmean(float(str(row["mean_ns"])) for row in selected if row["label"] == label) for label in ("before", "after")}
        ratio = means["after"] / means["before"]
        placebo = block in (5, 10)
        blocks.append({"block": block, "placebo": placebo, **means, "ratio": ratio})
        if not placebo:
            log_ratios.append(math.log(ratio))
    # Resample whole four-process blocks. Criterion samples within a process
    # are not independent before/after replicates. No measurements are removed.
    rng = random.Random(285002)  # noqa: S311 - reproducible statistical resampling
    boot = sorted(math.exp(statistics.fmean(rng.choices(log_ratios, k=len(log_ratios)))) for _ in range(100_000))
    observed = abs(statistics.fmean(log_ratios))
    permutations = [
        abs(statistics.fmean(x * s for x, s in zip(log_ratios, signs, strict=True))) for signs in itertools.product((-1, 1), repeat=len(log_ratios))
    ]
    print(
        json.dumps(
            {
                "runs": runs,
                "blocks": blocks,
                "processes": len(runs),
                "comparison_blocks": len(log_ratios),
                "comparison_mean_ns": {
                    label: statistics.fmean(float(str(row["mean_ns"])) for row in runs if row["label"] == label and int(str(row["block"])) not in (5, 10))
                    for label in ("before", "after")
                },
                "geometric_mean_block_ratio": math.exp(statistics.fmean(log_ratios)),
                "block_bootstrap_95_percent_interval": [boot[2499], boot[97499]],
                "two_sided_sign_flip_p": sum(x >= observed for x in permutations) / len(permutations),
                "limitations": (
                    "Conditional local estimates for these retained binaries; balanced order, not randomized. "
                    "Eight comparison blocks; two placebo blocks are descriptive only."
                ),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
