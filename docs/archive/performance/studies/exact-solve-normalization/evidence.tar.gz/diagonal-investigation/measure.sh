#!/usr/bin/env bash
set -euo pipefail

# Predeclared design: eight independent ABBA/BAAB blocks and two same-binary
# placebo blocks. Each process validates all fixtures before measurement.
# No builds or correctness suites may run concurrently with this script.
evidence_dir="$PWD/target/exact-normalization-20261018"
run_dir="$evidence_dir/diagonal-investigation"
export CRITERION_HOME="$run_dir/criterion"
printf 'block\tslot\tlabel\tbinary\tstarted_utc\n' > "$run_dir/runs.tsv"
for block in 1 2 3 4 5 6 7 8 9 10; do
  if (( block % 2 == 1 )); then
    labels=(before after after before)
  else
    labels=(after before before after)
  fi
  for slot in 0 1 2 3; do
    label="${labels[$slot]}"
    variant="$label"
    if (( block == 5 )); then variant=before; fi
    if (( block == 10 )); then variant=after; fi
    run="block-$block-slot-$slot-$label"
    printf '%s\t%s\t%s\t%s\t%s\n' "$block" "$slot" "$label" "$variant" \
      "$(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$run_dir/runs.tsv"
    "$evidence_dir/$variant-rational-solve" --bench \
      '^rational_solve/diagonal/rational_d8/prepared$' \
      --sample-size 100 --warm-up-time 2 --measurement-time 5 --noplot \
      --save-baseline "$run" > "$run_dir/$run.log" 2>&1
  done
  echo "Completed block $block/10"
done
