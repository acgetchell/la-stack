[inputs
 | (input_filename | capture("/criterion/(?<case>.+)/(?<run>before|after|before-repeat|after-repeat)/estimates.json$")) as $path
 | {case: $path.case, run: $path.run,
    mean_ns: .mean.point_estimate,
    lower_95_ns: .mean.confidence_interval.lower_bound,
    upper_95_ns: .mean.confidence_interval.upper_bound}]
| group_by(.case)
| map({case: .[0].case, runs: (map({key: .run, value: del(.case, .run)}) | from_entries)})
| map(. + {
    after_over_before: (if .runs.before and .runs.after then .runs.after.mean_ns / .runs.before.mean_ns else null end),
    repeat_after_over_before: (if .runs["before-repeat"] and .runs["after-repeat"] then .runs["after-repeat"].mean_ns / .runs["before-repeat"].mean_ns else null end)
  })
