#!/bin/sh
set -eu
study_root=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
filter=$(cat "$study_root/control-filter.txt")
export CRITERION_HOME="$study_root/criterion"
for phase in before-control1 after-control1 after-control2 before-control2; do
    variant=${phase%%-*}
    date -u '+%Y-%m-%dT%H:%M:%SZ' > "$study_root/$phase.log"
    "$study_root/bin/exact-$variant" --bench "$filter" --sample-size 30 \
        --warm-up-time 1 --measurement-time 2 --noplot --save-baseline "$phase" \
        >> "$study_root/$phase.log" 2>&1
    date -u '+%Y-%m-%dT%H:%M:%SZ' >> "$study_root/$phase.log"
done
