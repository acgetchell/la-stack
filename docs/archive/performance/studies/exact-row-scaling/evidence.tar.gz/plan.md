# Row-local determinant scaling revisit

Compare the final compact prototype with current main. Preserve exact values,
canonical rationals, signs, typed failures, and conversion semantics. A small
control regression is a tradeoff to report, not an automatic rejection.

The common harness adds row scales with binary exponent spreads 0, 8, 32, 64,
128, 256, 512, 1024, and 2000 across D=2–5. Symmetric exponents sum to zero;
the base determinant is unchanged. D=4 column scaling provides a control whose
within-row exponent spread cannot be removed by row normalization. All four
determinant APIs are validated before timing using rational Gaussian elimination
and the unchanged determinant of the unscaled integer matrix.

Run the complete exact suite before then after, including unaffected solve,
conversion, floating-point, and rational-input controls. Repeat all affected
determinant families in reverse order, after then before. Preserve every result;
do not select cases based on the first pass. Use 30 samples, one-second warm-up,
and two-second measurement targets for both passes. No builds or test runs
overlap timing. Means and per-run intervals are descriptive, not paired speedup
confidence intervals. Workload mixtures are explicitly hypothetical; no user
prevalence data is available.

The completed first pass exposed 17 unchanged controls with more than 10%
additional time and more than 5 ns absolute cost. Their candidate samples were
often much more variable. Repeat that complete selected set in A–B–B–A order
(baseline, candidate, candidate, baseline), using the same measurement settings.
The selection is recorded in `control-filter.txt`; retain the original results.
A CPU snapshot during the determinant repeat also showed substantial background
activity. This is a limitation, not proof of the cause of any individual result.

Build each executable with:

```sh
cargo bench --locked --features bench,exact --bench exact --no-run
```

Validate both executable inventories and fixture-test modes before measurement.
Retain the base revision, harness patch, prototype patch, source hashes, binaries,
environment, test logs, and raw Criterion data. Run final comprehensive CI on
the candidate. Document any correctness failure independently of speed results.
