#!/bin/sh
set -eu
study_root=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
for pass in first repeat control1 control2; do
    uv run --locked python "$study_root/analyze.py" "$study_root/criterion" \
        "before-$pass" "after-$pass" > "$study_root/$pass.json"
done
jq -n --slurpfile first "$study_root/first.json" --slurpfile repeat "$study_root/repeat.json" \
    '($repeat[0] | map({key:.benchmark,value:.}) | from_entries) as $r |
     $first[0] | map(. + {repeat:$r[.benchmark]})' > "$study_root/comparison.json"
jq -n --slurpfile first "$study_root/first.json" --slurpfile c1 "$study_root/control1.json" \
    --slurpfile c2 "$study_root/control2.json" \
    '($first[0]|map({key:.benchmark,value:.})|from_entries) as $f |
     ($c2[0]|map({key:.benchmark,value:.})|from_entries) as $r |
     $c1[0] | map({benchmark,original:$f[.benchmark],forward:.,reverse:$r[.benchmark]})' \
    > "$study_root/controls.json"
jq -f "$study_root/mixtures.jq" "$study_root/comparison.json" > "$study_root/mixtures.json"
