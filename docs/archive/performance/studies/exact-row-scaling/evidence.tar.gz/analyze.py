"""Summarize retained Criterion means without inferring paired uncertainty."""

import argparse
import json
import re
from pathlib import Path
from typing import Any


def read_results(root: Path, baseline: str, pattern: str) -> dict[str, dict[str, Any]]:
    results: dict[str, dict[str, Any]] = {}
    for path in sorted(root.glob(f"**/{baseline}/estimates.json")):
        estimate = json.loads(path.read_text())["mean"]
        benchmark = json.loads(path.with_name("benchmark.json").read_text())
        if not re.search(pattern, benchmark["full_id"]):
            continue
        results[benchmark["full_id"]] = {
            "mean_ns": estimate["point_estimate"],
            "mean_ci95_ns": [
                estimate["confidence_interval"]["lower_bound"],
                estimate["confidence_interval"]["upper_bound"],
            ],
        }
    return results


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("before")
    parser.add_argument("after")
    parser.add_argument("--filter", default=".*")
    args = parser.parse_args()
    before = read_results(args.root, args.before, args.filter)
    after = read_results(args.root, args.after, args.filter)
    if not before or before.keys() != after.keys():
        raise ValueError("nonempty matching benchmark inventories are required")
    print(json.dumps([
        {
            "benchmark": name,
            "before": before[name],
            "after": after[name],
            "after_over_before": after[name]["mean_ns"] / before[name]["mean_ns"],
        }
        for name in sorted(before)
    ], indent=2))


if __name__ == "__main__":
    main()
