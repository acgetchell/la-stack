def estimate($control; $benefit):
  ($control.after.mean_ns - $control.before.mean_ns) as $cost |
  ($benefit.before.mean_ns - $benefit.after.mean_ns) as $saving |
  if $cost <= 0 or $saving <= 0 then error("expected a cost and a saving") else
    {extra_control_ns: $cost, saved_benefit_ns: $saving,
     break_even_benefit_share: ($cost / ($cost + $saving))}
  end;
map({key: .benchmark, value: .}) | from_entries as $cases |
[
  ["det4_diagnostic_dense/det_exact", "det4_diagnostic_near_singular_positive/det_exact"],
  ["det4_diagnostic_dense/det_exact", "det4_diagnostic_mixed_exponents/det_exact"],
  ["exact_exponent_spread_row_d2/bits_0/det_exact", "exact_exponent_spread_row_d2/bits_64/det_exact"],
  ["exact_exponent_spread_row_d3/bits_0/det_exact", "exact_exponent_spread_row_d3/bits_64/det_exact"],
  ["exact_exponent_spread_row_d4/bits_0/det_exact", "exact_exponent_spread_row_d4/bits_64/det_exact"],
  ["exact_exponent_spread_row_d5/bits_0/det_exact", "exact_exponent_spread_row_d5/bits_64/det_exact"]
] | map(.[0] as $control | .[1] as $benefit |
  {control: $control, benefit: $benefit,
   first: estimate($cases[$control]; $cases[$benefit]),
   repeat: estimate($cases[$control].repeat; $cases[$benefit].repeat)})
