#!/bin/sh
set -eu
study_root=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
variant=$1
pass=$2
scope=${3:-full}
case "$scope" in
    full) filter='.*' ;;
    determinants) filter='^(exact_d[2-5]|exact_random_corpus_d[2-5]|exact_near_singular_3x3|exact_large_entries_3x3|exact_hilbert_[45]x[45]|det4_diagnostic_.*|exact_exponent_spread_.*)/det_(exact|exact_f64_result|exact_rounded_f64|sign_exact)$' ;;
    *) exit 2 ;;
esac
export CRITERION_HOME="$study_root/criterion"
date -u '+%Y-%m-%dT%H:%M:%SZ'
"$study_root/bin/exact-$variant" --bench "$filter" --sample-size 30 \
    --warm-up-time 1 --measurement-time 2 --noplot --save-baseline "$variant-$pass"
date -u '+%Y-%m-%dT%H:%M:%SZ'
