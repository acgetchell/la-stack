	.build_version macos, 11, 0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RINvNtCshzmyaYQzAhy_8la_stack4norm18norm_near_overflowKj4_ECs7wsLvUT6iAW_13codegen_audit:
	.cfi_startproc
	stp	d9, d8, [sp, #-80]!
	.cfi_def_cfa_offset 80
	stp	x28, x27, [sp, #16]
	stp	x22, x21, [sp, #32]
	stp	x20, x19, [sp, #48]
	stp	x29, x30, [sp, #64]
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w27, -56
	.cfi_offset w28, -64
	.cfi_offset b8, -72
	.cfi_offset b9, -80
	.cfi_remember_state
	sub	sp, sp, #544
	mov.16b	v8, v0
	mov	x20, x1
	mov	x19, x0
	add	x0, sp, #8
	mov	w1, #536
	bl	_bzero
	ldr	d0, [x20]
	fcmp	d0, #0.0
	b.eq	LBB0_2
	fmov	x8, d0
	ubfx	x9, x8, #52, #11
	and	x10, x8, #0xfffffffffffff
	mov	x11, #4503599627370496
	bfxil	x11, x8, #0, #52
	sub	x8, x9, #1075
	cmp	x9, #0
	csel	x1, x10, x11, eq
	mov	x9, #-1074
	csel	x3, x9, x8, eq
	add	x0, sp, #8
	mov	x2, #0
	bl	__RNvMNtCshzmyaYQzAhy_8la_stack4normNtB2_9SquareSum10add_square
LBB0_2:
	ldr	d0, [x20, #8]
	fcmp	d0, #0.0
	b.eq	LBB0_4
	fmov	x8, d0
	ubfx	x9, x8, #52, #11
	and	x10, x8, #0xfffffffffffff
	mov	x11, #4503599627370496
	bfxil	x11, x8, #0, #52
	sub	x8, x9, #1075
	cmp	x9, #0
	csel	x1, x10, x11, eq
	mov	x9, #-1074
	csel	x3, x9, x8, eq
	add	x0, sp, #8
	mov	x2, #0
	bl	__RNvMNtCshzmyaYQzAhy_8la_stack4normNtB2_9SquareSum10add_square
LBB0_4:
	ldr	d0, [x20, #16]
	fcmp	d0, #0.0
	b.eq	LBB0_6
	fmov	x8, d0
	ubfx	x9, x8, #52, #11
	and	x10, x8, #0xfffffffffffff
	mov	x11, #4503599627370496
	bfxil	x11, x8, #0, #52
	sub	x8, x9, #1075
	cmp	x9, #0
	csel	x1, x10, x11, eq
	mov	x9, #-1074
	csel	x3, x9, x8, eq
	add	x0, sp, #8
	mov	x2, #0
	bl	__RNvMNtCshzmyaYQzAhy_8la_stack4normNtB2_9SquareSum10add_square
LBB0_6:
	ldr	d0, [x20, #24]
	fcmp	d0, #0.0
	b.eq	LBB0_8
	fmov	x8, d0
	ubfx	x9, x8, #52, #11
	and	x10, x8, #0xfffffffffffff
	mov	x11, #4503599627370496
	bfxil	x11, x8, #0, #52
	sub	x8, x9, #1075
	cmp	x9, #0
	csel	x1, x10, x11, eq
	mov	x9, #-1074
	csel	x3, x9, x8, eq
	add	x0, sp, #8
	mov	x2, #0
	bl	__RNvMNtCshzmyaYQzAhy_8la_stack4normNtB2_9SquareSum10add_square
LBB0_8:
	mov	x8, #9218868437227405311
	fmov	d0, x8
	add	x0, sp, #8
	bl	__RNvMNtCshzmyaYQzAhy_8la_stack4normNtB2_9SquareSum16compare_midpoint
	mov	w21, #255
	bics	wzr, w21, w0
	b.eq	LBB0_10
	mov	w8, #4097
	strh	w8, [x19]
	mov	w8, #5
	strb	w8, [x19, #8]
	b	LBB0_22
LBB0_10:
	mov	x20, #9218868437227405311
	fmov	d0, x20
	add	x0, sp, #8
	bl	__RNvMNtCshzmyaYQzAhy_8la_stack4normNtB2_9SquareSum14compare_square
	bics	wzr, w21, w0
	b.eq	LBB0_12
	str	x20, [x19, #8]
	b	LBB0_21
LBB0_12:
	fmov	x21, d8
	sub	x8, x20, x21
	cmp	x8, #2
	b.hs	LBB0_14
	b	LBB0_17
LBB0_13:
	mov	x21, x22
	sub	x8, x20, x22
	cmp	x8, #1
	b.ls	LBB0_17
LBB0_14:
	add	x22, x21, x8, lsr #1
	fmov	d0, x22
	add	x0, sp, #8
	bl	__RNvMNtCshzmyaYQzAhy_8la_stack4normNtB2_9SquareSum14compare_square
	and	w8, w0, #0xff
	cmp	w8, #1
	b.eq	LBB0_13
	cmp	w8, #255
	b.ne	LBB0_23
	mov	x20, x22
	sub	x8, x22, x21
	cmp	x8, #1
	b.hi	LBB0_14
LBB0_17:
	fmov	d0, x21
	add	x0, sp, #8
	bl	__RNvMNtCshzmyaYQzAhy_8la_stack4normNtB2_9SquareSum16compare_midpoint
	ands	w8, w0, #0xff
	b.eq	LBB0_19
	cmp	w8, #1
	csel	x8, x20, x21, eq
	b	LBB0_20
LBB0_19:
	and	x8, x21, #0x1
	add	x8, x8, x21
LBB0_20:
	str	x8, [x19, #8]
LBB0_21:
	mov	w8, #255
	strb	w8, [x19]
LBB0_22:
	add	sp, sp, #544
	.cfi_def_cfa wsp, 80
	ldp	x29, x30, [sp, #64]
	ldp	x20, x19, [sp, #48]
	ldp	x22, x21, [sp, #32]
	ldp	x28, x27, [sp, #16]
	ldp	d9, d8, [sp], #80
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore b8
	.cfi_restore b9
	ret
LBB0_23:
	.cfi_restore_state
	str	x22, [x19, #8]
	b	LBB0_21
	.cfi_endproc

	.p2align	6
__RINvNtCshzmyaYQzAhy_8la_stack5exact25bareiss_forward_eliminateKj5_ECs7wsLvUT6iAW_13codegen_audit:
Lfunc_begin0:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception0
	stp	x28, x27, [sp, #-96]!
	.cfi_def_cfa_offset 96
	stp	x26, x25, [sp, #16]
	stp	x24, x23, [sp, #32]
	stp	x22, x21, [sp, #48]
	stp	x20, x19, [sp, #64]
	stp	x29, x30, [sp, #80]
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_remember_state
	sub	sp, sp, #448
	mov	x22, x2
	str	x0, [sp]
	mov	x19, #0
	mov	x13, #0
	str	wzr, [sp, #12]
	mov	w8, #2
	strb	w8, [sp, #168]
	mov	x8, #-1
	mov	w9, #1
	stp	x8, x9, [sp, #144]
	str	x9, [sp, #160]
	add	x20, x1, #184
	add	x9, x1, #32
	add	x8, x1, #192
	str	x8, [sp, #24]
	mov	w8, #4
	stp	x8, x9, [sp, #72]
	str	x1, [sp, #88]
	mov	x21, x1
	str	x2, [sp, #128]
	b	LBB1_2
LBB1_1:
	add	x19, x19, #32
	add	x21, x21, #160
	ldr	x1, [sp, #136]
	ldrb	w8, [x1, #24]
	strb	w8, [sp, #168]
	add	x20, x20, #192
	ldr	x8, [sp, #80]
	add	x9, x8, #192
	ldr	x8, [sp, #24]
	add	x8, x8, #192
	str	x8, [sp, #24]
	ldr	x8, [sp, #72]
	sub	x8, x8, #1
	stp	x8, x9, [sp, #72]
Ltmp24:
	add	x0, sp, #144
	bl	__RNvXs_NtCs70jQWIuBJri_10num_bigint9big_digitNtB4_9BigDigitsNtNtCsjIpoRzUjyHQ_4core5clone5Clone10clone_from
Ltmp25:
	ldr	x13, [sp, #16]
LBB1_2:
	ldr	x8, [sp, #88]
	mov	w9, #160
	madd	x10, x13, x9, x8
	add	x8, x10, x13, lsl #5
	str	x8, [sp, #136]
	ldrb	w12, [x8, #24]
	mov	x11, x20
	mov	x9, x21
	mov	x8, x19
	cmp	w12, #1
	b.ne	LBB1_8
LBB1_3:
	add	x8, x8, #32
	cmp	x8, #160
	b.eq	LBB1_68
	add	x9, x9, #160
	ldrb	w12, [x11], #160
	cmp	w12, #1
	b.eq	LBB1_3
	ldp	q0, q1, [x10, #128]
	stp	q0, q1, [sp, #368]
	ldp	q0, q1, [x10, #64]
	stp	q0, q1, [sp, #304]
	ldp	q0, q1, [x10, #96]
	stp	q0, q1, [sp, #336]
	ldp	q0, q1, [x10]
	stp	q0, q1, [sp, #240]
	ldp	q0, q1, [x10, #32]
	stp	q0, q1, [sp, #272]
	ldp	q0, q1, [x9]
	ldp	q2, q3, [x9, #32]
	ldp	q4, q5, [x9, #64]
	ldp	q6, q7, [x9, #96]
	ldp	q16, q17, [x9, #128]
	stp	q16, q17, [x10, #128]
	stp	q6, q7, [x10, #96]
	stp	q4, q5, [x10, #64]
	stp	q2, q3, [x10, #32]
	stp	q0, q1, [x10]
	ldp	q0, q1, [sp, #368]
	stp	q0, q1, [x9, #128]
	ldp	q0, q1, [sp, #304]
	stp	q0, q1, [x9, #64]
	ldp	q0, q1, [sp, #336]
	stp	q0, q1, [x9, #96]
	ldp	q0, q1, [sp, #240]
	stp	q0, q1, [x9]
	ldp	q0, q1, [sp, #272]
	stp	q0, q1, [x9, #32]
	cbz	x22, LBB1_7
	add	x9, x22, x13, lsl #5
	add	x8, x22, x8
	ldp	q1, q0, [x9]
	ldp	q3, q2, [x8]
	stp	q3, q2, [x9]
	stp	q1, q0, [x8]
LBB1_7:
	ldr	w8, [sp, #12]
	eor	w8, w8, #0x1
	str	w8, [sp, #12]
LBB1_8:
	add	x8, x13, #1
	cmp	x8, #5
	b.eq	LBB1_71
	add	x8, x13, #1
	str	x8, [sp, #16]
	lsl	x9, x13, #5
	ldr	x8, [sp, #88]
	stp	x9, x20, [sp, #32]
	add	x8, x8, x9
	str	x8, [sp, #96]
	ldr	x24, [sp, #24]
	add	x8, x13, #1
	stp	x19, x21, [sp, #48]
	str	x13, [sp, #64]
	b	LBB1_11
LBB1_10:
	str	xzr, [x8, #16]
	ldp	x21, x13, [sp, #56]
	add	x24, x24, #160
	ldr	x8, [sp, #104]
	cmp	x8, #5
	b.eq	LBB1_1
LBB1_11:
	mov	x10, x8
	add	x8, x8, #1
	stp	x8, x24, [sp, #104]
	ldp	x25, x8, [sp, #80]
	mov	w9, #160
	str	x10, [sp, #120]
	madd	x8, x10, x9, x8
	add	x23, x8, x13, lsl #5
	ldr	x20, [sp, #72]
	b	LBB1_13
LBB1_12:
	stp	x21, x26, [x24]
	add	x25, x25, #32
	str	x27, [x24, #16]
	strb	w19, [x24, #24]
	add	x24, x24, #32
	subs	x20, x20, #1
	b.eq	LBB1_37
LBB1_13:
Ltmp0:
	add	x0, sp, #208
	ldr	x1, [sp, #136]
	mov	x2, x24
	bl	__RNvXsf_NtNtCs70jQWIuBJri_10num_bigint6bigint14multiplicationRNtB7_6BigIntNtNtNtCsjIpoRzUjyHQ_4core3ops5arith3Mul3mul
Ltmp1:
Ltmp3:
	add	x0, sp, #240
	mov	x1, x23
	mov	x2, x25
	bl	__RNvXsf_NtNtCs70jQWIuBJri_10num_bigint6bigint14multiplicationRNtB7_6BigIntNtNtNtCsjIpoRzUjyHQ_4core3ops5arith3Mul3mul
Ltmp4:
Ltmp6:
	add	x0, sp, #176
	add	x1, sp, #208
	add	x2, sp, #240
	bl	__RNvXs1_NtNtCs70jQWIuBJri_10num_bigint6bigint11subtractionNtB7_6BigIntNtNtNtCsjIpoRzUjyHQ_4core3ops5arith3Sub3sub
Ltmp7:
Ltmp9:
	add	x8, sp, #240
	add	x0, sp, #176
	add	x1, sp, #144
	bl	__RNvNtNtCs70jQWIuBJri_10num_bigint7biguint8division11div_rem_ref
Ltmp10:
	ldp	x21, x26, [sp, #240]
	ldp	x27, x19, [sp, #256]
	ldr	x0, [sp, #272]
	ldrb	w8, [sp, #200]
	cmp	w8, #1
	b.ne	LBB1_21
	cmn	x21, #1
	b.eq	LBB1_22
	cmp	x21, #2
	b.hs	LBB1_23
	mov	x27, #0
	cmn	x19, #1
	b.ne	LBB1_26
	b	LBB1_31
LBB1_21:
	eor	w9, w26, #0x1
	cmp	x27, #0
	cset	w10, eq
	cmn	x21, #1
	csel	w9, w9, w10, eq
	tst	w9, #0x1
	csinc	w28, w8, wzr, eq
	ldrb	w22, [sp, #168]
	sub	x8, x19, #1
	cmn	x8, #3
	b.ls	LBB1_28
	b	LBB1_32
LBB1_22:
	mov	x26, #0
	cmn	x19, #1
	b.ne	LBB1_26
	b	LBB1_31
LBB1_23:
	cmp	x21, #1
	b.lt	LBB1_25
	lsl	x1, x21, #3
	mov	x21, x0
	mov	x0, x26
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	mov	x0, x21
LBB1_25:
	mov	x26, #0
	mov	x21, #-1
	cmn	x19, #1
	b.eq	LBB1_31
LBB1_26:
	cmp	x19, #2
	b.hs	LBB1_29
	mov	w28, #1
	ldrb	w22, [sp, #168]
	sub	x8, x19, #1
	cmn	x8, #3
	b.hi	LBB1_32
LBB1_28:
	lsl	x1, x19, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	b	LBB1_32
LBB1_29:
	cmp	x19, #1
	b.lt	LBB1_31
	lsl	x1, x19, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB1_31:
	ldrb	w22, [sp, #168]
	mov	w28, #1
LBB1_32:
	mov	w8, #2
	sub	w8, w8, w28
	.p2align	6, , 4
	cmp	w22, #0
	csel	w19, w8, w28, eq
	ldr	x8, [sp, #176]
	cmp	x8, #1
	b.lt	LBB1_35
	ldr	x0, [sp, #184]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB1_35:
	ldr	x8, [x24]
	cmp	x8, #1
	ldr	x22, [sp, #128]
	b.lt	LBB1_12
	ldr	x0, [x24, #8]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	b	LBB1_12
LBB1_37:
	ldr	x25, [sp, #120]
	cbz	x22, LBB1_66
	add	x23, x22, x25, lsl #5
Ltmp12:
	add	x0, sp, #208
	ldr	x1, [sp, #136]
	mov	x2, x23
	bl	__RNvXsf_NtNtCs70jQWIuBJri_10num_bigint6bigint14multiplicationRNtB7_6BigIntNtNtNtCsjIpoRzUjyHQ_4core3ops5arith3Mul3mul
Ltmp13:
	mov	w8, #160
	ldr	x9, [sp, #96]
	madd	x1, x25, x8, x9
Ltmp15:
	add	x0, sp, #240
	ldr	x8, [sp, #32]
	add	x2, x22, x8
	bl	__RNvXsf_NtNtCs70jQWIuBJri_10num_bigint6bigint14multiplicationRNtB7_6BigIntNtNtNtCsjIpoRzUjyHQ_4core3ops5arith3Mul3mul
Ltmp16:
Ltmp18:
	add	x0, sp, #176
	add	x1, sp, #208
	add	x2, sp, #240
	bl	__RNvXs1_NtNtCs70jQWIuBJri_10num_bigint6bigint11subtractionNtB7_6BigIntNtNtNtCsjIpoRzUjyHQ_4core3ops5arith3Sub3sub
Ltmp19:
Ltmp21:
	add	x8, sp, #240
	add	x0, sp, #176
	add	x1, sp, #144
	bl	__RNvNtNtCs70jQWIuBJri_10num_bigint7biguint8division11div_rem_ref
Ltmp22:
	ldp	x20, x24, [sp, #240]
	ldp	x21, x25, [sp, #256]
	ldr	x0, [sp, #272]
	ldrb	w8, [sp, #200]
	cmp	w8, #1
	b.ne	LBB1_46
	cmn	x20, #1
	b.eq	LBB1_48
	cmp	x20, #2
	b.hs	LBB1_51
	mov	x21, #0
	cmn	x25, #1
	b.ne	LBB1_54
	b	LBB1_59
LBB1_46:
	cmn	x20, #1
	b.eq	LBB1_49
	cmp	x21, #0
	cset	w9, eq
	b	LBB1_50
LBB1_48:
	mov	x24, #0
	cmn	x25, #1
	b.ne	LBB1_54
	b	LBB1_59
LBB1_49:
	eor	w9, w24, #0x1
LBB1_50:
	tst	w9, #0x1
	csinc	w19, w8, wzr, eq
	ldrb	w26, [sp, #168]
	sub	x8, x25, #1
	cmn	x8, #3
	b.ls	LBB1_56
	b	LBB1_60
LBB1_51:
	cmp	x20, #1
	b.lt	LBB1_53
	lsl	x1, x20, #3
	mov	x19, x0
	mov	x0, x24
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	mov	x0, x19
LBB1_53:
	mov	x24, #0
	mov	x20, #-1
	cmn	x25, #1
	b.eq	LBB1_59
LBB1_54:
	cmp	x25, #2
	b.hs	LBB1_57
	mov	w19, #1
	ldrb	w26, [sp, #168]
	sub	x8, x25, #1
	cmn	x8, #3
	b.hi	LBB1_60
LBB1_56:
	lsl	x1, x25, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	b	LBB1_60
LBB1_57:
	cmp	x25, #1
	b.lt	LBB1_59
	lsl	x1, x25, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB1_59:
	ldrb	w26, [sp, #168]
	mov	w19, #1
LBB1_60:
	mov	w8, #2
	sub	w8, w8, w19
	.p2align	6, , 4
	cmp	w26, #0
	csel	w19, w8, w19, eq
	ldr	x8, [sp, #176]
	cmp	x8, #1
	ldr	x25, [sp, #120]
	b.lt	LBB1_63
	ldr	x0, [sp, #184]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB1_63:
	ldr	x8, [x23]
	cmp	x8, #1
	b.lt	LBB1_65
	ldr	x0, [x23, #8]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB1_65:
	stp	x20, x24, [x23]
	str	x21, [x23, #16]
	strb	w19, [x23, #24]
LBB1_66:
	mov	w8, #160
	ldr	x9, [sp, #96]
	madd	x8, x25, x8, x9
	mov	w9, #1
	strb	w9, [x8, #24]
	ldr	x9, [x8]
	cmp	x9, #1
	ldp	x20, x19, [sp, #40]
	ldr	x24, [sp, #112]
	b.ge	LBB1_10
	mov	x9, #-1
	stp	x9, xzr, [x8]
	ldp	x21, x13, [sp, #56]
	add	x24, x24, #160
	ldr	x8, [sp, #104]
	cmp	x8, #5
	b.ne	LBB1_11
	b	LBB1_1
LBB1_68:
	ldr	x9, [sp]
	str	x13, [x9, #8]
	mov	w8, #1
	strb	w8, [x9]
	ldr	x8, [sp, #144]
	cmp	x8, #1
	b.lt	LBB1_70
LBB1_69:
	ldr	x0, [sp, #152]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB1_70:
	add	sp, sp, #448
	.cfi_def_cfa wsp, 96
	ldp	x29, x30, [sp, #80]
	ldp	x20, x19, [sp, #64]
	ldp	x22, x21, [sp, #48]
	ldp	x24, x23, [sp, #32]
	ldp	x26, x25, [sp, #16]
	ldp	x28, x27, [sp], #96
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	ret
LBB1_71:
	.cfi_restore_state
	ldr	x8, [sp]
	ldr	w9, [sp, #12]
	strb	w9, [x8, #1]
	strb	wzr, [x8]
	ldr	x8, [sp, #144]
	cmp	x8, #0
	b.gt	LBB1_69
	b	LBB1_70
LBB1_72:
Ltmp26:
	b	LBB1_82
LBB1_73:
Ltmp23:
	b	LBB1_78
LBB1_74:
Ltmp17:
	b	LBB1_84
LBB1_75:
Ltmp20:
	b	LBB1_82
LBB1_76:
Ltmp14:
	b	LBB1_82
LBB1_77:
Ltmp11:
LBB1_78:
	mov	x19, x0
	ldr	x8, [sp, #176]
	cmp	x8, #1
	b.lt	LBB1_87
	ldr	x0, [sp, #184]
	b	LBB1_86
LBB1_80:
Ltmp8:
	b	LBB1_82
LBB1_81:
Ltmp2:
LBB1_82:
	mov	x19, x0
	b	LBB1_87
LBB1_83:
Ltmp5:
LBB1_84:
	mov	x19, x0
	ldr	x8, [sp, #208]
	cmp	x8, #1
	b.lt	LBB1_87
	ldr	x0, [sp, #216]
LBB1_86:
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB1_87:
	ldr	x8, [sp, #144]
	cmp	x8, #1
	b.lt	LBB1_89
	ldr	x0, [sp, #152]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB1_89:
	mov	x0, x19
	bl	__Unwind_Resume
Lfunc_end0:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table1:
Lexception0:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 Lcst_end0-Lcst_begin0
Lcst_begin0:
	.uleb128 Ltmp24-Lfunc_begin0
	.uleb128 Ltmp25-Ltmp24
	.uleb128 Ltmp26-Lfunc_begin0
	.byte	0
	.uleb128 Ltmp0-Lfunc_begin0
	.uleb128 Ltmp1-Ltmp0
	.uleb128 Ltmp2-Lfunc_begin0
	.byte	0
	.uleb128 Ltmp3-Lfunc_begin0
	.uleb128 Ltmp4-Ltmp3
	.uleb128 Ltmp5-Lfunc_begin0
	.byte	0
	.uleb128 Ltmp6-Lfunc_begin0
	.uleb128 Ltmp7-Ltmp6
	.uleb128 Ltmp8-Lfunc_begin0
	.byte	0
	.uleb128 Ltmp9-Lfunc_begin0
	.uleb128 Ltmp10-Ltmp9
	.uleb128 Ltmp11-Lfunc_begin0
	.byte	0
	.uleb128 Ltmp12-Lfunc_begin0
	.uleb128 Ltmp13-Ltmp12
	.uleb128 Ltmp14-Lfunc_begin0
	.byte	0
	.uleb128 Ltmp15-Lfunc_begin0
	.uleb128 Ltmp16-Ltmp15
	.uleb128 Ltmp17-Lfunc_begin0
	.byte	0
	.uleb128 Ltmp18-Lfunc_begin0
	.uleb128 Ltmp19-Ltmp18
	.uleb128 Ltmp20-Lfunc_begin0
	.byte	0
	.uleb128 Ltmp21-Lfunc_begin0
	.uleb128 Ltmp22-Ltmp21
	.uleb128 Ltmp23-Lfunc_begin0
	.byte	0
	.uleb128 Ltmp22-Lfunc_begin0
	.uleb128 Lfunc_end0-Ltmp22
	.byte	0
	.byte	0
Lcst_end0:
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueAINtCsjLaZ3GaS80H_12num_rational5RatioNtNtCs70jQWIuBJri_10num_bigint6bigint6BigIntEj5_ECs7wsLvUT6iAW_13codegen_audit:
	.cfi_startproc
	stp	x20, x19, [sp, #-32]!
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_remember_state
	mov	x19, x0
	ldr	x8, [x0]
	cmp	x8, #1
	b.lt	LBB2_2
	ldr	x0, [x19, #8]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB2_2:
	ldr	x8, [x19, #32]
	cmp	x8, #1
	b.lt	LBB2_4
	ldr	x0, [x19, #40]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB2_4:
	ldr	x8, [x19, #64]
	cmp	x8, #1
	b.lt	LBB2_6
	ldr	x0, [x19, #72]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB2_6:
	ldr	x8, [x19, #96]
	cmp	x8, #1
	b.lt	LBB2_8
	ldr	x0, [x19, #104]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB2_8:
	ldr	x8, [x19, #128]
	cmp	x8, #1
	b.lt	LBB2_10
	ldr	x0, [x19, #136]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB2_10:
	ldr	x8, [x19, #160]
	cmp	x8, #1
	b.lt	LBB2_12
	ldr	x0, [x19, #168]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB2_12:
	ldr	x8, [x19, #192]
	cmp	x8, #1
	b.lt	LBB2_14
	ldr	x0, [x19, #200]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB2_14:
	ldr	x8, [x19, #224]
	cmp	x8, #1
	b.lt	LBB2_16
	ldr	x0, [x19, #232]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB2_16:
	ldr	x8, [x19, #256]
	cmp	x8, #1
	b.lt	LBB2_18
	ldr	x0, [x19, #264]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB2_18:
	ldr	x8, [x19, #288]
	cmp	x8, #1
	b.lt	LBB2_20
	ldr	x0, [x19, #296]
	lsl	x1, x8, #3
	mov	w2, #8
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	ldp	x20, x19, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	b	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB2_20:
	.cfi_restore_state
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	ldp	x20, x19, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	ret
	.cfi_endproc

	.p2align	2
__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueANtNtCs70jQWIuBJri_10num_bigint6bigint6BigIntj5_ECs7wsLvUT6iAW_13codegen_audit:
	.cfi_startproc
	stp	x20, x19, [sp, #-32]!
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_remember_state
	mov	x19, x0
	ldr	x8, [x0]
	cmp	x8, #1
	b.lt	LBB3_2
	ldr	x0, [x19, #8]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB3_2:
	ldr	x8, [x19, #32]
	cmp	x8, #1
	b.lt	LBB3_4
	ldr	x0, [x19, #40]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB3_4:
	ldr	x8, [x19, #64]
	cmp	x8, #1
	b.lt	LBB3_6
	ldr	x0, [x19, #72]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB3_6:
	ldr	x8, [x19, #96]
	cmp	x8, #1
	b.lt	LBB3_8
	ldr	x0, [x19, #104]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB3_8:
	ldr	x8, [x19, #128]
	cmp	x8, #1
	b.lt	LBB3_10
	ldr	x0, [x19, #136]
	lsl	x1, x8, #3
	mov	w2, #8
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	ldp	x20, x19, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	b	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB3_10:
	.cfi_restore_state
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	ldp	x20, x19, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	ret
	.cfi_endproc

	.p2align	2
__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueINtCsjLaZ3GaS80H_12num_rational5RatioNtNtCs70jQWIuBJri_10num_bigint6bigint6BigIntEECs7wsLvUT6iAW_13codegen_audit:
	.cfi_startproc
	stp	x20, x19, [sp, #-32]!
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_remember_state
	mov	x19, x0
	ldr	x8, [x0]
	cmp	x8, #1
	b.lt	LBB4_2
	ldr	x0, [x19, #8]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB4_2:
	ldr	x8, [x19, #32]
	cmp	x8, #1
	b.lt	LBB4_4
	ldr	x0, [x19, #40]
	lsl	x1, x8, #3
	mov	w2, #8
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	ldp	x20, x19, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	b	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB4_4:
	.cfi_restore_state
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	ldp	x20, x19, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	ret
	.cfi_endproc

	.p2align	2
__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueINtNtB4_5array5GuardNtNtCs70jQWIuBJri_10num_bigint6bigint6BigIntEECs7wsLvUT6iAW_13codegen_audit:
	.cfi_startproc
	cbz	x1, LBB5_6
	stp	x20, x19, [sp, #-32]!
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x1
	add	x20, x0, #8
	b	LBB5_3
LBB5_2:
	add	x20, x20, #32
	subs	x19, x19, #1
	b.eq	LBB5_5
LBB5_3:
	ldur	x8, [x20, #-8]
	cmp	x8, #1
	b.lt	LBB5_2
	ldr	x0, [x20]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	b	LBB5_2
LBB5_5:
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	ldp	x20, x19, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
LBB5_6:
	ret
	.cfi_endproc

	.p2align	2
__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueSANtNtCs70jQWIuBJri_10num_bigint6bigint6BigIntj5_ECs7wsLvUT6iAW_13codegen_audit:
	.cfi_startproc
	stp	x20, x19, [sp, #-32]!
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x1
	add	x20, x0, #72
	b	LBB6_2
LBB6_1:
	add	x20, x20, #160
	subs	x19, x19, #1
	b.eq	LBB6_12
LBB6_2:
	ldur	x8, [x20, #-72]
	cmp	x8, #1
	b.lt	LBB6_4
	ldur	x0, [x20, #-64]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB6_4:
	ldur	x8, [x20, #-40]
	cmp	x8, #1
	b.lt	LBB6_6
	ldur	x0, [x20, #-32]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB6_6:
	ldur	x8, [x20, #-8]
	cmp	x8, #1
	b.lt	LBB6_8
	ldr	x0, [x20]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB6_8:
	ldr	x8, [x20, #24]
	cmp	x8, #1
	b.lt	LBB6_10
	ldr	x0, [x20, #32]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB6_10:
	ldr	x8, [x20, #56]
	cmp	x8, #1
	b.lt	LBB6_1
	ldr	x0, [x20, #64]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	b	LBB6_1
LBB6_12:
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	ldp	x20, x19, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	ret
	.cfi_endproc

	.p2align	2
__RINvNvMs2_NtCs6zY7rJBZy9D_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs7wsLvUT6iAW_13codegen_audit:
	.cfi_startproc
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	stp	x20, x19, [sp, #32]
	stp	x29, x30, [sp, #48]
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_remember_state
	adds	x8, x2, x1
	b.hs	LBB7_3
	mov	x19, x0
	ldp	x1, x2, [x0]
	lsl	x9, x1, #1
	cmp	x8, x9
	csel	x8, x8, x9, hi
	mov	w9, #4
	cmp	x8, #4
	csel	x20, x8, x9, hi
	add	x0, sp, #8
	mov	x3, x20
	bl	__RNvMs5_NtCs6zY7rJBZy9D_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs7wsLvUT6iAW_13codegen_audit
	ldr	x8, [sp, #8]
	cbnz	x8, LBB7_4
	ldr	x8, [sp, #16]
	stp	x20, x8, [x19]
	.cfi_def_cfa wsp, 64
	ldp	x29, x30, [sp, #48]
	ldp	x20, x19, [sp, #32]
	add	sp, sp, #64
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	ret
LBB7_3:
	.cfi_restore_state
	mov	x0, #0
	bl	__RNvNtCs6zY7rJBZy9D_5alloc7raw_vec12handle_error
LBB7_4:
	ldp	x0, x1, [sp, #16]
	bl	__RNvNtCs6zY7rJBZy9D_5alloc7raw_vec12handle_error
	.cfi_endproc

	.globl	__RNvCs7wsLvUT6iAW_13codegen_audit10exact_det5
	.p2align	6
__RNvCs7wsLvUT6iAW_13codegen_audit10exact_det5:
Lfunc_begin1:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception1
	stp	x28, x27, [sp, #-96]!
	.cfi_def_cfa_offset 96
	stp	x26, x25, [sp, #16]
	stp	x24, x23, [sp, #32]
	stp	x22, x21, [sp, #48]
	stp	x20, x19, [sp, #64]
	stp	x29, x30, [sp, #80]
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_remember_state
	sub	sp, sp, #2240
	ldr	xzr, [sp]
	str	x8, [sp]
	mov	x8, #0
	add	x25, sp, #2032
	add	x9, x0, #16
	add	x10, sp, #1232
	b	LBB8_5
LBB8_1:
	mov	w7, #0
	ldr	x22, [x9, #16]
	ubfx	x21, x22, #52, #11
	and	x20, x22, #0xfffffffffffff
	cbz	w21, LBB8_25
LBB8_2:
	orr	x20, x20, #0x10000000000000
	sub	w21, w21, #1075
LBB8_3:
	rbit	x23, x20
	clz	x23, x23
	lsr	x20, x20, x23
	add	w21, w21, w23
	lsr	x23, x22, #63
	mov	w22, #1
LBB8_4:
	add	x24, x10, x8
	strb	w14, [x24]
	add	x9, x9, #40
	strb	w13, [x24, #1]
	str	w12, [x24, #4]
	str	x11, [x24, #8]
	strb	w17, [x24, #16]
	strb	w0, [x24, #17]
	str	w16, [x24, #20]
	str	x15, [x24, #24]
	strb	w3, [x24, #32]
	strb	w4, [x24, #33]
	str	w2, [x24, #36]
	str	x1, [x24, #40]
	strb	w7, [x24, #48]
	strb	w19, [x24, #49]
	str	w6, [x24, #52]
	str	x5, [x24, #56]
	strb	w22, [x24, #64]
	strb	w23, [x24, #65]
	str	w21, [x24, #68]
	add	x8, x8, #80
	str	x20, [x24, #72]
	cmp	x8, #400
	b.eq	LBB8_28
LBB8_5:
	ldur	x13, [x9, #-16]
	ubfx	x12, x13, #52, #11
	and	x11, x13, #0xfffffffffffff
	cbz	w12, LBB8_7
	orr	x11, x11, #0x10000000000000
	sub	w12, w12, #1075
	b	LBB8_9
LBB8_7:
	cbz	x11, LBB8_11
	mov	w12, #-1074
LBB8_9:
	rbit	x14, x11
	clz	x14, x14
	lsr	x11, x11, x14
	add	w12, w12, w14
	lsr	x13, x13, #63
	mov	w14, #1
	ldur	x17, [x9, #-8]
	ubfx	x16, x17, #52, #11
	and	x15, x17, #0xfffffffffffff
	cbz	w16, LBB8_12
LBB8_10:
	orr	x15, x15, #0x10000000000000
	sub	w16, w16, #1075
	b	LBB8_14
LBB8_11:
	mov	w14, #0
	ldur	x17, [x9, #-8]
	ubfx	x16, x17, #52, #11
	and	x15, x17, #0xfffffffffffff
	cbnz	w16, LBB8_10
LBB8_12:
	cbz	x15, LBB8_16
	mov	w16, #-1074
LBB8_14:
	rbit	x0, x15
	clz	x0, x0
	lsr	x15, x15, x0
	add	w16, w16, w0
	lsr	x0, x17, #63
	mov	w17, #1
	ldr	x3, [x9]
	ubfx	x2, x3, #52, #11
	and	x1, x3, #0xfffffffffffff
	cbz	w2, LBB8_17
LBB8_15:
	orr	x1, x1, #0x10000000000000
	sub	w2, w2, #1075
	b	LBB8_19
LBB8_16:
	mov	w17, #0
	ldr	x3, [x9]
	ubfx	x2, x3, #52, #11
	and	x1, x3, #0xfffffffffffff
	cbnz	w2, LBB8_15
LBB8_17:
	cbz	x1, LBB8_21
	mov	w2, #-1074
LBB8_19:
	rbit	x4, x1
	clz	x4, x4
	lsr	x1, x1, x4
	add	w2, w2, w4
	lsr	x4, x3, #63
	mov	w3, #1
	ldr	x7, [x9, #8]
	ubfx	x6, x7, #52, #11
	and	x5, x7, #0xfffffffffffff
	cbz	w6, LBB8_22
LBB8_20:
	orr	x5, x5, #0x10000000000000
	sub	w6, w6, #1075
	b	LBB8_24
LBB8_21:
	mov	w3, #0
	ldr	x7, [x9, #8]
	ubfx	x6, x7, #52, #11
	and	x5, x7, #0xfffffffffffff
	cbnz	w6, LBB8_20
LBB8_22:
	cbz	x5, LBB8_1
	mov	w6, #-1074
LBB8_24:
	rbit	x19, x5
	clz	x19, x19
	lsr	x5, x5, x19
	add	w6, w6, w19
	lsr	x19, x7, #63
	mov	w7, #1
	ldr	x22, [x9, #16]
	ubfx	x21, x22, #52, #11
	and	x20, x22, #0xfffffffffffff
	cbnz	w21, LBB8_2
LBB8_25:
	cbz	x20, LBB8_27
	mov	w21, #-1074
	b	LBB8_3
LBB8_27:
	mov	w22, #0
	b	LBB8_4
LBB8_28:
	add	x20, sp, #416
	add	x19, x20, #80
	add	x0, sp, #416
	add	x1, sp, #1232
	mov	w2, #400
	bl	_memcpy
	add	x8, x20, #16
	ldrb	w9, [sp, #416]
	tbz	w9, #0, LBB8_30
	mov	w9, #0
	mov	w10, #80
	mov	x11, x19
	add	x19, sp, #416
	b	LBB8_50
LBB8_30:
	add	x12, x20, #32
	ldrb	w9, [sp, #432]
	tbz	w9, #0, LBB8_32
	mov	w9, #0
	mov	w10, #80
	mov	x11, x19
	mov	x19, x8
	mov	x8, x12
	b	LBB8_50
LBB8_32:
	add	x10, sp, #416
	add	x8, x10, #48
	ldrb	w9, [sp, #448]
	tbz	w9, #0, LBB8_35
	mov	w9, #0
	mov	w10, #80
LBB8_34:
	mov	x11, x19
	mov	x19, x12
	b	LBB8_50
LBB8_35:
	ldrb	w9, [sp, #464]
	tbz	w9, #0, LBB8_37
	mov	w9, #0
	mov	x11, x19
	mov	x19, x8
	add	x8, x10, #64
	mov	w10, #80
	b	LBB8_50
LBB8_37:
	ldrb	w9, [sp, #480]
	add	x8, sp, #416
	tbz	w9, #0, LBB8_40
	mov	w9, #0
	mov	w10, #80
	add	x19, sp, #416
LBB8_39:
	ldr	w20, [x19, #68]
	b	LBB8_53
LBB8_40:
	add	x12, x20, #160
	add	x8, x8, #96
	ldrb	w9, [sp, #496]
	tbz	w9, #0, LBB8_42
LBB8_41:
	mov	w9, #65456
	mov	w10, #160
	mov	x11, x12
	b	LBB8_50
LBB8_42:
	add	x9, sp, #416
	add	x13, x9, #112
	ldrb	w10, [sp, #512]
	tbz	w10, #0, LBB8_46
	mov	w9, #65456
	mov	w10, #160
LBB8_44:
	mov	x11, x12
LBB8_45:
	mov	x19, x8
	mov	x8, x13
	b	LBB8_50
LBB8_46:
	add	x8, x9, #128
	ldrb	w9, [sp, #528]
	tbz	w9, #0, LBB8_114
	mov	w9, #65456
	mov	w10, #160
LBB8_48:
	mov	x11, x12
LBB8_49:
	mov	x19, x13
LBB8_50:
	ldr	w20, [x19, #4]
	sub	x11, x11, x8
	lsr	x11, x11, #4
	add	x8, x8, #4
LBB8_51:
	ldurb	w12, [x8, #-4]
	ldr	w13, [x8], #16
	.p2align	6, , 4
	cmp	w20, w13
	csel	w13, w20, w13, lt
	tst	w12, #0x1
	csel	w20, w13, w20, ne
	subs	x11, x11, #1
	b.ne	LBB8_51
LBB8_53:
	cmp	x10, #400
	b.eq	LBB8_61
	add	w8, w9, #320
	and	w8, w8, #0xffff
	mov	w9, #52429
	mul	w8, w8, w9
	lsr	w8, w8, #22
	add	x9, sp, #416
	add	x9, x10, x9
	add	x9, x9, #36
LBB8_55:
	ldurb	w10, [x9, #-36]
	ldur	w11, [x9, #-32]
	.p2align	6, , 4
	cmp	w20, w11
	csel	w11, w20, w11, lt
	tst	w10, #0x1
	csel	w10, w11, w20, ne
	ldurb	w11, [x9, #-20]
	ldur	w12, [x9, #-16]
	.p2align	6, , 4
	cmp	w10, w12
	csel	w12, w10, w12, lt
	tst	w11, #0x1
	csel	w10, w12, w10, ne
	ldurb	w11, [x9, #-4]
	ldr	w12, [x9]
	.p2align	6, , 4
	cmp	w10, w12
	csel	w12, w10, w12, lt
	tst	w11, #0x1
	csel	w10, w12, w10, ne
	ldrb	w11, [x9, #12]
	ldr	w12, [x9, #16]
	.p2align	6, , 4
	cmp	w10, w12
	csel	w12, w10, w12, lt
	tst	w11, #0x1
	csel	w10, w12, w10, ne
	ldrb	w11, [x9, #28]
	ldr	w12, [x9, #32]
	.p2align	6, , 4
	cmp	w10, w12
	csel	w12, w10, w12, lt
	tst	w11, #0x1
	csel	w20, w12, w10, ne
	add	x9, x9, #80
	subs	x8, x8, #1
	b.ne	LBB8_55
LBB8_61:
	add	x22, sp, #8
	add	x0, x22, #8
	add	x1, sp, #1232
	mov	w2, #400
	bl	_memcpy
	mov	x27, #0
	mov	x21, #0
	mov	w19, #1
	stp	w19, w20, [sp, #8]
	add	x24, sp, #416
	add	x26, sp, #1232
	b	LBB8_64
LBB8_62:
	stur	xzr, [x29, #-112]
Lloh0:
	adrp	x8, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.0@PAGE
Lloh1:
	add	x8, x8, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.0@PAGEOFF
Lloh2:
	ldr	q0, [x8]
	str	q0, [x25, #160]
	mov	w8, #1
LBB8_63:
	ldr	q0, [x25, #160]
	ldur	x9, [x29, #-112]
	str	x9, [sp, #2048]
	stur	q0, [x24, #128]
	stur	x9, [x24, #144]
	strb	w8, [sp, #568]
	stur	wzr, [x24, #153]
	stur	wzr, [x24, #156]
	add	x8, sp, #416
	ldp	q1, q2, [x8, #128]
	stp	q1, q2, [x25, #128]
	ldp	q1, q2, [x8, #64]
	stp	q1, q2, [x25, #64]
	ldp	q2, q3, [x8, #96]
	stp	q2, q3, [x25, #96]
	ldp	q2, q3, [x8]
	stp	q0, q3, [x25]
	ldp	q0, q3, [x8, #32]
	stp	q0, q3, [x25, #32]
	ldp	q3, q0, [x25, #128]
	stp	q3, q0, [x26, #128]
	ldr	q0, [x25, #80]
	ldp	q3, q4, [x25, #96]
	stp	q1, q0, [x26, #64]
	stp	q3, q4, [x26, #96]
	ldp	q0, q1, [x25, #16]
	stp	q2, q0, [x26]
	ldr	q0, [x25, #48]
	add	x21, x21, #1
	stp	q1, q0, [x26, #32]
	add	x27, x27, #80
	add	x26, x26, #160
	str	q2, [x25]
	cmp	x27, #400
	b.eq	LBB8_103
LBB8_64:
	add	x8, x22, x27
	ldrb	w9, [x8, #8]
	tbz	w9, #0, LBB8_69
	ldr	x28, [x8, #16]
	ldr	w1, [x8, #12]
	ldrb	w23, [x8, #9]
Ltmp27:
	mov	x22, #0
	mov	x0, x20
	bl	__RNvMs1_NtNtCshzmyaYQzAhy_8la_stack5exact13decompositionNtB5_13ScaleExponent9shift_for
Ltmp28:
	mov	x9, x0
	lsr	w1, w0, #6
	mov	x8, #-1
	str	x8, [sp, #2032]
	str	x19, [sp, #2040]
	str	x28, [sp, #2048]
Ltmp29:
	mov	x22, #0
	sub	x8, x29, #128
	add	x0, sp, #2032
	and	w2, w9, #0x3f
	bl	__RNvNtNtCs70jQWIuBJri_10num_bigint7biguint5shift12biguint_shl2
Ltmp30:
	ldur	x8, [x29, #-128]
	cmn	x8, #1
	b.eq	LBB8_70
	ldur	x8, [x29, #-112]
	cmp	x8, #0
	cset	w8, eq
	b	LBB8_71
LBB8_69:
	stur	xzr, [x29, #-112]
Lloh3:
	adrp	x8, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.0@PAGE
Lloh4:
	add	x8, x8, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.0@PAGEOFF
Lloh5:
	ldr	q0, [x8]
	str	q0, [x25, #160]
	mov	w8, #1
	b	LBB8_72
LBB8_70:
	ldur	w8, [x29, #-120]
	eor	w8, w8, #0x1
LBB8_71:
	add	x22, sp, #8
	cmp	w8, #0
	cinc	w9, w19, eq
	tst	w23, #0x1
	csel	w8, w8, w9, ne
LBB8_72:
	ldr	q0, [x25, #160]
	str	q0, [x25]
	ldur	x9, [x29, #-112]
	str	x9, [sp, #2048]
	add	x10, sp, #416
	str	q0, [x10]
	str	x9, [sp, #432]
	strb	w8, [sp, #440]
	stur	wzr, [x24, #25]
	stur	wzr, [x24, #28]
	add	x8, x22, x27
	ldrb	w9, [x8, #24]
	tbz	w9, #0, LBB8_77
	ldr	x28, [x8, #32]
	ldr	w1, [x8, #28]
	ldrb	w23, [x8, #25]
Ltmp31:
	mov	w22, #1
	mov	x0, x20
	bl	__RNvMs1_NtNtCshzmyaYQzAhy_8la_stack5exact13decompositionNtB5_13ScaleExponent9shift_for
Ltmp32:
	mov	x9, x0
	lsr	w1, w0, #6
	mov	x8, #-1
	str	x8, [sp, #2032]
	str	x19, [sp, #2040]
	str	x28, [sp, #2048]
Ltmp33:
	sub	x8, x29, #128
	add	x0, sp, #2032
	and	w2, w9, #0x3f
	mov	w22, #1
	bl	__RNvNtNtCs70jQWIuBJri_10num_bigint7biguint5shift12biguint_shl2
Ltmp34:
	ldur	x8, [x29, #-128]
	cmn	x8, #1
	b.eq	LBB8_78
	ldur	x8, [x29, #-112]
	cmp	x8, #0
	cset	w8, eq
	b	LBB8_79
LBB8_77:
	stur	xzr, [x29, #-112]
Lloh6:
	adrp	x8, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.0@PAGE
Lloh7:
	add	x8, x8, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.0@PAGEOFF
Lloh8:
	ldr	q0, [x8]
	str	q0, [x25, #160]
	mov	w8, #1
	b	LBB8_80
LBB8_78:
	ldur	w8, [x29, #-120]
	eor	w8, w8, #0x1
LBB8_79:
	add	x22, sp, #8
	cmp	w8, #0
	cinc	w9, w19, eq
	tst	w23, #0x1
	csel	w8, w8, w9, ne
LBB8_80:
	ldr	q0, [x25, #160]
	str	q0, [x25]
	ldur	x9, [x29, #-112]
	str	x9, [sp, #2048]
	stur	q0, [x24, #32]
	stur	x9, [x24, #48]
	strb	w8, [sp, #472]
	stur	wzr, [x24, #57]
	stur	wzr, [x24, #60]
	add	x8, x22, x27
	ldrb	w9, [x8, #40]
	tbz	w9, #0, LBB8_85
	ldr	x28, [x8, #48]
	ldr	w1, [x8, #44]
	ldrb	w23, [x8, #41]
Ltmp35:
	mov	w22, #2
	mov	x0, x20
	bl	__RNvMs1_NtNtCshzmyaYQzAhy_8la_stack5exact13decompositionNtB5_13ScaleExponent9shift_for
Ltmp36:
	mov	x9, x0
	lsr	w1, w0, #6
	mov	x8, #-1
	str	x8, [sp, #2032]
	str	x19, [sp, #2040]
	str	x28, [sp, #2048]
Ltmp37:
	sub	x8, x29, #128
	add	x0, sp, #2032
	and	w2, w9, #0x3f
	mov	w22, #2
	bl	__RNvNtNtCs70jQWIuBJri_10num_bigint7biguint5shift12biguint_shl2
Ltmp38:
	ldur	x8, [x29, #-128]
	cmn	x8, #1
	b.eq	LBB8_86
	ldur	x8, [x29, #-112]
	cmp	x8, #0
	cset	w8, eq
	b	LBB8_87
LBB8_85:
	stur	xzr, [x29, #-112]
Lloh9:
	adrp	x8, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.0@PAGE
Lloh10:
	add	x8, x8, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.0@PAGEOFF
Lloh11:
	ldr	q0, [x8]
	str	q0, [x25, #160]
	mov	w8, #1
	b	LBB8_88
LBB8_86:
	ldur	w8, [x29, #-120]
	eor	w8, w8, #0x1
LBB8_87:
	add	x22, sp, #8
	cmp	w8, #0
	cinc	w9, w19, eq
	tst	w23, #0x1
	csel	w8, w8, w9, ne
LBB8_88:
	ldr	q0, [x25, #160]
	str	q0, [x25]
	ldur	x9, [x29, #-112]
	str	x9, [sp, #2048]
	stur	q0, [x24, #64]
	stur	x9, [x24, #80]
	strb	w8, [sp, #504]
	stur	wzr, [x24, #89]
	stur	wzr, [x24, #92]
	add	x8, x22, x27
	ldrb	w9, [x8, #56]
	tbz	w9, #0, LBB8_93
	ldr	x28, [x8, #64]
	ldr	w1, [x8, #60]
	ldrb	w23, [x8, #57]
Ltmp39:
	mov	w22, #3
	mov	x0, x20
	bl	__RNvMs1_NtNtCshzmyaYQzAhy_8la_stack5exact13decompositionNtB5_13ScaleExponent9shift_for
Ltmp40:
	mov	x9, x0
	lsr	w1, w0, #6
	mov	x8, #-1
	str	x8, [sp, #2032]
	str	x19, [sp, #2040]
	str	x28, [sp, #2048]
Ltmp41:
	sub	x8, x29, #128
	add	x0, sp, #2032
	and	w2, w9, #0x3f
	mov	w22, #3
	bl	__RNvNtNtCs70jQWIuBJri_10num_bigint7biguint5shift12biguint_shl2
Ltmp42:
	ldur	x8, [x29, #-128]
	cmn	x8, #1
	b.eq	LBB8_94
	ldur	x8, [x29, #-112]
	cmp	x8, #0
	cset	w8, eq
	b	LBB8_95
LBB8_93:
	stur	xzr, [x29, #-112]
Lloh12:
	adrp	x8, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.0@PAGE
Lloh13:
	add	x8, x8, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.0@PAGEOFF
Lloh14:
	ldr	q0, [x8]
	str	q0, [x25, #160]
	mov	w8, #1
	b	LBB8_96
LBB8_94:
	ldur	w8, [x29, #-120]
	eor	w8, w8, #0x1
LBB8_95:
	add	x22, sp, #8
	cmp	w8, #0
	cinc	w9, w19, eq
	tst	w23, #0x1
	csel	w8, w8, w9, ne
LBB8_96:
	ldr	q0, [x25, #160]
	str	q0, [x25]
	ldur	x9, [x29, #-112]
	str	x9, [sp, #2048]
	stur	q0, [x24, #96]
	stur	x9, [x24, #112]
	strb	w8, [sp, #536]
	stur	wzr, [x24, #121]
	stur	wzr, [x24, #124]
	add	x8, x22, x27
	ldrb	w9, [x8, #72]
	tbz	w9, #0, LBB8_62
	ldr	x28, [x8, #80]
	ldr	w1, [x8, #76]
	ldrb	w23, [x8, #73]
Ltmp43:
	mov	w22, #4
	mov	x0, x20
	bl	__RNvMs1_NtNtCshzmyaYQzAhy_8la_stack5exact13decompositionNtB5_13ScaleExponent9shift_for
Ltmp44:
	mov	x9, x0
	lsr	w1, w0, #6
	mov	x8, #-1
	str	x8, [sp, #2032]
	str	x19, [sp, #2040]
	str	x28, [sp, #2048]
Ltmp45:
	sub	x8, x29, #128
	add	x0, sp, #2032
	and	w2, w9, #0x3f
	mov	w22, #4
	bl	__RNvNtNtCs70jQWIuBJri_10num_bigint7biguint5shift12biguint_shl2
Ltmp46:
	ldur	x8, [x29, #-128]
	cmn	x8, #1
	b.eq	LBB8_101
	ldur	x8, [x29, #-112]
	cmp	x8, #0
	cset	w8, eq
	b	LBB8_102
LBB8_101:
	ldur	w8, [x29, #-120]
	eor	w8, w8, #0x1
LBB8_102:
	add	x22, sp, #8
	cmp	w8, #0
	cinc	w9, w19, eq
	tst	w23, #0x1
	csel	w8, w8, w9, ne
	b	LBB8_63
LBB8_103:
	add	x0, sp, #416
	add	x1, sp, #1232
	mov	w2, #800
	bl	_memcpy
Ltmp48:
	add	x0, sp, #1232
	add	x1, sp, #416
	mov	x2, #0
	bl	__RINvNtCshzmyaYQzAhy_8la_stack5exact25bareiss_forward_eliminateKj5_ECs7wsLvUT6iAW_13codegen_audit
Ltmp49:
	ldrb	w8, [sp, #1232]
	add	x23, sp, #1224
	tbnz	w8, #0, LBB8_120
	ldrb	w8, [sp, #1233]
	ldr	x19, [sp, #1184]
	ldr	x21, [sp, #1192]
	ldr	x22, [sp, #1200]
	ldrb	w9, [sp, #1208]
	add	x10, sp, #416
	add	x10, x10, #793
	ldr	w11, [sp, #1212]
	stur	w11, [x23, #3]
	ldr	w10, [x10]
	str	w10, [sp, #1224]
Lloh15:
	adrp	x10, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.0@PAGE
Lloh16:
	add	x10, x10, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.0@PAGEOFF
	ldp	q0, q1, [x10]
	add	x10, sp, #416
	stp	q0, q1, [x10, #768]
	mov	w10, #2
	sub	w10, w10, w9
	.p2align	6, , 4
	cmp	w8, #0
	csel	w24, w10, w9, ne
LBB8_107:
	add	x0, sp, #416
	mov	w1, #5
	bl	__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueSANtNtCs70jQWIuBJri_10num_bigint6bigint6BigIntj5_ECs7wsLvUT6iAW_13codegen_audit
	ldr	w8, [sp, #1224]
	str	w8, [sp, #1232]
	ldur	w8, [x23, #3]
	stur	w8, [x23, #11]
	and	w8, w24, #0xff
	cmp	w8, #1
	b.ne	LBB8_110
	mov	w1, #0
	mov	w24, #1
LBB8_109:
	add	x8, sp, #1232
	b	LBB8_112
LBB8_110:
	sxtw	x8, w20
	add	x1, x8, w20, sxtw #2
	cmp	x1, w1, sxtw
	b.ne	LBB8_123
	add	x8, sp, #1224
LBB8_112:
	ldr	w9, [x8]
	str	w9, [sp, #416]
	ldur	w8, [x8, #3]
	add	x9, sp, #416
	stur	w8, [x9, #3]
	str	x19, [sp, #1232]
	str	x21, [sp, #1240]
	str	x22, [sp, #1248]
	strb	w24, [sp, #1256]
	ldr	w8, [sp, #416]
	stur	w8, [x23, #33]
	ldur	w8, [x9, #3]
	str	w8, [sp, #1260]
	add	x0, sp, #1232
	ldr	x8, [sp]
	bl	__RNvNtCshzmyaYQzAhy_8la_stack5exact27big_int_exp_to_big_rational
LBB8_113:
	add	sp, sp, #2240
	.cfi_def_cfa wsp, 96
	ldp	x29, x30, [sp, #80]
	ldp	x20, x19, [sp, #64]
	ldp	x22, x21, [sp, #48]
	ldp	x24, x23, [sp, #32]
	ldp	x26, x25, [sp, #16]
	ldp	x28, x27, [sp], #96
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	ret
LBB8_114:
	.cfi_restore_state
	ldrb	w9, [sp, #544]
	tbz	w9, #0, LBB8_116
	add	x9, sp, #416
	mov	x19, x8
	add	x8, x9, #144
	b	LBB8_41
LBB8_116:
	ldrb	w8, [sp, #560]
	tbz	w8, #0, LBB8_118
	mov	w9, #65456
	mov	w10, #160
	b	LBB8_39
LBB8_118:
	add	x19, x20, #240
	add	x9, sp, #416
	add	x8, x9, #176
	ldrb	w10, [sp, #576]
	tbz	w10, #0, LBB8_121
	mov	w9, #65376
	mov	w10, #240
	b	LBB8_34
LBB8_120:
	mov	x21, #0
	stur	wzr, [x23, #3]
	str	wzr, [sp, #1224]
	mov	w24, #1
	mov	x19, #-1
	b	LBB8_107
LBB8_121:
	add	x13, x9, #192
	ldrb	w9, [sp, #592]
	tbz	w9, #0, LBB8_126
	mov	w9, #65376
	mov	w10, #240
	mov	x11, x19
	b	LBB8_45
LBB8_123:
	sub	x8, x19, #1
	cmn	x8, #3
	b.hi	LBB8_125
	lsl	x1, x19, #3
	mov	x0, x21
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB8_125:
	ldr	w8, [sp, #416]
	ldr	x9, [sp]
	stur	w8, [x9, #41]
	add	x8, sp, #416
	ldur	w8, [x8, #3]
	str	w8, [x9, #44]
	mov	w8, #5
	strb	w8, [x9, #8]
	str	w20, [x9, #12]
	str	x8, [x9, #16]
	mov	x8, #-2
	str	x8, [x9]
	b	LBB8_113
LBB8_126:
	add	x9, sp, #416
	add	x8, x9, #208
	ldrb	w10, [sp, #608]
	tbz	w10, #0, LBB8_128
	mov	w9, #65376
	mov	w10, #240
	mov	x11, x19
	b	LBB8_49
LBB8_128:
	ldrb	w10, [sp, #624]
	tbz	w10, #0, LBB8_130
	mov	x11, x19
	mov	x19, x8
	add	x8, x9, #224
	mov	w9, #65376
	mov	w10, #240
	b	LBB8_50
LBB8_130:
	ldrb	w8, [sp, #640]
	tbz	w8, #0, LBB8_133
	mov	w9, #65376
	mov	w10, #240
LBB8_132:
	mov	x19, x12
	b	LBB8_39
LBB8_133:
	add	x12, x20, #320
	add	x9, sp, #416
	add	x8, x9, #256
	ldrb	w10, [sp, #656]
	tbz	w10, #0, LBB8_135
LBB8_134:
	mov	w9, #65296
	mov	w10, #320
	mov	x11, x12
	b	LBB8_50
LBB8_135:
	add	x13, x9, #272
	ldrb	w9, [sp, #672]
	tbz	w9, #0, LBB8_137
	mov	w9, #65296
	mov	w10, #320
	b	LBB8_44
LBB8_137:
	add	x9, sp, #416
	add	x8, x9, #288
	ldrb	w10, [sp, #688]
	tbz	w10, #0, LBB8_139
	mov	w9, #65296
	mov	w10, #320
	b	LBB8_48
LBB8_139:
	ldrb	w10, [sp, #704]
	tbz	w10, #0, LBB8_141
	mov	x19, x8
	add	x8, x9, #304
	b	LBB8_134
LBB8_141:
	ldrb	w8, [sp, #720]
	tbz	w8, #0, LBB8_143
	mov	w9, #65296
	mov	w10, #320
	b	LBB8_39
LBB8_143:
	add	x11, x20, #400
	add	x9, sp, #416
	add	x8, x9, #336
	ldrb	w10, [sp, #736]
	tbz	w10, #0, LBB8_145
	mov	w9, #65216
	mov	w10, #400
	mov	x19, x12
	b	LBB8_50
LBB8_145:
	add	x13, x9, #352
	ldrb	w9, [sp, #752]
	tbz	w9, #0, LBB8_147
	mov	w9, #65216
	mov	w10, #400
	b	LBB8_45
LBB8_147:
	add	x9, sp, #416
	add	x8, x9, #368
	ldrb	w10, [sp, #768]
	tbz	w10, #0, LBB8_149
	mov	w9, #65216
	mov	w10, #400
	b	LBB8_49
LBB8_149:
	ldrb	w10, [sp, #784]
	tbz	w10, #0, LBB8_151
	mov	x19, x8
	add	x8, x9, #384
	mov	w9, #65216
	mov	w10, #400
	b	LBB8_50
LBB8_151:
	ldrb	w8, [sp, #800]
	tbz	w8, #0, LBB8_153
	mov	w9, #65216
	mov	w10, #400
	b	LBB8_132
LBB8_153:
	mov	w1, #0
	mov	x21, #0
	add	x23, sp, #1224
	stur	wzr, [x23, #11]
	str	wzr, [sp, #1232]
	mov	x19, #-1
	mov	w24, #1
	b	LBB8_109
LBB8_154:
Ltmp50:
	mov	x19, x0
	add	x0, sp, #416
	mov	w1, #5
	b	LBB8_157
LBB8_155:
Ltmp47:
	mov	x19, x0
	add	x0, sp, #416
	mov	x1, x22
	bl	__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueINtNtB4_5array5GuardNtNtCs70jQWIuBJri_10num_bigint6bigint6BigIntEECs7wsLvUT6iAW_13codegen_audit
	cbz	x27, LBB8_158
	add	x0, sp, #1232
	mov	x1, x21
LBB8_157:
	bl	__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueSANtNtCs70jQWIuBJri_10num_bigint6bigint6BigIntj5_ECs7wsLvUT6iAW_13codegen_audit
LBB8_158:
	mov	x0, x19
	bl	__Unwind_Resume
	.loh AdrpAddLdr	Lloh0, Lloh1, Lloh2
	.loh AdrpAddLdr	Lloh3, Lloh4, Lloh5
	.loh AdrpAddLdr	Lloh6, Lloh7, Lloh8
	.loh AdrpAddLdr	Lloh9, Lloh10, Lloh11
	.loh AdrpAddLdr	Lloh12, Lloh13, Lloh14
	.loh AdrpAdd	Lloh15, Lloh16
Lfunc_end1:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table8:
Lexception1:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 Lcst_end1-Lcst_begin1
Lcst_begin1:
	.uleb128 Lfunc_begin1-Lfunc_begin1
	.uleb128 Ltmp27-Lfunc_begin1
	.byte	0
	.byte	0
	.uleb128 Ltmp27-Lfunc_begin1
	.uleb128 Ltmp46-Ltmp27
	.uleb128 Ltmp47-Lfunc_begin1
	.byte	0
	.uleb128 Ltmp46-Lfunc_begin1
	.uleb128 Ltmp48-Ltmp46
	.byte	0
	.byte	0
	.uleb128 Ltmp48-Lfunc_begin1
	.uleb128 Ltmp49-Ltmp48
	.uleb128 Ltmp50-Lfunc_begin1
	.byte	0
	.uleb128 Ltmp49-Lfunc_begin1
	.uleb128 Lfunc_end1-Ltmp49
	.byte	0
	.byte	0
Lcst_end1:
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.globl	__RNvCs7wsLvUT6iAW_13codegen_audit11ldlt_solve4
	.p2align	2
__RNvCs7wsLvUT6iAW_13codegen_audit11ldlt_solve4:
	.cfi_startproc
	sub	sp, sp, #288
	.cfi_def_cfa_offset 288
	stp	d9, d8, [sp, #192]
	stp	x28, x27, [sp, #208]
	stp	x24, x23, [sp, #224]
	stp	x22, x21, [sp, #240]
	stp	x20, x19, [sp, #256]
	stp	x29, x30, [sp, #272]
	add	x29, sp, #272
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	.cfi_offset b8, -88
	.cfi_offset b9, -96
	.cfi_remember_state
	ldr	d1, [x0, #8]
	ldr	d0, [x0, #32]
	fcmp	d1, d0
	b.ne	LBB9_75
	ldr	d2, [x0, #16]
	ldr	d3, [x0, #64]
	fcmp	d2, d3
	b.ne	LBB9_76
	ldr	d3, [x0, #24]
	ldr	d4, [x0, #96]
	fcmp	d3, d4
	b.ne	LBB9_77
	ldr	d4, [x0, #48]
	ldr	d5, [x0, #72]
	fcmp	d4, d5
	b.ne	LBB9_78
	mov	x9, x0
	ldr	d5, [x9, #56]!
	ldr	d6, [x9, #48]
	fcmp	d5, d6
	b.ne	LBB9_79
	ldr	d5, [x0, #88]
	ldr	d6, [x0, #112]
	fcmp	d5, d6
	b.ne	LBB9_80
	mov	x19, #0
	mov	w22, #0
	ldrb	w10, [x0]
	ldr	w11, [x0, #4]
	str	w11, [sp, #12]
	ldur	w11, [x0, #1]
	stur	w11, [sp, #9]
	ldp	q5, q6, [x9]
	stp	q5, q6, [sp, #64]
	ldp	q5, q6, [x9, #32]
	stp	q5, q6, [sp, #96]
	ldr	d5, [x0, #40]
	ldr	x9, [x9, #64]
	str	x9, [sp, #128]
	strb	w10, [sp, #8]
	add	x20, sp, #8
	stp	d1, d2, [sp, #16]
	stp	d3, d0, [sp, #32]
	stp	d5, d4, [sp, #48]
	ldr	d2, [sp, #8]
	fmov	x9, d2
	fabs	d6, d2
	ubfx	x9, x9, #52, #11
	cmp	x9, #2047
	cset	w9, lo
	mov	w23, #1
	mov	x10, #59921
	movk	x10, #33069, lsl #16
	movk	x10, #38809, lsl #32
	movk	x10, #15729, lsl #48
	fmov	d1, x10
	fcmp	d2, d1
	b.le	LBB9_31
	tbz	w9, #0, LBB9_31
	fdiv	d0, d0, d2
	fmov	x9, d0
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB9_50
	str	d0, [sp, #40]
	ldr	d1, [sp, #72]
	fdiv	d1, d1, d2
	fmov	x9, d1
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB9_51
	str	d1, [sp, #72]
	ldr	d3, [sp, #104]
	fdiv	d3, d3, d2
	fmov	x9, d3
	ubfx	x9, x9, #52, #11
	cmp	x9, #2047
	b.hs	LBB9_52
	fnmul	d4, d2, d0
	fmadd	d8, d4, d0, d5
	fmov	x9, d8
	fnmul	d5, d2, d1
	ldp	d4, d6, [sp, #80]
	fmadd	d4, d5, d0, d4
	str	d8, [sp, #48]
	fmadd	d6, d5, d1, d6
	stp	d4, d6, [sp, #80]
	fnmul	d7, d2, d3
	ldp	d5, d16, [sp, #112]
	fmadd	d5, d7, d0, d5
	fmadd	d16, d7, d1, d16
	stp	d3, d5, [sp, #104]
	ldr	d17, [sp, #128]
	fmadd	d17, d7, d3, d17
	stp	d16, d17, [sp, #120]
	ubfx	x9, x9, #52, #11
	cmp	x9, #2047
	cset	w9, lo
	fmov	d7, x10
	fcmp	d8, d7
	ccmp	w9, #0, #4, gt
	b.eq	LBB9_32
	fdiv	d4, d4, d8
	fmov	x9, d4
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB9_53
	str	d4, [sp, #80]
	fdiv	d5, d5, d8
	fmov	x9, d5
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB9_54
	fnmul	d7, d8, d4
	fmadd	d7, d7, d4, d6
	fmov	x9, d7
	str	d7, [sp, #88]
	fnmul	d6, d8, d5
	fmadd	d16, d6, d4, d16
	fmadd	d6, d6, d5, d17
	stp	d5, d16, [sp, #112]
	str	d6, [sp, #128]
	ubfx	x9, x9, #52, #11
	cmp	x9, #2047
	cset	w9, lo
	fmov	d17, x10
	fcmp	d7, d17
	ccmp	w9, #0, #4, gt
	b.eq	LBB9_33
	fdiv	d16, d16, d7
	fmov	x9, d16
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB9_55
	add	x20, x20, #24
	fnmul	d17, d7, d16
	fmadd	d17, d17, d16, d6
	fmov	x9, d17
	stp	d16, d17, [sp, #120]
	fabs	d6, d17
	ubfx	x9, x9, #52, #11
	cmp	x9, #2047
	cset	w9, lo
	mov	w22, #1
	mov	w23, #4
	mov	w19, #3
	fmov	d18, x10
	fcmp	d17, d18
	b.le	LBB9_34
	tbz	w9, #0, LBB9_34
	ldr	d6, [x1]
	fmov	x9, d6
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB9_43
	ldr	d18, [x1, #8]
	fmsub	d18, d0, d6, d18
	fmov	x9, d18
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB9_44
	ldr	d19, [x1, #16]
	fmsub	d19, d1, d6, d19
	fmsub	d19, d4, d18, d19
	fmov	x9, d19
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB9_45
	ldr	d20, [x1, #24]
	fmsub	d20, d3, d6, d20
	fmsub	d20, d5, d18, d20
	fmsub	d20, d16, d19, d20
	fmov	x9, d20
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB9_46
	fdiv	d2, d6, d2
	fmov	x9, d2
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB9_43
	fdiv	d18, d18, d8
	fmov	x9, d18
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB9_44
	fdiv	d7, d19, d7
	fmov	x9, d7
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB9_45
	fdiv	d6, d20, d17
	fmov	x9, d6
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB9_46
	fmsub	d7, d16, d6, d7
	fmov	x10, d7
	mov	w9, #2
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.hi	LBB9_57
	fmsub	d4, d4, d7, d18
	fmsub	d4, d5, d6, d4
	fmov	x10, d4
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.hi	LBB9_58
	fmsub	d0, d0, d4, d2
	fmsub	d0, d1, d7, d0
	fmsub	d0, d3, d6, d0
	fmov	x10, d0
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.hi	LBB9_59
	stp	d0, d4, [x8, #8]
	stp	d7, d6, [x8, #24]
	mov	w9, #255
	strb	w9, [x8]
LBB9_30:
	.cfi_def_cfa wsp, 288
	ldp	x29, x30, [sp, #272]
	ldp	x20, x19, [sp, #256]
	ldp	x22, x21, [sp, #240]
	ldp	x24, x23, [sp, #224]
	ldp	x28, x27, [sp, #208]
	ldp	d9, d8, [sp, #192]
	add	sp, sp, #288
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore b8
	.cfi_restore b9
	ret
LBB9_31:
	.cfi_restore_state
	mov.16b	v8, v2
	b	LBB9_35
LBB9_32:
	mov	w22, #0
	add	x20, x20, #8
	fabs	d6, d8
	mov	w23, #2
	mov	w19, #1
	b	LBB9_35
LBB9_33:
	mov	w22, #0
	add	x20, x20, #16
	fabs	d6, d7
	mov	w23, #3
	mov	w19, #2
	mov.16b	v8, v7
	b	LBB9_35
LBB9_34:
	mov.16b	v8, v17
LBB9_35:
	mov	x9, #0
	mov	x17, #0
	mov	x10, #0
	mov	x15, #0
	mov	w13, #1
	mov	w16, #3
	mov	x11, #9218868437227405312
	fmov	d0, x11
	fcmp	d6, d0
	mov	x11, x19
	b.eq	LBB9_66
	b.vs	LBB9_66
	add	x24, sp, #136
	fcmp	d8, #0.0
	b.pl	LBB9_39
	mov	x20, x8
	add	x0, sp, #136
	add	x1, sp, #8
	bl	__RNvMs_NtCshzmyaYQzAhy_8la_stack4ldltINtB4_4LdltKj4_E23non_finite_factor_errorCs7wsLvUT6iAW_13codegen_audit
	ldrb	w13, [sp, #136]
	cmp	w13, #255
	b.ne	LBB9_48
	mov	x9, #0
	mov	x10, #0
	fmov	x11, d8
	mov	w13, #10
	b	LBB9_49
LBB9_39:
	mov	x21, x8
	add	x0, sp, #136
	add	x1, sp, #8
	b.ne	LBB9_61
	bl	__RNvMs_NtCshzmyaYQzAhy_8la_stack4ldltINtB4_4LdltKj4_E23non_finite_factor_errorCs7wsLvUT6iAW_13codegen_audit
	ldrb	w13, [sp, #136]
	cmp	w13, #255
	b.ne	LBB9_64
	mov	x8, x21
	tbz	w22, #0, LBB9_68
	mov	x9, #0
	mov	x10, #0
	mov	x11, #0
	mov	w13, #0
	mov	x12, #59921
	movk	x12, #33069, lsl #16
	movk	x12, #38809, lsl #32
	movk	x12, #15729, lsl #48
	fmov	d1, x12
	mov	w19, #1
	mov	w15, #256
	mov	w17, #3
	b	LBB9_66
LBB9_43:
	mov	x9, #0
	b	LBB9_47
LBB9_44:
	mov	w9, #1
	b	LBB9_47
LBB9_45:
	mov	w9, #2
	b	LBB9_47
LBB9_46:
	mov	w9, #3
LBB9_47:
	mov	w10, #1281
	strh	w10, [x8]
	mov	w10, #2
	strb	w10, [x8, #8]
	str	x9, [x8, #16]
	b	LBB9_30
LBB9_48:
	ldrb	w16, [sp, #137]
	ldrh	w8, [sp, #142]
	ldur	w9, [x24, #2]
	orr	x14, x9, x8, lsl #32
	ldp	x9, x10, [sp, #144]
	ldr	x11, [sp, #160]
	ldp	d1, d0, [sp, #168]
	ldr	x12, [sp, #184]
	mov	x19, x9
LBB9_49:
	mov	x8, x20
	mov	x17, x19
	mov	x15, x10
	mov	x19, x10
	b	LBB9_66
LBB9_50:
	mov	x9, #0
	mov	x11, #0
	mov	w13, #769
	mov	w10, #1
	b	LBB9_56
LBB9_51:
	mov	x9, #0
	mov	x11, #0
	mov	w13, #769
	mov	w10, #2
	b	LBB9_56
LBB9_52:
	mov	x9, #0
	mov	x11, #0
	mov	w13, #769
	mov	w10, #3
	b	LBB9_56
LBB9_53:
	mov	x9, #0
	mov	w13, #769
	mov	w10, #2
	mov	w11, #1
	b	LBB9_56
LBB9_54:
	mov	x9, #0
	mov	w13, #769
	mov	w10, #3
	mov	w11, #1
	b	LBB9_56
LBB9_55:
	mov	x9, #0
	mov	w13, #769
	mov	w10, #3
	mov	w11, #2
LBB9_56:
	b	LBB9_67
LBB9_57:
	mov	w10, #2
	b	LBB9_60
LBB9_58:
	mov	w10, #1
	b	LBB9_60
LBB9_59:
	mov	x10, #0
LBB9_60:
	mov	w11, #1281
	strh	w11, [x8]
	strb	w9, [x8, #8]
	str	x10, [x8, #16]
	b	LBB9_30
LBB9_61:
	bl	__RNvMs_NtCshzmyaYQzAhy_8la_stack4ldltINtB4_4LdltKj4_E23non_finite_factor_errorCs7wsLvUT6iAW_13codegen_audit
	ldrb	w13, [sp, #136]
	cmp	w13, #255
	b.ne	LBB9_64
	mov	x9, #0
	mov	x10, #0
	mov	w13, #0
	fmov	x11, d8
	mov	x8, #59921
	movk	x8, #33069, lsl #16
	movk	x8, #38809, lsl #32
	movk	x8, #15729, lsl #48
	fmov	d1, x8
	mov	w15, #256
LBB9_63:
	mov	x17, x19
	mov	w19, #1
	b	LBB9_65
LBB9_64:
	ldrb	w16, [sp, #137]
	ldrh	w8, [sp, #142]
	ldur	w9, [x24, #2]
	orr	x14, x9, x8, lsl #32
	ldp	x9, x10, [sp, #144]
	ldr	x11, [sp, #160]
	ldp	d1, d0, [sp, #168]
	ldr	x12, [sp, #184]
	mov	x17, x9
	mov	x15, x10
	mov	x19, x10
LBB9_65:
	mov	x8, x21
LBB9_66:
	bfxil	x10, x15, #0, #16
	bfxil	x10, x19, #0, #8
	mov	w13, w13
	bfi	x13, x16, #8, #8
	orr	x13, x13, x14, lsl #16
	bfxil	x9, x17, #0, #8
LBB9_67:
	stp	x13, x9, [x8]
	stp	x10, x11, [x8, #16]
	stp	d1, d0, [x8, #32]
	str	x12, [x8, #48]
	b	LBB9_30
LBB9_68:
	lsl	x9, x23, #5
	add	x10, sp, #8
	add	x10, x10, x9
	ldr	d1, [x10, x19, lsl #3]
	fcmp	d1, #0.0
	b.eq	LBB9_70
	mov	x9, #0
	mov	x10, #0
	mov	x15, #0
	mov	w13, #10
	mov	x17, x19
	mov	w19, #1
	mov	x11, x23
	b	LBB9_66
LBB9_70:
	add	x11, x19, #1
	add	x8, x20, #32
	mov	x10, #59921
	movk	x10, #33069, lsl #16
	movk	x10, #38809, lsl #32
	movk	x10, #15729, lsl #48
	fmov	d2, x10
	mov	w15, #256
	mov	w13, #10
LBB9_71:
	cmp	x9, #96
	b.eq	LBB9_74
	ldr	d1, [x8, x9]
	add	x11, x11, #1
	add	x9, x9, #32
	fcmp	d1, #0.0
	b.eq	LBB9_71
	mov	x9, #0
	mov	x10, #0
	mov	x15, #0
	b	LBB9_63
LBB9_74:
	mov	x9, #0
	mov	x10, #0
	mov	x11, #0
	mov	w13, #0
	mov	x17, x19
	mov	w19, #1
	mov.16b	v1, v2
	b	LBB9_65
LBB9_75:
	mov	x12, #0
	mov	x9, #0
	mov	w13, #9
	mov	w11, #4
	mov	w10, #1
	b	LBB9_67
LBB9_76:
	mov	x12, #0
	mov	x9, #0
	mov	w13, #9
	mov	w11, #4
	mov	w10, #2
	mov.16b	v1, v2
	mov.16b	v0, v3
	b	LBB9_67
LBB9_77:
	mov	x12, #0
	mov	x9, #0
	mov	w13, #9
	mov	w11, #4
	mov	w10, #3
	mov.16b	v1, v3
	mov.16b	v0, v4
	b	LBB9_67
LBB9_78:
	mov	x12, #0
	mov	w13, #9
	mov	w9, #1
	mov	w11, #4
	mov	w10, #2
	mov.16b	v1, v4
	mov.16b	v0, v5
	b	LBB9_67
LBB9_79:
	mov	x12, #0
	mov	w13, #9
	mov	w9, #1
	b	LBB9_81
LBB9_80:
	mov	x12, #0
	mov	w13, #9
	mov	w9, #2
LBB9_81:
	mov	w11, #4
	mov	w10, #3
	mov.16b	v1, v5
	mov.16b	v0, v6
	b	LBB9_67
	.cfi_endproc

	.globl	__RNvCs7wsLvUT6iAW_13codegen_audit11ldlt_solve5
	.p2align	2
__RNvCs7wsLvUT6iAW_13codegen_audit11ldlt_solve5:
	.cfi_startproc
	sub	sp, sp, #352
	.cfi_def_cfa_offset 352
	stp	d9, d8, [sp, #256]
	stp	x28, x27, [sp, #272]
	stp	x24, x23, [sp, #288]
	stp	x22, x21, [sp, #304]
	stp	x20, x19, [sp, #320]
	stp	x29, x30, [sp, #336]
	add	x29, sp, #336
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	.cfi_offset b8, -88
	.cfi_offset b9, -96
	.cfi_remember_state
	ldr	d2, [x0, #8]
	ldr	d1, [x0, #40]
	movi.2d	v0, #0000000000000000
	fcmp	d2, d1
	b.ne	LBB10_88
	ldr	d3, [x0, #16]
	ldr	d4, [x0, #80]
	fcmp	d3, d4
	b.ne	LBB10_89
	ldr	d4, [x0, #24]
	ldr	d5, [x0, #120]
	fcmp	d4, d5
	b.ne	LBB10_90
	ldr	d5, [x0, #32]
	ldr	d6, [x0, #160]
	fcmp	d5, d6
	b.ne	LBB10_91
	mov	x9, x0
	ldr	d6, [x9, #56]!
	ldr	d7, [x9, #32]
	fcmp	d6, d7
	b.ne	LBB10_92
	ldr	d6, [x0, #64]
	ldr	d7, [x0, #128]
	fcmp	d6, d7
	b.ne	LBB10_93
	ldr	d6, [x0, #72]
	ldr	d7, [x0, #168]
	fcmp	d6, d7
	b.ne	LBB10_94
	ldr	d6, [x0, #104]
	ldr	d7, [x0, #136]
	fcmp	d6, d7
	b.ne	LBB10_95
	ldr	d6, [x0, #112]
	ldr	d7, [x0, #176]
	fcmp	d6, d7
	b.ne	LBB10_97
	ldr	d6, [x0, #152]
	ldr	d7, [x0, #184]
	fcmp	d6, d7
	b.ne	LBB10_98
	mov	x20, #0
	mov	w22, #0
	mov	x19, sp
	ldrb	w10, [x0]
	ldur	w11, [x0, #1]
	stur	w11, [sp, #1]
	ldr	w11, [x0, #4]
	str	w11, [sp, #4]
	ldr	q0, [x9, #128]
	stur	q0, [x19, #184]
	ldp	q0, q6, [x9, #64]
	stur	q0, [sp, #120]
	stur	q6, [x19, #136]
	ldp	q0, q6, [x9, #96]
	stur	q0, [x19, #152]
	stur	q6, [x19, #168]
	ldp	q0, q6, [x9]
	stur	q0, [sp, #56]
	stur	q6, [sp, #72]
	ldp	q0, q7, [x9, #32]
	stur	q0, [sp, #88]
	ldr	d6, [x0, #48]
	stur	q7, [sp, #104]
	strb	w10, [sp]
	mov	x21, sp
	stp	d2, d3, [sp, #8]
	ldr	d3, [sp]
	fmov	x9, d3
	fabs	d19, d3
	ubfx	x9, x9, #52, #11
	stp	d4, d5, [sp, #24]
	cmp	x9, #2047
	cset	w9, lo
	mov	w23, #1
	mov	x10, #59921
	movk	x10, #33069, lsl #16
	movk	x10, #38809, lsl #32
	movk	x10, #15729, lsl #48
	fmov	d0, x10
	fcmp	d3, d0
	stp	d1, d6, [sp, #40]
	b.le	LBB10_47
	tbz	w9, #0, LBB10_47
	fdiv	d0, d1, d3
	fmov	x9, d0
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB10_69
	str	d0, [sp, #40]
	ldr	d1, [sp, #80]
	fdiv	d1, d1, d3
	fmov	x9, d1
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB10_70
	str	d1, [sp, #80]
	ldr	d2, [sp, #120]
	fdiv	d2, d2, d3
	fmov	x9, d2
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB10_71
	str	d2, [sp, #120]
	ldr	d4, [sp, #160]
	fdiv	d4, d4, d3
	fmov	x9, d4
	ubfx	x9, x9, #52, #11
	cmp	x9, #2047
	b.hs	LBB10_72
	fnmul	d5, d3, d0
	fmadd	d8, d5, d0, d6
	fmov	x9, d8
	fnmul	d6, d3, d1
	ldp	d5, d7, [sp, #88]
	fmadd	d5, d6, d0, d5
	str	d8, [sp, #48]
	fmadd	d16, d6, d1, d7
	fnmul	d7, d3, d2
	ldp	d6, d17, [sp, #128]
	fmadd	d6, d7, d0, d6
	stp	d5, d16, [sp, #88]
	fmadd	d17, d7, d1, d17
	ldr	d18, [sp, #144]
	ldp	d20, d19, [sp, #168]
	fmadd	d18, d7, d2, d18
	stp	d6, d17, [sp, #128]
	str	d18, [sp, #144]
	fnmul	d21, d3, d4
	fmadd	d7, d21, d0, d20
	stp	d4, d7, [sp, #160]
	ldp	d23, d22, [sp, #184]
	fmadd	d20, d21, d1, d19
	fmadd	d19, d21, d2, d23
	stp	d20, d19, [sp, #176]
	fmadd	d21, d21, d4, d22
	str	d21, [sp, #192]
	ubfx	x9, x9, #52, #11
	cmp	x9, #2047
	cset	w9, lo
	fmov	d22, x10
	fcmp	d8, d22
	ccmp	w9, #0, #4, gt
	b.eq	LBB10_48
	fdiv	d5, d5, d8
	fmov	x9, d5
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB10_73
	str	d5, [sp, #88]
	fdiv	d6, d6, d8
	fmov	x9, d6
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB10_74
	str	d6, [sp, #128]
	fdiv	d7, d7, d8
	fmov	x9, d7
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB10_75
	fnmul	d22, d8, d5
	fmadd	d16, d22, d5, d16
	fmov	x9, d16
	fnmul	d22, d8, d6
	fmadd	d17, d22, d5, d17
	str	d16, [sp, #96]
	fmadd	d22, d22, d6, d18
	stp	d17, d22, [sp, #136]
	fnmul	d23, d8, d7
	fmadd	d18, d23, d5, d20
	fmadd	d19, d23, d6, d19
	stp	d7, d18, [sp, #168]
	fmadd	d21, d23, d7, d21
	stp	d19, d21, [sp, #184]
	ubfx	x9, x9, #52, #11
	cmp	x9, #2047
	cset	w9, lo
	fmov	d20, x10
	fcmp	d16, d20
	ccmp	w9, #0, #4, gt
	b.eq	LBB10_49
	fdiv	d17, d17, d16
	fmov	x9, d17
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB10_76
	str	d17, [sp, #136]
	fdiv	d18, d18, d16
	fmov	x9, d18
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB10_77
	fnmul	d20, d16, d17
	fmadd	d20, d20, d17, d22
	fmov	x9, d20
	str	d20, [sp, #144]
	fnmul	d23, d16, d18
	fmadd	d22, d23, d17, d19
	fmadd	d19, d23, d18, d21
	stp	d18, d22, [sp, #176]
	str	d19, [sp, #192]
	ubfx	x9, x9, #52, #11
	cmp	x9, #2047
	cset	w9, lo
	fmov	d21, x10
	fcmp	d20, d21
	ccmp	w9, #0, #4, gt
	b.eq	LBB10_50
	fdiv	d21, d22, d20
	fmov	x9, d21
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB10_78
	add	x21, x21, #32
	fnmul	d22, d20, d21
	fmadd	d22, d22, d21, d19
	fmov	x9, d22
	stp	d21, d22, [sp, #184]
	fabs	d19, d22
	ubfx	x9, x9, #52, #11
	cmp	x9, #2047
	cset	w9, lo
	mov	w22, #1
	mov	w23, #5
	mov	w20, #4
	fmov	d23, x10
	fcmp	d22, d23
	b.le	LBB10_51
	tbz	w9, #0, LBB10_51
	ldr	d19, [x1]
	fmov	x9, d19
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB10_43
	ldr	d23, [x1, #8]
	fmsub	d23, d0, d19, d23
	fmov	x9, d23
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB10_44
	ldr	d24, [x1, #16]
	fmsub	d24, d1, d19, d24
	fmsub	d24, d5, d23, d24
	fmov	x9, d24
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB10_45
	ldr	d25, [x1, #24]
	fmsub	d25, d2, d19, d25
	fmsub	d25, d6, d23, d25
	fmsub	d25, d17, d24, d25
	fmov	x9, d25
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB10_46
	ldr	d26, [x1, #32]
	fmsub	d26, d4, d19, d26
	fmsub	d26, d7, d23, d26
	fmsub	d26, d18, d24, d26
	fmsub	d26, d21, d25, d26
	fmov	x9, d26
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB10_60
	fdiv	d3, d19, d3
	fmov	x9, d3
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB10_43
	fdiv	d19, d23, d8
	fmov	x9, d19
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB10_44
	fdiv	d23, d24, d16
	fmov	x9, d23
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB10_45
	fdiv	d20, d25, d20
	fmov	x9, d20
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB10_46
	fdiv	d16, d26, d22
	fmov	x9, d16
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB10_60
	fmsub	d20, d21, d16, d20
	fmov	x9, d20
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB10_46
	fmsub	d18, d18, d16, d23
	fmsub	d17, d17, d20, d18
	fmov	x9, d17
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB10_45
	fmsub	d7, d7, d16, d19
	fmsub	d6, d6, d20, d7
	fmsub	d5, d5, d17, d6
	fmov	x9, d5
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB10_44
	fmsub	d3, d4, d16, d3
	fmsub	d2, d2, d20, d3
	fmsub	d1, d1, d17, d2
	fmsub	d0, d0, d5, d1
	fmov	x9, d0
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB10_43
	stp	d0, d5, [x8, #8]
	stp	d17, d20, [x8, #24]
	str	d16, [x8, #40]
	mov	w9, #255
	strb	w9, [x8]
LBB10_42:
	.cfi_def_cfa wsp, 352
	ldp	x29, x30, [sp, #336]
	ldp	x20, x19, [sp, #320]
	ldp	x22, x21, [sp, #304]
	ldp	x24, x23, [sp, #288]
	ldp	x28, x27, [sp, #272]
	ldp	d9, d8, [sp, #256]
	add	sp, sp, #352
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore b8
	.cfi_restore b9
	ret
LBB10_43:
	.cfi_restore_state
	mov	x9, #0
	b	LBB10_61
LBB10_44:
	mov	w9, #1
	b	LBB10_61
LBB10_45:
	mov	w9, #2
	b	LBB10_61
LBB10_46:
	mov	w9, #3
	b	LBB10_61
LBB10_47:
	mov.16b	v8, v3
	b	LBB10_52
LBB10_48:
	mov	w22, #0
	add	x21, x21, #8
	fabs	d19, d8
	mov	w23, #2
	mov	w20, #1
	b	LBB10_52
LBB10_49:
	mov	w22, #0
	add	x21, x21, #16
	fabs	d19, d16
	mov	w23, #3
	mov	w20, #2
	mov.16b	v8, v16
	b	LBB10_52
LBB10_50:
	mov	w22, #0
	add	x21, x21, #24
	fabs	d19, d20
	mov	w23, #4
	mov	w20, #3
	mov.16b	v8, v20
	b	LBB10_52
LBB10_51:
	mov.16b	v8, v22
LBB10_52:
	mov	x9, #0
	mov	x16, #0
	mov	x11, #0
	mov	x14, #0
	mov	w12, #1
	mov	w15, #3
	mov	x10, #9218868437227405312
	fmov	d0, x10
	fcmp	d19, d0
	mov	x10, x20
	b.eq	LBB10_68
	b.vs	LBB10_68
	fcmp	d8, #0.0
	b.pl	LBB10_56
	mov	x21, x8
	sub	x0, x29, #136
	mov	x1, sp
	bl	__RNvMs_NtCshzmyaYQzAhy_8la_stack4ldltINtB4_4LdltKj5_E23non_finite_factor_errorCs7wsLvUT6iAW_13codegen_audit
	ldurb	w12, [x29, #-136]
	cmp	w12, #255
	b.ne	LBB10_62
	mov	x9, #0
	mov	x11, #0
	fmov	x10, d8
	mov	w12, #10
	b	LBB10_63
LBB10_56:
	mov	x24, x8
	sub	x0, x29, #136
	mov	x1, sp
	b.ne	LBB10_64
	bl	__RNvMs_NtCshzmyaYQzAhy_8la_stack4ldltINtB4_4LdltKj5_E23non_finite_factor_errorCs7wsLvUT6iAW_13codegen_audit
	ldurb	w12, [x29, #-136]
	cmp	w12, #255
	b.ne	LBB10_66
	mov	x8, x24
	tbz	w22, #0, LBB10_81
	mov	x9, #0
	mov	x11, #0
	mov	x10, #0
	mov	w12, #0
	mov	x13, #59921
	movk	x13, #33069, lsl #16
	movk	x13, #38809, lsl #32
	movk	x13, #15729, lsl #48
	fmov	d2, x13
	mov	w20, #1
	mov	w14, #256
	mov	w16, #4
	b	LBB10_68
LBB10_60:
	mov	w9, #4
LBB10_61:
	mov	w10, #1281
	strh	w10, [x8]
	mov	w10, #2
	strb	w10, [x8, #8]
	str	x9, [x8, #16]
	b	LBB10_42
LBB10_62:
	ldurb	w15, [x29, #-135]
	ldurh	w8, [x29, #-130]
	ldur	w9, [x19, #202]
	orr	x13, x9, x8, lsl #32
	ldp	x9, x11, [x29, #-128]
	ldur	x10, [x29, #-112]
	ldp	d2, d1, [x29, #-104]
	ldur	d0, [x29, #-88]
	mov	x20, x9
LBB10_63:
	mov	x8, x21
	mov	x16, x20
	mov	x14, x11
	mov	x20, x11
	b	LBB10_68
LBB10_64:
	bl	__RNvMs_NtCshzmyaYQzAhy_8la_stack4ldltINtB4_4LdltKj5_E23non_finite_factor_errorCs7wsLvUT6iAW_13codegen_audit
	ldurb	w12, [x29, #-136]
	cmp	w12, #255
	b.ne	LBB10_66
	mov	x9, #0
	mov	x11, #0
	mov	w12, #0
	fmov	x10, d8
	mov	x8, #59921
	movk	x8, #33069, lsl #16
	movk	x8, #38809, lsl #32
	movk	x8, #15729, lsl #48
	fmov	d2, x8
	mov	w14, #256
	mov	x16, x20
	mov	w20, #1
	b	LBB10_67
LBB10_66:
	ldurb	w15, [x29, #-135]
	ldurh	w8, [x29, #-130]
	ldur	w9, [x19, #202]
	orr	x13, x9, x8, lsl #32
	ldp	x9, x11, [x29, #-128]
	ldur	x10, [x29, #-112]
	ldp	d2, d1, [x29, #-104]
	ldur	d0, [x29, #-88]
	mov	x16, x9
	mov	x14, x11
	mov	x20, x11
LBB10_67:
	mov	x8, x24
LBB10_68:
	bfxil	x11, x14, #0, #16
	bfxil	x11, x20, #0, #8
	mov	w12, w12
	bfi	x12, x15, #8, #8
	orr	x12, x12, x13, lsl #16
	bfxil	x9, x16, #0, #8
	b	LBB10_80
LBB10_69:
	mov	x9, #0
	mov	x10, #0
	mov	w12, #769
	mov	w11, #1
	b	LBB10_79
LBB10_70:
	mov	x9, #0
	mov	x10, #0
	mov	w12, #769
	mov	w11, #2
	b	LBB10_79
LBB10_71:
	mov	x9, #0
	mov	x10, #0
	mov	w12, #769
	mov	w11, #3
	b	LBB10_79
LBB10_72:
	mov	x9, #0
	mov	x10, #0
	mov	w12, #769
	mov	w11, #4
	b	LBB10_79
LBB10_73:
	mov	x9, #0
	mov	w12, #769
	mov	w11, #2
	mov	w10, #1
	b	LBB10_79
LBB10_74:
	mov	x9, #0
	mov	w12, #769
	mov	w11, #3
	mov	w10, #1
	b	LBB10_79
LBB10_75:
	mov	x9, #0
	mov	w12, #769
	mov	w11, #4
	mov	w10, #1
	b	LBB10_79
LBB10_76:
	mov	x9, #0
	mov	w12, #769
	mov	w11, #3
	mov	w10, #2
	b	LBB10_79
LBB10_77:
	mov	x9, #0
	mov	w12, #769
	mov	w11, #4
	mov	w10, #2
	b	LBB10_79
LBB10_78:
	mov	x9, #0
	mov	w12, #769
	mov	w11, #4
	mov	w10, #3
LBB10_79:
LBB10_80:
	stp	x12, x9, [x8]
	stp	x11, x10, [x8, #16]
	stp	d2, d1, [x8, #32]
	str	d0, [x8, #48]
	b	LBB10_42
LBB10_81:
	add	x9, x23, x23, lsl #2
	lsl	x9, x9, #3
	mov	x10, sp
	add	x10, x10, x9
	ldr	d2, [x10, x20, lsl #3]
	fcmp	d2, #0.0
	b.eq	LBB10_83
	mov	x9, #0
	mov	x11, #0
	mov	x14, #0
	mov	w12, #10
	mov	x16, x20
	mov	w20, #1
	mov	x10, x23
	b	LBB10_68
LBB10_83:
	add	x10, x20, #1
	add	x11, x21, #40
	mov	x12, #59921
	movk	x12, #33069, lsl #16
	movk	x12, #38809, lsl #32
	movk	x12, #15729, lsl #48
	fmov	d3, x12
	mov	w14, #256
	mov	w12, #10
LBB10_84:
	cmp	x9, #160
	b.eq	LBB10_87
	ldr	d2, [x11, x9]
	add	x10, x10, #1
	add	x9, x9, #40
	fcmp	d2, #0.0
	b.eq	LBB10_84
	mov	x9, #0
	mov	x11, #0
	mov	x14, #0
	mov	x16, x20
	mov	w20, #1
	b	LBB10_68
LBB10_87:
	mov	x9, #0
	mov	x11, #0
	mov	x10, #0
	mov	w12, #0
	mov	x16, x20
	mov	w20, #1
	mov.16b	v2, v3
	b	LBB10_68
LBB10_88:
	mov	x9, #0
	mov	w12, #9
	mov	w10, #5
	mov	w11, #1
	b	LBB10_80
LBB10_89:
	mov	x9, #0
	mov	w12, #9
	mov	w10, #5
	mov	w11, #2
	mov.16b	v2, v3
	mov.16b	v1, v4
	b	LBB10_80
LBB10_90:
	mov	x9, #0
	mov	w12, #9
	mov	w10, #5
	mov	w11, #3
	mov.16b	v2, v4
	mov.16b	v1, v5
	b	LBB10_80
LBB10_91:
	mov	x9, #0
	mov	w12, #9
	mov	w10, #5
	mov	w11, #4
	mov.16b	v2, v5
	mov.16b	v1, v6
	b	LBB10_80
LBB10_92:
	mov	w12, #9
	mov	w9, #1
	mov	w10, #5
	mov	w11, #2
	b	LBB10_100
LBB10_93:
	mov	w12, #9
	mov	w9, #1
	b	LBB10_96
LBB10_94:
	mov	w12, #9
	mov	w9, #1
	b	LBB10_99
LBB10_95:
	mov	w12, #9
	mov	w9, #2
LBB10_96:
	mov	w10, #5
	mov	w11, #3
	b	LBB10_100
LBB10_97:
	mov	w12, #9
	mov	w9, #2
	b	LBB10_99
LBB10_98:
	mov	w12, #9
	mov	w9, #3
LBB10_99:
	mov	w10, #5
	mov	w11, #4
LBB10_100:
	mov.16b	v2, v6
	mov.16b	v1, v7
	b	LBB10_80
	.cfi_endproc

	.globl	__RNvCs7wsLvUT6iAW_13codegen_audit13interval_det4
	.p2align	2
__RNvCs7wsLvUT6iAW_13codegen_audit13interval_det4:
	.cfi_startproc
	stp	d15, d14, [sp, #-160]!
	.cfi_def_cfa_offset 160
	stp	d13, d12, [sp, #16]
	stp	d11, d10, [sp, #32]
	stp	d9, d8, [sp, #48]
	stp	x28, x27, [sp, #64]
	stp	x26, x25, [sp, #80]
	stp	x24, x23, [sp, #96]
	stp	x22, x21, [sp, #112]
	stp	x20, x19, [sp, #128]
	stp	x29, x30, [sp, #144]
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	.cfi_offset b10, -120
	.cfi_offset b11, -128
	.cfi_offset b12, -136
	.cfi_offset b13, -144
	.cfi_offset b14, -152
	.cfi_offset b15, -160
	.cfi_remember_state
	sub	sp, sp, #2176
	ldr	xzr, [sp]
	mov	x20, x0
	mov	x19, x8
	sub	x22, x29, #216
	add	x23, sp, #56
	add	x0, x23, #16
	mov	w1, #2032
	bl	_bzero
	mov	x24, #4607182418800017408
	stp	x24, x24, [sp, #56]
	mov	w25, #1
	mov	w21, #5
	movi.2d	v12, #0000000000000000
	mov	w26, #1
LBB11_1:
	mov	x27, #0
	fmov	d0, x26
	cnt.8b	v0, v0
	addv.8b	b0, v0
	fmov	x8, d0
	add	x8, x20, x8, lsl #6
	sub	x28, x8, #64
	movi.2d	v3, #0000000000000000
	movi.2d	v0, #0000000000000000
	movi.2d	v14, #0000000000000000
	movi.2d	v13, #0000000000000000
	b	LBB11_5
LBB11_2:
	fmov	d0, x10
	fcmp	d0, #0.0
	fcsel	d14, d12, d0, eq
	fcmp	d1, #0.0
	fcsel	d13, d12, d1, eq
LBB11_3:
	mov.16b	v0, v13
	mov.16b	v3, v14
LBB11_4:
	add	x27, x27, #1
	add	x28, x28, #16
	cmp	x27, #4
	b.eq	LBB11_99
LBB11_5:
	lsr	x8, x26, x27
	tbz	w8, #0, LBB11_4
	lsl	x8, x25, x27
	eor	x8, x8, x26
	add	x8, x23, x8, lsl #4
	ldp	d0, d8, [x8]
	movi.2d	v2, #0000000000000000
	fcmp	d0, #0.0
	b.ne	LBB11_9
	fcmp	d8, #0.0
	b.ne	LBB11_9
	movi.2d	v3, #0000000000000000
	b	LBB11_16
LBB11_9:
	ldp	d1, d9, [x28]
	fcmp	d1, #0.0
	b.ne	LBB11_11
	fcmp	d9, #0.0
	movi.2d	v3, #0000000000000000
	b.eq	LBB11_16
LBB11_11:
	fmov	x8, d8
	fmov	x9, d0
	cmp	x9, x24
	ccmp	x8, x24, #0, eq
	b.eq	LBB11_15
	fmov	x10, d9
	fmov	x11, d1
	cmp	x11, x24
	b.ne	LBB11_49
	cmp	x10, x24
	b.ne	LBB11_49
	mov.16b	v2, v8
	mov.16b	v3, v0
	b	LBB11_16
LBB11_15:
	mov.16b	v2, v9
	mov.16b	v3, v1
LBB11_16:
	add	x8, x27, #1
	lsr	x8, x26, x8
	fmov	d0, x8
	cnt.8b	v0, v0
	addv.8b	b0, v0
	fmov	x8, d0
	tst	x8, #0x1
	b.ne	LBB11_18
	mov.16b	v0, v2
	fcmp	d14, #0.0
	b.eq	LBB11_19
	b	LBB11_21
LBB11_18:
	fneg	d0, d2
	fneg	d1, d3
	fcmp	d2, #0.0
	fcsel	d4, d12, d0, eq
	fcmp	d3, #0.0
	fcsel	d0, d12, d1, eq
	mov.16b	v3, v4
	fcmp	d14, #0.0
	b.ne	LBB11_21
LBB11_19:
	fcmp	d13, #0.0
	b.ne	LBB11_21
	mov.16b	v13, v0
	mov.16b	v14, v3
	b	LBB11_4
LBB11_21:
	fcmp	d0, #0.0
	b.ne	LBB11_23
	fcmp	d3, #0.0
	b.eq	LBB11_3
LBB11_23:
	fadd	d1, d14, d3
	fmov	x8, d1
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.hi	LBB11_102
	fabs	d4, d14
	fabs	d5, d3
	fcmp	d4, d5
	fcsel	d4, d3, d14, lt
	fcsel	d3, d14, d3, lt
	fsub	d4, d1, d4
	fsub	d4, d3, d4
	fmov	x8, d4
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.hi	LBB11_103
	fabs	d3, d1
	fcmp	d4, #0.0
	b.pl	LBB11_30
	fmov	x8, d1
	mov	x10, #-4503599627370496
	cmp	x8, x10
	b.eq	LBB11_33
	fmov	x9, d3
	cbz	x9, LBB11_62
	cmp	x8, x9
	b.ne	LBB11_64
	mov	w11, #0
	sub	x10, x8, #1
	b	LBB11_34
LBB11_30:
	fmov	x10, d1
	fcmp	d4, #0.0
	b.le	LBB11_33
	mov	x8, #9218868437227405312
	cmp	x10, x8
	b.ne	LBB11_56
	mov	w11, #0
	mov	x10, #9218868437227405312
	b	LBB11_34
LBB11_33:
	mov	w11, #0
LBB11_34:
	ubfx	x8, x10, #52, #11
	cmp	x8, #2046
	cset	w12, hi
	mov	w8, #2
	mov	w9, #12
	tbnz	w11, #0, LBB11_107
	tbnz	w12, #0, LBB11_107
	fadd	d1, d13, d0
	fmov	x8, d1
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.hi	LBB11_104
	fabs	d3, d13
	fabs	d4, d0
	fcmp	d3, d4
	fcsel	d3, d0, d13, lt
	fcsel	d0, d13, d0, lt
	fsub	d3, d1, d3
	fsub	d3, d0, d3
	fmov	x8, d3
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.hi	LBB11_105
	fabs	d0, d1
	fcmp	d3, #0.0
	b.pl	LBB11_43
	fmov	x9, d1
	mov	x8, #-4503599627370496
	cmp	x9, x8
	b.eq	LBB11_46
	fmov	x8, d0
	cbz	x8, LBB11_63
	cmp	x9, x8
	b.ne	LBB11_65
	mov	w11, #0
	sub	x8, x9, #1
	b	LBB11_47
LBB11_43:
	fmov	x8, d1
	fcmp	d3, #0.0
	b.le	LBB11_46
	mov	x9, #9218868437227405312
	cmp	x8, x9
	b.ne	LBB11_59
	mov	w11, #0
	mov	x8, #9218868437227405312
	b	LBB11_47
LBB11_46:
	mov	w11, #0
LBB11_47:
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	cset	w12, hi
	mov	w8, #2
	mov	w9, #12
	tbnz	w11, #0, LBB11_107
	tbz	w12, #0, LBB11_2
	b	LBB11_107
LBB11_49:
	cmp	x8, x9
	ccmp	x10, x11, #0, eq
	b.eq	LBB11_54
	fcmp	d0, #0.0
	b.ge	LBB11_66
	fcmp	d8, #0.0
	b.ls	LBB11_74
	fcmp	d1, #0.0
	b.lt	LBB11_79
	sub	x0, x29, #216
	mov.16b	v1, v9
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8interval22rounded_product_bounds
	ldurb	w8, [x29, #-216]
	cmp	w8, #255
	b.eq	LBB11_87
	b	LBB11_106
LBB11_54:
	sub	x0, x29, #216
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8interval22rounded_product_bounds
	ldurb	w8, [x29, #-216]
	cmp	w8, #255
	b.ne	LBB11_106
	ldp	d0, d1, [x29, #-208]
	fcmp	d1, #0.0
	fcsel	d2, d12, d1, eq
	fcmp	d0, #0.0
	fcsel	d3, d12, d0, eq
	b	LBB11_16
LBB11_56:
	fmov	x8, d3
	cbz	x8, LBB11_68
	cmp	x10, x8
	b.ne	LBB11_70
	add	x8, x10, #1
	b	LBB11_71
LBB11_59:
	fmov	x9, d0
	cbz	x9, LBB11_69
	cmp	x8, x9
	b.ne	LBB11_72
	add	x9, x8, #1
	b	LBB11_73
LBB11_62:
	mov	w11, #0
	mov	x10, #-9223372036854775807
	b	LBB11_34
LBB11_63:
	mov	w11, #0
	mov	x8, #-9223372036854775807
	b	LBB11_47
LBB11_64:
	mov	w11, #0
	add	x10, x8, #1
	b	LBB11_34
LBB11_65:
	mov	w11, #0
	add	x8, x9, #1
	b	LBB11_47
LBB11_66:
	fcmp	d1, #0.0
	b.lt	LBB11_76
	sub	x0, x29, #216
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8interval22rounded_product_bounds
	ldurb	w8, [x29, #-216]
	cmp	w8, #255
	b.eq	LBB11_87
	b	LBB11_106
LBB11_68:
	mov	w8, #1
	b	LBB11_71
LBB11_69:
	mov	w9, #1
	b	LBB11_73
LBB11_70:
	sub	x8, x10, #1
LBB11_71:
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	cset	w11, hi
	b	LBB11_34
LBB11_72:
	sub	x9, x8, #1
LBB11_73:
	fmov	d1, x9
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	cset	w11, hi
	b	LBB11_47
LBB11_74:
	mov.16b	v10, v1
	fcmp	d1, #0.0
	b.lt	LBB11_82
	sub	x0, x29, #216
	mov.16b	v1, v9
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8interval22rounded_product_bounds
	ldurb	w8, [x29, #-216]
	cmp	w8, #255
	b.eq	LBB11_96
	b	LBB11_106
LBB11_76:
	fcmp	d9, #0.0
	b.hi	LBB11_86
	mov.16b	v10, v0
	sub	x0, x29, #216
	mov.16b	v0, v8
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8interval22rounded_product_bounds
	ldurb	w8, [x29, #-216]
	cmp	w8, #255
	b.ne	LBB11_106
	ldur	d8, [x29, #-208]
	sub	x0, x29, #216
	mov.16b	v0, v10
	mov.16b	v1, v9
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8interval22rounded_product_bounds
	ldurb	w8, [x29, #-216]
	cmp	w8, #255
	b.eq	LBB11_85
	b	LBB11_106
LBB11_79:
	fcmp	d9, #0.0
	b.hi	LBB11_90
	mov.16b	v9, v0
	sub	x0, x29, #216
	mov.16b	v0, v8
	mov.16b	v8, v1
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8interval22rounded_product_bounds
	ldurb	w8, [x29, #-216]
	cmp	w8, #255
	b.ne	LBB11_106
	ldur	d10, [x29, #-208]
	sub	x0, x29, #216
	mov.16b	v0, v9
	mov.16b	v1, v8
	b	LBB11_88
LBB11_82:
	fcmp	d9, #0.0
	b.hi	LBB11_95
	mov.16b	v11, v0
	sub	x0, x29, #216
	mov.16b	v0, v8
	mov.16b	v1, v9
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8interval22rounded_product_bounds
	ldurb	w8, [x29, #-216]
	cmp	w8, #255
	b.ne	LBB11_106
	ldur	d8, [x29, #-208]
	sub	x0, x29, #216
	mov.16b	v0, v11
	mov.16b	v1, v10
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8interval22rounded_product_bounds
	ldurb	w8, [x29, #-216]
	cmp	w8, #255
	b.ne	LBB11_106
LBB11_85:
	ldur	d0, [x29, #-200]
	fcmp	d8, #0.0
	fcsel	d3, d12, d8, eq
	b	LBB11_98
LBB11_86:
	sub	x0, x29, #216
	mov.16b	v0, v8
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8interval22rounded_product_bounds
	ldurb	w8, [x29, #-216]
	cmp	w8, #255
	b.ne	LBB11_106
LBB11_87:
	ldur	d10, [x29, #-208]
	sub	x0, x29, #216
	mov.16b	v0, v8
	mov.16b	v1, v9
LBB11_88:
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8interval22rounded_product_bounds
	ldurb	w8, [x29, #-216]
	cmp	w8, #255
	b.ne	LBB11_106
	ldur	d0, [x29, #-200]
	fcmp	d10, #0.0
	fcsel	d3, d12, d10, eq
	b	LBB11_98
LBB11_90:
	mov.16b	v10, v1
	sub	x0, x29, #216
	mov.16b	v11, v0
	mov.16b	v1, v9
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8interval22rounded_product_bounds
	ldurb	w8, [x29, #-216]
	cmp	w8, #255
	b.ne	LBB11_106
	ldur	d15, [x29, #-208]
	sub	x0, x29, #216
	mov.16b	v0, v8
	mov.16b	v1, v10
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8interval22rounded_product_bounds
	ldurb	w8, [x29, #-216]
	cmp	w8, #255
	b.ne	LBB11_106
	str	d15, [sp, #8]
	ldur	d15, [x29, #-208]
	sub	x0, x29, #216
	mov.16b	v0, v11
	mov.16b	v1, v10
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8interval22rounded_product_bounds
	ldurb	w8, [x29, #-216]
	cmp	w8, #255
	b.ne	LBB11_106
	ldur	d10, [x29, #-200]
	sub	x0, x29, #216
	mov.16b	v0, v8
	mov.16b	v1, v9
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8interval22rounded_product_bounds
	ldurb	w8, [x29, #-216]
	cmp	w8, #255
	b.ne	LBB11_106
	ldur	d0, [x29, #-200]
	ldr	d1, [sp, #8]
	fcmp	d1, d15
	fcsel	d1, d1, d15, mi
	fcmp	d10, d0
	fcsel	d0, d10, d0, gt
	fcmp	d1, #0.0
	fcsel	d3, d12, d1, eq
	b	LBB11_98
LBB11_95:
	sub	x0, x29, #216
	mov.16b	v8, v0
	mov.16b	v1, v9
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8interval22rounded_product_bounds
	ldurb	w8, [x29, #-216]
	cmp	w8, #255
	b.ne	LBB11_106
LBB11_96:
	ldur	d9, [x29, #-208]
	sub	x0, x29, #216
	mov.16b	v0, v8
	mov.16b	v1, v10
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8interval22rounded_product_bounds
	ldurb	w8, [x29, #-216]
	cmp	w8, #255
	b.ne	LBB11_106
	ldur	d0, [x29, #-200]
	fcmp	d9, #0.0
	fcsel	d3, d12, d9, eq
LBB11_98:
	fcmp	d0, #0.0
	fcsel	d2, d12, d0, eq
	b	LBB11_16
LBB11_99:
	add	x8, x23, x26, lsl #4
	stp	d3, d0, [x8]
	add	x26, x26, #1
	cmp	x26, #16
	b.ne	LBB11_1
	ldr	d0, [sp, #296]
	fcmp	d0, #0.0
	b.le	LBB11_109
	mov	w8, #255
	b	LBB11_115
LBB11_102:
	mov	w8, #2
	mov	w9, #12
	b	LBB11_107
LBB11_103:
	mov	w8, #1
	mov	w9, #12
	b	LBB11_107
LBB11_104:
	mov	w8, #2
	b	LBB11_107
LBB11_105:
	mov	w8, #1
	b	LBB11_107
LBB11_106:
	ldurb	w9, [x29, #-215]
	ldur	w10, [x22, #2]
	str	w10, [sp, #48]
	ldurh	w10, [x29, #-210]
	strh	w10, [sp, #52]
	ldur	x21, [x29, #-208]
	ldur	d2, [x29, #-200]
	ldur	q0, [x22, #24]
	ldur	q1, [x22, #40]
	stp	q0, q1, [sp, #16]
LBB11_107:
	strb	w8, [x19]
	strb	w9, [x19, #1]
	ldr	w8, [sp, #48]
	stur	w8, [x19, #2]
	ldrh	w8, [sp, #52]
	strh	w8, [x19, #6]
	str	x21, [x19, #8]
	str	d2, [x19, #16]
	ldp	q0, q1, [sp, #16]
	stur	q0, [x19, #24]
	stur	q1, [x19, #40]
LBB11_108:
	add	sp, sp, #2176
	.cfi_def_cfa wsp, 160
	ldp	x29, x30, [sp, #144]
	ldp	x20, x19, [sp, #128]
	ldp	x22, x21, [sp, #112]
	ldp	x24, x23, [sp, #96]
	ldp	x26, x25, [sp, #80]
	ldp	x28, x27, [sp, #64]
	ldp	d9, d8, [sp, #48]
	ldp	d11, d10, [sp, #32]
	ldp	d13, d12, [sp, #16]
	ldp	d15, d14, [sp], #160
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	.cfi_restore b11
	.cfi_restore b12
	.cfi_restore b13
	.cfi_restore b14
	.cfi_restore b15
	ret
LBB11_109:
	.cfi_restore_state
	ldr	d1, [sp, #304]
	fcmp	d1, #0.0
	b.pl	LBB11_111
	mov	w8, #511
	b	LBB11_115
LBB11_111:
	fcmp	d0, #0.0
	b.ne	LBB11_114
	fcmp	d1, #0.0
	b.ne	LBB11_114
	mov	w8, #767
	b	LBB11_115
LBB11_114:
	mov	w8, #1023
LBB11_115:
	strh	w8, [x19]
	b	LBB11_108
	.cfi_endproc

	.globl	__RNvCs7wsLvUT6iAW_13codegen_audit13norm_squared3
	.p2align	2
__RNvCs7wsLvUT6iAW_13codegen_audit13norm_squared3:
	.cfi_startproc
	movi.2d	v0, #0000000000000000
	ldp	d1, d2, [x0]
	fmadd	d1, d1, d1, d0
	fmadd	d0, d2, d2, d1
	ldr	d2, [x0, #16]
	fmadd	d2, d2, d2, d0
	fmov	x9, d2
	ubfx	x9, x9, #52, #11
	cmp	x9, #2047
	b.hs	LBB12_2
	str	d2, [x8, #8]
	mov	w9, #255
	strb	w9, [x8]
	ret
LBB12_2:
	fmov	x9, d1
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.ls	LBB12_4
	mov	x9, #0
	mov	w10, #3841
	strh	w10, [x8]
	mov	w10, #2
	strb	w10, [x8, #8]
	str	x9, [x8, #16]
	ret
LBB12_4:
	fmov	x9, d0
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.ls	LBB12_6
	mov	w9, #1
	mov	w10, #3841
	strh	w10, [x8]
	mov	w10, #2
	strb	w10, [x8, #8]
	str	x9, [x8, #16]
	ret
LBB12_6:
	mov	w9, #2
	mov	w10, #3841
	strh	w10, [x8]
	mov	w10, #2
	strb	w10, [x8, #8]
	str	x9, [x8, #16]
	ret
	.cfi_endproc

	.globl	__RNvCs7wsLvUT6iAW_13codegen_audit13norm_squared5
	.p2align	2
__RNvCs7wsLvUT6iAW_13codegen_audit13norm_squared5:
	.cfi_startproc
	movi.2d	v0, #0000000000000000
	ldp	d1, d2, [x0]
	fmadd	d0, d1, d1, d0
	fmadd	d0, d2, d2, d0
	ldp	d1, d2, [x0, #16]
	fmadd	d0, d1, d1, d0
	fmadd	d0, d2, d2, d0
	ldr	d1, [x0, #32]
	fmadd	d0, d1, d1, d0
	fmov	x9, d0
	ubfx	x9, x9, #52, #11
	cmp	x9, #2047
	b.hs	LBB13_2
	str	d0, [x8, #8]
	mov	w9, #255
	strb	w9, [x8]
	ret
LBB13_2:
	mov	x1, x0
	mov	x0, x8
	mov	x2, x1
	b	__RNvMs0_NtCshzmyaYQzAhy_8la_stack6vectorINtB5_6VectorKj5_E20dot_non_finite_errorCs7wsLvUT6iAW_13codegen_audit
	.cfi_endproc

	.globl	__RNvCs7wsLvUT6iAW_13codegen_audit14certified_dot4
	.p2align	2
__RNvCs7wsLvUT6iAW_13codegen_audit14certified_dot4:
	.cfi_startproc
	sub	sp, sp, #144
	.cfi_def_cfa_offset 144
	stp	x22, x21, [sp, #96]
	stp	x20, x19, [sp, #112]
	stp	x29, x30, [sp, #128]
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_remember_state
	mov	x20, x1
	mov	x21, x0
	mov	x19, x8
Lloh17:
	adrp	x8, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.2@PAGE
Lloh18:
	add	x8, x8, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.2@PAGEOFF
Lloh19:
	ldr	q0, [x8]
	str	q0, [sp, #64]
	mov	w8, #1
	str	x8, [sp, #80]
	add	x22, sp, #8
	ldr	d0, [x0]
	ldr	d1, [x1]
	add	x8, sp, #8
	add	x0, sp, #64
	mov	x2, #0
	mov	w1, #13
	bl	__RNvMs_NtCshzmyaYQzAhy_8la_stack6vectorNtB4_18CertifiedReduction11add_product
	ldrb	w8, [sp, #8]
	cmp	w8, #255
	b.ne	LBB14_4
	ldur	q0, [x22, #8]
	str	q0, [sp, #64]
	ldur	x8, [x22, #24]
	str	x8, [sp, #80]
	ldr	d0, [x21, #8]
	ldr	d1, [x20, #8]
	add	x8, sp, #8
	add	x0, sp, #64
	mov	w1, #13
	mov	w2, #1
	bl	__RNvMs_NtCshzmyaYQzAhy_8la_stack6vectorNtB4_18CertifiedReduction11add_product
	ldrb	w8, [sp, #8]
	cmp	w8, #255
	b.ne	LBB14_4
	ldur	q0, [x22, #8]
	str	q0, [sp, #64]
	ldur	x8, [x22, #24]
	str	x8, [sp, #80]
	ldr	d0, [x21, #16]
	ldr	d1, [x20, #16]
	add	x8, sp, #8
	add	x0, sp, #64
	mov	w1, #13
	mov	w2, #2
	bl	__RNvMs_NtCshzmyaYQzAhy_8la_stack6vectorNtB4_18CertifiedReduction11add_product
	ldrb	w8, [sp, #8]
	cmp	w8, #255
	b.ne	LBB14_4
	ldur	q0, [x22, #8]
	str	q0, [sp, #64]
	ldur	x8, [x22, #24]
	str	x8, [sp, #80]
	ldr	d0, [x21, #24]
	ldr	d1, [x20, #24]
	add	x8, sp, #8
	add	x0, sp, #64
	mov	w1, #13
	mov	w2, #3
	bl	__RNvMs_NtCshzmyaYQzAhy_8la_stack6vectorNtB4_18CertifiedReduction11add_product
	ldrb	w8, [sp, #8]
	cmp	w8, #255
	b.eq	LBB14_6
LBB14_4:
	ldur	q0, [sp, #8]
	ldur	q1, [sp, #24]
	stp	q0, q1, [x19]
	ldur	q0, [sp, #40]
	str	q0, [x19, #32]
	ldr	x8, [sp, #56]
	str	x8, [x19, #48]
LBB14_5:
	.cfi_def_cfa wsp, 144
	ldp	x29, x30, [sp, #128]
	ldp	x20, x19, [sp, #112]
	ldp	x22, x21, [sp, #96]
	add	sp, sp, #144
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	ret
LBB14_6:
	.cfi_restore_state
	ldur	q0, [x22, #8]
	str	q0, [sp, #64]
	ldur	x8, [x22, #24]
	str	x8, [sp, #80]
	add	x8, x19, #8
	add	x0, sp, #64
	mov	w1, #1
	mov	w2, #4
	bl	__RNvMs_NtCshzmyaYQzAhy_8la_stack6vectorNtB4_18CertifiedReduction6finish
	mov	w8, #255
	strb	w8, [x19]
	b	LBB14_5
	.loh AdrpAddLdr	Lloh17, Lloh18, Lloh19
	.cfi_endproc

	.globl	__RNvCs7wsLvUT6iAW_13codegen_audit15rational_solve5
	.p2align	2
__RNvCs7wsLvUT6iAW_13codegen_audit15rational_solve5:
Lfunc_begin2:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception2
	stp	x28, x27, [sp, #-96]!
	.cfi_def_cfa_offset 96
	stp	x26, x25, [sp, #16]
	stp	x24, x23, [sp, #32]
	stp	x22, x21, [sp, #48]
	stp	x20, x19, [sp, #64]
	stp	x29, x30, [sp, #80]
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_remember_state
	sub	sp, sp, #3232
	ldr	xzr, [sp]
	mov	x20, x1
	mov	x21, x0
	str	x8, [sp]
	mov	x19, #0
	mov	x23, #0
	mov	x22, #0
	add	x24, sp, #368
	add	x25, sp, #2432
	add	x26, sp, #1328
	mov	w28, #1
	str	x1, [sp, #200]
LBB15_1:
	add	x27, x21, x23
	mov	x8, #-1
	str	x8, [sp, #1328]
	str	x28, [sp, #1336]
	str	x28, [sp, #1344]
	mov	w8, #2
	strb	w8, [sp, #1352]
	ldr	q0, [sp, #1328]
	ldr	q1, [sp, #1344]
	stp	q0, q1, [sp, #368]
	str	x27, [sp, #400]
Ltmp51:
	add	x8, sp, #1328
	add	x0, sp, #368
	add	x1, x27, #32
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8rational21least_common_multiple
Ltmp52:
	ldr	q0, [sp, #1328]
	ldr	q1, [sp, #1344]
	stp	q0, q1, [sp, #368]
	add	x8, x27, #64
	str	x8, [sp, #400]
Ltmp53:
	add	x8, sp, #1328
	add	x0, sp, #368
	add	x1, x27, #96
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8rational21least_common_multiple
Ltmp54:
	ldr	q0, [sp, #1328]
	ldr	q1, [sp, #1344]
	stp	q0, q1, [sp, #368]
	add	x27, x21, x23
	add	x8, x27, #128
	str	x8, [sp, #400]
Ltmp55:
	add	x8, sp, #1328
	add	x0, sp, #368
	add	x1, x27, #160
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8rational21least_common_multiple
Ltmp56:
	ldr	q0, [sp, #1328]
	ldr	q1, [sp, #1344]
	stp	q0, q1, [sp, #368]
	add	x8, x27, #192
	str	x8, [sp, #400]
Ltmp57:
	add	x8, sp, #1328
	add	x0, sp, #368
	add	x1, x27, #224
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8rational21least_common_multiple
Ltmp58:
	ldr	q0, [sp, #1328]
	ldr	q1, [sp, #1344]
	stp	q0, q1, [sp, #368]
	add	x9, x21, x23
	add	x8, x9, #256
	str	x8, [sp, #400]
Ltmp59:
	add	x8, sp, #1328
	add	x0, sp, #368
	add	x1, x9, #288
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8rational21least_common_multiple
Ltmp60:
	ldr	q0, [sp, #1328]
	ldr	x8, [sp, #1344]
	ldrb	w9, [sp, #1352]
	str	x8, [sp, #384]
	strb	w9, [sp, #392]
	ldur	w8, [x26, #25]
	stur	w8, [x24, #25]
	ldur	w8, [x26, #28]
	stur	w8, [x24, #28]
	str	q0, [sp, #368]
	str	x20, [sp, #400]
Ltmp61:
	add	x8, sp, #2432
	add	x0, sp, #368
	add	x1, x20, #32
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8rational21least_common_multiple
Ltmp62:
	ldr	q0, [sp, #2432]
	ldr	x8, [sp, #2448]
	ldrb	w9, [sp, #2456]
	ldur	w10, [x25, #25]
	str	w10, [sp, #368]
	ldur	w10, [x25, #28]
	stur	w10, [x24, #3]
	add	x10, sp, #1632
	add	x10, x10, x19
	str	q0, [x10]
	str	x8, [x10, #16]
	strb	w9, [x10, #24]
	ldr	w8, [sp, #368]
	ldur	w9, [x24, #3]
	str	w9, [x10, #28]
	stur	w8, [x10, #25]
	add	x22, x22, #1
	add	x23, x23, #320
	add	x19, x19, #32
	add	x20, x20, #64
	cmp	x23, #1600
	b.ne	LBB15_1
	mov	x19, #0
	mov	x22, #0
	ldr	q0, [sp, #1760]
	ldr	q1, [sp, #1776]
	stp	q0, q1, [sp, #336]
	ldr	q0, [sp, #1696]
	ldr	q1, [sp, #1712]
	stp	q0, q1, [sp, #272]
	ldr	q0, [sp, #1728]
	ldr	q1, [sp, #1744]
	stp	q0, q1, [sp, #304]
	ldr	q0, [sp, #1632]
	ldr	q1, [sp, #1648]
	stp	q0, q1, [sp, #208]
	ldr	q0, [sp, #1664]
	ldr	q1, [sp, #1680]
	add	x25, sp, #368
	add	x26, sp, #1632
	add	x23, sp, #208
	stp	q0, q1, [sp, #240]
LBB15_9:
	add	x20, x21, x19
Ltmp64:
	mov	x24, #0
	add	x8, sp, #1328
	add	x0, x21, x19
	mov	x1, x23
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8rational16integer_at_scale
Ltmp65:
	ldr	q0, [sp, #1344]
	ldr	q1, [sp, #1328]
	str	q1, [sp, #2432]
	str	q0, [sp, #2448]
	stp	q1, q0, [sp, #368]
Ltmp66:
	add	x8, sp, #1328
	add	x0, x20, #64
	mov	w24, #1
	mov	x1, x23
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8rational16integer_at_scale
Ltmp67:
	ldr	q0, [sp, #1344]
	ldr	q1, [sp, #1328]
	str	q1, [sp, #2432]
	str	q0, [sp, #2448]
	stp	q1, q0, [x25, #32]
	add	x20, x21, x19
Ltmp68:
	add	x8, sp, #1328
	add	x0, x20, #128
	mov	w24, #2
	mov	x1, x23
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8rational16integer_at_scale
Ltmp69:
	ldr	q0, [sp, #1344]
	ldr	q1, [sp, #1328]
	str	q1, [sp, #2432]
	str	q0, [sp, #2448]
	stp	q1, q0, [x25, #64]
Ltmp70:
	add	x8, sp, #1328
	add	x0, x20, #192
	mov	w24, #3
	mov	x1, x23
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8rational16integer_at_scale
Ltmp71:
	ldr	q0, [sp, #1344]
	ldr	q1, [sp, #1328]
	str	q1, [sp, #2432]
	str	q0, [sp, #2448]
	stp	q1, q0, [x25, #96]
	add	x9, x21, x19
Ltmp72:
	add	x8, sp, #1328
	add	x0, x9, #256
	mov	w24, #4
	mov	x1, x23
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8rational16integer_at_scale
Ltmp73:
	ldr	q0, [sp, #1344]
	ldr	q1, [sp, #1328]
	str	q1, [sp, #2432]
	str	q0, [sp, #2448]
	stp	q1, q0, [x25, #128]
	ldp	q0, q1, [sp, #496]
	str	q0, [sp, #2560]
	str	q1, [sp, #2576]
	ldp	q0, q1, [sp, #432]
	str	q0, [sp, #2496]
	str	q1, [sp, #2512]
	ldp	q1, q2, [sp, #464]
	str	q1, [sp, #2528]
	str	q2, [sp, #2544]
	ldp	q1, q2, [sp, #368]
	str	q1, [sp, #2432]
	str	q2, [sp, #2448]
	ldp	q2, q3, [sp, #400]
	str	q2, [sp, #2464]
	str	q3, [sp, #2480]
	ldr	q2, [sp, #2560]
	ldr	q3, [sp, #2576]
	stp	q2, q3, [x26, #128]
	ldr	q2, [sp, #2512]
	ldr	q3, [sp, #2480]
	stp	q0, q2, [x26, #64]
	ldr	q0, [sp, #2528]
	ldr	q2, [sp, #2544]
	stp	q0, q2, [x26, #96]
	ldr	q0, [sp, #2448]
	ldr	q2, [sp, #2464]
	stp	q1, q0, [x26]
	add	x22, x22, #1
	add	x19, x19, #320
	stp	q2, q3, [x26, #32]
	add	x26, x26, #160
	add	x23, x23, #32
	cmp	x19, #1600
	b.ne	LBB15_9
	add	x0, sp, #368
	add	x1, sp, #1632
	mov	w2, #800
	bl	_memcpy
Ltmp75:
	mov	x21, #0
	add	x19, sp, #208
	add	x8, sp, #1328
	add	x1, sp, #208
	ldr	x20, [sp, #200]
	mov	x0, x20
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8rational16integer_at_scale
Ltmp76:
	ldr	q0, [sp, #1344]
	ldr	q1, [sp, #1328]
	str	q1, [sp, #2432]
	str	q0, [sp, #2448]
	str	q0, [sp, #1648]
	str	q1, [sp, #1632]
	mov	w21, #1
Ltmp77:
	add	x8, sp, #1328
	add	x0, x20, #64
	add	x1, x19, #32
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8rational16integer_at_scale
Ltmp78:
	ldr	q0, [sp, #1344]
	ldr	q1, [sp, #1328]
	str	q1, [sp, #2432]
	str	q0, [sp, #2448]
	str	q0, [sp, #1680]
	str	q1, [sp, #1664]
	add	x19, sp, #208
	mov	w21, #2
Ltmp79:
	add	x8, sp, #1328
	add	x0, x20, #128
	add	x1, x19, #64
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8rational16integer_at_scale
Ltmp80:
	ldr	q0, [sp, #1344]
	ldr	q1, [sp, #1328]
	str	q1, [sp, #2432]
	str	q0, [sp, #2448]
	str	q0, [sp, #1712]
	str	q1, [sp, #1696]
	mov	w21, #3
Ltmp81:
	add	x8, sp, #1328
	add	x0, x20, #192
	add	x1, x19, #96
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8rational16integer_at_scale
Ltmp82:
	ldr	q0, [sp, #1344]
	ldr	q1, [sp, #1328]
	str	q1, [sp, #2432]
	str	q0, [sp, #2448]
	str	q0, [sp, #1744]
	str	q1, [sp, #1728]
	add	x9, sp, #208
	mov	w21, #4
Ltmp83:
	add	x8, sp, #1328
	add	x0, x20, #256
	add	x1, x9, #128
	bl	__RNvNtCshzmyaYQzAhy_8la_stack8rational16integer_at_scale
Ltmp84:
	ldr	q0, [sp, #1328]
	ldr	q1, [sp, #1344]
	str	q1, [sp, #1776]
	str	q0, [sp, #1760]
	str	q0, [sp, #1296]
	str	q1, [sp, #1312]
	ldr	q0, [sp, #1632]
	ldr	q1, [sp, #1648]
	ldr	q2, [sp, #1664]
	ldr	q3, [sp, #1680]
	str	q3, [sp, #1216]
	str	q2, [sp, #1200]
	str	q1, [sp, #1184]
	str	q0, [sp, #1168]
	ldr	q0, [sp, #1696]
	ldr	q1, [sp, #1712]
	ldr	q2, [sp, #1728]
	ldr	q3, [sp, #1744]
	str	q3, [sp, #1280]
	str	q2, [sp, #1264]
	str	q1, [sp, #1248]
	str	q0, [sp, #1232]
	add	x0, sp, #1632
	add	x1, sp, #368
	mov	w2, #800
	bl	_memcpy
Ltmp86:
	add	x0, sp, #2432
	add	x1, sp, #1632
	add	x2, sp, #1168
	bl	__RINvNtCshzmyaYQzAhy_8la_stack5exact25bareiss_forward_eliminateKj5_ECs7wsLvUT6iAW_13codegen_audit
Ltmp87:
	add	x26, sp, #2944
	ldrb	w8, [sp, #2432]
	tbnz	w8, #0, LBB15_323
	mov	x9, #-1
	adrp	x8, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.0@PAGE+16
	add	x8, x8, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.0@PAGEOFF+16
	str	x9, [sp, #2432]
	str	xzr, [sp, #2440]
	ldr	q0, [x8]
Lloh20:
	adrp	x8, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.3@PAGE
Lloh21:
	add	x8, x8, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.3@PAGEOFF
	ldp	q1, q2, [x8]
	str	q0, [sp, #2448]
	str	q1, [sp, #2464]
	str	q2, [sp, #2480]
	str	x9, [sp, #2496]
	str	xzr, [sp, #2504]
	str	q0, [sp, #2512]
	str	q1, [sp, #2528]
	str	q2, [sp, #2544]
	str	x9, [sp, #2560]
	str	xzr, [sp, #2568]
	str	q2, [sp, #2608]
	str	q0, [sp, #2576]
	str	q1, [sp, #2592]
	add	x27, sp, #2752
	str	x9, [sp, #2624]
	str	xzr, [sp, #2632]
	add	x8, sp, #2944
	add	x10, sp, #3008
	str	q2, [sp, #2672]
	add	x11, sp, #1328
	add	x12, sp, #2880
	add	x13, x27, #48
	add	x12, x12, #48
	stp	x12, x13, [sp, #24]
	str	q0, [sp, #2640]
	str	q1, [sp, #2656]
	add	x8, x8, #16
	str	x8, [sp, #48]
	add	x8, x10, #16
	str	x8, [sp, #8]
	add	x8, x11, #16
	str	x8, [sp, #16]
	mov	w21, #5
	str	x9, [sp, #2688]
	str	xzr, [sp, #2696]
	stp	q2, q1, [sp, #96]
	str	q2, [sp, #2736]
Lloh22:
	adrp	x8, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.0@PAGE
Lloh23:
	add	x8, x8, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.0@PAGEOFF
	ldp	q3, q2, [x8]
	stp	q2, q3, [sp, #128]
	str	q0, [sp, #2704]
	str	q1, [sp, #2720]
	b	LBB15_24
LBB15_23:
	ldr	x8, [sp, #40]
	mov	x21, x8
	add	x26, sp, #2944
	cbz	x8, LBB15_300
LBB15_24:
	sub	x10, x21, #1
	add	x8, sp, #1168
	sub	x9, x21, #1
	str	x9, [sp, #40]
	add	x8, x8, x10, lsl #5
	ldp	x9, x10, [x8]
	ldr	q3, [x8, #16]
	ldp	q1, q2, [sp, #128]
	stp	q2, q1, [x8]
	str	x9, [sp, #2752]
	str	x10, [sp, #2760]
	ldp	q0, q1, [sp, #96]
	stp	q3, q1, [x27, #16]
	stur	q0, [x27, #48]
	cmp	x21, #5
	b.hs	LBB15_241
	mov	w8, #160
	add	x9, sp, #1632
	sub	x10, x21, #1
	madd	x8, x10, x8, x9
	str	x8, [sp, #88]
	b	LBB15_27
LBB15_26:
	add	x21, x21, #1
	cmp	x21, #5
	b.eq	LBB15_241
LBB15_27:
	ldr	x8, [sp, #88]
	add	x8, x8, x21, lsl #5
	ldp	x9, x23, [x8]
	ldr	q3, [x8, #16]
	ldp	q2, q1, [sp, #128]
	stp	q1, q2, [x8]
	str	x9, [sp, #2816]
	str	x23, [sp, #2824]
	add	x8, sp, #2816
	ldp	q0, q1, [sp, #96]
	stp	q3, q1, [x8, #16]
	stur	q0, [x8, #48]
	ldrb	w19, [sp, #2840]
	ldr	x20, [sp, #2832]
	str	x9, [sp, #176]
	cmn	x9, #1
	b.eq	LBB15_31
	cbz	x20, LBB15_32
	cmp	x20, #1
	b.ne	LBB15_33
	ldr	x20, [x23]
	mov	x24, #-1
	mov	w25, #1
	b	LBB15_35
LBB15_31:
	mov	x24, #-1
	mov	x25, x23
	b	LBB15_35
LBB15_32:
	mov	x24, #-1
	mov	x25, x20
	b	LBB15_35
LBB15_33:
	lsl	x22, x20, #3
	bl	__RNvCsdtSMxSA38aw_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	x0, x22
	mov	w1, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc12___rust_alloc
	cbz	x0, LBB15_325
	mov	x25, x0
	mov	x1, x23
	mov	x2, x22
	bl	_memcpy
	mov	x24, x20
LBB15_35:
	add	x8, sp, #2432
	stp	x21, x23, [sp, #184]
	add	x21, x8, x21, lsl #6
	str	x24, [sp, #2944]
	str	x25, [sp, #2952]
	str	x20, [sp, #2960]
	strb	w19, [sp, #2968]
	mov	x8, #-1
	str	x8, [sp, #2976]
	mov	w8, #1
	str	x8, [sp, #2984]
	str	x8, [sp, #2992]
	mov	w8, #2
	strb	w8, [sp, #3000]
	ldrb	w19, [x21, #24]
	ldr	x8, [x21]
	ldr	x20, [x21, #16]
	cmn	x8, #1
	str	x24, [sp, #168]
	b.eq	LBB15_40
	cbz	x20, LBB15_44
	ldr	x23, [x21, #8]
	cmp	x20, #1
	b.ne	LBB15_45
	ldr	x20, [x23]
	mov	x8, #-1
	str	x8, [sp, #200]
	mov	w28, #1
	ldrb	w22, [x21, #56]
	ldr	x8, [x21, #32]
	ldr	x23, [x21, #48]
	cmn	x8, #1
	b.ne	LBB15_41
LBB15_39:
	ldr	x9, [x21, #40]
	mov	x21, #-1
	b	LBB15_50
LBB15_40:
	ldr	x28, [x21, #8]
	str	x8, [sp, #200]
	ldrb	w22, [x21, #56]
	ldr	x8, [x21, #32]
	ldr	x23, [x21, #48]
	cmn	x8, #1
	b.eq	LBB15_39
LBB15_41:
	cbz	x23, LBB15_47
	ldr	x24, [x21, #40]
	cmp	x23, #1
	b.ne	LBB15_48
	ldr	x23, [x24]
	mov	x21, #-1
	mov	w9, #1
	ldr	x24, [sp, #168]
	b	LBB15_50
LBB15_44:
	mov	x8, #-1
	str	x8, [sp, #200]
	mov	x28, x20
	ldrb	w22, [x21, #56]
	ldr	x8, [x21, #32]
	ldr	x23, [x21, #48]
	cmn	x8, #1
	b.ne	LBB15_41
	b	LBB15_39
LBB15_45:
	lsl	x24, x20, #3
	bl	__RNvCsdtSMxSA38aw_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	x0, x24
	mov	w1, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc12___rust_alloc
	cbz	x0, LBB15_326
	mov	x28, x0
	mov	x1, x23
	mov	x2, x24
	bl	_memcpy
	str	x20, [sp, #200]
	ldr	x24, [sp, #168]
	ldrb	w22, [x21, #56]
	ldr	x8, [x21, #32]
	ldr	x23, [x21, #48]
	cmn	x8, #1
	b.ne	LBB15_41
	b	LBB15_39
LBB15_47:
	mov	x21, #-1
	mov	x9, x23
	b	LBB15_50
LBB15_48:
	mov	x21, x25
	lsl	x25, x23, #3
	bl	__RNvCsdtSMxSA38aw_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	x0, x25
	mov	w1, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc12___rust_alloc
	cbz	x0, LBB15_328
	mov	x26, x0
	mov	x1, x24
	mov	x2, x25
	bl	_memcpy
	mov	x9, x26
	mov	x25, x21
	mov	x21, x23
	ldr	x24, [sp, #168]
	add	x26, sp, #2944
LBB15_50:
	ldr	x8, [sp, #200]
	str	x8, [sp, #3008]
	str	x28, [sp, #56]
	str	x28, [sp, #3016]
	str	x20, [sp, #3024]
	strb	w19, [sp, #3032]
	str	x21, [sp, #3040]
	stp	x9, x21, [sp, #72]
	str	x9, [sp, #3048]
	str	x23, [sp, #3056]
	strb	w22, [sp, #3064]
Ltmp98:
	add	x0, sp, #1328
	add	x1, sp, #2944
	add	x8, sp, #3008
	add	x2, x8, #32
	bl	__RNvXsh_NtCs70jQWIuBJri_10num_bigint7biguintNtB5_7BigUintNtCs5ZU5g2vqbRJ_11num_integer7Integer3gcd
Ltmp99:
	ldr	x19, [sp, #1328]
	cmn	x19, #1
	b.eq	LBB15_54
	ldr	x22, [sp, #1344]
	cbz	x22, LBB15_56
	mov	w21, #2
	ldr	x24, [sp, #1336]
	b	LBB15_61
LBB15_54:
	ldr	x8, [sp, #1336]
	cbz	x8, LBB15_59
	mov	x19, #-1
	mov	w21, #2
	ldr	x22, [sp, #1344]
	mov	w24, #1
	b	LBB15_61
LBB15_56:
	stur	wzr, [x26, #131]
	stur	wzr, [x29, #-240]
	cbz	x19, LBB15_58
	ldr	x0, [sp, #1336]
	lsl	x1, x19, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_58:
	mov	x24, #0
	b	LBB15_60
LBB15_59:
	mov	x24, #0
	stur	wzr, [x26, #131]
	stur	wzr, [x29, #-240]
LBB15_60:
	mov	x19, #-1
	mov	w21, #1
LBB15_61:
Ltmp101:
	add	x0, sp, #1328
	add	x8, sp, #2944
	add	x1, x8, #32
	add	x2, sp, #3008
	bl	__RNvXsh_NtCs70jQWIuBJri_10num_bigint7biguintNtB5_7BigUintNtCs5ZU5g2vqbRJ_11num_integer7Integer3gcd
Ltmp102:
	ldr	x20, [sp, #1328]
	cmn	x20, #1
	str	x25, [sp, #64]
	b.eq	LBB15_66
	ldr	x28, [sp, #1344]
	cbz	x28, LBB15_68
	mov	w23, #2
	ldr	x25, [sp, #1336]
	ldr	q0, [sp, #2944]
	ldr	q1, [sp, #2960]
	stp	q0, q1, [x29, #-128]
	cmn	x19, #1
	b.ne	LBB15_73
LBB15_65:
	mov	x9, #-1
	mov	x8, x22
	mov	x26, x24
	b	LBB15_79
LBB15_66:
	ldr	x8, [sp, #1336]
	cbz	x8, LBB15_71
	mov	x20, #-1
	mov	w23, #2
	ldr	x28, [sp, #1344]
	mov	w25, #1
	ldr	q0, [sp, #2944]
	ldr	q1, [sp, #2960]
	stp	q0, q1, [x29, #-128]
	cmn	x19, #1
	b.ne	LBB15_73
	b	LBB15_65
LBB15_68:
	stur	wzr, [x26, #139]
	stur	wzr, [x29, #-232]
	cbz	x20, LBB15_70
	ldr	x0, [sp, #1336]
	lsl	x1, x20, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_70:
	mov	x25, #0
	b	LBB15_72
LBB15_71:
	mov	x25, #0
	stur	wzr, [x26, #139]
	stur	wzr, [x29, #-232]
LBB15_72:
	mov	x20, #-1
	mov	w23, #1
	ldr	q0, [sp, #2944]
	ldr	q1, [sp, #2960]
	stp	q0, q1, [x29, #-128]
	cmn	x19, #1
	b.eq	LBB15_65
LBB15_73:
	cbz	x22, LBB15_76
	cmp	x22, #1
	b.ne	LBB15_77
	ldr	x8, [x24]
	mov	x9, #-1
	mov	w26, #1
	b	LBB15_79
LBB15_76:
	mov	x9, #-1
	mov	x26, x22
	b	LBB15_79
LBB15_77:
	lsl	x27, x22, #3
	bl	__RNvCsdtSMxSA38aw_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	x0, x27
	mov	w1, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc12___rust_alloc
	cbz	x0, LBB15_327
	mov	x26, x0
	mov	x1, x24
	mov	x2, x27
	bl	_memcpy
	mov	x8, x22
	mov	x9, x22
	add	x27, sp, #2752
LBB15_79:
	strb	w21, [sp, #1352]
	str	x9, [sp, #1328]
	str	x26, [sp, #1336]
	str	x8, [sp, #1344]
Ltmp107:
	sub	x0, x29, #192
	sub	x1, x29, #128
	add	x2, sp, #1328
	bl	__RNvXsF_NtNtCs70jQWIuBJri_10num_bigint6bigint8divisionNtB7_6BigIntNtNtNtCsjIpoRzUjyHQ_4core3ops5arith3Div3div
Ltmp108:
	ldr	q0, [sp, #3008]
	ldr	q1, [sp, #3024]
	stp	q0, q1, [x29, #-128]
	cmn	x20, #1
	b.eq	LBB15_84
	cbz	x28, LBB15_85
	cmp	x28, #1
	b.ne	LBB15_86
	ldr	x8, [x25]
	mov	x9, #-1
	mov	w26, #1
	b	LBB15_88
LBB15_84:
	mov	x9, #-1
	mov	x8, x28
	mov	x26, x25
	b	LBB15_88
LBB15_85:
	mov	x9, #-1
	mov	x26, x28
	b	LBB15_88
LBB15_86:
	lsl	x27, x28, #3
	bl	__RNvCsdtSMxSA38aw_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	x0, x27
	mov	w1, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc12___rust_alloc
	cbz	x0, LBB15_324
	mov	x26, x0
	mov	x1, x25
	mov	x2, x27
	bl	_memcpy
	mov	x8, x28
	mov	x9, x28
	add	x27, sp, #2752
LBB15_88:
	strb	w23, [sp, #1352]
	str	x9, [sp, #1328]
	str	x26, [sp, #1336]
	str	x8, [sp, #1344]
Ltmp113:
	sub	x0, x29, #160
	sub	x1, x29, #128
	add	x2, sp, #1328
	bl	__RNvXsF_NtNtCs70jQWIuBJri_10num_bigint6bigint8divisionNtB7_6BigIntNtNtNtCsjIpoRzUjyHQ_4core3ops5arith3Div3div
Ltmp114:
Ltmp116:
	sub	x0, x29, #224
	sub	x1, x29, #192
	sub	x2, x29, #160
	bl	__RNvXsc_NtNtCs70jQWIuBJri_10num_bigint6bigint14multiplicationNtB7_6BigIntNtNtNtCsjIpoRzUjyHQ_4core3ops5arith3Mul3mul
Ltmp117:
	add	x8, sp, #2944
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x29, #-128]
	str	x20, [sp, #1328]
	str	x25, [sp, #1336]
	str	x28, [sp, #1344]
	strb	w23, [sp, #1352]
	ldur	w8, [x29, #-232]
	add	x23, sp, #1328
	stur	w8, [x23, #25]
	add	x26, sp, #2944
	ldur	w8, [x26, #139]
	stur	w8, [x23, #28]
Ltmp119:
	sub	x0, x29, #192
	sub	x1, x29, #128
	add	x2, sp, #1328
	bl	__RNvXsF_NtNtCs70jQWIuBJri_10num_bigint6bigint8divisionNtB7_6BigIntNtNtNtCsjIpoRzUjyHQ_4core3ops5arith3Div3div
Ltmp120:
	add	x8, sp, #3008
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x29, #-128]
	str	x19, [sp, #1328]
	str	x24, [sp, #1336]
	str	x22, [sp, #1344]
	strb	w21, [sp, #1352]
	ldur	w8, [x29, #-240]
	stur	w8, [x23, #25]
	ldur	w8, [x26, #131]
	stur	w8, [x23, #28]
Ltmp122:
	sub	x0, x29, #160
	sub	x1, x29, #128
	add	x2, sp, #1328
	bl	__RNvXsF_NtNtCs70jQWIuBJri_10num_bigint6bigint8divisionNtB7_6BigIntNtNtNtCsjIpoRzUjyHQ_4core3ops5arith3Div3div
Ltmp123:
Ltmp125:
	sub	x0, x29, #128
	sub	x1, x29, #192
	sub	x2, x29, #160
	bl	__RNvXsc_NtNtCs70jQWIuBJri_10num_bigint6bigint14multiplicationNtB7_6BigIntNtNtNtCsjIpoRzUjyHQ_4core3ops5arith3Mul3mul
Ltmp126:
	ldp	q0, q1, [x29, #-224]
	str	q0, [sp, #1328]
	str	q1, [sp, #1344]
	ldp	q0, q1, [x29, #-128]
	stp	q0, q1, [x23, #32]
Ltmp128:
	add	x0, sp, #1328
	bl	__RNvMs_CsjLaZ3GaS80H_12num_rationalINtB4_5RatioNtNtCs70jQWIuBJri_10num_bigint6bigint6BigIntE6reduceCs7wsLvUT6iAW_13codegen_audit
Ltmp129:
	ldr	q0, [sp, #1328]
	ldr	q1, [sp, #1344]
	str	q0, [sp, #2880]
	str	q1, [sp, #2896]
	ldr	q0, [sp, #1376]
	ldr	q1, [sp, #1360]
	str	q0, [sp, #2928]
	str	q1, [sp, #2912]
	ldrb	w8, [sp, #2808]
	ldrb	w9, [sp, #2936]
	cmp	w8, w9
	b.ne	LBB15_98
	cmp	w8, #1
	b.ne	LBB15_104
LBB15_96:
	ldr	q0, [sp, #2896]
	ldr	q1, [sp, #2880]
	str	q0, [sp, #3024]
	str	q1, [sp, #3008]
	ldr	q0, [sp, #2752]
	ldr	q1, [sp, #2768]
	str	q0, [sp, #1328]
	str	q1, [sp, #1344]
	ldp	q0, q1, [sp, #128]
	str	q1, [sp, #2752]
	str	q0, [sp, #2768]
	ldrb	w25, [sp, #3032]
	cmp	w25, #1
	b.ne	LBB15_106
	ldr	x19, [sp, #1328]
	ldr	x21, [sp, #1336]
	ldr	x24, [sp, #1344]
	ldrb	w20, [sp, #1352]
	ldur	w8, [x23, #25]
	str	w8, [sp, #2944]
	ldur	w8, [x23, #28]
	stur	w8, [x26, #3]
	ldr	x23, [sp, #192]
	b	LBB15_234
LBB15_98:
	ldr	x19, [sp, #2784]
LBB15_99:
	cmn	x19, #1
	b.eq	LBB15_101
	ldr	x8, [sp, #2800]
	cbnz	x8, LBB15_113
	b	LBB15_102
LBB15_101:
	ldr	x8, [sp, #2792]
	cbnz	x8, LBB15_113
LBB15_102:
	ldr	x8, [sp, #2912]
	cmn	x8, #1
	b.eq	LBB15_112
	ldr	x8, [sp, #2928]
	cbnz	x8, LBB15_113
	b	LBB15_141
LBB15_104:
	ldr	x19, [sp, #2784]
	ldr	x8, [sp, #2792]
	ldr	x9, [sp, #2800]
	cmn	x19, #1
	csel	x9, x8, x9, eq
	ldr	x10, [sp, #2912]
	ldr	x11, [sp, #2920]
	ldr	x12, [sp, #2928]
	cmn	x10, #1
	csel	x12, x11, x12, eq
	cmp	x9, x12
	b.ne	LBB15_99
	tst	w11, #0x1
	ldr	x12, [sp, #24]
	mov	w13, #8
	csel	x12, x12, x13, ne
	cmn	x10, #1
	csel	x1, x12, x11, eq
	tst	w8, #0x1
	ldr	x10, [sp, #32]
	csel	x10, x10, x13, ne
	cmn	x19, #1
	csel	x0, x10, x8, eq
	lsl	x2, x9, #3
	bl	_memcmp
	cbnz	w0, LBB15_99
	b	LBB15_96
LBB15_106:
	ldrb	w20, [sp, #1352]
	cbz	w20, LBB15_189
	cmp	w20, #1
	ldr	x23, [sp, #192]
	b.ne	LBB15_193
	ldr	x19, [sp, #3008]
	ldr	x24, [sp, #3024]
	cmn	x19, #1
	b.eq	LBB15_207
	cbz	x24, LBB15_220
	mov	x20, x23
	ldr	x23, [sp, #3016]
	cmp	x24, #1
	b.ne	LBB15_221
	ldr	x24, [x23]
	mov	x19, #-1
	mov	w21, #1
	mov	x23, x20
	mov	w8, #2
	sub	w20, w8, w25
	ldr	x8, [sp, #1328]
	cmp	x8, #1
	b.ge	LBB15_223
	b	LBB15_234
LBB15_112:
	ldr	w8, [sp, #2920]
	tbz	w8, #0, LBB15_141
LBB15_113:
Ltmp131:
	add	x0, sp, #3008
	add	x1, x27, #32
	add	x8, sp, #2880
	add	x2, x8, #32
	bl	__RNvXsh_NtCs70jQWIuBJri_10num_bigint7biguintNtB5_7BigUintNtCs5ZU5g2vqbRJ_11num_integer7Integer3gcd
Ltmp132:
Ltmp134:
	add	x8, sp, #1328
	add	x0, x27, #32
	add	x1, sp, #3008
	bl	__RNvNtNtCs70jQWIuBJri_10num_bigint7biguint8division11div_rem_ref
Ltmp135:
	ldr	x19, [sp, #1328]
	ldr	x21, [sp, #1336]
	ldr	x20, [sp, #1344]
	ldr	x8, [sp, #1352]
	cmp	x8, #1
	b.lt	LBB15_117
	ldr	x0, [sp, #1360]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_117:
	str	x19, [sp, #2944]
	str	x21, [sp, #2952]
	str	x20, [sp, #2960]
	ldr	x8, [sp, #3008]
	cmp	x8, #1
	b.lt	LBB15_119
	ldr	x0, [sp, #3016]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_119:
	tst	w21, #0x1
	ldr	x8, [sp, #48]
	mov	w9, #8
	csel	x8, x8, x9, ne
	cmn	x19, #1
	csel	x1, x21, x20, eq
	csel	x0, x8, x21, eq
	ldr	x8, [sp, #2912]
	cmn	x8, #1
	b.eq	LBB15_121
	ldr	x22, [sp, #2920]
	ldr	x3, [sp, #2928]
	mov	x23, x22
	mov	x2, x22
	cbnz	x1, LBB15_124
	b	LBB15_128
LBB15_121:
	ldr	x23, [sp, #2920]
	cbz	x23, LBB15_123
	mov	w22, #1
	mov	w3, #1
	add	x9, sp, #2880
	add	x2, x9, #48
	cbnz	x1, LBB15_124
	b	LBB15_128
LBB15_123:
	mov	x22, #0
	mov	x3, #0
	mov	w2, #8
	cbz	x1, LBB15_128
LBB15_124:
	cbz	x3, LBB15_128
	cmp	x3, #1
	b.ne	LBB15_183
	ldr	x1, [x2]
	ldr	q0, [sp, #2944]
	str	q0, [sp, #1328]
	ldr	x8, [sp, #2960]
	str	x8, [sp, #1344]
Ltmp137:
	add	x0, sp, #1328
	bl	__RNvNtNtCs70jQWIuBJri_10num_bigint7biguint14multiplication10scalar_mul
Ltmp138:
	ldr	q0, [sp, #1328]
	str	q0, [sp, #3008]
	ldr	x8, [sp, #1344]
	str	x8, [sp, #3024]
	b	LBB15_131
LBB15_128:
	str	xzr, [sp, #3024]
Lloh24:
	adrp	x8, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.1@PAGE
Lloh25:
	add	x8, x8, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.1@PAGEOFF
Lloh26:
	ldr	q0, [x8]
	str	q0, [sp, #3008]
LBB15_129:
	cmp	x19, #1
	b.lt	LBB15_131
	lsl	x1, x19, #3
	mov	x0, x21
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_131:
	ldr	x9, [sp, #3008]
	cmn	x9, #1
	b.eq	LBB15_134
	ldr	x27, [sp, #3024]
	cbz	x27, LBB15_145
	mov	w20, #2
	ldr	x8, [sp, #3016]
	b	LBB15_136
LBB15_134:
	ldr	x8, [sp, #3016]
	cmp	x8, #1
	b.ne	LBB15_141
	mov	x9, #-1
	mov	w20, #2
	ldr	x27, [sp, #3024]
LBB15_136:
	str	x8, [sp, #200]
	ldrb	w25, [sp, #2776]
	ldr	x8, [sp, #2752]
	ldr	x21, [sp, #2768]
	cmn	x8, #1
	str	x9, [sp, #168]
	b.ne	LBB15_149
LBB15_137:
	mov	x19, #-1
	ldr	x22, [sp, #2760]
	sturb	w25, [x29, #-104]
	stp	x19, x22, [x29, #-128]
	stur	x21, [x29, #-112]
	cmn	x9, #1
	str	x19, [sp, #80]
	b.eq	LBB15_152
LBB15_138:
	ldr	x25, [sp, #200]
	cbz	x27, LBB15_142
	cmp	x27, #1
	b.ne	LBB15_143
	ldr	x8, [x25]
	mov	x28, #-1
	mov	w23, #1
	b	LBB15_153
LBB15_141:
	str	xzr, [sp, #200]
	stur	wzr, [x26, #179]
	stur	wzr, [x29, #-192]
	b	LBB15_148
LBB15_142:
	mov	x28, #-1
	mov	x23, x27
	b	LBB15_153
LBB15_143:
	lsl	x24, x27, #3
	bl	__RNvCsdtSMxSA38aw_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	x0, x24
	mov	w1, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc12___rust_alloc
	cbz	x0, LBB15_329
	mov	x23, x0
	mov	x1, x25
	mov	x2, x24
	bl	_memcpy
	mov	x8, x27
	mov	x28, x27
	b	LBB15_153
LBB15_145:
	stur	wzr, [x26, #179]
	stur	wzr, [x29, #-192]
	cbz	x9, LBB15_147
	ldr	x0, [sp, #3016]
	lsl	x1, x9, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_147:
	str	xzr, [sp, #200]
LBB15_148:
	mov	x9, #-1
	mov	w20, #1
	ldrb	w25, [sp, #2776]
	ldr	x8, [sp, #2752]
	ldr	x21, [sp, #2768]
	cmn	x8, #1
	str	x9, [sp, #168]
	b.eq	LBB15_137
LBB15_149:
	cbz	x21, LBB15_158
	ldr	x23, [sp, #2760]
	cmp	x21, #1
	b.ne	LBB15_159
	ldr	x21, [x23]
	mov	x19, #-1
	mov	w22, #1
	sturb	w25, [x29, #-104]
	stp	x19, x22, [x29, #-128]
	stur	x21, [x29, #-112]
	cmn	x9, #1
	str	x19, [sp, #80]
	b.ne	LBB15_138
LBB15_152:
	mov	x28, #-1
	mov	x8, x27
	ldr	x25, [sp, #200]
	mov	x23, x25
LBB15_153:
	strb	w20, [sp, #3032]
	str	x28, [sp, #3008]
	str	x23, [sp, #3016]
	str	x8, [sp, #3024]
	ldrb	w21, [sp, #2808]
	ldr	x8, [sp, #2784]
	ldr	x19, [sp, #2800]
	cmn	x8, #1
	b.eq	LBB15_157
	cbz	x19, LBB15_161
	ldr	x25, [sp, #2792]
	cmp	x19, #1
	b.ne	LBB15_162
	ldr	x19, [x25]
	mov	x8, #-1
	mov	w24, #1
	b	LBB15_164
LBB15_157:
	ldr	x24, [sp, #2792]
	b	LBB15_165
LBB15_158:
	mov	x19, #-1
	mov	x22, x21
	sturb	w25, [x29, #-104]
	stp	x19, x21, [x29, #-128]
	stur	x21, [x29, #-112]
	cmn	x9, #1
	str	x19, [sp, #80]
	b.ne	LBB15_138
	b	LBB15_152
LBB15_159:
	lsl	x24, x21, #3
	bl	__RNvCsdtSMxSA38aw_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	x0, x24
	mov	w1, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc12___rust_alloc
	cbz	x0, LBB15_330
	mov	x22, x0
	mov	x1, x23
	mov	x2, x24
	bl	_memcpy
	mov	x19, x21
	ldr	x9, [sp, #168]
	sturb	w25, [x29, #-104]
	stp	x21, x22, [x29, #-128]
	stur	x21, [x29, #-112]
	cmn	x9, #1
	str	x21, [sp, #80]
	b.ne	LBB15_138
	b	LBB15_152
LBB15_161:
	mov	x8, #-1
	mov	x24, x19
	b	LBB15_165
LBB15_162:
	lsl	x26, x19, #3
	bl	__RNvCsdtSMxSA38aw_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	x0, x26
	mov	w1, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc12___rust_alloc
	cbz	x0, LBB15_331
	mov	x24, x0
	mov	x1, x25
	mov	x2, x26
	bl	_memcpy
	mov	x8, x19
	add	x26, sp, #2944
LBB15_164:
	ldr	x25, [sp, #200]
LBB15_165:
	strb	w21, [sp, #1352]
	str	x8, [sp, #1328]
	str	x24, [sp, #1336]
	str	x19, [sp, #1344]
Ltmp158:
	add	x0, sp, #2944
	add	x1, sp, #3008
	add	x2, sp, #1328
	bl	__RNvXsF_NtNtCs70jQWIuBJri_10num_bigint6bigint8divisionNtB7_6BigIntNtNtNtCsjIpoRzUjyHQ_4core3ops5arith3Div3div
Ltmp159:
	ldr	x23, [sp, #192]
Ltmp161:
	sub	x0, x29, #160
	sub	x1, x29, #128
	add	x2, sp, #2944
	ldr	x24, [sp, #168]
	bl	__RNvXsc_NtNtCs70jQWIuBJri_10num_bigint6bigint14multiplicationNtB7_6BigIntNtNtNtCsjIpoRzUjyHQ_4core3ops5arith3Mul3mul
Ltmp162:
	cmn	x24, #1
	b.eq	LBB15_171
	ldr	x21, [sp, #184]
	cbz	x27, LBB15_172
	cmp	x27, #1
	b.ne	LBB15_173
	ldr	x8, [x25]
	mov	x9, #-1
	mov	w22, #1
	b	LBB15_175
LBB15_171:
	mov	x9, #-1
	mov	x8, x27
	mov	x22, x25
	ldr	x21, [sp, #184]
	b	LBB15_175
LBB15_172:
	mov	x9, #-1
	mov	x22, x27
	b	LBB15_175
LBB15_173:
	mov	x19, x23
	lsl	x23, x27, #3
	bl	__RNvCsdtSMxSA38aw_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	x0, x23
	mov	w1, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc12___rust_alloc
	cbz	x0, LBB15_332
	mov	x22, x0
	mov	x1, x25
	mov	x2, x23
	bl	_memcpy
	mov	x8, x27
	mov	x9, x27
	mov	x23, x19
LBB15_175:
	strb	w20, [sp, #3032]
	str	x9, [sp, #3008]
	str	x22, [sp, #3016]
	str	x8, [sp, #3024]
	add	x8, sp, #2880
	ldp	q0, q1, [x8, #32]
	str	q0, [sp, #1328]
	str	q1, [sp, #1344]
Ltmp167:
	add	x0, sp, #2944
	add	x1, sp, #3008
	add	x2, sp, #1328
	bl	__RNvXsF_NtNtCs70jQWIuBJri_10num_bigint6bigint8divisionNtB7_6BigIntNtNtNtCsjIpoRzUjyHQ_4core3ops5arith3Div3div
Ltmp168:
Ltmp170:
	sub	x0, x29, #128
	add	x1, sp, #2880
	add	x2, sp, #2944
	bl	__RNvXsc_NtNtCs70jQWIuBJri_10num_bigint6bigint14multiplicationNtB7_6BigIntNtNtNtCsjIpoRzUjyHQ_4core3ops5arith3Mul3mul
Ltmp171:
	ldp	q0, q1, [x29, #-160]
	str	q0, [sp, #1328]
	str	q1, [sp, #1344]
Ltmp173:
	add	x0, sp, #3008
	add	x1, sp, #1328
	sub	x2, x29, #128
	bl	__RNvXs1_NtNtCs70jQWIuBJri_10num_bigint6bigint11subtractionNtB7_6BigIntNtNtNtCsjIpoRzUjyHQ_4core3ops5arith3Sub3sub
Ltmp174:
	ldr	x8, [sp, #2752]
	cmp	x8, #1
	b.lt	LBB15_180
	ldr	x0, [sp, #2760]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_180:
	ldr	q0, [sp, #3008]
	ldr	q1, [sp, #3024]
	str	q0, [sp, #2752]
	str	q1, [sp, #2768]
	ldr	x8, [sp, #2784]
	cmp	x8, #1
	b.lt	LBB15_182
	ldr	x0, [sp, #2792]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_182:
	str	x24, [sp, #2784]
	str	x25, [sp, #2792]
	str	x27, [sp, #2800]
	strb	w20, [sp, #2808]
	ldur	w8, [x29, #-192]
	add	x27, sp, #2752
	stur	w8, [x27, #57]
	ldur	w8, [x26, #179]
	stur	w8, [x27, #60]
Ltmp176:
	add	x0, sp, #2752
	bl	__RNvMs_CsjLaZ3GaS80H_12num_rationalINtB4_5RatioNtNtCs70jQWIuBJri_10num_bigint6bigint6BigIntE6reduceCs7wsLvUT6iAW_13codegen_audit
Ltmp177:
	ldr	x19, [sp, #176]
	b	LBB15_239
LBB15_183:
	cmp	x1, #1
	b.ne	LBB15_188
	ldr	x1, [x0]
	ldr	x20, [sp, #2928]
	cmn	x8, #1
	b.eq	LBB15_213
	cbz	x20, LBB15_210
	cmp	x20, #1
	b.ne	LBB15_211
	ldr	x20, [x23]
	mov	x8, #-1
	mov	w22, #1
	b	LBB15_213
LBB15_188:
Ltmp140:
	add	x8, sp, #3008
	bl	__RNvNtNtCs70jQWIuBJri_10num_bigint7biguint14multiplication4mul3
Ltmp141:
	b	LBB15_129
LBB15_189:
	mov	w14, #8
	ldr	x23, [sp, #192]
	cbz	w25, LBB15_194
LBB15_190:
	ldr	q0, [sp, #1328]
	str	q0, [sp, #2944]
	ldr	x8, [sp, #1344]
	str	x8, [sp, #2960]
Ltmp182:
	sub	x8, x29, #128
	add	x0, sp, #2944
	add	x1, sp, #3008
	bl	__RNvXNtNtCs70jQWIuBJri_10num_bigint7biguint8additionNtB4_7BigUintINtNtNtCsjIpoRzUjyHQ_4core3ops5arith3AddRBN_E3add
Ltmp183:
	ldur	x19, [x29, #-128]
	cmn	x19, #1
	b.eq	LBB15_208
	ldp	x21, x24, [x29, #-120]
	cmp	x24, #0
	cset	w8, eq
	b	LBB15_209
LBB15_193:
	mov	w14, #8
	cbz	w25, LBB15_190
LBB15_194:
	ldr	x8, [sp, #1328]
	ldr	x9, [sp, #1336]
	ldr	x10, [sp, #1344]
	tst	w9, #0x1
	ldr	x11, [sp, #16]
	csel	x11, x11, x14, ne
	cmn	x8, #1
	csel	x10, x9, x10, eq
	csel	x9, x11, x9, eq
	ldr	x11, [sp, #3008]
	ldr	x12, [sp, #3016]
	ldr	x13, [sp, #3024]
	cmn	x11, #1
	csel	x13, x12, x13, eq
	cmp	x10, x13
	cset	w13, hi
	csinv	w13, w13, wzr, hs
	b.ne	LBB15_199
	tst	w12, #0x1
	ldr	x13, [sp, #8]
	csel	x13, x13, x14, ne
	cmn	x11, #1
	csel	x11, x13, x12, eq
	sub	x11, x11, #8
	lsl	x10, x10, #3
	sub	x9, x9, #8
LBB15_196:
	cbz	x10, LBB15_206
	ldr	x12, [x9, x10]
	ldr	x13, [x11, x10]
	sub	x10, x10, #8
	cmp	x12, x13
	b.eq	LBB15_196
	cset	w9, hi
	csinv	w13, w9, wzr, hs
LBB15_199:
	and	w9, w13, #0xff
	cmp	w9, #255
	b.eq	LBB15_215
	cmp	w9, #1
	b.ne	LBB15_206
	ldr	q0, [sp, #1328]
	str	q0, [sp, #2944]
	ldr	x8, [sp, #1344]
	str	x8, [sp, #2960]
Ltmp184:
	sub	x8, x29, #128
	add	x0, sp, #2944
	add	x1, sp, #3008
	bl	__RNvXNtNtCs70jQWIuBJri_10num_bigint7biguint11subtractionNtB4_7BigUintINtNtNtCsjIpoRzUjyHQ_4core3ops5arith3SubRBR_E3sub
Ltmp185:
	ldur	x19, [x29, #-128]
	cmp	w20, #1
	b.ne	LBB15_224
	cmn	x19, #1
	b.eq	LBB15_228
	stur	xzr, [x29, #-112]
	cmp	x19, #2
	b.hs	LBB15_219
LBB15_205:
	mov	w20, #1
	b	LBB15_233
LBB15_206:
	mov	x21, #0
	stur	wzr, [x26, #3]
	str	wzr, [sp, #2944]
	mov	x19, #-1
	mov	w20, #1
	cmp	x8, #1
	b.ge	LBB15_223
	b	LBB15_234
LBB15_207:
	ldr	x21, [sp, #3016]
	mov	w8, #2
	sub	w20, w8, w25
	ldr	x8, [sp, #1328]
	cmp	x8, #1
	b.ge	LBB15_223
	b	LBB15_234
LBB15_208:
	ldp	x21, x24, [x29, #-120]
	eor	w8, w21, #0x1
LBB15_209:
	cmp	w8, #0
	csinc	w20, w20, wzr, eq
	b	LBB15_234
LBB15_210:
	mov	x8, #-1
	mov	x22, x20
	b	LBB15_213
LBB15_211:
	mov	x25, x1
	lsl	x24, x20, #3
	bl	__RNvCsdtSMxSA38aw_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	x0, x24
	mov	w1, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc12___rust_alloc
	cbz	x0, LBB15_336
	mov	x22, x0
	mov	x1, x23
	mov	x2, x24
	bl	_memcpy
	mov	x8, x20
	mov	x1, x25
LBB15_213:
	str	x8, [sp, #1328]
	str	x22, [sp, #1336]
	str	x20, [sp, #1344]
Ltmp146:
	add	x0, sp, #1328
	bl	__RNvNtNtCs70jQWIuBJri_10num_bigint7biguint14multiplication10scalar_mul
Ltmp147:
	ldr	q0, [sp, #1328]
	str	q0, [sp, #3008]
	ldr	x8, [sp, #1344]
	str	x8, [sp, #3024]
	b	LBB15_129
LBB15_215:
	ldr	q0, [sp, #1328]
	str	q0, [sp, #2944]
	ldr	x8, [sp, #1344]
	str	x8, [sp, #2960]
Ltmp186:
	sub	x8, x29, #128
	add	x0, sp, #3008
	add	x1, sp, #2944
	bl	__RNvXs0_NtNtCs70jQWIuBJri_10num_bigint7biguint11subtractionRNtB7_7BigUintINtNtNtCsjIpoRzUjyHQ_4core3ops5arith3SubBV_E3sub
Ltmp187:
	ldur	x19, [x29, #-128]
	cmn	x19, #1
	tbz	w20, #0, LBB15_226
	b.eq	LBB15_228
	stur	xzr, [x29, #-112]
	cmp	x19, #2
	b.lo	LBB15_205
LBB15_219:
	ldur	x0, [x29, #-120]
	lsl	x1, x19, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	stur	xzr, [x29, #-112]
Lloh27:
	adrp	x8, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.1@PAGE
Lloh28:
	add	x8, x8, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.1@PAGEOFF
Lloh29:
	ldr	q0, [x8]
	stur	q0, [x29, #-128]
	mov	w20, #1
	mov	x19, #-1
	b	LBB15_233
LBB15_220:
	mov	x19, #-1
	mov	x21, x24
	mov	w8, #2
	sub	w20, w8, w25
	ldr	x8, [sp, #1328]
	cmp	x8, #1
	b.ge	LBB15_223
	b	LBB15_234
LBB15_221:
	lsl	x22, x24, #3
	bl	__RNvCsdtSMxSA38aw_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	x0, x22
	mov	w1, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc12___rust_alloc
	cbz	x0, LBB15_337
	mov	x21, x0
	mov	x1, x23
	mov	x2, x22
	bl	_memcpy
	mov	x19, x24
	mov	x23, x20
	mov	w8, #2
	sub	w20, w8, w25
	ldr	x8, [sp, #1328]
	cmp	x8, #1
	b.lt	LBB15_234
LBB15_223:
	ldr	x0, [sp, #1336]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	b	LBB15_234
LBB15_224:
	cmn	x19, #1
	b.eq	LBB15_229
	ldur	x8, [x29, #-112]
	cmp	x8, #0
	cset	w8, eq
	b	LBB15_230
LBB15_226:
	b.eq	LBB15_231
	ldur	x8, [x29, #-112]
	cmp	x8, #0
	cset	w8, eq
	b	LBB15_232
LBB15_228:
	stur	xzr, [x29, #-120]
	mov	w20, #1
	b	LBB15_233
LBB15_229:
	ldur	w8, [x29, #-120]
	eor	w8, w8, #0x1
LBB15_230:
	cmp	w8, #0
	csinc	w20, w20, wzr, eq
	b	LBB15_233
LBB15_231:
	ldur	w8, [x29, #-120]
	eor	w8, w8, #0x1
LBB15_232:
	mov	w9, #2
	sub	w9, w9, w20
	cmp	w8, #0
	csinc	w20, w9, wzr, eq
LBB15_233:
	ldp	x21, x24, [x29, #-120]
LBB15_234:
	str	x19, [sp, #2752]
	str	x21, [sp, #2760]
	str	x24, [sp, #2768]
	strb	w20, [sp, #2776]
	ldr	w8, [sp, #2944]
	stur	w8, [x27, #25]
	ldur	w8, [x26, #3]
	stur	w8, [x27, #28]
	ldr	x8, [sp, #3008]
	cmp	x8, #1
	b.lt	LBB15_236
	ldr	x0, [sp, #3016]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_236:
Ltmp189:
	add	x0, sp, #2752
	bl	__RNvMs_CsjLaZ3GaS80H_12num_rationalINtB4_5RatioNtNtCs70jQWIuBJri_10num_bigint6bigint6BigIntE6reduceCs7wsLvUT6iAW_13codegen_audit
Ltmp190:
	ldp	x19, x21, [sp, #176]
	ldr	x8, [sp, #2912]
	cmp	x8, #1
	b.lt	LBB15_239
	ldr	x0, [sp, #2920]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_239:
	cmp	x19, #1
	b.lt	LBB15_26
	lsl	x1, x19, #3
	mov	x0, x23
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	b	LBB15_26
LBB15_241:
	add	x24, sp, #2944
	mov	w8, #160
	add	x9, sp, #1632
	ldr	x10, [sp, #40]
	madd	x8, x10, x8, x9
	add	x8, x8, x10, lsl #5
	ldp	x26, x21, [x8]
	ldr	q3, [x8, #16]
	ldp	q2, q1, [sp, #128]
	stp	q1, q2, [x8]
	str	x26, [sp, #2816]
	str	x21, [sp, #2824]
	add	x8, sp, #2816
	ldp	q0, q1, [sp, #96]
	stp	q3, q1, [x8, #16]
	stur	q0, [x8, #48]
	ldr	q0, [sp, #2752]
	ldr	q1, [sp, #2768]
	str	q0, [sp, #2944]
	str	q1, [sp, #2960]
	ldr	q0, [sp, #2784]
	ldr	q1, [sp, #2800]
	str	q0, [sp, #2976]
	str	q1, [sp, #2992]
	ldrb	w19, [sp, #2840]
	ldr	x20, [sp, #2832]
	cmn	x26, #1
	b.eq	LBB15_245
	cbz	x20, LBB15_246
	cmp	x20, #1
	b.ne	LBB15_247
	ldr	x20, [x21]
	mov	x22, #-1
	mov	w25, #1
	b	LBB15_249
LBB15_245:
	mov	x22, #-1
	mov	x25, x21
	b	LBB15_249
LBB15_246:
	mov	x22, #-1
	mov	x25, x20
	b	LBB15_249
LBB15_247:
	lsl	x22, x20, #3
	bl	__RNvCsdtSMxSA38aw_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	x0, x22
	mov	w1, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc12___rust_alloc
	cbz	x0, LBB15_334
	mov	x25, x0
	mov	x1, x21
	mov	x2, x22
	bl	_memcpy
	mov	x22, x20
LBB15_249:
	str	x21, [sp, #192]
	str	x22, [sp, #3008]
	str	x25, [sp, #3016]
	str	x20, [sp, #3024]
	strb	w19, [sp, #3032]
	mov	x8, #-1
	str	x8, [sp, #3040]
	mov	w8, #1
	str	x8, [sp, #3048]
	str	x8, [sp, #3056]
	mov	w8, #2
	strb	w8, [sp, #3064]
Ltmp195:
	add	x0, sp, #1328
	add	x1, sp, #2944
	add	x2, sp, #3008
	bl	__RNvXsh_NtCs70jQWIuBJri_10num_bigint7biguintNtB5_7BigUintNtCs5ZU5g2vqbRJ_11num_integer7Integer3gcd
Ltmp196:
	ldr	x27, [sp, #1328]
	cmn	x27, #1
	b.eq	LBB15_253
	ldr	x20, [sp, #1344]
	cbz	x20, LBB15_256
	mov	w19, #2
	ldr	x8, [sp, #1336]
	b	LBB15_255
LBB15_253:
	ldr	x8, [sp, #1336]
	cbz	x8, LBB15_259
	mov	x27, #-1
	mov	w19, #2
	ldr	x20, [sp, #1344]
	mov	w8, #1
LBB15_255:
	str	x8, [sp, #200]
	b	LBB15_261
LBB15_256:
	stur	wzr, [x24, #131]
	stur	wzr, [x29, #-240]
	cbz	x27, LBB15_258
	ldr	x0, [sp, #1336]
	lsl	x1, x27, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_258:
	str	xzr, [sp, #200]
	b	LBB15_260
LBB15_259:
	str	xzr, [sp, #200]
	stur	wzr, [x24, #131]
	stur	wzr, [x29, #-240]
LBB15_260:
	mov	x27, #-1
	mov	w19, #1
LBB15_261:
Ltmp198:
	add	x0, sp, #1328
	add	x8, sp, #2944
	add	x1, x8, #32
	add	x8, sp, #3008
	add	x2, x8, #32
	bl	__RNvXsh_NtCs70jQWIuBJri_10num_bigint7biguintNtB5_7BigUintNtCs5ZU5g2vqbRJ_11num_integer7Integer3gcd
Ltmp199:
	ldr	x28, [sp, #1328]
	cmn	x28, #1
	str	x22, [sp, #184]
	b.eq	LBB15_266
	ldr	x21, [sp, #1344]
	cbz	x21, LBB15_268
	mov	w22, #2
	ldr	x23, [sp, #1336]
	ldr	q0, [sp, #2944]
	ldr	q1, [sp, #2960]
	str	q0, [sp, #2880]
	str	q1, [sp, #2896]
	cmn	x27, #1
	b.ne	LBB15_273
LBB15_265:
	mov	x9, #-1
	mov	x8, x20
	ldr	x24, [sp, #200]
	b	LBB15_279
LBB15_266:
	ldr	x8, [sp, #1336]
	cbz	x8, LBB15_271
	mov	x28, #-1
	mov	w22, #2
	ldr	x21, [sp, #1344]
	mov	w23, #1
	ldr	q0, [sp, #2944]
	ldr	q1, [sp, #2960]
	str	q0, [sp, #2880]
	str	q1, [sp, #2896]
	cmn	x27, #1
	b.ne	LBB15_273
	b	LBB15_265
LBB15_268:
	stur	wzr, [x24, #139]
	stur	wzr, [x29, #-232]
	cbz	x28, LBB15_270
	ldr	x0, [sp, #1336]
	lsl	x1, x28, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_270:
	mov	x23, #0
	b	LBB15_272
LBB15_271:
	mov	x23, #0
	stur	wzr, [x24, #139]
	stur	wzr, [x29, #-232]
LBB15_272:
	mov	x28, #-1
	mov	w22, #1
	ldr	q0, [sp, #2944]
	ldr	q1, [sp, #2960]
	str	q0, [sp, #2880]
	str	q1, [sp, #2896]
	cmn	x27, #1
	b.eq	LBB15_265
LBB15_273:
	cbz	x20, LBB15_276
	cmp	x20, #1
	b.ne	LBB15_277
	ldr	x8, [sp, #200]
	ldr	x8, [x8]
	mov	x9, #-1
	mov	w24, #1
	b	LBB15_279
LBB15_276:
	mov	x9, #-1
	mov	x24, x20
	b	LBB15_279
LBB15_277:
	str	x25, [sp, #176]
	lsl	x25, x20, #3
	bl	__RNvCsdtSMxSA38aw_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	x0, x25
	mov	w1, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc12___rust_alloc
	cbz	x0, LBB15_333
	mov	x24, x0
	ldr	x1, [sp, #200]
	mov	x2, x25
	bl	_memcpy
	mov	x8, x20
	mov	x9, x20
	ldr	x25, [sp, #176]
LBB15_279:
	strb	w19, [sp, #1352]
	str	x9, [sp, #1328]
	str	x24, [sp, #1336]
	str	x8, [sp, #1344]
Ltmp204:
	sub	x0, x29, #160
	add	x1, sp, #2880
	add	x2, sp, #1328
	bl	__RNvXsF_NtNtCs70jQWIuBJri_10num_bigint6bigint8divisionNtB7_6BigIntNtNtNtCsjIpoRzUjyHQ_4core3ops5arith3Div3div
Ltmp205:
	add	x8, sp, #3008
	ldp	q0, q1, [x8, #32]
	str	q0, [sp, #2880]
	str	q1, [sp, #2896]
	cmn	x28, #1
	b.eq	LBB15_284
	cbz	x21, LBB15_285
	cmp	x21, #1
	b.ne	LBB15_286
	ldr	x8, [x23]
	mov	x9, #-1
	mov	w24, #1
	b	LBB15_288
LBB15_284:
	mov	x9, #-1
	mov	x8, x21
	mov	x24, x23
	b	LBB15_288
LBB15_285:
	mov	x9, #-1
	mov	x24, x21
	b	LBB15_288
LBB15_286:
	str	x25, [sp, #176]
	lsl	x25, x21, #3
	bl	__RNvCsdtSMxSA38aw_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	x0, x25
	mov	w1, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc12___rust_alloc
	cbz	x0, LBB15_335
	mov	x24, x0
	mov	x1, x23
	mov	x2, x25
	bl	_memcpy
	mov	x8, x21
	mov	x9, x21
	ldr	x25, [sp, #176]
LBB15_288:
	strb	w22, [sp, #1352]
	str	x9, [sp, #1328]
	str	x24, [sp, #1336]
	str	x8, [sp, #1344]
Ltmp210:
	sub	x0, x29, #128
	add	x1, sp, #2880
	add	x2, sp, #1328
	bl	__RNvXsF_NtNtCs70jQWIuBJri_10num_bigint6bigint8divisionNtB7_6BigIntNtNtNtCsjIpoRzUjyHQ_4core3ops5arith3Div3div
Ltmp211:
Ltmp213:
	sub	x0, x29, #224
	sub	x1, x29, #160
	sub	x2, x29, #128
	bl	__RNvXsc_NtNtCs70jQWIuBJri_10num_bigint6bigint14multiplicationNtB7_6BigIntNtNtNtCsjIpoRzUjyHQ_4core3ops5arith3Mul3mul
Ltmp214:
	add	x8, sp, #2944
	ldp	q0, q1, [x8, #32]
	str	q0, [sp, #2880]
	str	q1, [sp, #2896]
	str	x28, [sp, #1328]
	str	x23, [sp, #1336]
	str	x21, [sp, #1344]
	strb	w22, [sp, #1352]
	ldur	w8, [x29, #-232]
	add	x22, sp, #1328
	stur	w8, [x22, #25]
	add	x21, sp, #2944
	ldur	w8, [x21, #139]
	stur	w8, [x22, #28]
Ltmp216:
	sub	x0, x29, #160
	add	x1, sp, #2880
	add	x2, sp, #1328
	bl	__RNvXsF_NtNtCs70jQWIuBJri_10num_bigint6bigint8divisionNtB7_6BigIntNtNtNtCsjIpoRzUjyHQ_4core3ops5arith3Div3div
Ltmp217:
	ldr	q0, [sp, #3008]
	ldr	q1, [sp, #3024]
	str	q0, [sp, #2880]
	str	q1, [sp, #2896]
	str	x27, [sp, #1328]
	ldr	x8, [sp, #200]
	str	x8, [sp, #1336]
	str	x20, [sp, #1344]
	strb	w19, [sp, #1352]
	ldur	w8, [x29, #-240]
	stur	w8, [x22, #25]
	ldur	w8, [x21, #131]
	stur	w8, [x22, #28]
Ltmp219:
	sub	x0, x29, #128
	add	x1, sp, #2880
	add	x2, sp, #1328
	bl	__RNvXsF_NtNtCs70jQWIuBJri_10num_bigint6bigint8divisionNtB7_6BigIntNtNtNtCsjIpoRzUjyHQ_4core3ops5arith3Div3div
Ltmp220:
Ltmp222:
	sub	x0, x29, #192
	sub	x1, x29, #160
	sub	x2, x29, #128
	bl	__RNvXsc_NtNtCs70jQWIuBJri_10num_bigint6bigint14multiplicationNtB7_6BigIntNtNtNtCsjIpoRzUjyHQ_4core3ops5arith3Mul3mul
Ltmp223:
	add	x27, sp, #2752
	ldp	q0, q1, [x29, #-224]
	str	q0, [sp, #1328]
	str	q1, [sp, #1344]
	ldp	q0, q1, [x29, #-192]
	stp	q0, q1, [x22, #32]
Ltmp225:
	add	x0, sp, #1328
	bl	__RNvMs_CsjLaZ3GaS80H_12num_rationalINtB4_5RatioNtNtCs70jQWIuBJri_10num_bigint6bigint6BigIntE6reduceCs7wsLvUT6iAW_13codegen_audit
Ltmp226:
	ldr	q0, [sp, #1328]
	ldr	q1, [sp, #1344]
	str	q0, [sp, #2880]
	str	q1, [sp, #2896]
	ldr	q0, [sp, #1360]
	ldr	q1, [sp, #1376]
	str	q0, [sp, #2912]
	str	q1, [sp, #2928]
	add	x8, sp, #2432
	ldr	x9, [sp, #40]
	add	x19, x8, x9, lsl #6
	ldr	x8, [x19]
	cmp	x8, #1
	b.lt	LBB15_296
	ldr	x0, [x19, #8]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_296:
	ldr	x8, [x19, #32]
	cmp	x8, #1
	b.lt	LBB15_298
	ldr	x0, [x19, #40]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_298:
	ldr	q0, [sp, #2880]
	ldr	q1, [sp, #2896]
	stp	q0, q1, [x19]
	ldr	q0, [sp, #2912]
	ldr	q1, [sp, #2928]
	stp	q0, q1, [x19, #32]
	cmp	x26, #1
	b.lt	LBB15_23
	lsl	x1, x26, #3
	ldr	x0, [sp, #192]
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	b	LBB15_23
LBB15_300:
	ldr	x22, [sp, #2432]
	ldrb	w20, [sp, #2440]
	add	x8, sp, #2186
	ldur	w8, [x8, #255]
	str	w8, [sp, #3008]
	ldr	w8, [sp, #2444]
	stur	w8, [x26, #67]
	ldr	x19, [sp, #2448]
	ldrb	w21, [sp, #2456]
	add	x8, sp, #2432
	add	x0, sp, #1328
	add	x1, x8, #25
	mov	w2, #295
	bl	_memcpy
	ldr	x8, [sp, #1168]
	cmp	x8, #1
	b.lt	LBB15_302
	ldr	x0, [sp, #1176]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_302:
	ldr	x8, [sp, #1200]
	cmp	x8, #1
	b.lt	LBB15_304
	ldr	x0, [sp, #1208]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_304:
	ldr	x8, [sp, #1232]
	cmp	x8, #1
	b.lt	LBB15_306
	ldr	x0, [sp, #1240]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_306:
	ldr	x8, [sp, #1264]
	cmp	x8, #1
	b.lt	LBB15_308
	ldr	x0, [sp, #1272]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_308:
	ldr	x8, [sp, #1296]
	cmp	x8, #1
	b.lt	LBB15_310
	ldr	x0, [sp, #1304]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_310:
	add	x0, sp, #1632
	mov	w1, #5
	bl	__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueSANtNtCs70jQWIuBJri_10num_bigint6bigint6BigIntj5_ECs7wsLvUT6iAW_13codegen_audit
	cmn	x22, #2
	b.ne	LBB15_322
LBB15_311:
	ldr	q0, [sp, #1328]
	ldr	q1, [sp, #1344]
	ldr	x9, [sp]
	stur	q0, [x9, #25]
	ldr	w8, [sp, #3008]
	stur	w8, [x9, #9]
	ldur	w8, [x26, #67]
	str	w8, [x9, #12]
	stur	q1, [x9, #41]
	add	x8, sp, #1104
	ldur	x8, [x8, #255]
	str	x8, [x9, #56]
	strb	w20, [x9, #8]
	str	x19, [x9, #16]
	strb	w21, [x9, #24]
	mov	x8, #-2
	str	x8, [x9]
	ldr	x8, [sp, #208]
	cmp	x8, #1
	b.lt	LBB15_313
LBB15_312:
	ldr	x0, [sp, #216]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_313:
	ldr	x8, [sp, #240]
	cmp	x8, #1
	b.lt	LBB15_315
	ldr	x0, [sp, #248]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_315:
	ldr	x8, [sp, #272]
	cmp	x8, #1
	b.lt	LBB15_317
	ldr	x0, [sp, #280]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_317:
	ldr	x8, [sp, #304]
	cmp	x8, #1
	b.lt	LBB15_319
	ldr	x0, [sp, #312]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_319:
	ldr	x8, [sp, #336]
	cmp	x8, #1
	b.lt	LBB15_321
	ldr	x0, [sp, #344]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_321:
	add	sp, sp, #3232
	.cfi_def_cfa wsp, 96
	ldp	x29, x30, [sp, #80]
	ldp	x20, x19, [sp, #64]
	ldp	x22, x21, [sp, #48]
	ldp	x24, x23, [sp, #32]
	ldp	x26, x25, [sp, #16]
	ldp	x28, x27, [sp], #96
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	ret
LBB15_322:
	.cfi_restore_state
	ldr	w8, [sp, #3008]
	ldr	x23, [sp]
	stur	w8, [x23, #9]
	ldur	w8, [x26, #67]
	str	w8, [x23, #12]
	add	x0, x23, #25
	add	x1, sp, #1328
	mov	w2, #295
	bl	_memcpy
	str	x22, [x23]
	strb	w20, [x23, #8]
	str	x19, [x23, #16]
	strb	w21, [x23, #24]
	ldr	x8, [sp, #208]
	cmp	x8, #1
	b.ge	LBB15_312
	b	LBB15_313
LBB15_323:
	ldr	x19, [sp, #2440]
	add	x0, sp, #1168
	bl	__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueANtNtCs70jQWIuBJri_10num_bigint6bigint6BigIntj5_ECs7wsLvUT6iAW_13codegen_audit
	add	x0, sp, #1632
	mov	w1, #5
	bl	__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueSANtNtCs70jQWIuBJri_10num_bigint6bigint6BigIntj5_ECs7wsLvUT6iAW_13codegen_audit
	mov	w20, #0
	mov	w21, #0
	b	LBB15_311
LBB15_324:
Ltmp110:
	mov	w0, #8
	mov	x1, x27
	bl	__RNvNtCs6zY7rJBZy9D_5alloc7raw_vec12handle_error
Ltmp111:
	b	LBB15_338
LBB15_325:
Ltmp89:
	mov	w0, #8
	mov	x1, x22
	bl	__RNvNtCs6zY7rJBZy9D_5alloc7raw_vec12handle_error
Ltmp90:
	b	LBB15_338
LBB15_326:
Ltmp92:
	mov	w0, #8
	mov	x1, x24
	bl	__RNvNtCs6zY7rJBZy9D_5alloc7raw_vec12handle_error
Ltmp93:
	b	LBB15_338
LBB15_327:
Ltmp104:
	mov	w0, #8
	mov	x1, x27
	bl	__RNvNtCs6zY7rJBZy9D_5alloc7raw_vec12handle_error
Ltmp105:
	b	LBB15_338
LBB15_328:
Ltmp95:
	mov	w0, #8
	mov	x1, x25
	bl	__RNvNtCs6zY7rJBZy9D_5alloc7raw_vec12handle_error
Ltmp96:
	b	LBB15_338
LBB15_329:
Ltmp152:
	mov	w0, #8
	mov	x1, x24
	bl	__RNvNtCs6zY7rJBZy9D_5alloc7raw_vec12handle_error
Ltmp153:
	b	LBB15_338
LBB15_330:
Ltmp149:
	mov	w0, #8
	mov	x1, x24
	bl	__RNvNtCs6zY7rJBZy9D_5alloc7raw_vec12handle_error
Ltmp150:
	b	LBB15_338
LBB15_331:
Ltmp155:
	mov	w0, #8
	mov	x1, x26
	bl	__RNvNtCs6zY7rJBZy9D_5alloc7raw_vec12handle_error
Ltmp156:
	b	LBB15_338
LBB15_332:
Ltmp164:
	mov	w0, #8
	mov	x1, x23
	bl	__RNvNtCs6zY7rJBZy9D_5alloc7raw_vec12handle_error
Ltmp165:
	b	LBB15_338
LBB15_333:
Ltmp201:
	mov	w0, #8
	mov	x1, x25
	bl	__RNvNtCs6zY7rJBZy9D_5alloc7raw_vec12handle_error
Ltmp202:
	b	LBB15_338
LBB15_334:
Ltmp192:
	mov	w0, #8
	mov	x1, x22
	bl	__RNvNtCs6zY7rJBZy9D_5alloc7raw_vec12handle_error
Ltmp193:
	b	LBB15_338
LBB15_335:
Ltmp207:
	mov	w0, #8
	mov	x1, x25
	bl	__RNvNtCs6zY7rJBZy9D_5alloc7raw_vec12handle_error
Ltmp208:
	b	LBB15_338
LBB15_336:
Ltmp143:
	mov	w0, #8
	mov	x1, x24
	bl	__RNvNtCs6zY7rJBZy9D_5alloc7raw_vec12handle_error
Ltmp144:
	b	LBB15_338
LBB15_337:
Ltmp179:
	mov	w0, #8
	mov	x1, x22
	bl	__RNvNtCs6zY7rJBZy9D_5alloc7raw_vec12handle_error
Ltmp180:
LBB15_338:
	brk	#0x1
LBB15_339:
Ltmp88:
	mov	x26, x0
	b	LBB15_478
LBB15_340:
Ltmp85:
	mov	x26, x0
	add	x0, sp, #1632
	mov	x1, x21
	bl	__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueINtNtB4_5array5GuardNtNtCs70jQWIuBJri_10num_bigint6bigint6BigIntEECs7wsLvUT6iAW_13codegen_audit
	add	x0, sp, #368
	b	LBB15_479
LBB15_341:
Ltmp181:
	mov	x26, x0
	ldr	x8, [sp, #1328]
	cmp	x8, #1
	b.lt	LBB15_391
	ldr	x0, [sp, #1336]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	b	LBB15_391
LBB15_343:
Ltmp145:
	b	LBB15_352
LBB15_344:
Ltmp209:
	mov	x26, x0
	ldr	x8, [sp, #2880]
	cmp	x8, #1
	b.lt	LBB15_364
	ldr	x0, [sp, #2888]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	b	LBB15_364
LBB15_346:
Ltmp194:
	mov	x26, x0
	add	x0, sp, #2944
	b	LBB15_360
LBB15_347:
Ltmp203:
	mov	x26, x0
	ldr	x8, [sp, #2880]
	cmp	x8, #1
	b.lt	LBB15_373
	ldr	x0, [sp, #2888]
	b	LBB15_366
LBB15_349:
Ltmp148:
	mov	x26, x0
	ldr	x8, [sp, #1328]
	cmp	x8, #1
	b.lt	LBB15_353
	ldr	x0, [sp, #1336]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	b	LBB15_353
LBB15_351:
Ltmp142:
LBB15_352:
	mov	x26, x0
LBB15_353:
	cmp	x19, #0
	b.gt	LBB15_417
	b	LBB15_418
LBB15_354:
Ltmp221:
	mov	x26, x0
	ldur	x8, [x29, #-160]
	cmp	x8, #1
	b.lt	LBB15_357
	ldur	x0, [x29, #-152]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	b	LBB15_357
LBB15_356:
Ltmp224:
	mov	x26, x0
LBB15_357:
	ldur	x8, [x29, #-224]
	cmp	x8, #0
	b.le	LBB15_389
	ldur	x0, [x29, #-216]
	b	LBB15_388
LBB15_359:
Ltmp227:
	mov	x26, x0
	add	x0, sp, #1328
LBB15_360:
	bl	__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueINtCsjLaZ3GaS80H_12num_rational5RatioNtNtCs70jQWIuBJri_10num_bigint6bigint6BigIntEECs7wsLvUT6iAW_13codegen_audit
	add	x0, sp, #2816
	b	LBB15_477
LBB15_361:
Ltmp197:
	str	x25, [sp, #176]
	mov	x26, x0
	mov	w20, #1
	mov	w19, #1
	cmp	x22, #1
	b.lt	LBB15_379
	b	LBB15_384
LBB15_362:
Ltmp200:
	str	x25, [sp, #176]
	mov	x26, x0
	mov	w19, #1
	mov	w20, #1
	b	LBB15_377
LBB15_363:
Ltmp212:
	str	x25, [sp, #176]
	mov	x26, x0
LBB15_364:
	ldur	x8, [x29, #-160]
	cmp	x8, #1
	b.lt	LBB15_373
	ldur	x0, [x29, #-152]
LBB15_366:
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	b	LBB15_373
LBB15_367:
Ltmp215:
	b	LBB15_372
LBB15_368:
Ltmp218:
	str	x25, [sp, #176]
	mov	x26, x0
	ldur	x8, [x29, #-224]
	cmp	x8, #1
	b.lt	LBB15_370
	ldur	x0, [x29, #-216]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_370:
	mov	w19, #0
	mov	w20, #0
	b	LBB15_376
LBB15_371:
Ltmp206:
LBB15_372:
	str	x25, [sp, #176]
	mov	x26, x0
LBB15_373:
	cmp	x28, #1
	b.lt	LBB15_375
	lsl	x1, x28, #3
	mov	x0, x23
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_375:
	mov	w20, #0
	mov	w19, #1
LBB15_376:
	ldr	x22, [sp, #184]
LBB15_377:
	cmp	x27, #1
	b.lt	LBB15_383
	lsl	x1, x27, #3
	ldr	x0, [sp, #200]
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	cmp	x22, #1
	b.ge	LBB15_384
LBB15_379:
	tbz	w20, #0, LBB15_385
LBB15_380:
	ldr	x8, [sp, #2944]
	cmp	x8, #1
	b.lt	LBB15_382
	ldr	x0, [sp, #2952]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_382:
	cbnz	w19, LBB15_386
	b	LBB15_389
LBB15_383:
	cmp	x22, #1
	b.lt	LBB15_379
LBB15_384:
	lsl	x1, x22, #3
	ldr	x0, [sp, #176]
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	tbnz	w20, #0, LBB15_380
LBB15_385:
	tbz	w19, #0, LBB15_389
LBB15_386:
	ldr	x8, [sp, #2976]
	cmp	x8, #1
	b.lt	LBB15_389
	ldr	x0, [sp, #2984]
LBB15_388:
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	add	x0, sp, #2816
	b	LBB15_477
LBB15_389:
	add	x0, sp, #2816
	b	LBB15_477
LBB15_390:
Ltmp188:
	mov	x26, x0
	ldr	x19, [sp, #3008]
LBB15_391:
	cmp	x19, #1
	b.lt	LBB15_442
	ldr	x0, [sp, #3016]
	lsl	x1, x19, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	b	LBB15_442
LBB15_393:
Ltmp139:
	mov	x26, x0
	ldr	x19, [sp, #1328]
	cmp	x19, #1
	b.lt	LBB15_418
	ldr	x21, [sp, #1336]
	b	LBB15_417
LBB15_395:
Ltmp166:
	mov	x26, x0
	mov	w20, #1
	b	LBB15_422
LBB15_396:
Ltmp157:
	mov	x26, x0
	sub	x8, x28, #1
	cmn	x8, #3
	b.hi	LBB15_398
	lsl	x1, x28, #3
	mov	x0, x23
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_398:
	ldr	x24, [sp, #168]
	ldr	x25, [sp, #200]
	b	LBB15_430
LBB15_399:
Ltmp151:
	mov	x26, x0
	mov	w20, #1
	mov	w19, #1
	ldr	x24, [sp, #168]
	ldr	x25, [sp, #200]
	b	LBB15_435
LBB15_400:
Ltmp154:
	mov	x26, x0
	ldr	x24, [sp, #168]
	b	LBB15_431
LBB15_401:
Ltmp97:
	mov	x26, x0
	ldr	x9, [sp, #200]
	sub	x8, x9, #1
	cmn	x8, #3
	b.hi	LBB15_406
	lsl	x1, x9, #3
	mov	x0, x28
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	b	LBB15_406
LBB15_403:
Ltmp106:
	mov	x26, x0
	ldur	x8, [x29, #-128]
	cmp	x8, #1
	b.lt	LBB15_445
	ldur	x0, [x29, #-120]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	b	LBB15_445
LBB15_405:
Ltmp94:
	mov	x26, x0
LBB15_406:
	add	x0, sp, #2944
	bl	__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueINtCsjLaZ3GaS80H_12num_rational5RatioNtNtCs70jQWIuBJri_10num_bigint6bigint6BigIntEECs7wsLvUT6iAW_13codegen_audit
	b	LBB15_476
LBB15_407:
Ltmp91:
	b	LBB15_428
LBB15_408:
Ltmp112:
	mov	x26, x0
	ldur	x8, [x29, #-128]
	cmp	x8, #1
	b.lt	LBB15_450
	ldur	x0, [x29, #-120]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	b	LBB15_450
LBB15_410:
Ltmp191:
	mov	x26, x0
	b	LBB15_442
LBB15_411:
Ltmp74:
	mov	x26, x0
	add	x0, sp, #368
	mov	x1, x24
	bl	__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueINtNtB4_5array5GuardNtNtCs70jQWIuBJri_10num_bigint6bigint6BigIntEECs7wsLvUT6iAW_13codegen_audit
	cbz	x19, LBB15_481
	add	x0, sp, #1632
	mov	x1, x22
	b	LBB15_480
LBB15_413:
Ltmp63:
	mov	x26, x0
	add	x0, sp, #1632
	mov	x1, x22
	bl	__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueINtNtB4_5array5GuardNtNtCs70jQWIuBJri_10num_bigint6bigint6BigIntEECs7wsLvUT6iAW_13codegen_audit
	mov	x0, x26
	bl	__Unwind_Resume
LBB15_414:
Ltmp133:
	mov	x26, x0
	b	LBB15_418
LBB15_415:
Ltmp136:
	mov	x26, x0
	ldr	x19, [sp, #3008]
	cmp	x19, #1
	b.lt	LBB15_418
	ldr	x21, [sp, #3016]
LBB15_417:
	lsl	x1, x19, #3
	mov	x0, x21
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_418:
	mov	w20, #1
	b	LBB15_438
LBB15_419:
Ltmp175:
	mov	x26, x0
	mov	w20, #0
	mov	w19, #0
	b	LBB15_435
LBB15_420:
Ltmp172:
	mov	x26, x0
	mov	w20, #0
	b	LBB15_424
LBB15_421:
Ltmp169:
	mov	x26, x0
	mov	w20, #0
LBB15_422:
	ldr	x8, [sp, #2880]
	cmp	x8, #1
	b.lt	LBB15_424
	ldr	x0, [sp, #2888]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_424:
	ldur	x8, [x29, #-160]
	cmp	x8, #1
	b.lt	LBB15_426
	ldur	x0, [x29, #-152]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_426:
	mov	w19, #0
	b	LBB15_435
LBB15_427:
Ltmp178:
LBB15_428:
	mov	x26, x0
	b	LBB15_476
LBB15_429:
Ltmp160:
	mov	x26, x0
	ldr	x24, [sp, #168]
LBB15_430:
	ldr	x19, [sp, #80]
LBB15_431:
	sub	x8, x19, #1
	cmn	x8, #3
	b.hi	LBB15_434
	lsl	x1, x19, #3
	mov	x0, x22
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	b	LBB15_434
LBB15_433:
Ltmp163:
	mov	x26, x0
LBB15_434:
	mov	w20, #1
	mov	w19, #1
LBB15_435:
	sub	x8, x24, #1
	cmn	x8, #3
	b.hi	LBB15_437
	lsl	x1, x24, #3
	mov	x0, x25
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_437:
	tbz	w19, #0, LBB15_441
LBB15_438:
	ldr	x8, [sp, #2880]
	cmp	x8, #1
	b.lt	LBB15_440
	ldr	x0, [sp, #2888]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_440:
	cbnz	w20, LBB15_442
	b	LBB15_476
LBB15_441:
	tbz	w20, #0, LBB15_476
LBB15_442:
	ldr	x8, [sp, #2912]
	cmp	x8, #1
	b.lt	LBB15_476
	ldr	x0, [sp, #2920]
	b	LBB15_457
LBB15_444:
Ltmp109:
	mov	x26, x0
LBB15_445:
	mov	w21, #1
	b	LBB15_460
LBB15_446:
Ltmp100:
	mov	x26, x0
	mov	w20, #1
	b	LBB15_469
LBB15_447:
Ltmp103:
	mov	x26, x0
	mov	w21, #1
	mov	w20, #1
	b	LBB15_466
LBB15_448:
Ltmp130:
	mov	x26, x0
	add	x0, sp, #1328
	bl	__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueINtCsjLaZ3GaS80H_12num_rational5RatioNtNtCs70jQWIuBJri_10num_bigint6bigint6BigIntEECs7wsLvUT6iAW_13codegen_audit
	b	LBB15_476
LBB15_449:
Ltmp115:
	mov	x26, x0
LBB15_450:
	ldur	x8, [x29, #-192]
	cmp	x8, #1
	b.lt	LBB15_459
	ldur	x0, [x29, #-184]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	b	LBB15_459
LBB15_452:
Ltmp124:
	mov	x26, x0
	ldur	x8, [x29, #-192]
	cmp	x8, #1
	b.lt	LBB15_455
	ldur	x0, [x29, #-184]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	b	LBB15_455
LBB15_454:
Ltmp127:
	mov	x26, x0
LBB15_455:
	ldur	x8, [x29, #-224]
	cmp	x8, #0
	b.le	LBB15_476
	ldur	x0, [x29, #-216]
LBB15_457:
	lsl	x1, x8, #3
	b	LBB15_475
LBB15_458:
Ltmp118:
	mov	x26, x0
LBB15_459:
	mov	w21, #0
LBB15_460:
	cmp	x20, #1
	b.lt	LBB15_465
	lsl	x1, x20, #3
	mov	x0, x25
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	b	LBB15_465
LBB15_462:
Ltmp121:
	mov	x26, x0
	ldur	x8, [x29, #-224]
	cmp	x8, #1
	b.lt	LBB15_464
	ldur	x0, [x29, #-216]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_464:
	mov	w21, #0
LBB15_465:
	mov	w20, #0
	ldr	x25, [sp, #64]
LBB15_466:
	cmp	x19, #1
	b.lt	LBB15_468
	lsl	x1, x19, #3
	mov	x0, x24
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_468:
	ldr	x24, [sp, #168]
	cbz	w21, LBB15_471
LBB15_469:
	ldr	x8, [sp, #200]
	cmp	x8, #1
	b.lt	LBB15_471
	lsl	x1, x8, #3
	ldr	x0, [sp, #56]
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_471:
	ldr	x8, [sp, #80]
	cmp	x8, #1
	b.lt	LBB15_473
	lsl	x1, x8, #3
	ldr	x0, [sp, #72]
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_473:
	cmp	x24, #0
	csel	w8, wzr, w20, le
	cbz	w8, LBB15_476
	lsl	x1, x24, #3
	mov	x0, x25
LBB15_475:
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB15_476:
	add	x0, sp, #2816
	bl	__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueINtCsjLaZ3GaS80H_12num_rational5RatioNtNtCs70jQWIuBJri_10num_bigint6bigint6BigIntEECs7wsLvUT6iAW_13codegen_audit
	add	x0, sp, #2752
LBB15_477:
	bl	__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueINtCsjLaZ3GaS80H_12num_rational5RatioNtNtCs70jQWIuBJri_10num_bigint6bigint6BigIntEECs7wsLvUT6iAW_13codegen_audit
	add	x0, sp, #2432
	bl	__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueAINtCsjLaZ3GaS80H_12num_rational5RatioNtNtCs70jQWIuBJri_10num_bigint6bigint6BigIntEj5_ECs7wsLvUT6iAW_13codegen_audit
LBB15_478:
	add	x0, sp, #1168
	bl	__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueANtNtCs70jQWIuBJri_10num_bigint6bigint6BigIntj5_ECs7wsLvUT6iAW_13codegen_audit
	add	x0, sp, #1632
LBB15_479:
	mov	w1, #5
LBB15_480:
	bl	__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueSANtNtCs70jQWIuBJri_10num_bigint6bigint6BigIntj5_ECs7wsLvUT6iAW_13codegen_audit
LBB15_481:
	add	x0, sp, #208
	bl	__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueANtNtCs70jQWIuBJri_10num_bigint6bigint6BigIntj5_ECs7wsLvUT6iAW_13codegen_audit
	mov	x0, x26
	bl	__Unwind_Resume
	.loh AdrpAdd	Lloh22, Lloh23
	.loh AdrpAdd	Lloh20, Lloh21
	.loh AdrpAddLdr	Lloh24, Lloh25, Lloh26
	.loh AdrpAddLdr	Lloh27, Lloh28, Lloh29
Lfunc_end2:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table15:
Lexception2:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 Lcst_end2-Lcst_begin2
Lcst_begin2:
	.uleb128 Ltmp51-Lfunc_begin2
	.uleb128 Ltmp62-Ltmp51
	.uleb128 Ltmp63-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp64-Lfunc_begin2
	.uleb128 Ltmp73-Ltmp64
	.uleb128 Ltmp74-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp73-Lfunc_begin2
	.uleb128 Ltmp75-Ltmp73
	.byte	0
	.byte	0
	.uleb128 Ltmp75-Lfunc_begin2
	.uleb128 Ltmp84-Ltmp75
	.uleb128 Ltmp85-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp84-Lfunc_begin2
	.uleb128 Ltmp86-Ltmp84
	.byte	0
	.byte	0
	.uleb128 Ltmp86-Lfunc_begin2
	.uleb128 Ltmp87-Ltmp86
	.uleb128 Ltmp88-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp87-Lfunc_begin2
	.uleb128 Ltmp98-Ltmp87
	.byte	0
	.byte	0
	.uleb128 Ltmp98-Lfunc_begin2
	.uleb128 Ltmp99-Ltmp98
	.uleb128 Ltmp100-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp101-Lfunc_begin2
	.uleb128 Ltmp102-Ltmp101
	.uleb128 Ltmp103-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp102-Lfunc_begin2
	.uleb128 Ltmp107-Ltmp102
	.byte	0
	.byte	0
	.uleb128 Ltmp107-Lfunc_begin2
	.uleb128 Ltmp108-Ltmp107
	.uleb128 Ltmp109-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp108-Lfunc_begin2
	.uleb128 Ltmp113-Ltmp108
	.byte	0
	.byte	0
	.uleb128 Ltmp113-Lfunc_begin2
	.uleb128 Ltmp114-Ltmp113
	.uleb128 Ltmp115-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp116-Lfunc_begin2
	.uleb128 Ltmp117-Ltmp116
	.uleb128 Ltmp118-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp119-Lfunc_begin2
	.uleb128 Ltmp120-Ltmp119
	.uleb128 Ltmp121-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp122-Lfunc_begin2
	.uleb128 Ltmp123-Ltmp122
	.uleb128 Ltmp124-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp125-Lfunc_begin2
	.uleb128 Ltmp126-Ltmp125
	.uleb128 Ltmp127-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp128-Lfunc_begin2
	.uleb128 Ltmp129-Ltmp128
	.uleb128 Ltmp130-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp131-Lfunc_begin2
	.uleb128 Ltmp132-Ltmp131
	.uleb128 Ltmp133-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp134-Lfunc_begin2
	.uleb128 Ltmp135-Ltmp134
	.uleb128 Ltmp136-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp137-Lfunc_begin2
	.uleb128 Ltmp138-Ltmp137
	.uleb128 Ltmp139-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp138-Lfunc_begin2
	.uleb128 Ltmp158-Ltmp138
	.byte	0
	.byte	0
	.uleb128 Ltmp158-Lfunc_begin2
	.uleb128 Ltmp159-Ltmp158
	.uleb128 Ltmp160-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp161-Lfunc_begin2
	.uleb128 Ltmp162-Ltmp161
	.uleb128 Ltmp163-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp162-Lfunc_begin2
	.uleb128 Ltmp167-Ltmp162
	.byte	0
	.byte	0
	.uleb128 Ltmp167-Lfunc_begin2
	.uleb128 Ltmp168-Ltmp167
	.uleb128 Ltmp169-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp170-Lfunc_begin2
	.uleb128 Ltmp171-Ltmp170
	.uleb128 Ltmp172-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp173-Lfunc_begin2
	.uleb128 Ltmp174-Ltmp173
	.uleb128 Ltmp175-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp176-Lfunc_begin2
	.uleb128 Ltmp177-Ltmp176
	.uleb128 Ltmp178-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp140-Lfunc_begin2
	.uleb128 Ltmp141-Ltmp140
	.uleb128 Ltmp142-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp182-Lfunc_begin2
	.uleb128 Ltmp185-Ltmp182
	.uleb128 Ltmp188-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp185-Lfunc_begin2
	.uleb128 Ltmp146-Ltmp185
	.byte	0
	.byte	0
	.uleb128 Ltmp146-Lfunc_begin2
	.uleb128 Ltmp147-Ltmp146
	.uleb128 Ltmp148-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp186-Lfunc_begin2
	.uleb128 Ltmp187-Ltmp186
	.uleb128 Ltmp188-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp187-Lfunc_begin2
	.uleb128 Ltmp189-Ltmp187
	.byte	0
	.byte	0
	.uleb128 Ltmp189-Lfunc_begin2
	.uleb128 Ltmp190-Ltmp189
	.uleb128 Ltmp191-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp190-Lfunc_begin2
	.uleb128 Ltmp195-Ltmp190
	.byte	0
	.byte	0
	.uleb128 Ltmp195-Lfunc_begin2
	.uleb128 Ltmp196-Ltmp195
	.uleb128 Ltmp197-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp198-Lfunc_begin2
	.uleb128 Ltmp199-Ltmp198
	.uleb128 Ltmp200-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp199-Lfunc_begin2
	.uleb128 Ltmp204-Ltmp199
	.byte	0
	.byte	0
	.uleb128 Ltmp204-Lfunc_begin2
	.uleb128 Ltmp205-Ltmp204
	.uleb128 Ltmp206-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp205-Lfunc_begin2
	.uleb128 Ltmp210-Ltmp205
	.byte	0
	.byte	0
	.uleb128 Ltmp210-Lfunc_begin2
	.uleb128 Ltmp211-Ltmp210
	.uleb128 Ltmp212-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp213-Lfunc_begin2
	.uleb128 Ltmp214-Ltmp213
	.uleb128 Ltmp215-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp216-Lfunc_begin2
	.uleb128 Ltmp217-Ltmp216
	.uleb128 Ltmp218-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp219-Lfunc_begin2
	.uleb128 Ltmp220-Ltmp219
	.uleb128 Ltmp221-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp222-Lfunc_begin2
	.uleb128 Ltmp223-Ltmp222
	.uleb128 Ltmp224-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp225-Lfunc_begin2
	.uleb128 Ltmp226-Ltmp225
	.uleb128 Ltmp227-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp226-Lfunc_begin2
	.uleb128 Ltmp110-Ltmp226
	.byte	0
	.byte	0
	.uleb128 Ltmp110-Lfunc_begin2
	.uleb128 Ltmp111-Ltmp110
	.uleb128 Ltmp112-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp89-Lfunc_begin2
	.uleb128 Ltmp90-Ltmp89
	.uleb128 Ltmp91-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp92-Lfunc_begin2
	.uleb128 Ltmp93-Ltmp92
	.uleb128 Ltmp94-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp104-Lfunc_begin2
	.uleb128 Ltmp105-Ltmp104
	.uleb128 Ltmp106-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp95-Lfunc_begin2
	.uleb128 Ltmp96-Ltmp95
	.uleb128 Ltmp97-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp152-Lfunc_begin2
	.uleb128 Ltmp153-Ltmp152
	.uleb128 Ltmp154-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp149-Lfunc_begin2
	.uleb128 Ltmp150-Ltmp149
	.uleb128 Ltmp151-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp155-Lfunc_begin2
	.uleb128 Ltmp156-Ltmp155
	.uleb128 Ltmp157-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp164-Lfunc_begin2
	.uleb128 Ltmp165-Ltmp164
	.uleb128 Ltmp166-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp201-Lfunc_begin2
	.uleb128 Ltmp202-Ltmp201
	.uleb128 Ltmp203-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp192-Lfunc_begin2
	.uleb128 Ltmp193-Ltmp192
	.uleb128 Ltmp194-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp207-Lfunc_begin2
	.uleb128 Ltmp208-Ltmp207
	.uleb128 Ltmp209-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp143-Lfunc_begin2
	.uleb128 Ltmp144-Ltmp143
	.uleb128 Ltmp145-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp179-Lfunc_begin2
	.uleb128 Ltmp180-Ltmp179
	.uleb128 Ltmp181-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp180-Lfunc_begin2
	.uleb128 Lfunc_end2-Ltmp180
	.byte	0
	.byte	0
Lcst_end2:
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.globl	__RNvCs7wsLvUT6iAW_13codegen_audit4det4
	.p2align	2
__RNvCs7wsLvUT6iAW_13codegen_audit4det4:
	.cfi_startproc
	ldp	d0, d4, [x0]
	ldp	d7, d16, [x0, #16]
	ldp	d5, d1, [x0, #32]
	ldp	d2, d3, [x0, #48]
	fcmp	d0, #0.0
	b.eq	LBB16_9
	fcmp	d4, #0.0
	b.eq	LBB16_9
	fcmp	d7, #0.0
	b.eq	LBB16_9
	fcmp	d16, #0.0
	b.eq	LBB16_9
	fcmp	d5, #0.0
	b.eq	LBB16_9
	fcmp	d1, #0.0
	b.eq	LBB16_9
	fcmp	d2, #0.0
	b.eq	LBB16_9
	fcmp	d3, #0.0
	b.eq	LBB16_9
	ldp	d6, d17, [x0, #80]
	ldp	d19, d18, [x0, #112]
	fnmul	d20, d19, d17
	fmadd	d20, d6, d18, d20
	ldp	d22, d21, [x0, #96]
	fnmul	d23, d21, d17
	ldp	d25, d24, [x0, #64]
	fmadd	d23, d24, d18, d23
	fnmul	d26, d21, d6
	fmadd	d26, d24, d19, d26
	fnmul	d17, d22, d17
	fmadd	d17, d25, d18, d17
	fnmul	d6, d22, d6
	fmadd	d6, d25, d19, d6
	fnmul	d18, d22, d24
	fmadd	d18, d25, d21, d18
	fmul	d19, d3, d26
	fmsub	d19, d2, d23, d19
	fmadd	d19, d1, d20, d19
	fmul	d21, d3, d6
	fmsub	d21, d2, d17, d21
	fmadd	d20, d5, d20, d21
	fmul	d3, d3, d18
	fmsub	d3, d1, d17, d3
	fmadd	d3, d5, d23, d3
	fmul	d2, d2, d18
	fmsub	d1, d1, d6, d2
	fmadd	d1, d5, d26, d1
	fnmul	d1, d1, d16
	fmadd	d1, d7, d3, d1
	fmsub	d1, d4, d20, d1
	fmadd	d6, d0, d19, d1
	fmov	x9, d6
	ubfx	x9, x9, #52, #11
	cmp	x9, #2047
	b.hs	LBB16_32
	b	LBB16_43
LBB16_9:
	movi.2d	v6, #0000000000000000
	fcmp	d16, #0.0
	b.eq	LBB16_17
	ldp	d19, d6, [x0, #64]
	ldr	d18, [x0, #80]
	ldp	d21, d17, [x0, #96]
	fcmp	d5, #0.0
	ldr	d20, [x0, #112]
	b.eq	LBB16_14
	fcmp	d1, #0.0
	b.eq	LBB16_14
	fcmp	d2, #0.0
	b.eq	LBB16_14
	fnmul	d22, d17, d18
	fmadd	d22, d6, d20, d22
	fnmul	d18, d21, d18
	fmadd	d18, d19, d20, d18
	fnmul	d6, d21, d6
	fmadd	d6, d19, d17, d6
	fmul	d6, d2, d6
	fmsub	d6, d1, d18, d6
	fmadd	d19, d5, d22, d6
	b	LBB16_16
LBB16_14:
	fnmul	d22, d21, d6
	fmadd	d22, d19, d17, d22
	fmul	d22, d2, d22
	fcmp	d2, #0.0
	movi.2d	v23, #0000000000000000
	fcsel	d22, d23, d22, eq
	fnmul	d21, d21, d18
	fmadd	d19, d19, d20, d21
	fmsub	d19, d1, d19, d22
	fcmp	d1, #0.0
	fcsel	d19, d19, d22, ne
	fcmp	d5, #0.0
	b.eq	LBB16_16
	fnmul	d17, d17, d18
	fmadd	d6, d6, d20, d17
	fmadd	d19, d5, d6, d19
LBB16_16:
	fnmul	d6, d19, d16
LBB16_17:
	fcmp	d7, #0.0
	b.eq	LBB16_22
	ldp	d19, d16, [x0, #64]
	ldp	d18, d21, [x0, #88]
	ldr	d17, [x0, #104]
	fcmp	d5, #0.0
	ldr	d20, [x0, #120]
	b.eq	LBB16_23
	fcmp	d1, #0.0
	b.eq	LBB16_23
	fcmp	d3, #0.0
	b.eq	LBB16_23
	fnmul	d22, d17, d18
	fmadd	d22, d16, d20, d22
	fnmul	d18, d21, d18
	fmadd	d18, d19, d20, d18
	fnmul	d16, d21, d16
	fmadd	d16, d19, d17, d16
	fmul	d16, d3, d16
	fmsub	d16, d1, d18, d16
	fmadd	d19, d5, d22, d16
	fmadd	d6, d7, d19, d6
LBB16_22:
	fcmp	d4, #0.0
	b.ne	LBB16_26
	b	LBB16_30
LBB16_23:
	fnmul	d22, d21, d16
	fmadd	d22, d19, d17, d22
	fmul	d22, d3, d22
	fcmp	d3, #0.0
	movi.2d	v23, #0000000000000000
	fcsel	d22, d23, d22, eq
	fnmul	d21, d21, d18
	fmadd	d19, d19, d20, d21
	fmsub	d19, d1, d19, d22
	fcmp	d1, #0.0
	fcsel	d19, d19, d22, ne
	fcmp	d5, #0.0
	b.eq	LBB16_25
	fnmul	d17, d17, d18
	fmadd	d16, d16, d20, d17
	fmadd	d19, d5, d16, d19
LBB16_25:
	fmadd	d6, d7, d19, d6
	fcmp	d4, #0.0
	b.eq	LBB16_30
LBB16_26:
	ldr	d17, [x0, #64]
	ldp	d7, d16, [x0, #80]
	ldr	d20, [x0, #96]
	fcmp	d5, #0.0
	ldp	d18, d19, [x0, #112]
	b.eq	LBB16_33
	fcmp	d2, #0.0
	b.eq	LBB16_33
	fcmp	d3, #0.0
	b.eq	LBB16_33
	fnmul	d21, d18, d16
	fmadd	d21, d7, d19, d21
	fnmul	d16, d20, d16
	fmadd	d16, d17, d19, d16
	fnmul	d7, d20, d7
	fmadd	d7, d17, d18, d7
	fmul	d7, d3, d7
	fmsub	d7, d2, d16, d7
	fmadd	d17, d5, d21, d7
	fmsub	d6, d4, d17, d6
LBB16_30:
	fcmp	d0, #0.0
	b.ne	LBB16_36
LBB16_31:
	fmov	x9, d6
	ubfx	x9, x9, #52, #11
	cmp	x9, #2047
	b.lo	LBB16_43
LBB16_32:
	mov	w9, #6
	strb	w9, [x8, #1]
	mov	w9, #1
	mov	x10, #5
	fmov	d6, x10
	strb	w9, [x8]
	str	d6, [x8, #8]
	ret
LBB16_33:
	fnmul	d21, d20, d7
	fmadd	d21, d17, d18, d21
	fmul	d21, d3, d21
	fcmp	d3, #0.0
	movi.2d	v22, #0000000000000000
	fcsel	d21, d22, d21, eq
	fnmul	d20, d20, d16
	fmadd	d17, d17, d19, d20
	fmsub	d17, d2, d17, d21
	fcmp	d2, #0.0
	fcsel	d17, d17, d21, ne
	fcmp	d5, #0.0
	b.eq	LBB16_35
	fnmul	d16, d18, d16
	fmadd	d7, d7, d19, d16
	fmadd	d17, d5, d7, d17
LBB16_35:
	fmsub	d6, d4, d17, d6
	fcmp	d0, #0.0
	b.eq	LBB16_31
LBB16_36:
	ldp	d16, d4, [x0, #72]
	ldr	d7, [x0, #88]
	ldp	d18, d5, [x0, #104]
	fcmp	d1, #0.0
	ldr	d17, [x0, #120]
	b.eq	LBB16_40
	fcmp	d2, #0.0
	b.eq	LBB16_40
	fcmp	d3, #0.0
	b.eq	LBB16_40
	fnmul	d19, d5, d7
	fmadd	d19, d4, d17, d19
	fnmul	d7, d18, d7
	fmadd	d7, d16, d17, d7
	fnmul	d4, d18, d4
	fmadd	d4, d16, d5, d4
	fmul	d3, d3, d4
	fmsub	d2, d2, d7, d3
	fmadd	d2, d1, d19, d2
	b	LBB16_42
LBB16_40:
	fnmul	d19, d18, d4
	fmadd	d19, d16, d5, d19
	fmul	d19, d3, d19
	fcmp	d3, #0.0
	movi.2d	v3, #0000000000000000
	fcsel	d3, d3, d19, eq
	fnmul	d18, d18, d7
	fmadd	d16, d16, d17, d18
	fmsub	d16, d2, d16, d3
	fcmp	d2, #0.0
	fcsel	d2, d16, d3, ne
	fcmp	d1, #0.0
	b.eq	LBB16_42
	fnmul	d3, d5, d7
	fmadd	d3, d4, d17, d3
	fmadd	d2, d1, d3, d2
LBB16_42:
	fmadd	d6, d0, d2, d6
	fmov	x9, d6
	ubfx	x9, x9, #52, #11
	cmp	x9, #2047
	b.hs	LBB16_32
LBB16_43:
	mov	w9, #255
	strb	w9, [x8]
	str	d6, [x8, #8]
	ret
	.cfi_endproc

	.globl	__RNvCs7wsLvUT6iAW_13codegen_audit4dot4
	.p2align	2
__RNvCs7wsLvUT6iAW_13codegen_audit4dot4:
	.cfi_startproc
	movi.2d	v0, #0000000000000000
	ldp	d1, d3, [x0]
	ldp	d2, d4, [x1]
	fmadd	d2, d1, d2, d0
	fmadd	d0, d3, d4, d2
	ldp	d1, d3, [x0, #16]
	ldp	d4, d5, [x1, #16]
	fmadd	d1, d1, d4, d0
	fmadd	d3, d3, d5, d1
	fmov	x9, d3
	ubfx	x9, x9, #52, #11
	cmp	x9, #2047
	b.hs	LBB17_2
	str	d3, [x8, #8]
	mov	w9, #255
	strb	w9, [x8]
	ret
LBB17_2:
	fmov	x9, d2
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.ls	LBB17_4
	mov	x9, #0
	mov	w10, #3329
	strh	w10, [x8]
	mov	w10, #2
	strb	w10, [x8, #8]
	str	x9, [x8, #16]
	ret
LBB17_4:
	fmov	x9, d0
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.ls	LBB17_6
	mov	w9, #1
	mov	w10, #3329
	strh	w10, [x8]
	mov	w10, #2
	strb	w10, [x8, #8]
	str	x9, [x8, #16]
	ret
LBB17_6:
	fmov	x9, d1
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.ls	LBB17_8
	mov	w9, #2
	mov	w10, #3329
	strh	w10, [x8]
	mov	w10, #2
	strb	w10, [x8, #8]
	str	x9, [x8, #16]
	ret
LBB17_8:
	mov	w9, #3
	mov	w10, #3329
	strh	w10, [x8]
	mov	w10, #2
	strb	w10, [x8, #8]
	str	x9, [x8, #16]
	ret
	.cfi_endproc

	.globl	__RNvCs7wsLvUT6iAW_13codegen_audit5norm4
	.p2align	2
__RNvCs7wsLvUT6iAW_13codegen_audit5norm4:
	.cfi_startproc
	mov	x1, x0
	ldr	d0, [x0]
	fabs	d0, d0
	fmov	d2, #1.00000000
	mov	w9, #8
	fmov	d1, #1.00000000
LBB18_1:
	mov	x10, x9
LBB18_2:
	cmp	x10, #32
	b.eq	LBB18_7
	add	x9, x10, #8
	ldr	d3, [x1, x10]
	fcmp	d3, #0.0
	mov	x10, x9
	b.eq	LBB18_2
	fabs	d3, d3
	fcmp	d0, d3
	b.mi	LBB18_6
	fdiv	d3, d3, d0
	fmadd	d1, d3, d3, d1
	b	LBB18_1
LBB18_6:
	fdiv	d0, d0, d3
	fmul	d1, d1, d0
	fmadd	d1, d1, d0, d2
	mov.16b	v0, v3
	b	LBB18_1
LBB18_7:
	mov	x9, #9200854038717923328
	fmov	d2, x9
	fcmp	d0, d2
	b.gt	LBB18_9
	fsqrt	d1, d1
	fmul	d0, d0, d1
	str	d0, [x8, #8]
	mov	w9, #255
	strb	w9, [x8]
	ret
LBB18_9:
	mov	x0, x8
	b	__RINvNtCshzmyaYQzAhy_8la_stack4norm18norm_near_overflowKj4_ECs7wsLvUT6iAW_13codegen_audit
	.cfi_endproc

	.globl	__RNvCs7wsLvUT6iAW_13codegen_audit9lu_solve4
	.p2align	2
__RNvCs7wsLvUT6iAW_13codegen_audit9lu_solve4:
	.cfi_startproc
	sub	sp, sp, #224
	.cfi_def_cfa_offset 224
	stp	x29, x30, [sp, #208]
	add	x29, sp, #208
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	ldp	q0, q1, [x0, #64]
	stp	q0, q1, [sp, #64]
	ldp	q0, q1, [x0, #96]
	stp	q0, q1, [sp, #96]
	ldp	q0, q1, [x0]
	stp	q0, q1, [sp]
	ldp	q0, q1, [x0, #32]
	stp	q0, q1, [sp, #32]
	mov	w9, #1
	mov	w10, #2
	stp	x9, x10, [x29, #-64]
	mov	w9, #3
	stur	x9, [x29, #-48]
	ldr	d0, [sp]
	ldr	d2, [sp, #32]
	fabs	d1, d0
	fabs	d3, d2
	fcmp	d3, d1
	cset	w11, gt
	fcsel	d3, d3, d1, gt
	ldr	d1, [sp, #64]
	ldr	d16, [sp, #96]
	fabs	d4, d1
	fcmp	d4, d3
	fcsel	d3, d4, d3, gt
	csel	x10, x10, x11, gt
	fabs	d4, d16
	fcmp	d4, d3
	csel	x10, x9, x10, gt
	fcsel	d20, d4, d3, gt
	mov	x9, #59921
	movk	x9, #33069, lsl #16
	movk	x9, #38809, lsl #32
	movk	x9, #15729, lsl #48
	fmov	d3, x9
	fcmp	d20, d3
	b.ls	LBB19_38
	cbz	x10, LBB19_3
	mov	x11, sp
	add	x11, x11, x10, lsl #5
	ldp	q0, q1, [x11]
	stp	q0, q1, [sp]
	ldp	q0, q1, [x0]
	stp	q0, q1, [x11]
	sub	x11, x29, #72
	ldr	x0, [x11, x10, lsl #3]
	str	xzr, [x11, x10, lsl #3]
	ldr	d0, [sp]
	ldr	d2, [sp, #32]
	ldr	d1, [sp, #64]
	ldr	d16, [sp, #96]
	b	LBB19_4
LBB19_3:
	mov	x0, #0
LBB19_4:
	fdiv	d7, d2, d0
	ldp	d2, d3, [sp, #8]
	ldp	d5, d6, [sp, #40]
	ldr	d4, [sp, #24]
	fmsub	d5, d7, d2, d5
	stp	d7, d5, [sp, #32]
	ldr	d17, [sp, #56]
	fmsub	d6, d7, d3, d6
	fmsub	d7, d7, d4, d17
	stp	d6, d7, [sp, #48]
	fdiv	d18, d1, d0
	ldp	d1, d17, [sp, #72]
	fmsub	d1, d18, d2, d1
	stp	d18, d1, [sp, #64]
	fmsub	d17, d18, d3, d17
	ldr	d19, [sp, #88]
	ldp	d21, d20, [sp, #104]
	fmsub	d18, d18, d4, d19
	stp	d17, d18, [sp, #80]
	fdiv	d16, d16, d0
	fmsub	d19, d16, d2, d21
	stp	d16, d19, [sp, #96]
	ldr	d21, [sp, #120]
	fmsub	d22, d16, d3, d20
	fmsub	d21, d16, d4, d21
	stp	d22, d21, [sp, #112]
	fabs	d16, d5
	fabs	d20, d1
	fcmp	d20, d16
	fcsel	d16, d20, d16, gt
	mov	w10, #2
	csinc	x10, x10, xzr, gt
	fabs	d20, d19
	fcmp	d20, d16
	mov	w11, #3
	csel	x11, x11, x10, gt
	fcsel	d20, d20, d16, gt
	mov	x10, #59921
	movk	x10, #33069, lsl #16
	movk	x10, #38809, lsl #32
	movk	x10, #15729, lsl #48
	fmov	d16, x10
	fcmp	d20, d16
	b.ls	LBB19_39
	mov	x10, sp
	cmp	x11, #1
	b.eq	LBB19_7
	mov	x12, sp
	ldp	q5, q1, [x10, #32]
	add	x12, x12, x11, lsl #5
	ldp	q7, q6, [x12]
	stp	q7, q6, [x10, #32]
	stp	q5, q1, [x12]
	ldur	x12, [x29, #-64]
	sub	x13, x29, #72
	ldr	x14, [x13, x11, lsl #3]
	stur	x14, [x29, #-64]
	str	x12, [x13, x11, lsl #3]
	ldp	d5, d6, [sp, #40]
	ldp	d1, d17, [sp, #72]
	ldr	d7, [sp, #56]
	ldr	d18, [sp, #88]
	ldp	d19, d22, [sp, #104]
	ldr	d21, [sp, #120]
LBB19_7:
	fdiv	d1, d1, d5
	fmsub	d16, d1, d6, d17
	stp	d1, d16, [sp, #72]
	fmsub	d17, d1, d7, d18
	fdiv	d18, d19, d5
	str	d17, [sp, #88]
	str	d18, [sp, #104]
	fmsub	d1, d18, d6, d22
	fmsub	d18, d18, d7, d21
	stp	d1, d18, [sp, #112]
	fabs	d19, d16
	fabs	d21, d1
	fcmp	d21, d19
	fcsel	d20, d19, d21, le
	mov	x11, #59921
	movk	x11, #33069, lsl #16
	movk	x11, #38809, lsl #32
	movk	x11, #15729, lsl #48
	fmov	d22, x11
	fcmp	d20, d22
	b.ls	LBB19_40
	fcmp	d21, d19
	b.le	LBB19_10
	ldp	q16, q1, [x10, #64]
	ldp	q17, q18, [x10, #96]
	stp	q17, q18, [x10, #64]
	stp	q16, q1, [x10, #96]
	ldp	x10, x11, [x29, #-56]
	stp	x11, x10, [x29, #-56]
	ldp	d16, d17, [sp, #80]
	ldp	d1, d18, [sp, #112]
LBB19_10:
	fdiv	d19, d1, d16
	fmsub	d18, d19, d17, d18
	stp	d19, d18, [sp, #112]
	fabs	d20, d18
	mov	x10, #59921
	movk	x10, #33069, lsl #16
	movk	x10, #38809, lsl #32
	movk	x10, #15729, lsl #48
	fmov	d1, x10
	fcmp	d20, d1
	b.ls	LBB19_41
	fmov	x10, d0
	movi.2d	v1, #0000000000000000
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB19_13
LBB19_12:
	mov	x11, #0
	mov	x10, #0
	mov	x12, #513
	fmov	d0, x12
	b	LBB19_24
LBB19_13:
	fmov	x10, d2
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB19_16
LBB19_14:
	mov	x11, #0
	mov	x10, #0
	mov	x12, #513
	fmov	d0, x12
LBB19_15:
	mov	x12, #1
	fmov	d1, x12
	b	LBB19_24
LBB19_16:
	fmov	x10, d3
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB19_19
LBB19_17:
	mov	x11, #0
	mov	x10, #0
	mov	x12, #513
	fmov	d0, x12
LBB19_18:
	mov	x12, #2
	fmov	d1, x12
	b	LBB19_24
LBB19_19:
	fmov	x10, d4
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB19_22
LBB19_20:
	mov	x11, #0
	mov	x10, #0
	mov	x12, #513
	fmov	d0, x12
LBB19_21:
	mov	x12, #3
	fmov	d1, x12
	b	LBB19_24
LBB19_22:
	ldr	d20, [sp, #32]
	fmov	x10, d20
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB19_26
LBB19_23:
	mov	x10, #0
	mov	x11, #513
	fmov	d0, x11
	mov	w11, #1
LBB19_24:
	str	d0, [x8]
	stp	x10, x11, [x8, #8]
	str	d1, [x8, #24]
	str	x9, [x8, #32]
LBB19_25:
	.cfi_def_cfa wsp, 224
	ldp	x29, x30, [sp, #208]
	add	sp, sp, #224
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
LBB19_26:
	.cfi_restore_state
	fmov	x10, d5
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB19_28
LBB19_27:
	mov	x10, #0
	mov	x11, #513
	fmov	d0, x11
	mov	w11, #1
	b	LBB19_15
LBB19_28:
	fmov	x10, d6
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB19_30
LBB19_29:
	mov	x10, #0
	mov	x11, #513
	fmov	d0, x11
	mov	w11, #1
	b	LBB19_18
LBB19_30:
	fmov	x10, d7
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB19_32
LBB19_31:
	mov	x10, #0
	mov	x11, #513
	fmov	d0, x11
	mov	w11, #1
	b	LBB19_21
LBB19_32:
	ldr	d21, [sp, #64]
	fmov	x10, d21
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB19_34
LBB19_33:
	mov	x10, #0
	mov	x11, #513
	fmov	d0, x11
	mov	w11, #2
	b	LBB19_24
LBB19_34:
	ldr	d22, [sp, #72]
	fmov	x10, d22
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB19_36
LBB19_35:
	mov	x10, #0
	mov	x11, #513
	fmov	d0, x11
	mov	w11, #2
	b	LBB19_15
LBB19_36:
	fmov	x10, d16
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB19_59
LBB19_37:
	mov	x10, #0
	mov	x11, #513
	fmov	d0, x11
	mov	w11, #2
	b	LBB19_18
LBB19_38:
	mov	x10, #0
	b	LBB19_42
LBB19_39:
	mov	w10, #1
	b	LBB19_42
LBB19_40:
	mov	w10, #2
	b	LBB19_42
LBB19_41:
	mov	w10, #3
LBB19_42:
	fmov	x11, d0
	movi.2d	v1, #0000000000000000
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB19_12
	ldr	x11, [sp, #8]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB19_14
	ldr	x11, [sp, #16]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB19_17
	ldr	x11, [sp, #24]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2047
	b.hs	LBB19_20
	ldr	x11, [sp, #32]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB19_23
	ldr	x11, [sp, #40]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB19_27
	ldr	x11, [sp, #48]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB19_29
	ldr	x11, [sp, #56]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB19_31
	ldr	x11, [sp, #64]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB19_33
	ldr	x11, [sp, #72]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB19_35
	ldr	x11, [sp, #80]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB19_37
	ldr	x11, [sp, #88]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB19_60
	ldr	x11, [sp, #96]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB19_62
	ldr	x11, [sp, #104]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB19_64
	ldr	x11, [sp, #112]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB19_66
	ldr	x11, [sp, #120]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB19_68
	movi.2d	v0, #0000000000000000
	mov	w11, #1
	mov.16b	v1, v20
	b	LBB19_24
LBB19_59:
	fmov	x10, d17
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB19_61
LBB19_60:
	mov	x10, #0
	mov	x11, #513
	fmov	d0, x11
	mov	w11, #2
	b	LBB19_21
LBB19_61:
	ldr	d23, [sp, #96]
	fmov	x10, d23
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB19_63
LBB19_62:
	mov	x10, #0
	mov	x11, #513
	fmov	d0, x11
	mov	w11, #3
	b	LBB19_24
LBB19_63:
	ldr	d24, [sp, #104]
	fmov	x10, d24
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB19_65
LBB19_64:
	mov	x10, #0
	mov	x11, #513
	fmov	d0, x11
	mov	w11, #3
	b	LBB19_15
LBB19_65:
	fmov	x10, d19
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB19_67
LBB19_66:
	mov	x10, #0
	mov	x11, #513
	fmov	d0, x11
	mov	w11, #3
	b	LBB19_18
LBB19_67:
	fmov	x10, d18
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB19_69
LBB19_68:
	mov	x10, #0
	mov	x11, #513
	fmov	d0, x11
	mov	w11, #3
	b	LBB19_21
LBB19_69:
	cmp	x0, #4
	b.hs	LBB19_97
	ldur	x11, [x29, #-64]
	cmp	x11, #3
	b.hi	LBB19_94
	ldur	x10, [x29, #-56]
	cmp	x10, #3
	b.hi	LBB19_95
	ldur	x9, [x29, #-48]
	cmp	x9, #4
	b.hs	LBB19_96
	ldr	d1, [x1, x0, lsl #3]
	fmov	x12, d1
	ubfx	x12, x12, #52, #11
	cmp	x12, #2047
	b.hs	LBB19_88
	ldr	d25, [x1, x11, lsl #3]
	fmsub	d20, d20, d1, d25
	fmov	x11, d20
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB19_87
	ldr	d25, [x1, x10, lsl #3]
	fmsub	d21, d21, d1, d25
	fmsub	d21, d22, d20, d21
	fmov	x10, d21
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.hi	LBB19_86
	ldr	d22, [x1, x9, lsl #3]
	fmsub	d22, d23, d1, d22
	fmsub	d22, d24, d20, d22
	fmsub	d19, d19, d21, d22
	fmov	x9, d19
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB19_85
	fdiv	d18, d19, d18
	fmov	x9, d18
	ubfx	x9, x9, #52, #11
	cmp	x9, #2047
	b.hs	LBB19_85
	fmsub	d17, d17, d18, d21
	fmov	x10, d17
	mov	w9, #2
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.hi	LBB19_90
	fdiv	d16, d17, d16
	fmov	x10, d16
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.hi	LBB19_86
	fmsub	d6, d6, d16, d20
	fmsub	d6, d7, d18, d6
	fmov	x10, d6
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.hi	LBB19_91
	fdiv	d5, d6, d5
	fmov	x10, d5
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.hi	LBB19_87
	fmsub	d1, d2, d5, d1
	fmsub	d1, d3, d16, d1
	fmsub	d1, d4, d18, d1
	fmov	x10, d1
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.hi	LBB19_92
	fdiv	d0, d1, d0
	fmov	x9, d0
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB19_88
	stp	d0, d5, [x8, #8]
	stp	d16, d18, [x8, #24]
	mov	w9, #255
	strb	w9, [x8]
	b	LBB19_25
LBB19_85:
	mov	w9, #3
	b	LBB19_89
LBB19_86:
	mov	w9, #2
	b	LBB19_89
LBB19_87:
	mov	w9, #1
	b	LBB19_89
LBB19_88:
	mov	x9, #0
LBB19_89:
	mov	w10, #1025
	strh	w10, [x8]
	mov	w10, #2
	strb	w10, [x8, #8]
	str	x9, [x8, #16]
	b	LBB19_25
LBB19_90:
	mov	w10, #2
	b	LBB19_93
LBB19_91:
	mov	w10, #1
	b	LBB19_93
LBB19_92:
	mov	x10, #0
LBB19_93:
	mov	w11, #1025
	strh	w11, [x8]
	strb	w9, [x8, #8]
	str	x10, [x8, #16]
	b	LBB19_25
LBB19_94:
	mov	x0, x11
Lloh30:
	adrp	x2, l_alloc_4bd28277e2eacf0bcc30cc366dd2df7a@PAGE
Lloh31:
	add	x2, x2, l_alloc_4bd28277e2eacf0bcc30cc366dd2df7a@PAGEOFF
	mov	w1, #4
	bl	__RNvNtCsjIpoRzUjyHQ_4core9panicking18panic_bounds_check
LBB19_95:
	mov	x0, x10
Lloh32:
	adrp	x2, l_alloc_4bd28277e2eacf0bcc30cc366dd2df7a@PAGE
Lloh33:
	add	x2, x2, l_alloc_4bd28277e2eacf0bcc30cc366dd2df7a@PAGEOFF
	mov	w1, #4
	bl	__RNvNtCsjIpoRzUjyHQ_4core9panicking18panic_bounds_check
LBB19_96:
	mov	x0, x9
LBB19_97:
Lloh34:
	adrp	x2, l_alloc_4bd28277e2eacf0bcc30cc366dd2df7a@PAGE
Lloh35:
	add	x2, x2, l_alloc_4bd28277e2eacf0bcc30cc366dd2df7a@PAGEOFF
	mov	w1, #4
	bl	__RNvNtCsjIpoRzUjyHQ_4core9panicking18panic_bounds_check
	.loh AdrpAdd	Lloh30, Lloh31
	.loh AdrpAdd	Lloh32, Lloh33
	.loh AdrpAdd	Lloh34, Lloh35
	.cfi_endproc

	.globl	__RNvCs7wsLvUT6iAW_13codegen_audit9lu_solve5
	.p2align	2
__RNvCs7wsLvUT6iAW_13codegen_audit9lu_solve5:
	.cfi_startproc
	sub	sp, sp, #368
	.cfi_def_cfa_offset 368
	stp	d11, d10, [sp, #304]
	stp	d9, d8, [sp, #320]
	stp	x28, x27, [sp, #336]
	stp	x29, x30, [sp, #352]
	add	x29, sp, #352
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	.cfi_offset b8, -40
	.cfi_offset b9, -48
	.cfi_offset b10, -56
	.cfi_offset b11, -64
	.cfi_remember_state
	mov	x11, #0
	ldr	x9, [x0, #192]
	str	x9, [sp, #192]
	ldp	q0, q1, [x0, #128]
	stp	q0, q1, [sp, #128]
	ldp	q0, q1, [x0, #160]
	stp	q0, q1, [sp, #160]
	ldp	q0, q1, [x0, #64]
	stp	q0, q1, [sp, #64]
	ldp	q0, q1, [x0, #96]
	stp	q0, q1, [sp, #96]
	ldp	q0, q1, [x0]
	stp	q0, q1, [sp]
	ldp	q0, q1, [x0, #32]
	stp	q0, q1, [sp, #32]
	mov	x12, sp
	add	x13, x12, #48
	mov	w9, #1
	stp	xzr, x9, [x29, #-144]
	mov	w9, #2
	mov	w10, #3
	mov	w17, #4
	add	x14, x12, #40
	stp	x9, x10, [x29, #-128]
	orr	x15, x12, #0x8
	mov	w16, #40
	stur	x17, [x29, #-112]
	mov	x9, #59921
	movk	x9, #33069, lsl #16
	movk	x9, #38809, lsl #32
	movk	x9, #15729, lsl #48
	fmov	d0, x9
	sub	x17, x29, #144
	sturb	wzr, [x29, #-104]
	b	LBB20_2
LBB20_1:
	add	x14, x14, #48
	add	x13, x13, #48
	add	x15, x15, #48
	cmp	x11, #5
	b.eq	LBB20_12
LBB20_2:
	mov	x10, x11
	madd	x0, x11, x16, x12
	ldr	d1, [x0, x11, lsl #3]
	add	x11, x11, #1
	fabs	d2, d1
	mov	x2, x10
	mov	x3, x14
	add	x4, x10, #1
	cmp	x10, #3
	b.hi	LBB20_4
LBB20_3:
	ldr	d3, [x3], #40
	fabs	d3, d3
	fcmp	d3, d2
	csel	x2, x4, x2, gt
	add	x4, x4, #1
	fcsel	d2, d3, d2, gt
	cmp	x4, #5
	b.ne	LBB20_3
LBB20_4:
	fcmp	d2, d0
	b.ls	LBB20_30
	cmp	x2, x10
	b.eq	LBB20_7
	madd	x3, x2, x16, x12
	ldp	q1, q2, [x0]
	ldr	x4, [x0, #32]
	ldr	x5, [x3, #32]
	ldp	q4, q3, [x3]
	stp	q4, q3, [x0]
	str	x5, [x0, #32]
	ldr	x5, [x17, x10, lsl #3]
	ldr	x6, [x17, x2, lsl #3]
	str	x4, [x3, #32]
	str	x6, [x17, x10, lsl #3]
	str	x5, [x17, x2, lsl #3]
	stp	q1, q2, [x3]
	ldurb	w2, [x29, #-104]
	eor	w2, w2, #0x1
	sturb	w2, [x29, #-104]
	ldr	d1, [x0, x10, lsl #3]
LBB20_7:
	cmp	x10, #3
	b.hi	LBB20_1
	mov	x0, x13
	add	x2, x10, #1
LBB20_9:
	mov	x3, #0
	madd	x4, x2, x16, x12
	ldr	d2, [x4, x10, lsl #3]
	fdiv	d2, d2, d1
	str	d2, [x4, x10, lsl #3]
LBB20_10:
	ldr	d3, [x15, x3, lsl #3]
	ldr	d4, [x0, x3, lsl #3]
	fmsub	d3, d2, d3, d4
	str	d3, [x0, x3, lsl #3]
	add	x3, x3, #1
	add	x4, x10, x3
	cmp	x4, #4
	b.ne	LBB20_10
	add	x2, x2, #1
	add	x0, x0, #40
	cmp	x2, #5
	b.ne	LBB20_9
	b	LBB20_1
LBB20_12:
	ldr	d1, [sp]
	fmov	x10, d1
	movi.2d	v0, #0000000000000000
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB20_14
LBB20_13:
	mov	x11, #0
	mov	x10, #0
	mov	x12, #513
	fmov	d1, x12
	b	LBB20_28
LBB20_14:
	ldr	d2, [sp, #8]
	fmov	x10, d2
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB20_17
LBB20_15:
	mov	x11, #0
	mov	x10, #0
	mov	x12, #513
	fmov	d1, x12
LBB20_16:
	mov	x12, #1
	fmov	d0, x12
	b	LBB20_28
LBB20_17:
	ldr	d3, [sp, #16]
	fmov	x10, d3
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB20_20
LBB20_18:
	mov	x11, #0
	mov	x10, #0
	mov	x12, #513
	fmov	d1, x12
LBB20_19:
	mov	x12, #2
	fmov	d0, x12
	b	LBB20_28
LBB20_20:
	ldr	d4, [sp, #24]
	fmov	x10, d4
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB20_23
LBB20_21:
	mov	x11, #0
	mov	x10, #0
	mov	x12, #513
	fmov	d1, x12
LBB20_22:
	mov	x12, #3
	fmov	d0, x12
	b	LBB20_28
LBB20_23:
	ldr	d5, [sp, #32]
	fmov	x10, d5
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB20_26
LBB20_24:
	mov	x11, #0
	mov	x10, #0
	mov	x12, #513
	fmov	d1, x12
LBB20_25:
	mov	x12, #4
	fmov	d0, x12
	b	LBB20_28
LBB20_26:
	ldr	d21, [sp, #40]
	fmov	x10, d21
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB20_56
LBB20_27:
	mov	x10, #0
	mov	x11, #513
	fmov	d1, x11
	mov	w11, #1
LBB20_28:
	str	d1, [x8]
	stp	x10, x11, [x8, #8]
	str	d0, [x8, #24]
	str	x9, [x8, #32]
LBB20_29:
	.cfi_def_cfa wsp, 368
	ldp	x29, x30, [sp, #352]
	ldp	x28, x27, [sp, #336]
	ldp	d9, d8, [sp, #320]
	ldp	d11, d10, [sp, #304]
	add	sp, sp, #368
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	.cfi_restore b11
	ret
LBB20_30:
	.cfi_restore_state
	ldr	x11, [sp]
	movi.2d	v0, #0000000000000000
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB20_13
	ldr	x11, [sp, #8]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB20_15
	ldr	x11, [sp, #16]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB20_18
	ldr	x11, [sp, #24]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB20_21
	ldr	x11, [sp, #32]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2047
	b.hs	LBB20_24
	ldr	x11, [sp, #40]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB20_27
	ldr	x11, [sp, #48]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB20_57
	ldr	x11, [sp, #56]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB20_59
	ldr	x11, [sp, #64]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB20_61
	ldr	x11, [sp, #72]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB20_63
	ldr	x11, [sp, #80]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB20_65
	ldr	x11, [sp, #88]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB20_67
	ldr	x11, [sp, #96]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB20_69
	ldr	x11, [sp, #104]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB20_71
	ldr	x11, [sp, #112]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB20_73
	ldr	x11, [sp, #120]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB20_75
	ldr	x11, [sp, #128]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB20_77
	ldr	x11, [sp, #136]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB20_79
	ldr	x11, [sp, #144]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB20_81
	ldr	x11, [sp, #152]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB20_83
	ldr	x11, [sp, #160]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB20_85
	ldr	x11, [sp, #168]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB20_87
	ldr	x11, [sp, #176]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB20_89
	ldr	x11, [sp, #184]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB20_91
	ldr	x11, [sp, #192]
	ubfx	x11, x11, #52, #11
	cmp	x11, #2046
	b.hi	LBB20_93
	movi.2d	v1, #0000000000000000
	mov	w11, #1
	mov.16b	v0, v2
	b	LBB20_28
LBB20_56:
	ldr	d6, [sp, #48]
	fmov	x10, d6
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB20_58
LBB20_57:
	mov	x10, #0
	mov	x11, #513
	fmov	d1, x11
	mov	w11, #1
	b	LBB20_16
LBB20_58:
	ldr	d7, [sp, #56]
	fmov	x10, d7
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB20_60
LBB20_59:
	mov	x10, #0
	mov	x11, #513
	fmov	d1, x11
	mov	w11, #1
	b	LBB20_19
LBB20_60:
	ldr	d16, [sp, #64]
	fmov	x10, d16
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB20_62
LBB20_61:
	mov	x10, #0
	mov	x11, #513
	fmov	d1, x11
	mov	w11, #1
	b	LBB20_22
LBB20_62:
	ldr	d17, [sp, #72]
	fmov	x10, d17
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB20_64
LBB20_63:
	mov	x10, #0
	mov	x11, #513
	fmov	d1, x11
	mov	w11, #1
	b	LBB20_25
LBB20_64:
	ldr	d22, [sp, #80]
	fmov	x10, d22
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB20_66
LBB20_65:
	mov	x10, #0
	mov	x11, #513
	fmov	d1, x11
	mov	w11, #2
	b	LBB20_28
LBB20_66:
	ldr	d24, [sp, #88]
	fmov	x10, d24
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB20_68
LBB20_67:
	mov	x10, #0
	mov	x11, #513
	fmov	d1, x11
	mov	w11, #2
	b	LBB20_16
LBB20_68:
	ldr	d18, [sp, #96]
	fmov	x10, d18
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB20_70
LBB20_69:
	mov	x10, #0
	mov	x11, #513
	fmov	d1, x11
	mov	w11, #2
	b	LBB20_19
LBB20_70:
	ldr	d19, [sp, #104]
	fmov	x10, d19
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB20_72
LBB20_71:
	mov	x10, #0
	mov	x11, #513
	fmov	d1, x11
	mov	w11, #2
	b	LBB20_22
LBB20_72:
	ldr	d20, [sp, #112]
	fmov	x10, d20
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB20_74
LBB20_73:
	mov	x10, #0
	mov	x11, #513
	fmov	d1, x11
	mov	w11, #2
	b	LBB20_25
LBB20_74:
	ldr	d26, [sp, #120]
	fmov	x10, d26
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB20_76
LBB20_75:
	mov	x10, #0
	mov	x11, #513
	fmov	d1, x11
	mov	w11, #3
	b	LBB20_28
LBB20_76:
	ldr	d27, [sp, #128]
	fmov	x10, d27
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB20_78
LBB20_77:
	mov	x10, #0
	mov	x11, #513
	fmov	d1, x11
	mov	w11, #3
	b	LBB20_16
LBB20_78:
	ldr	d28, [sp, #136]
	fmov	x10, d28
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB20_80
LBB20_79:
	mov	x10, #0
	mov	x11, #513
	fmov	d1, x11
	mov	w11, #3
	b	LBB20_19
LBB20_80:
	ldr	d23, [sp, #144]
	fmov	x10, d23
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB20_82
LBB20_81:
	mov	x10, #0
	mov	x11, #513
	fmov	d1, x11
	mov	w11, #3
	b	LBB20_22
LBB20_82:
	ldr	d25, [sp, #152]
	fmov	x10, d25
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB20_84
LBB20_83:
	mov	x10, #0
	mov	x11, #513
	fmov	d1, x11
	mov	w11, #3
	b	LBB20_25
LBB20_84:
	ldr	d29, [sp, #160]
	fmov	x10, d29
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB20_86
LBB20_85:
	mov	x10, #0
	mov	x11, #513
	fmov	d1, x11
	mov	w11, #4
	b	LBB20_28
LBB20_86:
	ldr	d30, [sp, #168]
	fmov	x10, d30
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB20_88
LBB20_87:
	mov	x10, #0
	mov	x11, #513
	fmov	d1, x11
	mov	w11, #4
	b	LBB20_16
LBB20_88:
	ldr	d31, [sp, #176]
	fmov	x10, d31
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB20_90
LBB20_89:
	mov	x10, #0
	mov	x11, #513
	fmov	d1, x11
	mov	w11, #4
	b	LBB20_19
LBB20_90:
	ldr	d8, [sp, #184]
	fmov	x10, d8
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB20_92
LBB20_91:
	mov	x10, #0
	mov	x11, #513
	fmov	d1, x11
	mov	w11, #4
	b	LBB20_22
LBB20_92:
	ldr	d9, [sp, #192]
	fmov	x10, d9
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB20_94
LBB20_93:
	mov	x10, #0
	mov	x11, #513
	fmov	d1, x11
	mov	w11, #4
	b	LBB20_25
LBB20_94:
	ldur	x0, [x29, #-144]
	cmp	x0, #5
	b.hs	LBB20_120
	ldr	d0, [x1, x0, lsl #3]
	fmov	x9, d0
	ubfx	x9, x9, #52, #11
	cmp	x9, #2047
	b.hs	LBB20_117
	ldur	x0, [x29, #-136]
	cmp	x0, #4
	b.hi	LBB20_120
	ldr	d10, [x1, x0, lsl #3]
	fmsub	d21, d21, d0, d10
	fmov	x9, d21
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB20_116
	ldur	x0, [x29, #-128]
	cmp	x0, #4
	b.hi	LBB20_120
	ldr	d10, [x1, x0, lsl #3]
	fmsub	d22, d22, d0, d10
	fmsub	d24, d24, d21, d22
	fmov	x9, d24
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB20_115
	ldur	x0, [x29, #-120]
	cmp	x0, #4
	b.hi	LBB20_120
	ldr	d22, [x1, x0, lsl #3]
	fmsub	d22, d26, d0, d22
	fmsub	d22, d27, d21, d22
	fmsub	d26, d28, d24, d22
	fmov	x9, d26
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB20_114
	ldur	x0, [x29, #-112]
	cmp	x0, #4
	b.hi	LBB20_120
	ldr	d22, [x1, x0, lsl #3]
	fmsub	d22, d29, d0, d22
	fmsub	d22, d30, d21, d22
	fmsub	d22, d31, d24, d22
	fmsub	d22, d8, d26, d22
	fmov	x9, d22
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB20_118
	fdiv	d22, d22, d9
	fmov	x9, d22
	ubfx	x9, x9, #52, #11
	cmp	x9, #2047
	b.hs	LBB20_118
	fmsub	d25, d25, d22, d26
	fmov	x9, d25
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB20_114
	fdiv	d23, d25, d23
	fmov	x9, d23
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB20_114
	fmsub	d19, d19, d23, d24
	fmsub	d19, d20, d22, d19
	fmov	x9, d19
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB20_115
	fdiv	d18, d19, d18
	fmov	x9, d18
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB20_115
	fmsub	d7, d7, d18, d21
	fmsub	d7, d16, d23, d7
	fmsub	d7, d17, d22, d7
	fmov	x9, d7
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB20_116
	fdiv	d6, d7, d6
	fmov	x9, d6
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB20_116
	fmsub	d0, d2, d6, d0
	fmsub	d0, d3, d18, d0
	fmsub	d0, d4, d23, d0
	fmsub	d0, d5, d22, d0
	fmov	x9, d0
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB20_117
	fdiv	d0, d0, d1
	fmov	x9, d0
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB20_117
	stp	d0, d6, [x8, #8]
	stp	d18, d23, [x8, #24]
	str	d22, [x8, #40]
	mov	w9, #255
	strb	w9, [x8]
	b	LBB20_29
LBB20_114:
	mov	w9, #3
	b	LBB20_119
LBB20_115:
	mov	w9, #2
	b	LBB20_119
LBB20_116:
	mov	w9, #1
	b	LBB20_119
LBB20_117:
	mov	x9, #0
	b	LBB20_119
LBB20_118:
	mov	w9, #4
LBB20_119:
	mov	w10, #1025
	strh	w10, [x8]
	mov	w10, #2
	strb	w10, [x8, #8]
	str	x9, [x8, #16]
	b	LBB20_29
LBB20_120:
Lloh36:
	adrp	x2, l_alloc_74fb70046b86dd3ae9161bcc5691b5a8@PAGE
Lloh37:
	add	x2, x2, l_alloc_74fb70046b86dd3ae9161bcc5691b5a8@PAGEOFF
	mov	w1, #5
	bl	__RNvNtCsjIpoRzUjyHQ_4core9panicking18panic_bounds_check
	.loh AdrpAdd	Lloh36, Lloh37
	.cfi_endproc

	.p2align	2
__RNvMs0_NtCshzmyaYQzAhy_8la_stack6vectorINtB5_6VectorKj5_E20dot_non_finite_errorCs7wsLvUT6iAW_13codegen_audit:
	.cfi_startproc
	ldr	d0, [x1]
	ldr	d1, [x2]
	movi.2d	v2, #0000000000000000
	fmadd	d0, d0, d1, d2
	fmov	x8, d0
	ubfx	x8, x8, #52, #11
	cmp	x8, #2047
	b.lo	LBB21_2
	mov	x8, #0
	mov	w9, #2
	strb	w9, [x0, #8]
	str	x8, [x0, #16]
	mov	w8, #3841
	strh	w8, [x0]
	ret
LBB21_2:
	ldr	d1, [x1, #8]
	ldr	d2, [x2, #8]
	fmadd	d0, d1, d2, d0
	fmov	x8, d0
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB21_4
	mov	w8, #1
	mov	w9, #2
	strb	w9, [x0, #8]
	str	x8, [x0, #16]
	mov	w8, #3841
	strh	w8, [x0]
	ret
LBB21_4:
	ldr	d1, [x1, #16]
	ldr	d2, [x2, #16]
	fmadd	d0, d1, d2, d0
	fmov	x8, d0
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB21_6
	mov	w8, #2
	mov	w9, #2
	strb	w9, [x0, #8]
	str	x8, [x0, #16]
	mov	w8, #3841
	strh	w8, [x0]
	ret
LBB21_6:
	ldr	d1, [x1, #24]
	ldr	d2, [x2, #24]
	fmadd	d0, d1, d2, d0
	fmov	x8, d0
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB21_8
	mov	w8, #3
	mov	w9, #2
	strb	w9, [x0, #8]
	str	x8, [x0, #16]
	mov	w8, #3841
	strh	w8, [x0]
	ret
LBB21_8:
	mov	w8, #4
	mov	w9, #2
	strb	w9, [x0, #8]
	str	x8, [x0, #16]
	mov	w8, #3841
	strh	w8, [x0]
	ret
	.cfi_endproc

	.p2align	2
__RNvMs5_NtCs6zY7rJBZy9D_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs7wsLvUT6iAW_13codegen_audit:
	.cfi_startproc
	stp	x20, x19, [sp, #-32]!
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	lsl	x20, x3, #3
	and	x8, x3, #0xe000000000000000
	mov	x9, #9223372036854775800
	cmp	x20, x9
	ccmp	x8, #0, #0, ls
	b.eq	LBB22_2
	mov	x20, #0
	mov	w8, #1
	mov	w9, #8
	b	LBB22_10
LBB22_2:
	cbz	x1, LBB22_4
	lsl	x1, x1, #3
	mov	x0, x2
	mov	w2, #8
	mov	x3, x20
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_realloc
	cbnz	x0, LBB22_8
	b	LBB22_6
LBB22_4:
	cbz	x20, LBB22_7
	bl	__RNvCsdtSMxSA38aw_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	x0, x20
	mov	w1, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc12___rust_alloc
	cbnz	x0, LBB22_8
LBB22_6:
	mov	w8, #8
	str	x8, [x19, #8]
	mov	w8, #1
	b	LBB22_9
LBB22_7:
	mov	w0, #8
LBB22_8:
	mov	x8, #0
	str	x0, [x19, #8]
LBB22_9:
	mov	w9, #16
LBB22_10:
	str	x20, [x19, x9]
	str	x8, [x19]
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	ldp	x20, x19, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	ret
	.cfi_endproc

	.p2align	2
__RNvMs_CsjLaZ3GaS80H_12num_rationalINtB4_5RatioNtNtCs70jQWIuBJri_10num_bigint6bigint6BigIntE6reduceCs7wsLvUT6iAW_13codegen_audit:
Lfunc_begin3:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception3
	sub	sp, sp, #224
	.cfi_def_cfa_offset 224
	stp	x26, x25, [sp, #144]
	stp	x24, x23, [sp, #160]
	stp	x22, x21, [sp, #176]
	stp	x20, x19, [sp, #192]
	stp	x29, x30, [sp, #208]
	add	x29, sp, #208
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_remember_state
	ldrb	w8, [x0, #56]
	cmp	w8, #1
	b.eq	LBB23_44
	mov	x19, x0
	ldrb	w9, [x0, #24]
	cmp	w9, #1
	b.ne	LBB23_6
	ldur	x8, [x19, #32]
	cmn	x8, #1
	b.eq	LBB23_10
	str	xzr, [x19, #48]
	cbnz	x8, LBB23_5
	add	x0, x19, #32
	bl	__RNvMs4_NtCs6zY7rJBZy9D_5alloc7raw_vecINtB5_6RawVecyE8grow_oneCs70jQWIuBJri_10num_bigint
LBB23_5:
	ldr	x8, [x19, #40]
	mov	w9, #1
	str	x9, [x8]
	str	x9, [x19, #48]
	b	LBB23_12
LBB23_6:
	cmp	w9, w8
	b.ne	LBB23_18
	ldr	x20, [x19]
	cmn	x20, #1
	b.eq	LBB23_13
	ldp	x21, x8, [x19, #8]
	mov	x0, x21
	ldr	x22, [x19, #32]
	cmn	x22, #1
	b.eq	LBB23_14
LBB23_9:
	ldp	x1, x9, [x19, #40]
	cmp	x8, x9
	b.eq	LBB23_17
	b	LBB23_18
LBB23_10:
	mov	w8, #1
	str	x8, [x19, #40]
LBB23_11:
	str	x8, [x19, #48]
LBB23_12:
	mov	w8, #2
	strb	w8, [x19, #56]
	b	LBB23_34
LBB23_13:
	ldr	x8, [x19, #8]
	mov	w9, #8
	add	x10, x19, #16
	cmp	x8, #0
	csel	x21, x8, x8, eq
	cset	x8, ne
	csel	x0, x9, x10, eq
	ldr	x22, [x19, #32]
	cmn	x22, #1
	b.ne	LBB23_9
LBB23_14:
	ldr	x9, [x19, #40]
	cbz	x9, LBB23_16
	add	x1, x19, #48
	mov	w9, #1
	cmp	x8, x9
	b.eq	LBB23_17
	b	LBB23_18
LBB23_16:
	mov	w1, #8
	cmp	x8, x9
	b.ne	LBB23_18
LBB23_17:
	lsl	x2, x8, #3
	bl	_memcmp
	cbz	w0, LBB23_35
LBB23_18:
	sub	x0, x29, #96
	add	x2, x19, #32
	mov	x1, x19
	bl	__RNvXsh_NtCs70jQWIuBJri_10num_bigint7biguintNtB5_7BigUintNtCs5ZU5g2vqbRJ_11num_integer7Integer3gcd
	ldur	x23, [x29, #-96]
Lloh38:
	adrp	x24, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.0@PAGE
Lloh39:
	add	x24, x24, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.0@PAGEOFF
	cmn	x23, #1
	b.eq	LBB23_22
	ldur	x25, [x29, #-80]
	cbz	x25, LBB23_24
	ldur	x20, [x29, #-88]
	ldp	q0, q1, [x19]
	stp	q0, q1, [sp, #80]
	ldp	q0, q1, [x24]
	stp	q0, q1, [x19]
	cmp	x25, #1
	b.ne	LBB23_26
	ldr	x8, [x20]
	mov	x9, #-1
	mov	w22, #2
	mov	w21, #1
	b	LBB23_31
LBB23_22:
	ldur	x8, [x29, #-88]
	cbz	x8, LBB23_28
	ldur	x25, [x29, #-80]
	ldp	q0, q1, [x19]
	stp	q0, q1, [sp, #80]
	ldp	q0, q1, [x24]
	mov	w22, #2
	mov	x23, #-1
	stp	q0, q1, [x19]
	mov	w20, #1
	mov	x8, x25
	mov	w21, #1
	b	LBB23_30
LBB23_24:
	stur	wzr, [sp, #43]
	str	wzr, [sp, #40]
	cbz	x23, LBB23_29
	ldur	x0, [x29, #-88]
	lsl	x1, x23, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	b	LBB23_29
LBB23_26:
	lsl	x22, x25, #3
	bl	__RNvCsdtSMxSA38aw_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	x0, x22
	mov	w1, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc12___rust_alloc
	cbz	x0, LBB23_45
	mov	x21, x0
	mov	x1, x20
	mov	x2, x22
	bl	_memcpy
	mov	w22, #2
	mov	x8, x25
	mov	x9, x25
	b	LBB23_31
LBB23_28:
	stur	wzr, [sp, #43]
	str	wzr, [sp, #40]
LBB23_29:
	mov	x20, #0
	mov	x21, #0
	ldp	q0, q1, [x19]
	stp	q0, q1, [sp, #80]
	ldp	q0, q1, [x24]
	stp	q0, q1, [x19]
	mov	w22, #1
	mov	x23, #-1
LBB23_30:
	mov	x9, #-1
LBB23_31:
	sturb	w22, [x29, #-72]
	stp	x9, x21, [x29, #-96]
	stur	x8, [x29, #-80]
Ltmp231:
	add	x0, sp, #48
	add	x1, sp, #80
	sub	x2, x29, #96
	bl	__RNvXsF_NtNtCs70jQWIuBJri_10num_bigint6bigint8divisionNtB7_6BigIntNtNtNtCsjIpoRzUjyHQ_4core3ops5arith3Div3div
Ltmp232:
	ldp	q0, q1, [sp, #48]
	stp	q0, q1, [x19]
	ldr	w8, [sp, #40]
	stur	w8, [x29, #-71]
	ldur	w8, [sp, #43]
	stur	w8, [x29, #-68]
	ldp	q0, q1, [x19, #32]
	stp	q0, q1, [sp, #80]
	ldp	q0, q1, [x24]
	stp	q1, q0, [sp]
	stp	q0, q1, [x19, #32]
	stp	x23, x20, [x29, #-96]
	stur	x25, [x29, #-80]
	sturb	w22, [x29, #-72]
	add	x0, sp, #48
	add	x1, sp, #80
	sub	x2, x29, #96
	bl	__RNvXsF_NtNtCs70jQWIuBJri_10num_bigint6bigint8divisionNtB7_6BigIntNtNtNtCsjIpoRzUjyHQ_4core3ops5arith3Div3div
	ldp	q0, q1, [sp, #48]
	stp	q0, q1, [x19, #32]
	ldrb	w8, [x19, #56]
	cbnz	w8, LBB23_34
	ldp	q0, q1, [x19]
	stp	q0, q1, [sp, #80]
	ldp	q1, q0, [sp]
	stp	q0, q1, [x19]
	stp	q0, q1, [x29, #-96]
	add	x0, sp, #48
	sub	x1, x29, #96
	add	x2, sp, #80
	bl	__RNvXs1_NtNtCs70jQWIuBJri_10num_bigint6bigint11subtractionNtB7_6BigIntNtNtNtCsjIpoRzUjyHQ_4core3ops5arith3Sub3sub
	ldp	q0, q1, [sp, #48]
	stp	q0, q1, [x19]
	ldp	q0, q1, [x19, #32]
	stp	q0, q1, [sp, #80]
	ldp	q1, q0, [sp]
	stp	q0, q1, [x19, #32]
	stp	q0, q1, [x29, #-96]
	add	x0, sp, #48
	sub	x1, x29, #96
	add	x2, sp, #80
	bl	__RNvXs1_NtNtCs70jQWIuBJri_10num_bigint6bigint11subtractionNtB7_6BigIntNtNtNtCsjIpoRzUjyHQ_4core3ops5arith3Sub3sub
	ldp	q0, q1, [sp, #48]
	stp	q0, q1, [x19, #32]
LBB23_34:
	.cfi_def_cfa wsp, 224
	ldp	x29, x30, [sp, #208]
	ldp	x20, x19, [sp, #192]
	ldp	x22, x21, [sp, #176]
	ldp	x24, x23, [sp, #160]
	ldp	x26, x25, [sp, #144]
	add	sp, sp, #224
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	ret
LBB23_35:
	.cfi_restore_state
	cmn	x20, #1
	b.eq	LBB23_42
	str	xzr, [x19, #16]
	cbnz	x20, LBB23_38
	mov	x0, x19
	bl	__RNvMs4_NtCs6zY7rJBZy9D_5alloc7raw_vecINtB5_6RawVecyE8grow_oneCs70jQWIuBJri_10num_bigint
	ldr	x21, [x19, #8]
LBB23_38:
	mov	w8, #1
	str	x8, [x21]
	str	x8, [x19, #16]
	ldr	x22, [x19, #32]
	mov	w8, #2
	strb	w8, [x19, #24]
	cmn	x22, #1
	b.eq	LBB23_43
LBB23_39:
	str	xzr, [x19, #48]
	cbnz	x22, LBB23_41
	add	x0, x19, #32
	bl	__RNvMs4_NtCs6zY7rJBZy9D_5alloc7raw_vecINtB5_6RawVecyE8grow_oneCs70jQWIuBJri_10num_bigint
LBB23_41:
	ldr	x8, [x19, #40]
	mov	w9, #1
	str	x9, [x8]
	mov	w8, #1
	b	LBB23_11
LBB23_42:
	mov	w8, #1
	stp	x8, x8, [x19, #8]
	mov	w8, #2
	strb	w8, [x19, #24]
	cmn	x22, #1
	b.ne	LBB23_39
LBB23_43:
	mov	w8, #1
	str	x8, [x19, #40]
	mov	w8, #1
	b	LBB23_11
LBB23_44:
Lloh40:
	adrp	x0, l_alloc_2378476402a17344e404981387c3e319@PAGE
Lloh41:
	add	x0, x0, l_alloc_2378476402a17344e404981387c3e319@PAGEOFF
Lloh42:
	adrp	x2, l_alloc_9d84ef19db37a76f9abdfeef0faf287f@PAGE
Lloh43:
	add	x2, x2, l_alloc_9d84ef19db37a76f9abdfeef0faf287f@PAGEOFF
	mov	w1, #33
	bl	__RNvNtCsjIpoRzUjyHQ_4core9panicking9panic_fmt
LBB23_45:
Ltmp228:
	mov	w0, #8
	mov	x1, x22
	bl	__RNvNtCs6zY7rJBZy9D_5alloc7raw_vec12handle_error
Ltmp229:
	brk	#0x1
LBB23_47:
Ltmp230:
	mov	x19, x0
	ldr	x8, [sp, #80]
	cmp	x8, #1
	b.lt	LBB23_49
	ldr	x0, [sp, #88]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	cmp	x23, #1
	b.lt	LBB23_52
	b	LBB23_50
LBB23_49:
	cmp	x23, #1
	b.lt	LBB23_52
LBB23_50:
	lsl	x1, x23, #3
	mov	x0, x20
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	mov	x0, x19
	bl	__Unwind_Resume
LBB23_51:
Ltmp233:
	mov	x19, x0
	cmp	x23, #1
	b.ge	LBB23_50
LBB23_52:
	mov	x0, x19
	bl	__Unwind_Resume
	.loh AdrpAdd	Lloh38, Lloh39
	.loh AdrpAdd	Lloh42, Lloh43
	.loh AdrpAdd	Lloh40, Lloh41
Lfunc_end3:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table23:
Lexception3:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 Lcst_end3-Lcst_begin3
Lcst_begin3:
	.uleb128 Lfunc_begin3-Lfunc_begin3
	.uleb128 Ltmp231-Lfunc_begin3
	.byte	0
	.byte	0
	.uleb128 Ltmp231-Lfunc_begin3
	.uleb128 Ltmp232-Ltmp231
	.uleb128 Ltmp233-Lfunc_begin3
	.byte	0
	.uleb128 Ltmp232-Lfunc_begin3
	.uleb128 Ltmp228-Ltmp232
	.byte	0
	.byte	0
	.uleb128 Ltmp228-Lfunc_begin3
	.uleb128 Ltmp229-Ltmp228
	.uleb128 Ltmp230-Lfunc_begin3
	.byte	0
	.uleb128 Ltmp229-Lfunc_begin3
	.uleb128 Lfunc_end3-Ltmp229
	.byte	0
	.byte	0
Lcst_end3:
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RNvMs_NtCshzmyaYQzAhy_8la_stack4ldltINtB4_4LdltKj4_E23non_finite_factor_errorCs7wsLvUT6iAW_13codegen_audit:
	.cfi_startproc
	ldr	x8, [x1]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB24_2
	mov	x9, #0
	mov	x8, #0
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB24_2:
	ldr	x8, [x1, #8]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB24_4
	mov	x9, #0
	mov	w8, #1
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB24_4:
	ldr	x8, [x1, #16]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB24_6
	mov	x9, #0
	mov	w8, #2
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB24_6:
	ldr	x8, [x1, #24]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2047
	b.lo	LBB24_8
	mov	x9, #0
	mov	w8, #3
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB24_8:
	ldr	x8, [x1, #32]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB24_10
	mov	x8, #0
	mov	w9, #1
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB24_10:
	ldr	x8, [x1, #40]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB24_12
	mov	w9, #1
	mov	w8, #1
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB24_12:
	ldr	x8, [x1, #48]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB24_14
	mov	w8, #2
	mov	w9, #1
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB24_14:
	ldr	x8, [x1, #56]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB24_16
	mov	w8, #3
	mov	w9, #1
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB24_16:
	ldr	x8, [x1, #64]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB24_18
	mov	x8, #0
	mov	w9, #2
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB24_18:
	ldr	x8, [x1, #72]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB24_20
	mov	w8, #1
	mov	w9, #2
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB24_20:
	ldr	x8, [x1, #80]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB24_22
	mov	w9, #2
	mov	w8, #2
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB24_22:
	ldr	x8, [x1, #88]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB24_24
	mov	w8, #3
	mov	w9, #2
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB24_24:
	ldr	x8, [x1, #96]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB24_26
	mov	x8, #0
	mov	w9, #3
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB24_26:
	ldr	x8, [x1, #104]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB24_28
	mov	w8, #1
	mov	w9, #3
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB24_28:
	ldr	x8, [x1, #112]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB24_30
	mov	w8, #2
	mov	w9, #3
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB24_30:
	ldr	x8, [x1, #120]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB24_32
	mov	w9, #3
	mov	w8, #3
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB24_32:
	mov	w8, #255
	strb	w8, [x0]
	ret
	.cfi_endproc

	.p2align	2
__RNvMs_NtCshzmyaYQzAhy_8la_stack4ldltINtB4_4LdltKj5_E23non_finite_factor_errorCs7wsLvUT6iAW_13codegen_audit:
	.cfi_startproc
	ldr	x8, [x1]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB25_2
	mov	x9, #0
	mov	x8, #0
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB25_2:
	ldr	x8, [x1, #8]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB25_4
	mov	x9, #0
	mov	w8, #1
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB25_4:
	ldr	x8, [x1, #16]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB25_6
	mov	x9, #0
	mov	w8, #2
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB25_6:
	ldr	x8, [x1, #24]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB25_8
	mov	x9, #0
	mov	w8, #3
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB25_8:
	ldr	x8, [x1, #32]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2047
	b.lo	LBB25_10
	mov	x9, #0
	mov	w8, #4
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB25_10:
	ldr	x8, [x1, #40]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB25_12
	mov	x8, #0
	mov	w9, #1
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB25_12:
	ldr	x8, [x1, #48]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB25_14
	mov	w9, #1
	mov	w8, #1
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB25_14:
	ldr	x8, [x1, #56]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB25_16
	mov	w8, #2
	mov	w9, #1
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB25_16:
	ldr	x8, [x1, #64]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB25_18
	mov	w8, #3
	mov	w9, #1
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB25_18:
	ldr	x8, [x1, #72]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB25_20
	mov	w8, #4
	mov	w9, #1
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB25_20:
	ldr	x8, [x1, #80]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB25_22
	mov	x8, #0
	mov	w9, #2
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB25_22:
	ldr	x8, [x1, #88]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB25_24
	mov	w8, #1
	mov	w9, #2
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB25_24:
	ldr	x8, [x1, #96]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB25_26
	mov	w9, #2
	mov	w8, #2
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB25_26:
	ldr	x8, [x1, #104]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB25_28
	mov	w8, #3
	mov	w9, #2
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB25_28:
	ldr	x8, [x1, #112]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB25_30
	mov	w8, #4
	mov	w9, #2
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB25_30:
	ldr	x8, [x1, #120]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB25_32
	mov	x8, #0
	mov	w9, #3
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB25_32:
	ldr	x8, [x1, #128]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB25_34
	mov	w8, #1
	mov	w9, #3
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB25_34:
	ldr	x8, [x1, #136]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB25_36
	mov	w8, #2
	mov	w9, #3
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB25_36:
	ldr	x8, [x1, #144]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB25_38
	mov	w9, #3
	mov	w8, #3
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB25_38:
	ldr	x8, [x1, #152]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB25_40
	mov	w8, #4
	mov	w9, #3
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB25_40:
	ldr	x8, [x1, #160]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB25_42
	mov	x8, #0
	mov	w9, #4
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB25_42:
	ldr	x8, [x1, #168]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB25_44
	mov	w8, #1
	mov	w9, #4
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB25_44:
	ldr	x8, [x1, #176]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB25_46
	mov	w8, #2
	mov	w9, #4
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB25_46:
	ldr	x8, [x1, #184]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB25_48
	mov	w8, #3
	mov	w9, #4
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB25_48:
	ldr	x8, [x1, #192]
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB25_50
	mov	w9, #4
	mov	w8, #4
	mov	w10, #769
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x9, x8, [x0, #16]
	ret
LBB25_50:
	mov	w8, #255
	strb	w8, [x0]
	ret
	.cfi_endproc

	.p2align	2
__RNvNtCshzmyaYQzAhy_8la_stack8interval22rounded_product_bounds:
	.cfi_startproc
	fcmp	d0, #0.0
	b.eq	LBB26_4
	fcmp	d1, #0.0
	b.eq	LBB26_4
	fmul	d2, d0, d1
	fmov	x8, d2
	ubfx	x8, x8, #52, #11
	cmp	x8, #2047
	b.lo	LBB26_5
LBB26_3:
	mov	w8, #3074
	strh	w8, [x0]
	ret
LBB26_4:
	stp	xzr, xzr, [x0, #8]
	mov	w8, #255
	strb	w8, [x0]
	ret
LBB26_5:
	fabs	d3, d2
	fmov	x8, d0
	fmov	x9, d1
	eor	x8, x9, x8
	fcmp	d2, #0.0
	b.ne	LBB26_7
	tbz	x8, #63, LBB26_12
	b	LBB26_17
LBB26_7:
	mov	x9, #0
	fmov	x10, d0
	ubfx	x11, x10, #52, #11
	and	x12, x10, #0xfffffffffffff
	mov	x13, #4503599627370496
	mov	x14, #4503599627370496
	bfxil	x14, x10, #0, #52
	sub	x10, x11, #1075
	mov	x15, #-1074
	cmp	x11, #0
	csel	x16, x15, x10, eq
	csel	x10, x12, x14, eq
	fmov	x11, d1
	ubfx	x12, x11, #52, #11
	and	x14, x11, #0xfffffffffffff
	mov	x17, #4503599627370496
	bfxil	x17, x11, #0, #52
	sub	x11, x12, #1075
	cmp	x12, #0
	csel	x12, x15, x11, eq
	csel	x11, x14, x17, eq
	umulh	x14, x11, x10
	mul	x10, x11, x10
	fmov	x11, d3
	lsr	x17, x11, #52
	and	x1, x11, #0xfffffffffffff
	bfxil	x13, x11, #0, #52
	sub	x11, x17, #1075
	cmp	x17, #0
	csel	x15, x15, x11, eq
	csel	x17, x1, x13, eq
	rbit	x11, x10
	clz	x11, x11
	rbit	x13, x14
	clz	x13, x13
	add	x13, x13, #64
	cmp	x10, #0
	csel	x1, x11, x13, ne
	rbit	x11, x17
	clz	x11, x11
	mov	w13, #128
	cmp	x17, #0
	csel	x2, x11, x13, ne
	mvn	w11, w1
	lsl	x13, x14, #1
	lsl	x11, x13, x11
	lsr	x10, x10, x1
	orr	x10, x11, x10
	lsr	x13, x14, x1
	and	x11, x1, #0x7f
	tst	x11, #0x40
	csel	x11, x13, x10, ne
	csel	x13, xzr, x13, ne
	and	x10, x2, #0x7f
	tst	x10, #0x40
	lsr	x10, x17, x2
	csel	x10, xzr, x10, ne
	add	x12, x12, x16
	add	x14, x12, x1
	add	x12, x15, x2
	clz	x15, x13
	clz	x16, x11
	add	w16, w16, #64
	cmp	x13, #0
	csel	w15, w15, w16, ne
	mov	w16, #127
	sub	w15, w16, w15
	add	x15, x15, x14
	clz	x17, x10
	add	w17, w17, #64
	cmp	x9, #0
	mov	w9, #64
	csel	w9, w9, w17, ne
	sub	w9, w16, w9
	add	x9, x9, x12
	cmp	x15, x9
	b.ge	LBB26_9
LBB26_8:
	mov	w9, #255
	cmp	x8, #0
	cneg	w8, w9, mi
	tbz	w8, #7, LBB26_11
	b	LBB26_17
LBB26_9:
	b.le	LBB26_15
	mov	w9, #1
	cmp	x8, #0
	cneg	w8, w9, mi
	tbnz	w8, #7, LBB26_17
LBB26_11:
	sxtb	w8, w8
	cbz	w8, LBB26_20
LBB26_12:
	fmov	x10, d2
	mov	x8, #9218868437227405312
	cmp	x10, x8
	b.ne	LBB26_14
	mov	w9, #0
	ubfx	x10, x8, #52, #11
	cmp	x10, #2046
	b.ls	LBB26_18
	b	LBB26_3
LBB26_14:
	fmov	x8, d3
	sub	x9, x10, #1
	cmp	x10, x8
	csinc	x9, x9, x8, ne
	cmp	x8, #0
	csinc	x8, x9, xzr, ne
	ubfx	x9, x8, #52, #11
	fmov	d2, x8
	cmp	x9, #2046
	cset	w9, hi
	mov	x8, x10
	ubfx	x10, x10, #52, #11
	cmp	x10, #2046
	b.ls	LBB26_18
	b	LBB26_3
LBB26_15:
	cmp	x14, x12
	csel	x15, x14, x12, lt
	sub	w9, w14, w15
	mvn	w14, w9
	and	x16, x9, #0x7f
	lsl	x13, x13, x9
	lsr	x17, x11, #1
	lsr	x14, x17, x14
	orr	x13, x13, x14
	lsl	x11, x11, x9
	tst	x16, #0x40
	csel	x9, x11, x13, ne
	csel	x11, xzr, x11, ne
	sub	w12, w12, w15
	mvn	w13, w12
	and	x14, x12, #0x7f
	lsl	x12, x10, x12
	lsr	x10, x10, #1
	lsr	x10, x10, x13
	tst	x14, #0x40
	csel	x10, x12, x10, ne
	csel	x12, xzr, x12, ne
	cmp	x11, x12
	sbcs	xzr, x9, x10
	b.lo	LBB26_8
	cmp	x12, x11
	sbcs	xzr, x10, x9
	cset	w9, lo
	cmp	x8, #0
	cneg	w8, w9, mi
	tbz	w8, #7, LBB26_11
LBB26_17:
	fmov	x8, d2
	mov	x9, #-4503599627370496
	fmov	x10, d3
	mov	x11, #-9223372036854775807
	sub	x12, x10, #1
	cmp	x8, x10
	csinc	x12, x12, x8, eq
	cmp	x10, #0
	csel	x10, x11, x12, eq
	csel	w11, wzr, wzr, eq
	cmp	x8, x9
	csel	x8, x9, x10, eq
	csel	w9, wzr, w11, eq
	ubfx	x10, x8, #52, #11
	cmp	x10, #2046
	b.hi	LBB26_3
LBB26_18:
	tbnz	w9, #0, LBB26_3
	fmov	d0, x8
	fcmp	d0, #0.0
	csel	x8, xzr, x8, eq
	fcmp	d2, #0.0
	movi.2d	v0, #0000000000000000
	fcsel	d0, d0, d2, eq
	str	x8, [x0, #8]
	str	d0, [x0, #16]
	mov	w8, #255
	strb	w8, [x0]
	ret
LBB26_20:
	mov	w9, #0
	fmov	x8, d2
	ubfx	x10, x8, #52, #11
	cmp	x10, #2046
	b.ls	LBB26_18
	b	LBB26_3
	.cfi_endproc

	.p2align	2
__RNvXs1_NtNtCs70jQWIuBJri_10num_bigint6bigint11subtractionNtB7_6BigIntNtNtNtCsjIpoRzUjyHQ_4core3ops5arith3Sub3sub:
Lfunc_begin4:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception4
	sub	sp, sp, #192
	.cfi_def_cfa_offset 192
	stp	x24, x23, [sp, #128]
	stp	x22, x21, [sp, #144]
	stp	x20, x19, [sp, #160]
	stp	x29, x30, [sp, #176]
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_remember_state
	ldrb	w8, [x2, #24]
	cmp	w8, #1
	b.ne	LBB27_3
	ldp	q0, q1, [x1]
	stp	q0, q1, [x0]
	ldr	x8, [x2]
	cmp	x8, #1
	b.lt	LBB27_68
	ldr	x0, [x2, #8]
	lsl	x1, x8, #3
	b	LBB27_50
LBB27_3:
	ldrb	w19, [x1, #24]
	cbz	w19, LBB27_6
	cmp	w19, #1
	b.ne	LBB27_10
	ldp	q1, q0, [x2]
	stp	q1, q0, [x0]
	ldrb	w8, [x0, #24]
	mov	w9, #2
	sub	w8, w9, w8
	strb	w8, [x0, #24]
	ldr	x20, [x1]
	b	LBB27_48
LBB27_6:
	cbz	w8, LBB27_11
LBB27_7:
	mov	x20, x0
	ldr	q0, [x1]
	str	q0, [sp, #32]
	ldr	x8, [x1, #16]
	str	x8, [sp, #48]
	ldr	q0, [x2]
	str	q0, [sp, #64]
	ldr	x8, [x2, #16]
	str	x8, [sp, #80]
	ldr	x23, [sp, #32]
	cmn	x23, #1
	csinc	x8, x23, xzr, ne
	ldr	x21, [sp, #64]
	cmn	x21, #1
	csinc	x9, x21, xzr, ne
	cmp	x8, x9
	b.hs	LBB27_25
	add	x8, sp, #32
	add	x22, x8, #8
	ldr	q0, [x2]
	stur	q0, [x29, #-80]
	ldr	x8, [x2, #16]
	stur	x8, [x29, #-64]
Ltmp237:
	mov	x8, sp
	sub	x0, x29, #80
	add	x1, sp, #32
	bl	__RNvXNtNtCs70jQWIuBJri_10num_bigint7biguint8additionNtB4_7BigUintINtNtNtCsjIpoRzUjyHQ_4core3ops5arith3AddRBN_E3add
Ltmp238:
	cmp	x23, #1
	b.ge	LBB27_27
	b	LBB27_28
LBB27_10:
	cbz	w8, LBB27_7
LBB27_11:
	ldr	x20, [x1]
	cmn	x20, #1
	b.eq	LBB27_34
	ldp	x10, x11, [x1, #8]
	ldr	x9, [x2]
	cmn	x9, #1
	b.eq	LBB27_35
LBB27_13:
	ldp	x8, x12, [x2, #8]
	mov	x13, x8
	cmp	x11, x12
	cset	w12, hi
	csinv	w12, w12, wzr, hs
	b.ne	LBB27_36
LBB27_14:
	sub	x12, x13, #8
	lsl	x11, x11, #3
	sub	x10, x10, #8
LBB27_15:
	cbz	x11, LBB27_46
	ldr	x13, [x10, x11]
	ldr	x14, [x12, x11]
	sub	x11, x11, #8
	cmp	x13, x14
	b.eq	LBB27_15
	cset	w10, hi
	csinv	w12, w10, wzr, hs
	and	w10, w12, #0xff
	cmp	w10, #255
	b.ne	LBB27_37
LBB27_18:
	mov	x20, x0
	ldr	q0, [x2]
	str	q0, [sp, #64]
	ldr	x8, [x2, #16]
	str	x8, [sp, #80]
	ldr	q0, [x1]
	stur	q0, [x29, #-80]
	ldr	x8, [x1, #16]
	stur	x8, [x29, #-64]
Ltmp243:
	add	x8, sp, #32
	add	x0, sp, #64
	sub	x1, x29, #80
	bl	__RNvXNtNtCs70jQWIuBJri_10num_bigint7biguint11subtractionNtB4_7BigUintINtNtNtCsjIpoRzUjyHQ_4core3ops5arith3SubRBR_E3sub
Ltmp244:
	ldur	x8, [x29, #-80]
	cmp	x8, #1
	b.lt	LBB27_21
	ldur	x0, [x29, #-72]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB27_21:
	ldr	x10, [sp, #32]
	tbz	w19, #0, LBB27_58
	cmn	x10, #1
	mov	x8, x20
	b.eq	LBB27_60
	str	xzr, [sp, #48]
	cmp	x10, #2
	b.lo	LBB27_61
	ldr	x0, [sp, #40]
	lsl	x1, x10, #3
	b	LBB27_45
LBB27_25:
	add	x8, sp, #64
	add	x22, x8, #8
	ldr	q0, [x1]
	stur	q0, [x29, #-80]
	ldr	x8, [x1, #16]
	stur	x8, [x29, #-64]
Ltmp234:
	mov	x8, sp
	sub	x0, x29, #80
	add	x1, sp, #64
	bl	__RNvXNtNtCs70jQWIuBJri_10num_bigint7biguint8additionNtB4_7BigUintINtNtNtCsjIpoRzUjyHQ_4core3ops5arith3AddRBN_E3add
Ltmp235:
	mov	x23, x21
	cmp	x21, #0
	b.le	LBB27_28
LBB27_27:
	ldr	x0, [x22]
	lsl	x1, x23, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB27_28:
	ldr	x9, [sp]
	cmp	w19, #1
	b.ne	LBB27_32
	cmn	x9, #1
	mov	x8, x20
	b.eq	LBB27_51
	str	xzr, [sp, #16]
	cmp	x9, #2
	b.lo	LBB27_52
	ldr	x0, [sp, #8]
	lsl	x1, x9, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	mov	x8, x20
	str	xzr, [sp, #16]
Lloh44:
	adrp	x9, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.1@PAGE
Lloh45:
	add	x9, x9, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.1@PAGEOFF
Lloh46:
	ldr	q0, [x9]
	str	q0, [sp]
	b	LBB27_52
LBB27_32:
	cmn	x9, #1
	mov	x8, x20
	b.eq	LBB27_53
	ldr	x9, [sp, #16]
	cmp	x9, #0
	cset	w9, eq
	b	LBB27_54
LBB27_34:
	ldr	x8, [x1, #8]
	mov	w9, #8
	add	x10, x1, #16
	cmp	x8, #0
	csel	x10, x9, x10, eq
	cset	x11, ne
	ldr	x9, [x2]
	cmn	x9, #1
	b.ne	LBB27_13
LBB27_35:
	ldr	x8, [x2, #8]
	mov	w13, #8
	add	x14, x2, #16
	cmp	x8, #0
	csel	x8, x8, x8, eq
	cset	x12, ne
	csel	x13, x13, x14, eq
	cmp	x11, x12
	cset	w12, hi
	csinv	w12, w12, wzr, hs
	b.eq	LBB27_14
LBB27_36:
	and	w10, w12, #0xff
	cmp	w10, #255
	b.eq	LBB27_18
LBB27_37:
	cmp	w10, #1
	b.ne	LBB27_46
	mov	x20, x0
	ldr	q0, [x1]
	str	q0, [sp, #64]
	ldr	x8, [x1, #16]
	str	x8, [sp, #80]
	ldr	q0, [x2]
	stur	q0, [x29, #-80]
	ldr	x8, [x2, #16]
	stur	x8, [x29, #-64]
Ltmp240:
	add	x8, sp, #32
	add	x0, sp, #64
	sub	x1, x29, #80
	bl	__RNvXNtNtCs70jQWIuBJri_10num_bigint7biguint11subtractionNtB4_7BigUintINtNtNtCsjIpoRzUjyHQ_4core3ops5arith3SubRBR_E3sub
Ltmp241:
	ldur	x8, [x29, #-80]
	cmp	x8, #1
	b.lt	LBB27_41
	ldur	x0, [x29, #-72]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB27_41:
	ldr	x9, [sp, #32]
	cmp	w19, #1
	b.ne	LBB27_56
	cmn	x9, #1
	mov	x8, x20
	b.eq	LBB27_60
	str	xzr, [sp, #48]
	cmp	x9, #2
	b.lo	LBB27_61
	ldr	x0, [sp, #40]
	lsl	x1, x9, #3
LBB27_45:
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	mov	x8, x20
	str	xzr, [sp, #48]
Lloh47:
	adrp	x9, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.1@PAGE
Lloh48:
	add	x9, x9, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.1@PAGEOFF
Lloh49:
	ldr	q0, [x9]
	str	q0, [sp, #32]
	b	LBB27_61
LBB27_46:
Lloh50:
	adrp	x10, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.0@PAGE
Lloh51:
	add	x10, x10, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.0@PAGEOFF
	ldp	q0, q1, [x10]
	stp	q0, q1, [x0]
	cmp	x9, #1
	b.lt	LBB27_48
	lsl	x9, x9, #3
	mov	x0, x8
	mov	x19, x1
	mov	x1, x9
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	mov	x1, x19
LBB27_48:
	cmp	x20, #1
	b.lt	LBB27_68
	ldr	x0, [x1, #8]
	lsl	x1, x20, #3
LBB27_50:
	mov	w2, #8
	.cfi_def_cfa wsp, 192
	ldp	x29, x30, [sp, #176]
	ldp	x20, x19, [sp, #160]
	ldp	x22, x21, [sp, #144]
	ldp	x24, x23, [sp, #128]
	add	sp, sp, #192
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	b	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB27_51:
	.cfi_restore_state
	.cfi_remember_state
	str	xzr, [sp, #8]
LBB27_52:
	mov	w9, #1
	b	LBB27_55
LBB27_53:
	ldr	w9, [sp, #8]
	eor	w9, w9, #0x1
LBB27_54:
	cmp	w9, #0
	csinc	w9, w19, wzr, eq
LBB27_55:
	ldr	q0, [sp]
	str	q0, [x8]
	ldr	x10, [sp, #16]
	b	LBB27_67
LBB27_56:
	cmn	x9, #1
	mov	x8, x20
	b.eq	LBB27_62
	ldr	x9, [sp, #48]
	cmp	x9, #0
	cset	w9, eq
	b	LBB27_63
LBB27_58:
	mov	w8, #2
	sub	w9, w8, w19
	cmn	x10, #1
	mov	x8, x20
	b.eq	LBB27_64
	ldr	x10, [sp, #48]
	cmp	x10, #0
	cset	w10, eq
	b	LBB27_65
LBB27_60:
	str	xzr, [sp, #40]
LBB27_61:
	mov	w9, #1
	b	LBB27_66
LBB27_62:
	ldr	w9, [sp, #40]
	eor	w9, w9, #0x1
LBB27_63:
	cmp	w9, #0
	csinc	w9, w19, wzr, eq
	b	LBB27_66
LBB27_64:
	ldr	w10, [sp, #40]
	eor	w10, w10, #0x1
LBB27_65:
	cmp	w10, #0
	csinc	w9, w9, wzr, eq
LBB27_66:
	ldr	q0, [sp, #32]
	str	q0, [x8]
	ldr	x10, [sp, #48]
LBB27_67:
	str	x10, [x8, #16]
	strb	w9, [x8, #24]
LBB27_68:
	.cfi_def_cfa wsp, 192
	ldp	x29, x30, [sp, #176]
	ldp	x20, x19, [sp, #160]
	ldp	x22, x21, [sp, #144]
	ldp	x24, x23, [sp, #128]
	add	sp, sp, #192
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	ret
LBB27_69:
	.cfi_restore_state
Ltmp242:
	mov	x19, x0
	ldur	x21, [x29, #-80]
	cmp	x21, #1
	b.lt	LBB27_75
	b	LBB27_71
LBB27_70:
Ltmp245:
	mov	x19, x0
	ldur	x21, [x29, #-80]
	cmp	x21, #1
	b.lt	LBB27_75
LBB27_71:
	ldur	x0, [x29, #-72]
	lsl	x1, x21, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	mov	x0, x19
	bl	__Unwind_Resume
LBB27_72:
Ltmp236:
	mov	x19, x0
	cmp	x21, #1
	b.lt	LBB27_75
LBB27_73:
	ldr	x0, [x22]
	lsl	x1, x21, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	mov	x0, x19
	bl	__Unwind_Resume
LBB27_74:
Ltmp239:
	mov	x19, x0
	mov	x21, x23
	cmp	x23, #0
	b.gt	LBB27_73
LBB27_75:
	mov	x0, x19
	bl	__Unwind_Resume
	.loh AdrpAddLdr	Lloh44, Lloh45, Lloh46
	.loh AdrpAddLdr	Lloh47, Lloh48, Lloh49
	.loh AdrpAdd	Lloh50, Lloh51
Lfunc_end4:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table27:
Lexception4:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 Lcst_end4-Lcst_begin4
Lcst_begin4:
	.uleb128 Ltmp237-Lfunc_begin4
	.uleb128 Ltmp238-Ltmp237
	.uleb128 Ltmp239-Lfunc_begin4
	.byte	0
	.uleb128 Ltmp243-Lfunc_begin4
	.uleb128 Ltmp244-Ltmp243
	.uleb128 Ltmp245-Lfunc_begin4
	.byte	0
	.uleb128 Ltmp234-Lfunc_begin4
	.uleb128 Ltmp235-Ltmp234
	.uleb128 Ltmp236-Lfunc_begin4
	.byte	0
	.uleb128 Ltmp240-Lfunc_begin4
	.uleb128 Ltmp241-Ltmp240
	.uleb128 Ltmp242-Lfunc_begin4
	.byte	0
	.uleb128 Ltmp241-Lfunc_begin4
	.uleb128 Lfunc_end4-Ltmp241
	.byte	0
	.byte	0
Lcst_end4:
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.p2align	6
__RNvXsF_NtNtCs70jQWIuBJri_10num_bigint6bigint8divisionNtB7_6BigIntNtNtNtCsjIpoRzUjyHQ_4core3ops5arith3Div3div:
Lfunc_begin5:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception5
	sub	sp, sp, #144
	.cfi_def_cfa_offset 144
	stp	x28, x27, [sp, #48]
	stp	x26, x25, [sp, #64]
	stp	x24, x23, [sp, #80]
	stp	x22, x21, [sp, #96]
	stp	x20, x19, [sp, #112]
	stp	x29, x30, [sp, #128]
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_remember_state
	mov	x19, x2
	mov	x20, x1
	mov	x21, x0
Ltmp246:
	mov	x8, sp
	mov	x0, x1
	mov	x1, x2
	bl	__RNvNtNtCs70jQWIuBJri_10num_bigint7biguint8division11div_rem_ref
Ltmp247:
	ldp	x23, x22, [sp]
	ldp	x24, x25, [sp, #16]
	ldr	x0, [sp, #32]
	ldrb	w8, [x20, #24]
	cmp	w8, #1
	b.ne	LBB28_5
	cmn	x23, #1
	b.eq	LBB28_6
	cmp	x23, #2
	b.hs	LBB28_7
	mov	x24, #0
	cmn	x25, #1
	b.ne	LBB28_10
	b	LBB28_15
LBB28_5:
	eor	w9, w22, #0x1
	cmp	x24, #0
	cset	w10, eq
	cmn	x23, #1
	csel	w9, w9, w10, eq
	tst	w9, #0x1
	csinc	w26, w8, wzr, eq
	ldrb	w27, [x19, #24]
	sub	x8, x25, #1
	cmn	x8, #3
	b.ls	LBB28_12
	b	LBB28_16
LBB28_6:
	mov	x22, #0
	cmn	x25, #1
	b.ne	LBB28_10
	b	LBB28_15
LBB28_7:
	cmp	x23, #1
	b.lt	LBB28_9
	lsl	x1, x23, #3
	mov	x23, x0
	mov	x0, x22
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	mov	x0, x23
LBB28_9:
	mov	x22, #0
	mov	x23, #-1
	cmn	x25, #1
	b.eq	LBB28_15
LBB28_10:
	cmp	x25, #2
	b.hs	LBB28_13
	mov	w26, #1
	ldrb	w27, [x19, #24]
	sub	x8, x25, #1
	cmn	x8, #3
	b.hi	LBB28_16
LBB28_12:
	lsl	x1, x25, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	b	LBB28_16
LBB28_13:
	cmp	x25, #1
	b.lt	LBB28_15
	lsl	x1, x25, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB28_15:
	ldrb	w27, [x19, #24]
	mov	w26, #1
LBB28_16:
	mov	w8, #2
	sub	w8, w8, w26
	.p2align	6, , 4
	cmp	w27, #0
	csel	w8, w8, w26, eq
	stp	x23, x22, [x21]
	str	x24, [x21, #16]
	strb	w8, [x21, #24]
	ldr	x8, [x20]
	cmp	x8, #1
	b.lt	LBB28_19
	ldr	x0, [x20, #8]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB28_19:
	ldr	x8, [x19]
	cmp	x8, #1
	b.lt	LBB28_21
	ldr	x0, [x19, #8]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB28_21:
	.cfi_def_cfa wsp, 144
	ldp	x29, x30, [sp, #128]
	ldp	x20, x19, [sp, #112]
	ldp	x22, x21, [sp, #96]
	ldp	x24, x23, [sp, #80]
	ldp	x26, x25, [sp, #64]
	ldp	x28, x27, [sp, #48]
	add	sp, sp, #144
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	ret
LBB28_22:
	.cfi_restore_state
Ltmp248:
	mov	x21, x0
	ldr	x8, [x20]
	cmp	x8, #1
	b.ge	LBB28_25
	ldr	x8, [x19]
	cmp	x8, #1
	b.ge	LBB28_26
LBB28_24:
	mov	x0, x21
	bl	__Unwind_Resume
LBB28_25:
	ldr	x0, [x20, #8]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	ldr	x8, [x19]
	cmp	x8, #1
	b.lt	LBB28_24
LBB28_26:
	ldr	x0, [x19, #8]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	mov	x0, x21
	bl	__Unwind_Resume
Lfunc_end5:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table28:
Lexception5:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 Lcst_end5-Lcst_begin5
Lcst_begin5:
	.uleb128 Ltmp246-Lfunc_begin5
	.uleb128 Ltmp247-Ltmp246
	.uleb128 Ltmp248-Lfunc_begin5
	.byte	0
	.uleb128 Ltmp247-Lfunc_begin5
	.uleb128 Lfunc_end5-Ltmp247
	.byte	0
	.byte	0
Lcst_end5:
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RNvXs_NtCs70jQWIuBJri_10num_bigint9big_digitNtB4_9BigDigitsNtNtCsjIpoRzUjyHQ_4core5clone5Clone10clone_from:
	.cfi_startproc
	stp	x24, x23, [sp, #-64]!
	.cfi_def_cfa_offset 64
	stp	x22, x21, [sp, #16]
	stp	x20, x19, [sp, #32]
	stp	x29, x30, [sp, #48]
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_remember_state
	mov	x19, x0
	ldr	x8, [x0]
	cmp	x8, #0
	b.le	LBB29_4
	str	xzr, [x19, #16]
	ldr	x9, [x1]
	cmn	x9, #1
	b.eq	LBB29_8
	mov	x9, x1
	ldr	x1, [x1, #8]
	ldr	x20, [x9, #16]
	cmp	x20, x8
	b.hi	LBB29_19
	mov	x21, #0
	mov	x8, #0
	cbnz	x20, LBB29_10
	b	LBB29_13
LBB29_4:
	ldr	x8, [x1]
	ldr	x23, [x1, #16]
	cmn	x8, #1
	b.eq	LBB29_11
	cbz	x23, LBB29_14
	ldr	x21, [x1, #8]
	cmp	x23, #1
	b.ne	LBB29_15
	ldr	x23, [x21]
	mov	x8, #-1
	mov	w20, #1
	b	LBB29_17
LBB29_8:
	ldr	w8, [x1, #8]
	tbz	w8, #0, LBB29_12
	mov	x21, #0
	add	x1, x1, #16
	mov	w20, #1
LBB29_10:
	ldr	x8, [x19, #8]
	add	x0, x8, x21, lsl #3
	lsl	x2, x20, #3
	bl	_memcpy
	mov	x8, x20
	b	LBB29_13
LBB29_11:
	ldr	x20, [x1, #8]
	b	LBB29_17
LBB29_12:
	mov	x8, #0
	mov	x21, #0
LBB29_13:
	add	x8, x21, x8
	str	x8, [x19, #16]
	b	LBB29_18
LBB29_14:
	mov	x8, #-1
	mov	x20, x23
	b	LBB29_17
LBB29_15:
	lsl	x22, x23, #3
	bl	__RNvCsdtSMxSA38aw_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	x0, x22
	mov	w1, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc12___rust_alloc
	cbz	x0, LBB29_20
	mov	x20, x0
	mov	x1, x21
	mov	x2, x22
	bl	_memcpy
	mov	x8, x23
LBB29_17:
	stp	x8, x20, [x19]
	str	x23, [x19, #16]
LBB29_18:
	.cfi_def_cfa wsp, 64
	ldp	x29, x30, [sp, #48]
	ldp	x20, x19, [sp, #32]
	ldp	x22, x21, [sp, #16]
	ldp	x24, x23, [sp], #64
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	ret
LBB29_19:
	.cfi_restore_state
	mov	x0, x19
	mov	x21, x1
	mov	x1, #0
	mov	x2, x20
	bl	__RINvNvMs2_NtCs6zY7rJBZy9D_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs7wsLvUT6iAW_13codegen_audit
	mov	x1, x21
	ldr	x21, [x19, #16]
	b	LBB29_10
LBB29_20:
	mov	w0, #8
	mov	x1, x22
	bl	__RNvNtCs6zY7rJBZy9D_5alloc7raw_vec12handle_error
	.cfi_endproc

	.p2align	2
__RNvXsc_NtNtCs70jQWIuBJri_10num_bigint6bigint14multiplicationNtB7_6BigIntNtNtNtCsjIpoRzUjyHQ_4core3ops5arith3Mul3mul:
Lfunc_begin6:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception6
	sub	sp, sp, #208
	.cfi_def_cfa_offset 208
	stp	x26, x25, [sp, #128]
	stp	x24, x23, [sp, #144]
	stp	x22, x21, [sp, #160]
	stp	x20, x19, [sp, #176]
	stp	x29, x30, [sp, #192]
	add	x29, sp, #192
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_remember_state
	mov	x19, x0
	ldr	q0, [x1]
	str	q0, [sp]
	ldr	x8, [x1, #16]
	str	x8, [sp, #16]
	ldr	q0, [x2]
	str	q0, [sp, #32]
	ldr	x8, [x2, #16]
	str	x8, [sp, #48]
	ldrb	w8, [x1, #24]
	cmp	w8, #1
	b.ne	LBB30_2
	mov	w24, #1
	mov	w23, #1
	ldr	x22, [sp]
	cmn	x22, #1
	b.ne	LBB30_7
	b	LBB30_11
LBB30_2:
	ldrb	w23, [x2, #24]
	cbz	w23, LBB30_5
	cmp	w23, #1
	b.ne	LBB30_9
	mov	w24, #1
	ldr	x22, [sp]
	cmn	x22, #1
	b.ne	LBB30_7
	b	LBB30_11
LBB30_5:
	cbz	w8, LBB30_10
LBB30_6:
	mov	w24, #0
	mov	w23, #0
	ldr	x22, [sp]
	cmn	x22, #1
	b.eq	LBB30_11
LBB30_7:
	ldp	x20, x9, [sp, #8]
	mov	x0, x20
	ldr	x25, [sp, #32]
	cmn	x25, #1
	b.eq	LBB30_12
LBB30_8:
	ldp	x21, x3, [sp, #40]
	mov	x10, x21
	cbnz	x9, LBB30_13
	b	LBB30_17
LBB30_9:
	cbz	w8, LBB30_6
LBB30_10:
	mov	w24, #0
	mov	w23, #2
	ldr	x22, [sp]
	cmn	x22, #1
	b.ne	LBB30_7
LBB30_11:
	ldr	x8, [sp, #8]
	mov	w10, #8
	mov	x9, sp
	add	x11, x9, #16
	cmp	x8, #0
	csel	x20, x8, x8, eq
	cset	x9, ne
	csel	x0, x10, x11, eq
	ldr	x25, [sp, #32]
	cmn	x25, #1
	b.ne	LBB30_8
LBB30_12:
	ldr	x8, [sp, #40]
	mov	w10, #8
	add	x11, sp, #32
	add	x11, x11, #16
	cmp	x8, #0
	csel	x21, x8, x8, eq
	cset	x3, ne
	csel	x10, x10, x11, eq
	cbz	x9, LBB30_17
LBB30_13:
	cbz	x3, LBB30_17
	cmp	x3, #1
	b.ne	LBB30_28
	ldr	x8, [x10]
	ldr	q0, [x1]
	str	q0, [sp, #96]
	ldr	x9, [x1, #16]
	str	x9, [sp, #112]
Ltmp249:
	add	x0, sp, #96
	mov	x1, x8
	bl	__RNvNtNtCs70jQWIuBJri_10num_bigint7biguint14multiplication10scalar_mul
Ltmp250:
	ldr	q0, [sp, #96]
	str	q0, [sp, #64]
	ldr	x8, [sp, #112]
	str	x8, [sp, #80]
	mov	x22, x25
	mov	x20, x21
	cmp	x25, #0
	b.gt	LBB30_21
	b	LBB30_22
LBB30_17:
	str	xzr, [sp, #80]
Lloh52:
	adrp	x8, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.1@PAGE
Lloh53:
	add	x8, x8, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.1@PAGEOFF
Lloh54:
	ldr	q0, [x8]
	str	q0, [sp, #64]
LBB30_18:
	cmp	x25, #1
	b.lt	LBB30_20
	lsl	x1, x25, #3
	mov	x0, x21
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB30_20:
	cmp	x22, #0
	b.le	LBB30_22
LBB30_21:
	lsl	x1, x22, #3
	mov	x0, x20
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB30_22:
	ldr	x8, [sp, #64]
	tbz	w24, #0, LBB30_26
	cmn	x8, #1
	b.eq	LBB30_31
	str	xzr, [sp, #80]
	cmp	x8, #2
	b.lo	LBB30_32
	ldr	x0, [sp, #72]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	str	xzr, [sp, #80]
Lloh55:
	adrp	x8, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.1@PAGE
Lloh56:
	add	x8, x8, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.1@PAGEOFF
Lloh57:
	ldr	q0, [x8]
	str	q0, [sp, #64]
	b	LBB30_32
LBB30_26:
	cmn	x8, #1
	b.eq	LBB30_33
	ldr	x8, [sp, #80]
	cmp	x8, #0
	cset	w8, eq
	b	LBB30_34
LBB30_28:
	cmp	x9, #1
	b.ne	LBB30_36
	ldr	x1, [x0]
	ldr	q0, [x2]
	str	q0, [sp, #96]
	ldr	x8, [x2, #16]
	str	x8, [sp, #112]
Ltmp255:
	add	x0, sp, #96
	bl	__RNvNtNtCs70jQWIuBJri_10num_bigint7biguint14multiplication10scalar_mul
Ltmp256:
	ldr	q0, [sp, #96]
	str	q0, [sp, #64]
	ldr	x8, [sp, #112]
	str	x8, [sp, #80]
	cmp	x22, #0
	b.gt	LBB30_21
	b	LBB30_22
LBB30_31:
	str	xzr, [sp, #72]
LBB30_32:
	mov	w8, #1
	b	LBB30_35
LBB30_33:
	ldr	w8, [sp, #72]
	eor	w8, w8, #0x1
LBB30_34:
	cmp	w8, #0
	csinc	w8, w23, wzr, eq
LBB30_35:
	ldr	q0, [sp, #64]
	str	q0, [x19]
	ldr	x9, [sp, #80]
	str	x9, [x19, #16]
	strb	w8, [x19, #24]
	.cfi_def_cfa wsp, 208
	ldp	x29, x30, [sp, #192]
	ldp	x20, x19, [sp, #176]
	ldp	x22, x21, [sp, #160]
	ldp	x24, x23, [sp, #144]
	ldp	x26, x25, [sp, #128]
	add	sp, sp, #208
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	ret
LBB30_36:
	.cfi_restore_state
Ltmp252:
	add	x8, sp, #64
	mov	x1, x9
	mov	x2, x10
	bl	__RNvNtNtCs70jQWIuBJri_10num_bigint7biguint14multiplication4mul3
Ltmp253:
	b	LBB30_18
LBB30_37:
Ltmp254:
	mov	x19, x0
	mov	w23, #1
	b	LBB30_43
LBB30_38:
Ltmp257:
	mov	x19, x0
	ldr	x8, [sp, #96]
	cmp	x8, #1
	b.lt	LBB30_46
	ldr	x0, [sp, #104]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	b	LBB30_46
LBB30_40:
Ltmp251:
	mov	x19, x0
	ldr	x8, [sp, #96]
	cmp	x8, #1
	b.lt	LBB30_42
	ldr	x0, [sp, #104]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB30_42:
	mov	w23, #0
LBB30_43:
	cmp	x25, #1
	b.lt	LBB30_45
	lsl	x1, x25, #3
	mov	x0, x21
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB30_45:
	tbz	w23, #0, LBB30_48
LBB30_46:
	cmp	x22, #1
	b.lt	LBB30_48
	lsl	x1, x22, #3
	mov	x0, x20
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB30_48:
	mov	x0, x19
	bl	__Unwind_Resume
	.loh AdrpAddLdr	Lloh52, Lloh53, Lloh54
	.loh AdrpAddLdr	Lloh55, Lloh56, Lloh57
Lfunc_end6:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table30:
Lexception6:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 Lcst_end6-Lcst_begin6
Lcst_begin6:
	.uleb128 Ltmp249-Lfunc_begin6
	.uleb128 Ltmp250-Ltmp249
	.uleb128 Ltmp251-Lfunc_begin6
	.byte	0
	.uleb128 Ltmp255-Lfunc_begin6
	.uleb128 Ltmp256-Ltmp255
	.uleb128 Ltmp257-Lfunc_begin6
	.byte	0
	.uleb128 Ltmp252-Lfunc_begin6
	.uleb128 Ltmp253-Ltmp252
	.uleb128 Ltmp254-Lfunc_begin6
	.byte	0
	.uleb128 Ltmp253-Lfunc_begin6
	.uleb128 Lfunc_end6-Ltmp253
	.byte	0
	.byte	0
Lcst_end6:
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RNvXsf_NtNtCs70jQWIuBJri_10num_bigint6bigint14multiplicationRNtB7_6BigIntNtNtNtCsjIpoRzUjyHQ_4core3ops5arith3Mul3mul:
Lfunc_begin7:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception7
	sub	sp, sp, #128
	.cfi_def_cfa_offset 128
	stp	x26, x25, [sp, #48]
	stp	x24, x23, [sp, #64]
	stp	x22, x21, [sp, #80]
	stp	x20, x19, [sp, #96]
	stp	x29, x30, [sp, #112]
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_remember_state
	mov	x19, x0
	ldrb	w8, [x1, #24]
	cmp	w8, #1
	b.ne	LBB31_2
	mov	w25, #1
	mov	w24, #1
	ldr	x8, [x1]
	cmn	x8, #1
	b.ne	LBB31_7
	b	LBB31_11
LBB31_2:
	ldrb	w24, [x2, #24]
	cbz	w24, LBB31_5
	cmp	w24, #1
	b.ne	LBB31_9
	mov	w25, #1
	ldr	x8, [x1]
	cmn	x8, #1
	b.ne	LBB31_7
	b	LBB31_11
LBB31_5:
	cbz	w8, LBB31_10
LBB31_6:
	mov	w25, #0
	mov	w24, #0
	ldr	x8, [x1]
	cmn	x8, #1
	b.eq	LBB31_11
LBB31_7:
	ldp	x20, x9, [x1, #8]
	mov	x21, x20
	mov	x0, x20
	ldr	x11, [x2]
	cmn	x11, #1
	b.eq	LBB31_12
LBB31_8:
	ldp	x22, x3, [x2, #8]
	mov	x23, x22
	mov	x10, x22
	cbnz	x9, LBB31_13
	b	LBB31_19
LBB31_9:
	cbz	w8, LBB31_6
LBB31_10:
	mov	w25, #0
	mov	w24, #2
	ldr	x8, [x1]
	cmn	x8, #1
	b.ne	LBB31_7
LBB31_11:
	ldr	x9, [x1, #8]
	mov	w10, #8
	add	x11, x1, #16
	cmp	x9, #0
	csel	x21, x9, x9, eq
	cset	x20, ne
	cset	x9, ne
	csel	x0, x10, x11, eq
	ldr	x11, [x2]
	cmn	x11, #1
	b.ne	LBB31_8
LBB31_12:
	ldr	x10, [x2, #8]
	mov	w12, #8
	add	x13, x2, #16
	cmp	x10, #0
	csel	x23, x10, x10, eq
	cset	x22, ne
	cset	x3, ne
	csel	x10, x12, x13, eq
	cbz	x9, LBB31_19
LBB31_13:
	cbz	x3, LBB31_19
	cmp	x3, #1
	b.ne	LBB31_20
	ldr	x22, [x10]
	ldr	x26, [x1, #16]
	cmn	x8, #1
	b.eq	LBB31_33
	cbz	x26, LBB31_30
	cmp	x26, #1
	b.ne	LBB31_31
	ldr	x26, [x21]
	mov	x8, #-1
	mov	w20, #1
	b	LBB31_33
LBB31_19:
	str	xzr, [sp, #16]
Lloh58:
	adrp	x8, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.1@PAGE
Lloh59:
	add	x8, x8, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.1@PAGEOFF
Lloh60:
	ldr	q0, [x8]
	str	q0, [sp]
	ldr	x8, [sp]
	tbz	w25, #0, LBB31_26
	b	LBB31_40
LBB31_20:
	cmp	x9, #1
	b.ne	LBB31_25
	ldr	x1, [x0]
	ldr	x21, [x2, #16]
	cmn	x11, #1
	b.eq	LBB31_34
	cbz	x21, LBB31_35
	cmp	x21, #1
	b.ne	LBB31_36
	ldr	x21, [x23]
	mov	x8, #-1
	mov	w22, #1
	b	LBB31_38
LBB31_25:
	mov	x8, sp
	mov	x1, x9
	mov	x2, x10
	bl	__RNvNtNtCs70jQWIuBJri_10num_bigint7biguint14multiplication4mul3
	ldr	x8, [sp]
	tbnz	w25, #0, LBB31_40
LBB31_26:
	cmn	x8, #1
	b.eq	LBB31_28
	ldr	x8, [sp, #16]
	cmp	x8, #0
	cset	w8, eq
	b	LBB31_29
LBB31_28:
	ldr	w8, [sp, #8]
	eor	w8, w8, #0x1
LBB31_29:
	cmp	w8, #0
	csinc	w8, w24, wzr, eq
	b	LBB31_45
LBB31_30:
	mov	x8, #-1
	mov	x20, x26
	b	LBB31_33
LBB31_31:
	lsl	x23, x26, #3
	bl	__RNvCsdtSMxSA38aw_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	x0, x23
	mov	w1, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc12___rust_alloc
	cbz	x0, LBB31_46
	mov	x20, x0
	mov	x1, x21
	mov	x2, x23
	bl	_memcpy
	mov	x8, x26
LBB31_33:
	stp	x8, x20, [sp, #24]
	str	x26, [sp, #40]
Ltmp258:
	add	x0, sp, #24
	mov	x1, x22
	bl	__RNvNtNtCs70jQWIuBJri_10num_bigint7biguint14multiplication10scalar_mul
Ltmp259:
	b	LBB31_39
LBB31_34:
	mov	x8, #-1
	b	LBB31_38
LBB31_35:
	mov	x8, #-1
	mov	x22, x21
	b	LBB31_38
LBB31_36:
	mov	x26, x1
	lsl	x20, x21, #3
	bl	__RNvCsdtSMxSA38aw_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	x0, x20
	mov	w1, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc12___rust_alloc
	cbz	x0, LBB31_47
	mov	x22, x0
	mov	x1, x23
	mov	x2, x20
	bl	_memcpy
	mov	x8, x21
	mov	x1, x26
LBB31_38:
	stp	x8, x22, [sp, #24]
	str	x21, [sp, #40]
Ltmp261:
	add	x0, sp, #24
	bl	__RNvNtNtCs70jQWIuBJri_10num_bigint7biguint14multiplication10scalar_mul
Ltmp262:
LBB31_39:
	ldur	q0, [sp, #24]
	str	q0, [sp]
	ldr	x8, [sp, #40]
	str	x8, [sp, #16]
	ldr	x8, [sp]
	tbz	w25, #0, LBB31_26
LBB31_40:
	cmn	x8, #1
	b.eq	LBB31_43
	str	xzr, [sp, #16]
	cmp	x8, #2
	b.lo	LBB31_44
	ldr	x0, [sp, #8]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
	str	xzr, [sp, #16]
Lloh61:
	adrp	x8, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.1@PAGE
Lloh62:
	add	x8, x8, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.1@PAGEOFF
Lloh63:
	ldr	q0, [x8]
	str	q0, [sp]
	b	LBB31_44
LBB31_43:
	str	xzr, [sp, #8]
LBB31_44:
	mov	w8, #1
LBB31_45:
	ldr	q0, [sp]
	str	q0, [x19]
	ldr	x9, [sp, #16]
	str	x9, [x19, #16]
	strb	w8, [x19, #24]
	.cfi_def_cfa wsp, 128
	ldp	x29, x30, [sp, #112]
	ldp	x20, x19, [sp, #96]
	ldp	x22, x21, [sp, #80]
	ldp	x24, x23, [sp, #64]
	ldp	x26, x25, [sp, #48]
	add	sp, sp, #128
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	ret
LBB31_46:
	.cfi_restore_state
	mov	w0, #8
	mov	x1, x23
	bl	__RNvNtCs6zY7rJBZy9D_5alloc7raw_vec12handle_error
LBB31_47:
	mov	w0, #8
	mov	x1, x20
	bl	__RNvNtCs6zY7rJBZy9D_5alloc7raw_vec12handle_error
LBB31_48:
Ltmp263:
	b	LBB31_50
LBB31_49:
Ltmp260:
LBB31_50:
	mov	x19, x0
	ldr	x8, [sp, #24]
	cmp	x8, #1
	b.lt	LBB31_52
	ldr	x0, [sp, #32]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB31_52:
	mov	x0, x19
	bl	__Unwind_Resume
	.loh AdrpAddLdr	Lloh58, Lloh59, Lloh60
	.loh AdrpAddLdr	Lloh61, Lloh62, Lloh63
Lfunc_end7:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table31:
Lexception7:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 Lcst_end7-Lcst_begin7
Lcst_begin7:
	.uleb128 Lfunc_begin7-Lfunc_begin7
	.uleb128 Ltmp258-Lfunc_begin7
	.byte	0
	.byte	0
	.uleb128 Ltmp258-Lfunc_begin7
	.uleb128 Ltmp259-Ltmp258
	.uleb128 Ltmp260-Lfunc_begin7
	.byte	0
	.uleb128 Ltmp259-Lfunc_begin7
	.uleb128 Ltmp261-Ltmp259
	.byte	0
	.byte	0
	.uleb128 Ltmp261-Lfunc_begin7
	.uleb128 Ltmp262-Ltmp261
	.uleb128 Ltmp263-Lfunc_begin7
	.byte	0
	.uleb128 Ltmp262-Lfunc_begin7
	.uleb128 Lfunc_end7-Ltmp262
	.byte	0
	.byte	0
Lcst_end7:
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RNvXsh_NtCs70jQWIuBJri_10num_bigint7biguintNtB5_7BigUintNtCs5ZU5g2vqbRJ_11num_integer7Integer3gcd:
Lfunc_begin8:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception8
	sub	sp, sp, #160
	.cfi_def_cfa_offset 160
	stp	x26, x25, [sp, #80]
	stp	x24, x23, [sp, #96]
	stp	x22, x21, [sp, #112]
	stp	x20, x19, [sp, #128]
	stp	x29, x30, [sp, #144]
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_remember_state
	mov	x19, x0
	ldr	x8, [x1]
	cmn	x8, #1
	b.eq	LBB32_9
	ldr	x9, [x1, #16]
	cbz	x9, LBB32_10
LBB32_2:
	ldr	x23, [x2]
	cmn	x23, #1
	b.eq	LBB32_14
	ldr	x9, [x2, #16]
	cbz	x9, LBB32_15
LBB32_4:
	ldr	x24, [x1, #16]
	cmn	x8, #1
	b.eq	LBB32_22
	cbz	x24, LBB32_28
	ldr	x21, [x1, #8]
	cmp	x24, #1
	b.ne	LBB32_29
	ldr	x24, [x21]
	mov	x8, #-1
	mov	w20, #1
	stp	x8, x20, [sp, #8]
	str	x24, [sp, #24]
	ldr	x24, [x2, #16]
	cmn	x23, #1
	b.ne	LBB32_23
LBB32_8:
	ldr	x20, [x2, #8]
	mov	x8, #-1
	b	LBB32_34
LBB32_9:
	ldr	x9, [x1, #8]
	cbnz	x9, LBB32_2
LBB32_10:
	ldr	x8, [x2]
	ldr	x23, [x2, #16]
	cmn	x8, #1
	b.eq	LBB32_20
	cbz	x23, LBB32_21
	ldr	x21, [x2, #8]
	cmp	x23, #1
	b.ne	LBB32_18
LBB32_13:
	ldr	x23, [x21]
	mov	x8, #-1
	mov	w20, #1
	b	LBB32_27
LBB32_14:
	ldr	x9, [x2, #8]
	cbnz	x9, LBB32_4
LBB32_15:
	ldr	x23, [x1, #16]
	cmn	x8, #1
	b.eq	LBB32_26
	cbz	x23, LBB32_21
	ldr	x21, [x1, #8]
	cmp	x23, #1
	b.eq	LBB32_13
LBB32_18:
	lsl	x22, x23, #3
	bl	__RNvCsdtSMxSA38aw_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	x0, x22
	mov	w1, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc12___rust_alloc
	cbz	x0, LBB32_73
	mov	x20, x0
	mov	x1, x21
	mov	x2, x22
	bl	_memcpy
	mov	x8, x23
	b	LBB32_27
LBB32_20:
	ldr	x20, [x2, #8]
	b	LBB32_27
LBB32_21:
	mov	x8, #-1
	mov	x20, x23
	b	LBB32_27
LBB32_22:
	ldr	x20, [x1, #8]
	stp	x8, x20, [sp, #8]
	str	x24, [sp, #24]
	ldr	x24, [x2, #16]
	cmn	x23, #1
	b.eq	LBB32_8
LBB32_23:
	cbz	x24, LBB32_31
	ldr	x21, [x2, #8]
	cmp	x24, #1
	b.ne	LBB32_32
	ldr	x24, [x21]
	mov	x8, #-1
	mov	w20, #1
	b	LBB32_34
LBB32_26:
	ldr	x20, [x1, #8]
LBB32_27:
	stp	x8, x20, [x19]
	str	x23, [x19, #16]
	b	LBB32_59
LBB32_28:
	mov	x8, #-1
	stp	x8, x24, [sp, #8]
	str	x24, [sp, #24]
	ldr	x24, [x2, #16]
	cmn	x23, #1
	b.ne	LBB32_23
	b	LBB32_8
LBB32_29:
	mov	x25, x2
	lsl	x22, x24, #3
	bl	__RNvCsdtSMxSA38aw_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	x0, x22
	mov	w1, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc12___rust_alloc
	cbz	x0, LBB32_73
	mov	x20, x0
	mov	x1, x21
	mov	x2, x22
	bl	_memcpy
	mov	x2, x25
	stp	x24, x20, [sp, #8]
	str	x24, [sp, #24]
	ldr	x24, [x25, #16]
	cmn	x23, #1
	b.ne	LBB32_23
	b	LBB32_8
LBB32_31:
	mov	x8, #-1
	mov	x20, x24
	b	LBB32_34
LBB32_32:
	lsl	x22, x24, #3
	bl	__RNvCsdtSMxSA38aw_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	x0, x22
	mov	w1, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc12___rust_alloc
	cbz	x0, LBB32_74
	mov	x20, x0
	mov	x1, x21
	mov	x2, x22
	bl	_memcpy
	mov	x8, x24
LBB32_34:
	stp	x8, x20, [sp, #32]
	add	x22, sp, #32
	str	x24, [sp, #48]
Ltmp267:
	add	x0, sp, #32
	bl	__RNvMsj_NtCs70jQWIuBJri_10num_bigint7biguintNtB5_7BigUint14trailing_zeros
Ltmp268:
Ltmp269:
	mov	x20, x0
	mov	x21, x1
	add	x0, sp, #8
	bl	__RNvMsj_NtCs70jQWIuBJri_10num_bigint7biguintNtB5_7BigUint14trailing_zeros
Ltmp270:
	cmp	x1, x21
	csel	x8, x1, x21, lo
	and	w9, w0, w20
	tst	w9, #0x1
	csel	x20, x8, xzr, ne
Ltmp271:
	add	x0, sp, #32
	bl	__RNvMsj_NtCs70jQWIuBJri_10num_bigint7biguintNtB5_7BigUint14trailing_zeros
Ltmp272:
	tst	w0, #0x1
	csel	x1, x1, xzr, ne
Ltmp273:
	add	x0, sp, #32
	bl	__RNvXsl_NtNtCs70jQWIuBJri_10num_bigint7biguint5shiftNtB7_7BigUintINtNtNtCsjIpoRzUjyHQ_4core3ops3bit9ShrAssignyE10shr_assign
Ltmp274:
	add	x8, sp, #8
	add	x23, x8, #16
	add	x24, x22, #16
	ldr	x21, [sp, #32]
	ldr	x22, [sp, #48]
	mov	w25, #8
	b	LBB32_40
LBB32_39:
Ltmp285:
	add	x0, sp, #8
	add	x1, sp, #32
	bl	__RNvXs_NtNtCs70jQWIuBJri_10num_bigint7biguint11subtractionNtB6_7BigUintINtNtNtCsjIpoRzUjyHQ_4core3ops5arith9SubAssignRBT_E10sub_assign
Ltmp286:
LBB32_40:
	ldr	x8, [sp, #8]
	cmn	x8, #1
	b.eq	LBB32_42
	ldr	x8, [sp, #24]
	cbnz	x8, LBB32_43
	b	LBB32_51
LBB32_42:
	ldr	x8, [sp, #16]
	cbz	x8, LBB32_51
LBB32_43:
Ltmp281:
	add	x0, sp, #8
	bl	__RNvMsj_NtCs70jQWIuBJri_10num_bigint7biguintNtB5_7BigUint14trailing_zeros
Ltmp282:
	tst	w0, #0x1
	csel	x1, x1, xzr, ne
Ltmp283:
	add	x0, sp, #8
	bl	__RNvXsl_NtNtCs70jQWIuBJri_10num_bigint7biguint5shiftNtB7_7BigUintINtNtNtCsjIpoRzUjyHQ_4core3ops3bit9ShrAssignyE10shr_assign
Ltmp284:
	ldr	x8, [sp, #40]
	tst	w8, #0x1
	csel	x9, x24, x25, ne
	cmn	x21, #1
	csel	x13, x8, x22, eq
	csel	x12, x9, x8, eq
	ldp	x9, x11, [sp, #8]
	ldr	x10, [sp, #24]
	cmn	x9, #1
	csel	x14, x11, x10, eq
	cmp	x13, x14
	b.ne	LBB32_49
	tst	w11, #0x1
	csel	x14, x23, x25, ne
	cmn	x9, #1
	csel	x14, x14, x11, eq
	sub	x14, x14, #8
	lsl	x13, x13, #3
	sub	x12, x12, #8
LBB32_47:
	cbz	x13, LBB32_39
	ldr	x15, [x12, x13]
	ldr	x16, [x14, x13]
	sub	x13, x13, #8
	cmp	x15, x16
	b.eq	LBB32_47
LBB32_49:
	b.ls	LBB32_39
	stp	x9, x11, [sp, #32]
	stp	x21, x8, [sp, #8]
	str	x22, [sp, #24]
	mov	x22, x10
	mov	x21, x9
	str	x10, [sp, #48]
	b	LBB32_39
LBB32_51:
	ldr	x8, [sp, #40]
	cmn	x21, #2
	b.ne	LBB32_54
	ldr	x9, [x8]
	cmn	x9, #1
	b.eq	LBB32_60
	ldr	x9, [x8, #16]
	b	LBB32_55
LBB32_54:
	mov	x9, x22
	mov	x10, x8
	cmn	x21, #1
	b.eq	LBB32_61
LBB32_55:
	cbz	x9, LBB32_62
LBB32_56:
	lsr	x1, x20, #6
	stp	x21, x8, [sp, #56]
	str	x22, [sp, #72]
Ltmp278:
	add	x0, sp, #56
	and	w2, w20, #0x3f
	mov	x8, x19
	bl	__RNvNtNtCs70jQWIuBJri_10num_bigint7biguint5shift12biguint_shl2
Ltmp279:
	ldr	x8, [sp, #8]
	cmp	x8, #1
	b.lt	LBB32_59
LBB32_58:
	ldr	x0, [sp, #16]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB32_59:
	.cfi_def_cfa wsp, 160
	ldp	x29, x30, [sp, #144]
	ldp	x20, x19, [sp, #128]
	ldp	x22, x21, [sp, #112]
	ldp	x24, x23, [sp, #96]
	ldp	x26, x25, [sp, #80]
	add	sp, sp, #160
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	ret
LBB32_60:
	.cfi_restore_state
	ldr	x10, [x8, #8]
LBB32_61:
	tbnz	w10, #0, LBB32_56
LBB32_62:
	cmn	x21, #2
	b.ne	LBB32_67
	ldr	x9, [x8]
	ldr	x23, [x8, #16]
	cmn	x9, #1
	b.eq	LBB32_68
	cbz	x23, LBB32_69
	ldr	x21, [x8, #8]
	cmp	x23, #1
	b.ne	LBB32_70
	ldr	x23, [x21]
	mov	x8, #-1
	mov	w20, #1
	b	LBB32_72
LBB32_67:
	stp	x21, x8, [x19]
	str	x22, [x19, #16]
	ldr	x8, [sp, #8]
	cmp	x8, #1
	b.ge	LBB32_58
	b	LBB32_59
LBB32_68:
	ldr	x20, [x8, #8]
	mov	x8, #-1
	b	LBB32_72
LBB32_69:
	mov	x8, #-1
	mov	x20, x23
	b	LBB32_72
LBB32_70:
	lsl	x22, x23, #3
	bl	__RNvCsdtSMxSA38aw_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	x0, x22
	mov	w1, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc12___rust_alloc
	cbz	x0, LBB32_75
	mov	x20, x0
	mov	x1, x21
	mov	x2, x22
	bl	_memcpy
	mov	x8, x23
LBB32_72:
	stp	x8, x20, [x19]
	str	x23, [x19, #16]
	ldr	x8, [sp, #8]
	cmp	x8, #1
	b.ge	LBB32_58
	b	LBB32_59
LBB32_73:
	mov	w0, #8
	mov	x1, x22
	bl	__RNvNtCs6zY7rJBZy9D_5alloc7raw_vec12handle_error
LBB32_74:
Ltmp264:
	mov	w0, #8
	mov	x1, x22
	bl	__RNvNtCs6zY7rJBZy9D_5alloc7raw_vec12handle_error
Ltmp265:
	b	LBB32_76
LBB32_75:
Ltmp276:
	mov	w0, #8
	mov	x1, x22
	bl	__RNvNtCs6zY7rJBZy9D_5alloc7raw_vec12handle_error
Ltmp277:
LBB32_76:
	brk	#0x1
LBB32_77:
Ltmp266:
	b	LBB32_79
LBB32_78:
Ltmp280:
LBB32_79:
	mov	x19, x0
	b	LBB32_84
LBB32_80:
Ltmp275:
	mov	x19, x0
	ldr	x21, [sp, #32]
	b	LBB32_82
LBB32_81:
Ltmp287:
	mov	x19, x0
LBB32_82:
	sub	x8, x21, #1
	cmn	x8, #3
	b.hi	LBB32_84
	ldr	x0, [sp, #40]
	lsl	x1, x21, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB32_84:
	ldr	x8, [sp, #8]
	cmp	x8, #1
	b.lt	LBB32_86
	ldr	x0, [sp, #16]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc14___rust_dealloc
LBB32_86:
	mov	x0, x19
	bl	__Unwind_Resume
Lfunc_end8:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table32:
Lexception8:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 Lcst_end8-Lcst_begin8
Lcst_begin8:
	.uleb128 Lfunc_begin8-Lfunc_begin8
	.uleb128 Ltmp267-Lfunc_begin8
	.byte	0
	.byte	0
	.uleb128 Ltmp267-Lfunc_begin8
	.uleb128 Ltmp274-Ltmp267
	.uleb128 Ltmp275-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp285-Lfunc_begin8
	.uleb128 Ltmp284-Ltmp285
	.uleb128 Ltmp287-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp278-Lfunc_begin8
	.uleb128 Ltmp279-Ltmp278
	.uleb128 Ltmp280-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp279-Lfunc_begin8
	.uleb128 Ltmp264-Ltmp279
	.byte	0
	.byte	0
	.uleb128 Ltmp264-Lfunc_begin8
	.uleb128 Ltmp265-Ltmp264
	.uleb128 Ltmp266-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp276-Lfunc_begin8
	.uleb128 Ltmp277-Ltmp276
	.uleb128 Ltmp280-Lfunc_begin8
	.byte	0
	.uleb128 Ltmp277-Lfunc_begin8
	.uleb128 Lfunc_end8-Ltmp277
	.byte	0
	.byte	0
Lcst_end8:
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
__RNvXsl_NtNtCs70jQWIuBJri_10num_bigint7biguint5shiftNtB7_7BigUintINtNtNtCsjIpoRzUjyHQ_4core3ops3bit9ShrAssignyE10shr_assign:
	.cfi_startproc
	sub	sp, sp, #112
	.cfi_def_cfa_offset 112
	stp	x24, x23, [sp, #48]
	stp	x22, x21, [sp, #64]
	stp	x20, x19, [sp, #80]
	stp	x29, x30, [sp, #96]
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_remember_state
	mov	x19, x0
	ldp	x10, x8, [x0]
	ldr	x11, [x0, #16]
	str	xzr, [x0, #16]
Lloh64:
	adrp	x9, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.1@PAGE
Lloh65:
	add	x9, x9, l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.1@PAGEOFF
Lloh66:
	ldr	q0, [x9]
	str	q0, [x0]
	cmn	x10, #2
	b.ne	LBB33_3
	ldr	x9, [x8]
	cmn	x9, #1
	b.eq	LBB33_6
	ldr	x9, [x8, #16]
	b	LBB33_4
LBB33_3:
	mov	x9, x11
	mov	x12, x8
	cmn	x10, #1
	b.eq	LBB33_7
LBB33_4:
	cbz	x9, LBB33_8
LBB33_5:
	lsr	x9, x1, #6
	stp	x10, x8, [sp, #24]
	str	x11, [sp, #40]
	mov	x8, sp
	add	x0, sp, #24
	and	w2, w1, #0x3f
	mov	x1, x9
	bl	__RNvNtNtCs70jQWIuBJri_10num_bigint7biguint5shift12biguint_shr2
	b	LBB33_19
LBB33_6:
	ldr	x12, [x8, #8]
LBB33_7:
	tbnz	w12, #0, LBB33_5
LBB33_8:
	cmn	x10, #2
	b.ne	LBB33_13
	ldr	x9, [x8]
	ldr	x23, [x8, #16]
	cmn	x9, #1
	b.eq	LBB33_14
	cbz	x23, LBB33_15
	ldr	x21, [x8, #8]
	cmp	x23, #1
	b.ne	LBB33_16
	ldr	x23, [x21]
	mov	x8, #-1
	mov	w20, #1
	b	LBB33_18
LBB33_13:
	stp	x10, x8, [sp]
	str	x11, [sp, #16]
	b	LBB33_19
LBB33_14:
	ldr	x20, [x8, #8]
	mov	x8, #-1
	b	LBB33_18
LBB33_15:
	mov	x8, #-1
	mov	x20, x23
	b	LBB33_18
LBB33_16:
	lsl	x22, x23, #3
	bl	__RNvCsdtSMxSA38aw_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	x0, x22
	mov	w1, #8
	bl	__RNvCsdtSMxSA38aw_7___rustc12___rust_alloc
	cbz	x0, LBB33_20
	mov	x20, x0
	mov	x1, x21
	mov	x2, x22
	bl	_memcpy
	mov	x8, x23
LBB33_18:
	stp	x8, x20, [sp]
	str	x23, [sp, #16]
LBB33_19:
	ldr	q0, [sp]
	str	q0, [x19]
	ldr	x8, [sp, #16]
	str	x8, [x19, #16]
	.cfi_def_cfa wsp, 112
	ldp	x29, x30, [sp, #96]
	ldp	x20, x19, [sp, #80]
	ldp	x22, x21, [sp, #64]
	ldp	x24, x23, [sp, #48]
	add	sp, sp, #112
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	ret
LBB33_20:
	.cfi_restore_state
	mov	w0, #8
	mov	x1, x22
	bl	__RNvNtCs6zY7rJBZy9D_5alloc7raw_vec12handle_error
	.loh AdrpAddLdr	Lloh64, Lloh65, Lloh66
	.cfi_endproc

	.section	__TEXT,__const
	.p2align	3, 0x0
l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.0:
	.asciz	"\377\377\377\377\377\377\377\377\000\000\000\000\000\000\000"
	.space	8
	.byte	1
	.space	7

	.p2align	3, 0x0
l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.1:
	.asciz	"\377\377\377\377\377\377\377\377\000\000\000\000\000\000\000"
	.space	8

	.section	__TEXT,__cstring,cstring_literals
l_alloc_be11ab6ad17cfb5c6ecbde08cec637a7:
	.asciz	"src/lu.rs"

	.section	__DATA,__const
	.p2align	3, 0x0
l_alloc_74fb70046b86dd3ae9161bcc5691b5a8:
	.quad	l_alloc_be11ab6ad17cfb5c6ecbde08cec637a7
	.asciz	"\t\000\000\000\000\000\000\000\031\001\000\000\037\000\000"

	.p2align	3, 0x0
l_alloc_4bd28277e2eacf0bcc30cc366dd2df7a:
	.quad	l_alloc_be11ab6ad17cfb5c6ecbde08cec637a7
	.asciz	"\t\000\000\000\000\000\000\000\374\000\000\000\030\000\000"

	.section	__TEXT,__const
	.p2align	3, 0x0
l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.2:
	.ascii	"\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001"
	.space	7

	.section	__TEXT,__literal16,16byte_literals
l_alloc_2378476402a17344e404981387c3e319:
	.ascii	"denominator == 0"

	.section	__TEXT,__cstring,cstring_literals
l_alloc_4f43e8257145cebaa9cfc53f656a73c4:
	.asciz	"/Users/adam/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/num-rational-0.4.2/src/lib.rs"

	.section	__DATA,__const
	.p2align	3, 0x0
l_alloc_9d84ef19db37a76f9abdfeef0faf287f:
	.quad	l_alloc_4f43e8257145cebaa9cfc53f656a73c4
	.asciz	"^\000\000\000\000\000\000\000\211\000\000\000\r\000\000"

	.section	__TEXT,__const
	.p2align	3, 0x0
l_anon.e2a79a2f5f66c283b7cce3ca53df15cd.3:
	.ascii	"\377\377\377\377\377\377\377\377\001\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\002"
	.space	7

.subsections_via_symbols
