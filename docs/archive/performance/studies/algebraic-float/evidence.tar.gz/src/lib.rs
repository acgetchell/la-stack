#![forbid(unsafe_code)]

use la_stack::{LaError, Matrix};

/// Disposable candidate. Only the row additions differ on the success path.
/// Reuse the strict public method for typed errors if a completed row is nonfinite.
#[inline]
pub fn algebraic_norm<const D: usize>(matrix: &Matrix<D>) -> Result<f64, LaError> {
    let mut maximum = 0.0;
    let mut r = 0;
    while r < D {
        let mut sum: f64 = 0.0;
        let mut c = 0;
        while c < D {
            sum = sum.algebraic_add(matrix.as_rows()[r][c].abs());
            c += 1;
        }
        if !sum.is_finite() {
            return matrix.norm_inf();
        }
        if sum > maximum {
            maximum = sum;
        }
        r += 1;
    }
    Ok(maximum)
}

/// Separate exported probes make assembly and IR inspectable without unsafe attributes.
#[inline(never)]
pub fn algebraic_d4(matrix: &Matrix<4>) -> Result<f64, LaError> {
    algebraic_norm(matrix)
}

#[inline(never)]
pub fn strict_d4(matrix: &Matrix<4>) -> Result<f64, LaError> {
    matrix.norm_inf()
}

#[inline(never)]
pub fn algebraic_d5(matrix: &Matrix<5>) -> Result<f64, LaError> {
    algebraic_norm(matrix)
}

#[inline(never)]
pub fn strict_d5(matrix: &Matrix<5>) -> Result<f64, LaError> {
    matrix.norm_inf()
}
