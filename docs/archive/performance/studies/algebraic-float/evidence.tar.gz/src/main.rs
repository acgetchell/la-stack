#![forbid(unsafe_code)]

use algebraic_norm_study::algebraic_norm;
use criterion::Criterion;
use la_stack::{ArithmeticOperation, LaError, Matrix, NonFiniteLocation, NonFiniteOrigin};
use num_rational::BigRational;
use num_traits::{Signed, ToPrimitive, Zero};
use std::hint::black_box;
use std::time::Duration;

fn rational(x: f64) -> BigRational {
    BigRational::from_float(x).expect("finite binary64 input")
}

// Arbitrary-precision summation of exact binary64 values, independent of the kernel.
fn oracle<const D: usize>(matrix: &Matrix<D>) -> BigRational {
    matrix
        .as_rows()
        .iter()
        .map(|row| row.iter().map(|x| rational(*x).abs()).sum::<BigRational>())
        .max()
        .unwrap_or_else(BigRational::zero)
}

fn shared<const D: usize>() -> Matrix<D> {
    // Same fixture formula as benches/common/vs_linalg.rs::matrix_entry.
    Matrix::try_from_rows(std::array::from_fn(|r| {
        std::array::from_fn(|c| {
            if r == c {
                (r as f64).mul_add(1.0e-3, D as f64 + 1.0)
            } else {
                0.1 / (r + c + 1) as f64
            }
        })
    }))
    .unwrap()
}

fn integer<const D: usize>() -> Matrix<D> {
    Matrix::try_from_rows(std::array::from_fn(|r| {
        std::array::from_fn(|c| (1 + r * D + c) as f64 * if (r + c) % 2 == 0 { 1.0 } else { -1.0 })
    }))
    .unwrap()
}

fn result_text(value: &Result<f64, LaError>) -> String {
    match value {
        Ok(x) => format!("0x{:016x}", x.to_bits()),
        Err(LaError::NonFinite {
            location: NonFiniteLocation::MatrixCell { row, col, .. },
            origin:
                NonFiniteOrigin::Computation {
                    operation: ArithmeticOperation::MatrixInfinityNorm,
                    ..
                },
            ..
        }) => format!("overflow:r{row}:c{col}"),
        Err(error) => panic!("unexpected error: {error:?}"),
    }
}

fn assess<const D: usize>(label: &str, rows: [[f64; D]; D]) -> (bool, bool) {
    let matrix = Matrix::try_from_rows(black_box(rows)).unwrap();
    let exact = oracle(&matrix);
    let strict = matrix.norm_inf();
    let candidate = algebraic_norm(black_box(&matrix));
    let same_class = strict.is_ok() == candidate.is_ok();
    let same_bits = match (&strict, &candidate) {
        (Ok(a), Ok(b)) => a.to_bits() == b.to_bits(),
        (Err(a), Err(b)) => a == b,
        _ => false,
    };
    let relative = |result: &Result<f64, LaError>| match result {
        Ok(value) if !exact.is_zero() => ((rational(*value) - &exact).abs() / &exact)
            .to_f64()
            .unwrap(),
        Ok(_) => 0.0,
        Err(_) => f64::INFINITY,
    };
    // Every explicit case is retained; random successes are summarized separately.
    if !label.starts_with("random") || !same_class || !same_bits {
        println!(
            "{D},{label},{},{},{same_class},{same_bits},{:.17e},{:.17e}",
            result_text(&strict),
            result_text(&candidate),
            relative(&strict),
            relative(&candidate)
        );
    }
    (same_class, same_bits)
}

fn check_dimension<const D: usize>() {
    assess("shared", *shared::<D>().as_rows());
    assess("integer", *integer::<D>().as_rows());
    for (name, values) in [
        ("signed_zero", vec![-0.0]),
        ("minimum_subnormal", vec![f64::from_bits(1)]),
        ("minimum_normal", vec![f64::MIN_POSITIVE]),
        (
            "mixed_magnitudes",
            vec![2.0_f64.powi(53), 1.0, -1.0, 1.0, -1.0],
        ),
        (
            "range_large_first",
            vec![f64::MAX, 2.0_f64.powi(969), 2.0_f64.powi(969), 0.0, 0.0],
        ),
        (
            "range_small_first",
            vec![2.0_f64.powi(969), 2.0_f64.powi(969), f64::MAX, 0.0, 0.0],
        ),
        ("definite_overflow", vec![f64::MAX, f64::MAX]),
        (
            "wide_range",
            vec![
                -f64::MIN_POSITIVE,
                f64::from_bits(1),
                -2.0_f64.powi(900),
                2.0_f64.powi(-900),
            ],
        ),
    ] {
        let rows: [[f64; D]; D] =
            std::array::from_fn(|_| std::array::from_fn(|c| values[c % values.len()]));
        assess(name, rows);
    }
    if D > 0 {
        for exponent in 968..=971 {
            for position in 0..D {
                let row = std::array::from_fn(|c| {
                    if c == position {
                        f64::MAX
                    } else {
                        2.0_f64.powi(exponent)
                    }
                });
                assess(&format!("range-e{exponent}-max-at-{position}"), [row; D]);
            }
        }
        for value in [f64::NAN, f64::INFINITY, f64::NEG_INFINITY] {
            let mut rows = [[0.0; D]; D];
            rows[D - 1][D - 1] = value;
            assert!(
                matches!(Matrix::try_from_rows(rows), Err(LaError::NonFinite {
                location: NonFiniteLocation::MatrixCell { row, col, .. },
                origin: NonFiniteOrigin::Input, ..
            }) if row == D - 1 && col == D - 1)
            );
        }
    }
    let mut state = 250_u64;
    let mut class_changes = 0;
    let mut value_changes = 0;
    for case in 0..1000 {
        let rows: [[f64; D]; D] = std::array::from_fn(|_| {
            std::array::from_fn(|_| {
                state ^= state << 13;
                state ^= state >> 7;
                state ^= state << 17;
                // Include all finite exponents, subnormals, signs and mantissas.
                f64::from_bits((state & !(0x7ff_u64 << 52)) | (((state >> 32) % 2047) << 52))
            })
        });
        let (same_class, same_bits) = assess(&format!("random-{case}"), rows);
        class_changes += usize::from(!same_class);
        value_changes += usize::from(!same_bits);
    }
    eprintln!(
        "D={D}: 1000 random matrices; {class_changes} classification changes, {value_changes} bit/error changes; raw nonfinite rejection checked"
    );
}

fn validated<const D: usize>(matrix: &Matrix<D>) {
    let exact = oracle(matrix);
    // Independent strict-summation envelope, an empirical gate, not an algebraic guarantee.
    let n_u = rational(D as f64 * f64::EPSILON / 2.0);
    let gamma = &n_u / (rational(1.0) - &n_u);
    for result in [matrix.norm_inf(), algebraic_norm(black_box(matrix))] {
        let value = result.expect("timed fixtures must have finite results");
        assert!((rational(value) - &exact).abs() <= &gamma * &exact);
    }
}

fn bench_dimension<const D: usize>(criterion: &mut Criterion, variant: &str) {
    let mut group = criterion.benchmark_group(format!("norm_inf_d{D}"));
    for (name, matrix) in [("shared", shared::<D>()), ("integer", integer::<D>())] {
        validated(&matrix);
        // Dispatch outside timing; measure the complete Result-producing operation.
        if variant == "algebraic" {
            group.bench_function(name, |b| b.iter(|| algebraic_norm(black_box(&matrix))));
        } else {
            group.bench_function(name, |b| b.iter(|| black_box(&matrix).norm_inf()));
        }
    }
    group.finish();
}

fn main() {
    if std::env::args().nth(1).as_deref() == Some("check") {
        println!(
            "dimension,case,strict,algebraic,same_class,same_bits,strict_relative_error,algebraic_relative_error"
        );
        check_dimension::<0>();
        check_dimension::<1>();
        check_dimension::<2>();
        check_dimension::<3>();
        check_dimension::<4>();
        check_dimension::<5>();
        check_dimension::<8>();
        check_dimension::<16>();
    } else {
        let variant = std::env::var("STUDY_VARIANT").expect("STUDY_VARIANT=strict or algebraic");
        assert!(variant == "strict" || variant == "algebraic");
        let mut criterion = Criterion::default()
            .sample_size(100)
            .warm_up_time(Duration::from_secs(1))
            .measurement_time(Duration::from_secs(3))
            .confidence_level(0.95)
            .configure_from_args();
        bench_dimension::<2>(&mut criterion, &variant);
        bench_dimension::<3>(&mut criterion, &variant);
        bench_dimension::<4>(&mut criterion, &variant);
        bench_dimension::<5>(&mut criterion, &variant);
        bench_dimension::<8>(&mut criterion, &variant);
        criterion.final_summary();
    }
}
