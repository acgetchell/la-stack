#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

# Compile and validate before measuring. Do not run validation/build jobs in parallel.
cargo +1.99.0 build --release --locked --offline
target/release/algebraic-norm-study check >evidence/numerical.csv 2>evidence/numerical-summary.txt

for phase in forward reverse; do
    export CRITERION_HOME="$PWD/evidence/$phase"
    if [[ "$phase" == forward ]]; then
        variants=(strict algebraic)
    else
        variants=(algebraic strict)
    fi
    for variant in "${variants[@]}"; do
        STUDY_VARIANT="$variant" target/release/algebraic-norm-study \
            --bench --noplot --save-baseline "$variant" \
            >"evidence/$phase-$variant.log" 2>&1
    done
done
