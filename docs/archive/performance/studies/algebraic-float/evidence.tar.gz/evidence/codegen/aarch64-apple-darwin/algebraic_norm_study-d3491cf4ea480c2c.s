	.build_version macos, 11, 0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__RNvCs8KrBXEn51CD_20algebraic_norm_study12algebraic_d4
	.p2align	2
__RNvCs8KrBXEn51CD_20algebraic_norm_study12algebraic_d4:
	.cfi_startproc
	mov	x1, x0
	ldp	d0, d1, [x0]
	fabs	d0, d0
	fabs	d1, d1
	fadd	d0, d1, d0
	ldp	d1, d2, [x0, #16]
	fabs	d1, d1
	fabs	d2, d2
	fadd	d1, d1, d2
	fadd	d0, d0, d1
	fmov	x9, d0
	ubfx	x9, x9, #52, #11
	cmp	x9, #2047
	b.hs	LBB0_4
	ldp	d1, d2, [x1, #32]
	fabs	d1, d1
	fabs	d2, d2
	fadd	d1, d2, d1
	ldp	d2, d3, [x1, #48]
	fabs	d2, d2
	fabs	d3, d3
	fadd	d2, d2, d3
	fadd	d1, d1, d2
	fmov	x9, d1
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB0_4
	ldp	d2, d3, [x1, #64]
	fabs	d2, d2
	fabs	d3, d3
	fadd	d2, d3, d2
	ldp	d3, d4, [x1, #80]
	fabs	d3, d3
	fabs	d4, d4
	fadd	d3, d3, d4
	fadd	d2, d2, d3
	fmov	x9, d2
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB0_4
	ldp	d3, d4, [x1, #96]
	fabs	d3, d3
	fabs	d4, d4
	fadd	d3, d4, d3
	ldp	d4, d5, [x1, #112]
	fabs	d4, d4
	fabs	d5, d5
	fadd	d4, d4, d5
	fadd	d3, d3, d4
	fmov	x9, d3
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.ls	LBB0_5
LBB0_4:
	mov	x0, x8
	b	__RNvMs2_NtCsitGMdM2ysxe_8la_stack6matrixINtB5_6MatrixKj4_E8norm_infCs8KrBXEn51CD_20algebraic_norm_study
LBB0_5:
	fcmp	d0, #0.0
	movi.2d	v4, #0000000000000000
	fcsel	d0, d0, d4, gt
	fcmp	d1, d0
	fcsel	d0, d1, d0, gt
	fcmp	d2, d0
	fcsel	d0, d2, d0, gt
	fcmp	d3, d0
	fcsel	d0, d3, d0, gt
	str	d0, [x8, #8]
	mov	w9, #255
	strb	w9, [x8]
	ret
	.cfi_endproc

	.globl	__RNvCs8KrBXEn51CD_20algebraic_norm_study12algebraic_d5
	.p2align	2
__RNvCs8KrBXEn51CD_20algebraic_norm_study12algebraic_d5:
	.cfi_startproc
	mov	x1, x0
	ldp	d0, d1, [x0]
	fabs	d0, d0
	fabs	d1, d1
	fadd	d0, d1, d0
	ldp	d1, d2, [x0, #16]
	fabs	d1, d1
	fabs	d2, d2
	fadd	d1, d1, d2
	fadd	d0, d0, d1
	ldr	d1, [x0, #32]
	fabs	d1, d1
	fadd	d0, d0, d1
	fmov	x9, d0
	ubfx	x9, x9, #52, #11
	cmp	x9, #2047
	b.hs	LBB1_5
	ldp	d1, d2, [x1, #40]
	fabs	d1, d1
	fabs	d2, d2
	fadd	d1, d2, d1
	ldp	d2, d3, [x1, #56]
	fabs	d2, d2
	fabs	d3, d3
	fadd	d2, d2, d3
	fadd	d1, d1, d2
	ldr	d2, [x1, #72]
	fabs	d2, d2
	fadd	d1, d1, d2
	fmov	x9, d1
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB1_5
	ldp	d2, d3, [x1, #80]
	fabs	d2, d2
	fabs	d3, d3
	fadd	d2, d3, d2
	ldp	d3, d4, [x1, #96]
	fabs	d3, d3
	fabs	d4, d4
	fadd	d3, d3, d4
	fadd	d2, d2, d3
	ldr	d3, [x1, #112]
	fabs	d3, d3
	fadd	d2, d2, d3
	fmov	x9, d2
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB1_5
	ldp	d3, d4, [x1, #120]
	fabs	d3, d3
	fabs	d4, d4
	fadd	d3, d4, d3
	ldp	d4, d5, [x1, #136]
	fabs	d4, d4
	fabs	d5, d5
	fadd	d4, d4, d5
	fadd	d3, d3, d4
	ldr	d4, [x1, #152]
	fabs	d4, d4
	fadd	d3, d3, d4
	fmov	x9, d3
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB1_5
	ldp	d4, d5, [x1, #160]
	fabs	d4, d4
	fabs	d5, d5
	fadd	d4, d5, d4
	ldp	d5, d6, [x1, #176]
	fabs	d5, d5
	fabs	d6, d6
	fadd	d5, d5, d6
	fadd	d4, d4, d5
	ldr	d5, [x1, #192]
	fabs	d5, d5
	fadd	d4, d4, d5
	fmov	x9, d4
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.ls	LBB1_6
LBB1_5:
	mov	x0, x8
	b	__RNvMs2_NtCsitGMdM2ysxe_8la_stack6matrixINtB5_6MatrixKj5_E8norm_infCs8KrBXEn51CD_20algebraic_norm_study
LBB1_6:
	fcmp	d0, #0.0
	movi.2d	v5, #0000000000000000
	fcsel	d0, d0, d5, gt
	fcmp	d1, d0
	fcsel	d0, d1, d0, gt
	fcmp	d2, d0
	fcsel	d0, d2, d0, gt
	fcmp	d3, d0
	fcsel	d0, d3, d0, gt
	fcmp	d4, d0
	fcsel	d0, d4, d0, gt
	str	d0, [x8, #8]
	mov	w9, #255
	strb	w9, [x8]
	ret
	.cfi_endproc

	.globl	__RNvCs8KrBXEn51CD_20algebraic_norm_study9strict_d4
	.p2align	2
__RNvCs8KrBXEn51CD_20algebraic_norm_study9strict_d4:
	.cfi_startproc
	mov	x1, x0
	mov	x0, x8
	b	__RNvMs2_NtCsitGMdM2ysxe_8la_stack6matrixINtB5_6MatrixKj4_E8norm_infCs8KrBXEn51CD_20algebraic_norm_study
	.cfi_endproc

	.globl	__RNvCs8KrBXEn51CD_20algebraic_norm_study9strict_d5
	.p2align	2
__RNvCs8KrBXEn51CD_20algebraic_norm_study9strict_d5:
	.cfi_startproc
	mov	x1, x0
	mov	x0, x8
	b	__RNvMs2_NtCsitGMdM2ysxe_8la_stack6matrixINtB5_6MatrixKj5_E8norm_infCs8KrBXEn51CD_20algebraic_norm_study
	.cfi_endproc

	.p2align	2
__RNvMs2_NtCsitGMdM2ysxe_8la_stack6matrixINtB5_6MatrixKj4_E8norm_infCs8KrBXEn51CD_20algebraic_norm_study:
	.cfi_startproc
	ldp	d0, d1, [x1]
	fabs	d0, d0
	fabs	d1, d1
	fadd	d1, d0, d1
	ldp	d2, d3, [x1, #16]
	fabs	d2, d2
	fadd	d1, d1, d2
	fabs	d2, d3
	fadd	d1, d1, d2
	fmov	x8, d1
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.hi	LBB4_5
	mov	x9, x1
	ldp	d0, d2, [x9, #32]!
	fabs	d0, d0
	ldr	d3, [x9, #16]
	fabs	d2, d2
	fadd	d2, d0, d2
	fabs	d3, d3
	fadd	d2, d2, d3
	ldr	d3, [x9, #24]
	fabs	d3, d3
	fadd	d2, d2, d3
	fmov	x8, d2
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.hi	LBB4_6
	mov	x9, x1
	ldp	d0, d3, [x9, #64]!
	fabs	d0, d0
	ldr	d4, [x9, #16]
	fabs	d3, d3
	fadd	d3, d0, d3
	fabs	d4, d4
	fadd	d3, d3, d4
	ldr	d4, [x9, #24]
	fabs	d4, d4
	fadd	d3, d3, d4
	fmov	x8, d3
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.hi	LBB4_7
	ldp	d0, d4, [x1, #96]!
	fabs	d0, d0
	ldr	d5, [x1, #16]
	fabs	d4, d4
	fadd	d4, d0, d4
	fabs	d5, d5
	fadd	d4, d4, d5
	ldr	d5, [x1, #24]
	fabs	d5, d5
	fadd	d4, d4, d5
	fmov	x8, d4
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.hi	LBB4_8
	fcmp	d1, #0.0
	movi.2d	v0, #0000000000000000
	fcsel	d0, d1, d0, gt
	fcmp	d2, d0
	fcsel	d0, d2, d0, gt
	fcmp	d3, d0
	fcsel	d0, d3, d0, gt
	fcmp	d4, d0
	fcsel	d0, d4, d0, gt
	str	d0, [x0, #8]
	mov	w8, #255
	strb	w8, [x0]
	ret
LBB4_5:
	mov	x8, #0
	b	LBB4_9
LBB4_6:
	mov	w8, #1
	mov	x1, x9
	b	LBB4_9
LBB4_7:
	mov	w8, #2
	mov	x1, x9
	b	LBB4_9
LBB4_8:
	mov	w8, #3
LBB4_9:
	mov	x9, #0
	mov	x10, #9218868437227405312
	fmov	d1, x10
	fcmp	d0, d1
	b.eq	LBB4_15
	b.vs	LBB4_15
	ldr	d1, [x1, #8]
	fabs	d1, d1
	fadd	d0, d0, d1
	fmov	x9, d0
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.ls	LBB4_12
	mov	w9, #1
	mov	w10, #4
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x8, x9, [x0, #16]
	ret
LBB4_12:
	ldr	d1, [x1, #16]
	fabs	d1, d1
	fadd	d0, d0, d1
	fmov	x9, d0
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.ls	LBB4_14
	mov	w9, #2
	mov	w10, #4
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x8, x9, [x0, #16]
	ret
LBB4_14:
	mov	w9, #3
LBB4_15:
	mov	w10, #4
	strh	w10, [x0]
	strb	wzr, [x0, #8]
	stp	x8, x9, [x0, #16]
	ret
	.cfi_endproc

	.p2align	2
__RNvMs2_NtCsitGMdM2ysxe_8la_stack6matrixINtB5_6MatrixKj5_E23norm_inf_overflow_errorCs8KrBXEn51CD_20algebraic_norm_study:
	.cfi_startproc
	ldr	d0, [x1]
	fmov	x8, d0
	ubfx	x8, x8, #52, #11
	cmp	x8, #2047
	b.lo	LBB5_2
	mov	x8, #0
	strb	wzr, [x0, #8]
	stp	x2, x8, [x0, #16]
	mov	w8, #4
	strh	w8, [x0]
	ret
LBB5_2:
	fabs	d0, d0
	ldr	d1, [x1, #8]
	fabs	d1, d1
	fadd	d0, d0, d1
	fmov	x8, d0
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB5_4
	mov	w8, #1
	strb	wzr, [x0, #8]
	stp	x2, x8, [x0, #16]
	mov	w8, #4
	strh	w8, [x0]
	ret
LBB5_4:
	ldr	d1, [x1, #16]
	fabs	d1, d1
	fadd	d0, d0, d1
	fmov	x8, d0
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB5_6
	mov	w8, #2
	strb	wzr, [x0, #8]
	stp	x2, x8, [x0, #16]
	mov	w8, #4
	strh	w8, [x0]
	ret
LBB5_6:
	ldr	d1, [x1, #24]
	fabs	d1, d1
	fadd	d0, d0, d1
	fmov	x8, d0
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.ls	LBB5_8
	mov	w8, #3
	strb	wzr, [x0, #8]
	stp	x2, x8, [x0, #16]
	mov	w8, #4
	strh	w8, [x0]
	ret
LBB5_8:
	mov	w8, #4
	strb	wzr, [x0, #8]
	stp	x2, x8, [x0, #16]
	mov	w8, #4
	strh	w8, [x0]
	ret
	.cfi_endproc

	.p2align	2
__RNvMs2_NtCsitGMdM2ysxe_8la_stack6matrixINtB5_6MatrixKj5_E8norm_infCs8KrBXEn51CD_20algebraic_norm_study:
	.cfi_startproc
	ldp	d0, d1, [x1]
	fabs	d0, d0
	fabs	d1, d1
	fadd	d0, d0, d1
	ldp	d1, d2, [x1, #16]
	fabs	d1, d1
	fadd	d0, d0, d1
	fabs	d1, d2
	fadd	d0, d0, d1
	ldr	d1, [x1, #32]
	fabs	d1, d1
	fadd	d0, d0, d1
	fmov	x8, d0
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.hi	LBB6_6
	mov	x8, x1
	ldp	d1, d2, [x8, #40]!
	fabs	d1, d1
	ldr	d3, [x8, #16]
	fabs	d2, d2
	fadd	d1, d1, d2
	fabs	d2, d3
	fadd	d1, d1, d2
	ldp	d2, d3, [x8, #24]
	fabs	d2, d2
	fadd	d1, d1, d2
	fabs	d2, d3
	fadd	d1, d1, d2
	fmov	x9, d1
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB6_7
	mov	x8, x1
	ldp	d2, d3, [x8, #80]!
	fabs	d2, d2
	ldr	d4, [x8, #16]
	fabs	d3, d3
	fadd	d2, d2, d3
	fabs	d3, d4
	fadd	d2, d2, d3
	ldp	d3, d4, [x8, #24]
	fabs	d3, d3
	fadd	d2, d2, d3
	fabs	d3, d4
	fadd	d2, d2, d3
	fmov	x9, d2
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB6_8
	mov	x8, x1
	ldp	d3, d4, [x8, #120]!
	fabs	d3, d3
	ldr	d5, [x8, #16]
	fabs	d4, d4
	fadd	d3, d3, d4
	fabs	d4, d5
	fadd	d3, d3, d4
	ldp	d4, d5, [x8, #24]
	fabs	d4, d4
	fadd	d3, d3, d4
	fabs	d4, d5
	fadd	d3, d3, d4
	fmov	x9, d3
	ubfx	x9, x9, #52, #11
	cmp	x9, #2046
	b.hi	LBB6_9
	ldp	d4, d5, [x1, #160]!
	fabs	d4, d4
	ldr	d6, [x1, #16]
	fabs	d5, d5
	fadd	d4, d4, d5
	fabs	d5, d6
	fadd	d4, d4, d5
	ldp	d5, d6, [x1, #24]
	fabs	d5, d5
	fadd	d4, d4, d5
	fabs	d5, d6
	fadd	d4, d4, d5
	fmov	x8, d4
	ubfx	x8, x8, #52, #11
	cmp	x8, #2046
	b.hi	LBB6_10
	fcmp	d0, #0.0
	movi.2d	v5, #0000000000000000
	fcsel	d0, d0, d5, gt
	fcmp	d1, d0
	fcsel	d0, d1, d0, gt
	fcmp	d2, d0
	fcsel	d0, d2, d0, gt
	fcmp	d3, d0
	fcsel	d0, d3, d0, gt
	fcmp	d4, d0
	fcsel	d0, d4, d0, gt
	str	d0, [x0, #8]
	mov	w8, #255
	strb	w8, [x0]
	ret
LBB6_6:
	mov	x2, #0
	b	LBB6_11
LBB6_7:
	mov	w2, #1
	mov	x1, x8
	b	LBB6_11
LBB6_8:
	mov	w2, #2
	mov	x1, x8
	b	LBB6_11
LBB6_9:
	mov	w2, #3
	mov	x1, x8
	b	LBB6_11
LBB6_10:
	mov	w2, #4
LBB6_11:
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	__RNvMs2_NtCsitGMdM2ysxe_8la_stack6matrixINtB5_6MatrixKj5_E23norm_inf_overflow_errorCs8KrBXEn51CD_20algebraic_norm_study
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.cfi_endproc

.subsections_via_symbols
