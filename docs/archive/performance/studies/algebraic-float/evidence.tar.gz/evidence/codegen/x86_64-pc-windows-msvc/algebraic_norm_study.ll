; ModuleID = 'algebraic_norm_study.54c96358e94492a9-cgu.0'
source_filename = "algebraic_norm_study.54c96358e94492a9-cgu.0"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc"

; algebraic_norm_study::algebraic_d4
; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable
define void @_RNvCs7hjGl8LVxbh_20algebraic_norm_study12algebraic_d4(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([56 x i8]) align 8 captures(none) dereferenceable(56) initializes((0, 1), (8, 9)) %_0, ptr noalias nofree noundef readonly align 8 captures(none) dereferenceable(128) %matrix) unnamed_addr #0 !guid !3 {
start:
  tail call void @llvm.experimental.noalias.scope.decl(metadata !4)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  %_12.i = load double, ptr %matrix, align 8, !alias.scope !7, !noalias !4, !noundef !9
  %_11.i = tail call double @llvm.fabs.f64(double %_12.i)
  %0 = getelementptr inbounds nuw i8, ptr %matrix, i64 8
  %_12.1.i = load double, ptr %0, align 8, !alias.scope !7, !noalias !4, !noundef !9
  %_11.1.i = tail call double @llvm.fabs.f64(double %_12.1.i)
  %_10.1.i = fadd reassoc nsz arcp contract double %_11.1.i, %_11.i
  %1 = getelementptr inbounds nuw i8, ptr %matrix, i64 16
  %_12.2.i = load double, ptr %1, align 8, !alias.scope !7, !noalias !4, !noundef !9
  %_11.2.i = tail call double @llvm.fabs.f64(double %_12.2.i)
  %_10.2.i = fadd reassoc nsz arcp contract double %_10.1.i, %_11.2.i
  %2 = getelementptr inbounds nuw i8, ptr %matrix, i64 24
  %_12.3.i = load double, ptr %2, align 8, !alias.scope !7, !noalias !4, !noundef !9
  %_11.3.i = tail call double @llvm.fabs.f64(double %_12.3.i)
  %_10.3.i = fadd reassoc nsz arcp contract double %_10.2.i, %_11.3.i
  %_22.i = tail call double @llvm.fabs.f64(double %_10.3.i)
  %_17.i = fcmp ueq double %_22.i, +inf
  br i1 %_17.i, label %bb9.i, label %bb8.i

bb9.i:                                            ; preds = %bb8.2.i, %bb8.1.i, %bb8.i, %start
; call <la_stack::matrix::Matrix<4>>::norm_inf
  tail call fastcc void @_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj4_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study(ptr noalias nofree noundef nonnull align 8 captures(none) dereferenceable(56) %_0, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(128) %matrix) #6, !alias.scope !10
  br label %_RINvCs7hjGl8LVxbh_20algebraic_norm_study14algebraic_normKj4_EB2_.exit

bb8.i:                                            ; preds = %start
  %3 = getelementptr inbounds nuw i8, ptr %matrix, i64 32
  %_12.112.i = load double, ptr %3, align 8, !alias.scope !7, !noalias !4, !noundef !9
  %_11.113.i = tail call double @llvm.fabs.f64(double %_12.112.i)
  %4 = getelementptr inbounds nuw i8, ptr %matrix, i64 40
  %_12.1.1.i = load double, ptr %4, align 8, !alias.scope !7, !noalias !4, !noundef !9
  %_11.1.1.i = tail call double @llvm.fabs.f64(double %_12.1.1.i)
  %_10.1.1.i = fadd reassoc nsz arcp contract double %_11.1.1.i, %_11.113.i
  %5 = getelementptr inbounds nuw i8, ptr %matrix, i64 48
  %_12.2.1.i = load double, ptr %5, align 8, !alias.scope !7, !noalias !4, !noundef !9
  %_11.2.1.i = tail call double @llvm.fabs.f64(double %_12.2.1.i)
  %_10.2.1.i = fadd reassoc nsz arcp contract double %_10.1.1.i, %_11.2.1.i
  %6 = getelementptr inbounds nuw i8, ptr %matrix, i64 56
  %_12.3.1.i = load double, ptr %6, align 8, !alias.scope !7, !noalias !4, !noundef !9
  %_11.3.1.i = tail call double @llvm.fabs.f64(double %_12.3.1.i)
  %_10.3.1.i = fadd reassoc nsz arcp contract double %_10.2.1.i, %_11.3.1.i
  %_22.1.i = tail call double @llvm.fabs.f64(double %_10.3.1.i)
  %_17.1.i = fcmp ueq double %_22.1.i, +inf
  br i1 %_17.1.i, label %bb9.i, label %bb8.1.i

bb8.1.i:                                          ; preds = %bb8.i
  %7 = getelementptr inbounds nuw i8, ptr %matrix, i64 64
  %_12.214.i = load double, ptr %7, align 8, !alias.scope !7, !noalias !4, !noundef !9
  %_11.215.i = tail call double @llvm.fabs.f64(double %_12.214.i)
  %8 = getelementptr inbounds nuw i8, ptr %matrix, i64 72
  %_12.1.2.i = load double, ptr %8, align 8, !alias.scope !7, !noalias !4, !noundef !9
  %_11.1.2.i = tail call double @llvm.fabs.f64(double %_12.1.2.i)
  %_10.1.2.i = fadd reassoc nsz arcp contract double %_11.1.2.i, %_11.215.i
  %9 = getelementptr inbounds nuw i8, ptr %matrix, i64 80
  %_12.2.2.i = load double, ptr %9, align 8, !alias.scope !7, !noalias !4, !noundef !9
  %_11.2.2.i = tail call double @llvm.fabs.f64(double %_12.2.2.i)
  %_10.2.2.i = fadd reassoc nsz arcp contract double %_10.1.2.i, %_11.2.2.i
  %10 = getelementptr inbounds nuw i8, ptr %matrix, i64 88
  %_12.3.2.i = load double, ptr %10, align 8, !alias.scope !7, !noalias !4, !noundef !9
  %_11.3.2.i = tail call double @llvm.fabs.f64(double %_12.3.2.i)
  %_10.3.2.i = fadd reassoc nsz arcp contract double %_10.2.2.i, %_11.3.2.i
  %_22.2.i = tail call double @llvm.fabs.f64(double %_10.3.2.i)
  %_17.2.i = fcmp ueq double %_22.2.i, +inf
  br i1 %_17.2.i, label %bb9.i, label %bb8.2.i

bb8.2.i:                                          ; preds = %bb8.1.i
  %11 = getelementptr inbounds nuw i8, ptr %matrix, i64 96
  %_12.316.i = load double, ptr %11, align 8, !alias.scope !7, !noalias !4, !noundef !9
  %_11.317.i = tail call double @llvm.fabs.f64(double %_12.316.i)
  %12 = getelementptr inbounds nuw i8, ptr %matrix, i64 104
  %_12.1.3.i = load double, ptr %12, align 8, !alias.scope !7, !noalias !4, !noundef !9
  %_11.1.3.i = tail call double @llvm.fabs.f64(double %_12.1.3.i)
  %_10.1.3.i = fadd reassoc nsz arcp contract double %_11.1.3.i, %_11.317.i
  %13 = getelementptr inbounds nuw i8, ptr %matrix, i64 112
  %_12.2.3.i = load double, ptr %13, align 8, !alias.scope !7, !noalias !4, !noundef !9
  %_11.2.3.i = tail call double @llvm.fabs.f64(double %_12.2.3.i)
  %_10.2.3.i = fadd reassoc nsz arcp contract double %_10.1.3.i, %_11.2.3.i
  %14 = getelementptr inbounds nuw i8, ptr %matrix, i64 120
  %_12.3.3.i = load double, ptr %14, align 8, !alias.scope !7, !noalias !4, !noundef !9
  %_11.3.3.i = tail call double @llvm.fabs.f64(double %_12.3.3.i)
  %_10.3.3.i = fadd reassoc nsz arcp contract double %_10.2.3.i, %_11.3.3.i
  %_22.3.i = tail call double @llvm.fabs.f64(double %_10.3.3.i)
  %_17.3.i = fcmp ueq double %_22.3.i, +inf
  br i1 %_17.3.i, label %bb9.i, label %bb8.3.i

bb8.3.i:                                          ; preds = %bb8.2.i
  %_19.i = fcmp ogt double %_10.3.i, 0.000000e+00
  %maximum.sroa.0.1.i = select i1 %_19.i, double %_10.3.i, double 0.000000e+00
  %_19.1.i = fcmp ogt double %_10.3.1.i, %maximum.sroa.0.1.i
  %maximum.sroa.0.1.1.i = select i1 %_19.1.i, double %_10.3.1.i, double %maximum.sroa.0.1.i
  %_19.2.i = fcmp ogt double %_10.3.2.i, %maximum.sroa.0.1.1.i
  %maximum.sroa.0.1.2.i = select i1 %_19.2.i, double %_10.3.2.i, double %maximum.sroa.0.1.1.i
  %_19.3.i = fcmp ogt double %_10.3.3.i, %maximum.sroa.0.1.2.i
  %maximum.sroa.0.1.3.i = select i1 %_19.3.i, double %_10.3.3.i, double %maximum.sroa.0.1.2.i
  %15 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store double %maximum.sroa.0.1.3.i, ptr %15, align 8, !alias.scope !4, !noalias !7
  store i8 -1, ptr %_0, align 8, !alias.scope !4, !noalias !7
  br label %_RINvCs7hjGl8LVxbh_20algebraic_norm_study14algebraic_normKj4_EB2_.exit

_RINvCs7hjGl8LVxbh_20algebraic_norm_study14algebraic_normKj4_EB2_.exit: ; preds = %bb9.i, %bb8.3.i
  ret void
}

; algebraic_norm_study::algebraic_d5
; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable
define void @_RNvCs7hjGl8LVxbh_20algebraic_norm_study12algebraic_d5(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([56 x i8]) align 8 captures(none) dereferenceable(56) initializes((0, 1), (8, 9)) %_0, ptr noalias nofree noundef readonly align 8 captures(none) dereferenceable(200) %matrix) unnamed_addr #0 !guid !11 {
start:
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  %_12.i = load double, ptr %matrix, align 8, !alias.scope !15, !noalias !12, !noundef !9
  %_11.i = tail call double @llvm.fabs.f64(double %_12.i)
  %0 = getelementptr inbounds nuw i8, ptr %matrix, i64 8
  %_12.1.i = load double, ptr %0, align 8, !alias.scope !15, !noalias !12, !noundef !9
  %_11.1.i = tail call double @llvm.fabs.f64(double %_12.1.i)
  %_10.1.i = fadd reassoc nsz arcp contract double %_11.1.i, %_11.i
  %1 = getelementptr inbounds nuw i8, ptr %matrix, i64 16
  %_12.2.i = load double, ptr %1, align 8, !alias.scope !15, !noalias !12, !noundef !9
  %_11.2.i = tail call double @llvm.fabs.f64(double %_12.2.i)
  %_10.2.i = fadd reassoc nsz arcp contract double %_10.1.i, %_11.2.i
  %2 = getelementptr inbounds nuw i8, ptr %matrix, i64 24
  %_12.3.i = load double, ptr %2, align 8, !alias.scope !15, !noalias !12, !noundef !9
  %_11.3.i = tail call double @llvm.fabs.f64(double %_12.3.i)
  %_10.3.i = fadd reassoc nsz arcp contract double %_10.2.i, %_11.3.i
  %3 = getelementptr inbounds nuw i8, ptr %matrix, i64 32
  %_12.4.i = load double, ptr %3, align 8, !alias.scope !15, !noalias !12, !noundef !9
  %_11.4.i = tail call double @llvm.fabs.f64(double %_12.4.i)
  %_10.4.i = fadd reassoc nsz arcp contract double %_10.3.i, %_11.4.i
  %_22.i = tail call double @llvm.fabs.f64(double %_10.4.i)
  %_17.i = fcmp ueq double %_22.i, +inf
  br i1 %_17.i, label %bb9.i, label %bb8.i

bb9.i:                                            ; preds = %bb8.3.i, %bb8.2.i, %bb8.1.i, %bb8.i, %start
; call <la_stack::matrix::Matrix<5>>::norm_inf
  tail call fastcc void @_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj5_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study(ptr noalias nofree noundef nonnull align 8 captures(none) dereferenceable(56) %_0, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(200) %matrix) #6, !alias.scope !17
  br label %_RINvCs7hjGl8LVxbh_20algebraic_norm_study14algebraic_normKj5_EB2_.exit

bb8.i:                                            ; preds = %start
  %4 = getelementptr inbounds nuw i8, ptr %matrix, i64 40
  %_12.112.i = load double, ptr %4, align 8, !alias.scope !15, !noalias !12, !noundef !9
  %_11.113.i = tail call double @llvm.fabs.f64(double %_12.112.i)
  %5 = getelementptr inbounds nuw i8, ptr %matrix, i64 48
  %_12.1.1.i = load double, ptr %5, align 8, !alias.scope !15, !noalias !12, !noundef !9
  %_11.1.1.i = tail call double @llvm.fabs.f64(double %_12.1.1.i)
  %_10.1.1.i = fadd reassoc nsz arcp contract double %_11.1.1.i, %_11.113.i
  %6 = getelementptr inbounds nuw i8, ptr %matrix, i64 56
  %_12.2.1.i = load double, ptr %6, align 8, !alias.scope !15, !noalias !12, !noundef !9
  %_11.2.1.i = tail call double @llvm.fabs.f64(double %_12.2.1.i)
  %_10.2.1.i = fadd reassoc nsz arcp contract double %_10.1.1.i, %_11.2.1.i
  %7 = getelementptr inbounds nuw i8, ptr %matrix, i64 64
  %_12.3.1.i = load double, ptr %7, align 8, !alias.scope !15, !noalias !12, !noundef !9
  %_11.3.1.i = tail call double @llvm.fabs.f64(double %_12.3.1.i)
  %_10.3.1.i = fadd reassoc nsz arcp contract double %_10.2.1.i, %_11.3.1.i
  %8 = getelementptr inbounds nuw i8, ptr %matrix, i64 72
  %_12.4.1.i = load double, ptr %8, align 8, !alias.scope !15, !noalias !12, !noundef !9
  %_11.4.1.i = tail call double @llvm.fabs.f64(double %_12.4.1.i)
  %_10.4.1.i = fadd reassoc nsz arcp contract double %_10.3.1.i, %_11.4.1.i
  %_22.1.i = tail call double @llvm.fabs.f64(double %_10.4.1.i)
  %_17.1.i = fcmp ueq double %_22.1.i, +inf
  br i1 %_17.1.i, label %bb9.i, label %bb8.1.i

bb8.1.i:                                          ; preds = %bb8.i
  %9 = getelementptr inbounds nuw i8, ptr %matrix, i64 80
  %_12.214.i = load double, ptr %9, align 8, !alias.scope !15, !noalias !12, !noundef !9
  %_11.215.i = tail call double @llvm.fabs.f64(double %_12.214.i)
  %10 = getelementptr inbounds nuw i8, ptr %matrix, i64 88
  %_12.1.2.i = load double, ptr %10, align 8, !alias.scope !15, !noalias !12, !noundef !9
  %_11.1.2.i = tail call double @llvm.fabs.f64(double %_12.1.2.i)
  %_10.1.2.i = fadd reassoc nsz arcp contract double %_11.1.2.i, %_11.215.i
  %11 = getelementptr inbounds nuw i8, ptr %matrix, i64 96
  %_12.2.2.i = load double, ptr %11, align 8, !alias.scope !15, !noalias !12, !noundef !9
  %_11.2.2.i = tail call double @llvm.fabs.f64(double %_12.2.2.i)
  %_10.2.2.i = fadd reassoc nsz arcp contract double %_10.1.2.i, %_11.2.2.i
  %12 = getelementptr inbounds nuw i8, ptr %matrix, i64 104
  %_12.3.2.i = load double, ptr %12, align 8, !alias.scope !15, !noalias !12, !noundef !9
  %_11.3.2.i = tail call double @llvm.fabs.f64(double %_12.3.2.i)
  %_10.3.2.i = fadd reassoc nsz arcp contract double %_10.2.2.i, %_11.3.2.i
  %13 = getelementptr inbounds nuw i8, ptr %matrix, i64 112
  %_12.4.2.i = load double, ptr %13, align 8, !alias.scope !15, !noalias !12, !noundef !9
  %_11.4.2.i = tail call double @llvm.fabs.f64(double %_12.4.2.i)
  %_10.4.2.i = fadd reassoc nsz arcp contract double %_10.3.2.i, %_11.4.2.i
  %_22.2.i = tail call double @llvm.fabs.f64(double %_10.4.2.i)
  %_17.2.i = fcmp ueq double %_22.2.i, +inf
  br i1 %_17.2.i, label %bb9.i, label %bb8.2.i

bb8.2.i:                                          ; preds = %bb8.1.i
  %14 = getelementptr inbounds nuw i8, ptr %matrix, i64 120
  %_12.316.i = load double, ptr %14, align 8, !alias.scope !15, !noalias !12, !noundef !9
  %_11.317.i = tail call double @llvm.fabs.f64(double %_12.316.i)
  %15 = getelementptr inbounds nuw i8, ptr %matrix, i64 128
  %_12.1.3.i = load double, ptr %15, align 8, !alias.scope !15, !noalias !12, !noundef !9
  %_11.1.3.i = tail call double @llvm.fabs.f64(double %_12.1.3.i)
  %_10.1.3.i = fadd reassoc nsz arcp contract double %_11.1.3.i, %_11.317.i
  %16 = getelementptr inbounds nuw i8, ptr %matrix, i64 136
  %_12.2.3.i = load double, ptr %16, align 8, !alias.scope !15, !noalias !12, !noundef !9
  %_11.2.3.i = tail call double @llvm.fabs.f64(double %_12.2.3.i)
  %_10.2.3.i = fadd reassoc nsz arcp contract double %_10.1.3.i, %_11.2.3.i
  %17 = getelementptr inbounds nuw i8, ptr %matrix, i64 144
  %_12.3.3.i = load double, ptr %17, align 8, !alias.scope !15, !noalias !12, !noundef !9
  %_11.3.3.i = tail call double @llvm.fabs.f64(double %_12.3.3.i)
  %_10.3.3.i = fadd reassoc nsz arcp contract double %_10.2.3.i, %_11.3.3.i
  %18 = getelementptr inbounds nuw i8, ptr %matrix, i64 152
  %_12.4.3.i = load double, ptr %18, align 8, !alias.scope !15, !noalias !12, !noundef !9
  %_11.4.3.i = tail call double @llvm.fabs.f64(double %_12.4.3.i)
  %_10.4.3.i = fadd reassoc nsz arcp contract double %_10.3.3.i, %_11.4.3.i
  %_22.3.i = tail call double @llvm.fabs.f64(double %_10.4.3.i)
  %_17.3.i = fcmp ueq double %_22.3.i, +inf
  br i1 %_17.3.i, label %bb9.i, label %bb8.3.i

bb8.3.i:                                          ; preds = %bb8.2.i
  %19 = getelementptr inbounds nuw i8, ptr %matrix, i64 160
  %_12.418.i = load double, ptr %19, align 8, !alias.scope !15, !noalias !12, !noundef !9
  %_11.419.i = tail call double @llvm.fabs.f64(double %_12.418.i)
  %20 = getelementptr inbounds nuw i8, ptr %matrix, i64 168
  %_12.1.4.i = load double, ptr %20, align 8, !alias.scope !15, !noalias !12, !noundef !9
  %_11.1.4.i = tail call double @llvm.fabs.f64(double %_12.1.4.i)
  %_10.1.4.i = fadd reassoc nsz arcp contract double %_11.1.4.i, %_11.419.i
  %21 = getelementptr inbounds nuw i8, ptr %matrix, i64 176
  %_12.2.4.i = load double, ptr %21, align 8, !alias.scope !15, !noalias !12, !noundef !9
  %_11.2.4.i = tail call double @llvm.fabs.f64(double %_12.2.4.i)
  %_10.2.4.i = fadd reassoc nsz arcp contract double %_10.1.4.i, %_11.2.4.i
  %22 = getelementptr inbounds nuw i8, ptr %matrix, i64 184
  %_12.3.4.i = load double, ptr %22, align 8, !alias.scope !15, !noalias !12, !noundef !9
  %_11.3.4.i = tail call double @llvm.fabs.f64(double %_12.3.4.i)
  %_10.3.4.i = fadd reassoc nsz arcp contract double %_10.2.4.i, %_11.3.4.i
  %23 = getelementptr inbounds nuw i8, ptr %matrix, i64 192
  %_12.4.4.i = load double, ptr %23, align 8, !alias.scope !15, !noalias !12, !noundef !9
  %_11.4.4.i = tail call double @llvm.fabs.f64(double %_12.4.4.i)
  %_10.4.4.i = fadd reassoc nsz arcp contract double %_10.3.4.i, %_11.4.4.i
  %_22.4.i = tail call double @llvm.fabs.f64(double %_10.4.4.i)
  %_17.4.i = fcmp ueq double %_22.4.i, +inf
  br i1 %_17.4.i, label %bb9.i, label %bb8.4.i

bb8.4.i:                                          ; preds = %bb8.3.i
  %_19.i = fcmp ogt double %_10.4.i, 0.000000e+00
  %maximum.sroa.0.1.i = select i1 %_19.i, double %_10.4.i, double 0.000000e+00
  %_19.1.i = fcmp ogt double %_10.4.1.i, %maximum.sroa.0.1.i
  %maximum.sroa.0.1.1.i = select i1 %_19.1.i, double %_10.4.1.i, double %maximum.sroa.0.1.i
  %_19.2.i = fcmp ogt double %_10.4.2.i, %maximum.sroa.0.1.1.i
  %maximum.sroa.0.1.2.i = select i1 %_19.2.i, double %_10.4.2.i, double %maximum.sroa.0.1.1.i
  %_19.3.i = fcmp ogt double %_10.4.3.i, %maximum.sroa.0.1.2.i
  %maximum.sroa.0.1.3.i = select i1 %_19.3.i, double %_10.4.3.i, double %maximum.sroa.0.1.2.i
  %_19.4.i = fcmp ogt double %_10.4.4.i, %maximum.sroa.0.1.3.i
  %maximum.sroa.0.1.4.i = select i1 %_19.4.i, double %_10.4.4.i, double %maximum.sroa.0.1.3.i
  %24 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store double %maximum.sroa.0.1.4.i, ptr %24, align 8, !alias.scope !12, !noalias !15
  store i8 -1, ptr %_0, align 8, !alias.scope !12, !noalias !15
  br label %_RINvCs7hjGl8LVxbh_20algebraic_norm_study14algebraic_normKj5_EB2_.exit

_RINvCs7hjGl8LVxbh_20algebraic_norm_study14algebraic_normKj5_EB2_.exit: ; preds = %bb9.i, %bb8.4.i
  ret void
}

; algebraic_norm_study::strict_d4
; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(argmem: readwrite) uwtable
define void @_RNvCs7hjGl8LVxbh_20algebraic_norm_study9strict_d4(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([56 x i8]) align 8 captures(none) dereferenceable(56) initializes((0, 1), (8, 9)) %_0, ptr noalias nofree noundef readonly align 8 captures(none) dereferenceable(128) %matrix) unnamed_addr #1 !guid !18 {
start:
; call <la_stack::matrix::Matrix<4>>::norm_inf
  tail call fastcc void @_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj4_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study(ptr noalias nofree noundef align 8 captures(none) dereferenceable(56) %_0, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(128) %matrix) #6
  ret void
}

; algebraic_norm_study::strict_d5
; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(argmem: readwrite) uwtable
define void @_RNvCs7hjGl8LVxbh_20algebraic_norm_study9strict_d5(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([56 x i8]) align 8 captures(none) dereferenceable(56) initializes((0, 1), (8, 9)) %_0, ptr noalias nofree noundef readonly align 8 captures(none) dereferenceable(200) %matrix) unnamed_addr #1 !guid !19 {
start:
; call <la_stack::matrix::Matrix<5>>::norm_inf
  tail call fastcc void @_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj5_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study(ptr noalias nofree noundef align 8 captures(none) dereferenceable(56) %_0, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(200) %matrix) #6
  ret void
}

; <la_stack::matrix::Matrix<4>>::norm_inf
; Function Attrs: inlinehint mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite) uwtable
define internal fastcc void @_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj4_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study(ptr dead_on_unwind noalias nofree noundef nonnull writable writeonly align 8 captures(none) dereferenceable(56) initializes((0, 1), (8, 9)) %_0, ptr noalias nofree noundef nonnull readonly align 8 captures(none) dereferenceable(128) %self) unnamed_addr #2 !guid !20 {
start:
  %_14 = load double, ptr %self, align 8, !noundef !9
  %_13 = tail call double @llvm.fabs.f64(double %_14)
  %0 = getelementptr inbounds nuw i8, ptr %self, i64 8
  %_14.1 = load double, ptr %0, align 8, !noundef !9
  %_13.1 = tail call double @llvm.fabs.f64(double %_14.1)
  %1 = fadd double %_13, %_13.1
  %2 = getelementptr inbounds nuw i8, ptr %self, i64 16
  %_14.2 = load double, ptr %2, align 8, !noundef !9
  %_13.2 = tail call double @llvm.fabs.f64(double %_14.2)
  %3 = fadd double %1, %_13.2
  %4 = getelementptr inbounds nuw i8, ptr %self, i64 24
  %_14.3 = load double, ptr %4, align 8, !noundef !9
  %_13.3 = tail call double @llvm.fabs.f64(double %_14.3)
  %5 = fadd double %3, %_13.3
  %_24 = tail call double @llvm.fabs.f64(double %5)
  %_17 = fcmp ueq double %_24, +inf
  br i1 %_17, label %bb9, label %bb8, !prof !21

bb16:                                             ; preds = %_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj4_E23norm_inf_overflow_errorCs7hjGl8LVxbh_20algebraic_norm_study.exit, %bb8.3
  ret void

bb9:                                              ; preds = %bb8.2, %bb8.1, %bb8, %start
  %_8.i.pre-phi = phi double [ %_13.323, %bb8.2 ], [ %_13.221, %bb8.1 ], [ %_13.119, %bb8 ], [ %_13, %start ]
  %r.sroa.0.014.lcssa = phi i64 [ 3, %bb8.2 ], [ 2, %bb8.1 ], [ 1, %bb8 ], [ 0, %start ]
  %row.lcssa = phi ptr [ %row.3, %bb8.2 ], [ %row.2, %bb8.1 ], [ %row.1, %bb8 ], [ %self, %start ]
  %_12.i = fcmp ueq double %_8.i.pre-phi, +inf
  br i1 %_12.i, label %_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj4_E23norm_inf_overflow_errorCs7hjGl8LVxbh_20algebraic_norm_study.exit, label %bb4.i

bb4.i:                                            ; preds = %bb9
  %6 = getelementptr inbounds nuw i8, ptr %row.lcssa, i64 8
  %_9.1.i = load double, ptr %6, align 8, !alias.scope !22, !noalias !25, !noundef !9
  %_8.1.i = tail call double @llvm.fabs.f64(double %_9.1.i)
  %7 = fadd double %_8.i.pre-phi, %_8.1.i
  %_14.1.i = tail call double @llvm.fabs.f64(double %7)
  %_12.1.i = fcmp ueq double %_14.1.i, +inf
  br i1 %_12.1.i, label %_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj4_E23norm_inf_overflow_errorCs7hjGl8LVxbh_20algebraic_norm_study.exit, label %bb4.1.i

bb4.1.i:                                          ; preds = %bb4.i
  %8 = getelementptr inbounds nuw i8, ptr %row.lcssa, i64 16
  %_9.2.i = load double, ptr %8, align 8, !alias.scope !22, !noalias !25, !noundef !9
  %_8.2.i = tail call double @llvm.fabs.f64(double %_9.2.i)
  %9 = fadd double %7, %_8.2.i
  %_14.2.i = tail call double @llvm.fabs.f64(double %9)
  %_12.2.i = fcmp ueq double %_14.2.i, +inf
  br i1 %_12.2.i, label %_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj4_E23norm_inf_overflow_errorCs7hjGl8LVxbh_20algebraic_norm_study.exit, label %bb4.2.i

bb4.2.i:                                          ; preds = %bb4.1.i
  br label %_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj4_E23norm_inf_overflow_errorCs7hjGl8LVxbh_20algebraic_norm_study.exit

_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj4_E23norm_inf_overflow_errorCs7hjGl8LVxbh_20algebraic_norm_study.exit: ; preds = %bb9, %bb4.i, %bb4.1.i, %bb4.2.i
  %col.sroa.0.07.lcssa.sink.i = phi i64 [ 3, %bb4.2.i ], [ 0, %bb9 ], [ 1, %bb4.i ], [ 2, %bb4.1.i ]
  store i8 4, ptr %_0, align 8
  %_20.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 1
  store i8 0, ptr %_20.sroa.4.0._0.sroa_idx, align 1
  %_20.sroa.58.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 0, ptr %_20.sroa.58.0._0.sroa_idx, align 8
  %_20.sroa.69.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %r.sroa.0.014.lcssa, ptr %_20.sroa.69.0._0.sroa_idx, align 8
  %_20.sroa.7.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24
  store i64 %col.sroa.0.07.lcssa.sink.i, ptr %_20.sroa.7.0._0.sroa_idx, align 8
  br label %bb16

bb8:                                              ; preds = %start
  %row.1 = getelementptr inbounds nuw i8, ptr %self, i64 32
  %_14.118 = load double, ptr %row.1, align 8, !noundef !9
  %_13.119 = tail call double @llvm.fabs.f64(double %_14.118)
  %10 = getelementptr inbounds nuw i8, ptr %self, i64 40
  %_14.1.1 = load double, ptr %10, align 8, !noundef !9
  %_13.1.1 = tail call double @llvm.fabs.f64(double %_14.1.1)
  %11 = fadd double %_13.119, %_13.1.1
  %12 = getelementptr inbounds nuw i8, ptr %self, i64 48
  %_14.2.1 = load double, ptr %12, align 8, !noundef !9
  %_13.2.1 = tail call double @llvm.fabs.f64(double %_14.2.1)
  %13 = fadd double %11, %_13.2.1
  %14 = getelementptr inbounds nuw i8, ptr %self, i64 56
  %_14.3.1 = load double, ptr %14, align 8, !noundef !9
  %_13.3.1 = tail call double @llvm.fabs.f64(double %_14.3.1)
  %15 = fadd double %13, %_13.3.1
  %_24.1 = tail call double @llvm.fabs.f64(double %15)
  %_17.1 = fcmp ueq double %_24.1, +inf
  br i1 %_17.1, label %bb9, label %bb8.1, !prof !21

bb8.1:                                            ; preds = %bb8
  %row.2 = getelementptr inbounds nuw i8, ptr %self, i64 64
  %_14.220 = load double, ptr %row.2, align 8, !noundef !9
  %_13.221 = tail call double @llvm.fabs.f64(double %_14.220)
  %16 = getelementptr inbounds nuw i8, ptr %self, i64 72
  %_14.1.2 = load double, ptr %16, align 8, !noundef !9
  %_13.1.2 = tail call double @llvm.fabs.f64(double %_14.1.2)
  %17 = fadd double %_13.221, %_13.1.2
  %18 = getelementptr inbounds nuw i8, ptr %self, i64 80
  %_14.2.2 = load double, ptr %18, align 8, !noundef !9
  %_13.2.2 = tail call double @llvm.fabs.f64(double %_14.2.2)
  %19 = fadd double %17, %_13.2.2
  %20 = getelementptr inbounds nuw i8, ptr %self, i64 88
  %_14.3.2 = load double, ptr %20, align 8, !noundef !9
  %_13.3.2 = tail call double @llvm.fabs.f64(double %_14.3.2)
  %21 = fadd double %19, %_13.3.2
  %_24.2 = tail call double @llvm.fabs.f64(double %21)
  %_17.2 = fcmp ueq double %_24.2, +inf
  br i1 %_17.2, label %bb9, label %bb8.2, !prof !21

bb8.2:                                            ; preds = %bb8.1
  %row.3 = getelementptr inbounds nuw i8, ptr %self, i64 96
  %_14.322 = load double, ptr %row.3, align 8, !noundef !9
  %_13.323 = tail call double @llvm.fabs.f64(double %_14.322)
  %22 = getelementptr inbounds nuw i8, ptr %self, i64 104
  %_14.1.3 = load double, ptr %22, align 8, !noundef !9
  %_13.1.3 = tail call double @llvm.fabs.f64(double %_14.1.3)
  %23 = fadd double %_13.323, %_13.1.3
  %24 = getelementptr inbounds nuw i8, ptr %self, i64 112
  %_14.2.3 = load double, ptr %24, align 8, !noundef !9
  %_13.2.3 = tail call double @llvm.fabs.f64(double %_14.2.3)
  %25 = fadd double %23, %_13.2.3
  %26 = getelementptr inbounds nuw i8, ptr %self, i64 120
  %_14.3.3 = load double, ptr %26, align 8, !noundef !9
  %_13.3.3 = tail call double @llvm.fabs.f64(double %_14.3.3)
  %27 = fadd double %25, %_13.3.3
  %_24.3 = tail call double @llvm.fabs.f64(double %27)
  %_17.3 = fcmp ueq double %_24.3, +inf
  br i1 %_17.3, label %bb9, label %bb8.3, !prof !21

bb8.3:                                            ; preds = %bb8.2
  %_21 = fcmp ogt double %5, 0.000000e+00
  %max_row_sum.sroa.0.1 = select i1 %_21, double %5, double 0.000000e+00
  %_21.1 = fcmp ogt double %15, %max_row_sum.sroa.0.1
  %max_row_sum.sroa.0.1.1 = select i1 %_21.1, double %15, double %max_row_sum.sroa.0.1
  %_21.2 = fcmp ogt double %21, %max_row_sum.sroa.0.1.1
  %max_row_sum.sroa.0.1.2 = select i1 %_21.2, double %21, double %max_row_sum.sroa.0.1.1
  %_21.3 = fcmp ogt double %27, %max_row_sum.sroa.0.1.2
  %max_row_sum.sroa.0.1.3 = select i1 %_21.3, double %27, double %max_row_sum.sroa.0.1.2
  %28 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store double %max_row_sum.sroa.0.1.3, ptr %28, align 8
  store i8 -1, ptr %_0, align 8
  br label %bb16
}

; <la_stack::matrix::Matrix<5>>::norm_inf_overflow_error
; Function Attrs: cold mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite) uwtable
define internal fastcc void @_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj5_E23norm_inf_overflow_errorCs7hjGl8LVxbh_20algebraic_norm_study(ptr dead_on_unwind noalias nofree noundef nonnull writable writeonly align 8 captures(none) dereferenceable(56) initializes((0, 2), (8, 9), (16, 32)) %_0, ptr noalias nofree noundef nonnull readonly align 8 captures(none) dereferenceable(40) %row, i64 noundef range(i64 0, 5) %row_index) unnamed_addr #3 !guid !27 {
start:
  %_9 = load double, ptr %row, align 8, !noundef !9
  %_8 = tail call double @llvm.fabs.f64(double %_9)
  %_12 = fcmp ueq double %_8, +inf
  br i1 %_12, label %bb7, label %bb4

bb7:                                              ; preds = %start, %bb4, %bb4.1, %bb4.2, %bb4.3
  %col.sroa.0.07.lcssa.sink = phi i64 [ 4, %bb4.3 ], [ 0, %start ], [ 1, %bb4 ], [ 2, %bb4.1 ], [ 3, %bb4.2 ]
  %0 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 0, ptr %0, align 8
  %_15.sroa.44.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %row_index, ptr %_15.sroa.44.0..sroa_idx, align 8
  %_15.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24
  store i64 %col.sroa.0.07.lcssa.sink, ptr %_15.sroa.5.0..sroa_idx, align 8
  %1 = getelementptr inbounds nuw i8, ptr %_0, i64 1
  store i8 0, ptr %1, align 1
  store i8 4, ptr %_0, align 8
  ret void

bb4:                                              ; preds = %start
  %2 = getelementptr inbounds nuw i8, ptr %row, i64 8
  %_9.1 = load double, ptr %2, align 8, !noundef !9
  %_8.1 = tail call double @llvm.fabs.f64(double %_9.1)
  %3 = fadd double %_8, %_8.1
  %_14.1 = tail call double @llvm.fabs.f64(double %3)
  %_12.1 = fcmp ueq double %_14.1, +inf
  br i1 %_12.1, label %bb7, label %bb4.1

bb4.1:                                            ; preds = %bb4
  %4 = getelementptr inbounds nuw i8, ptr %row, i64 16
  %_9.2 = load double, ptr %4, align 8, !noundef !9
  %_8.2 = tail call double @llvm.fabs.f64(double %_9.2)
  %5 = fadd double %3, %_8.2
  %_14.2 = tail call double @llvm.fabs.f64(double %5)
  %_12.2 = fcmp ueq double %_14.2, +inf
  br i1 %_12.2, label %bb7, label %bb4.2

bb4.2:                                            ; preds = %bb4.1
  %6 = getelementptr inbounds nuw i8, ptr %row, i64 24
  %_9.3 = load double, ptr %6, align 8, !noundef !9
  %_8.3 = tail call double @llvm.fabs.f64(double %_9.3)
  %7 = fadd double %5, %_8.3
  %_14.3 = tail call double @llvm.fabs.f64(double %7)
  %_12.3 = fcmp ueq double %_14.3, +inf
  br i1 %_12.3, label %bb7, label %bb4.3

bb4.3:                                            ; preds = %bb4.2
  br label %bb7
}

; <la_stack::matrix::Matrix<5>>::norm_inf
; Function Attrs: inlinehint mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite) uwtable
define internal fastcc void @_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj5_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study(ptr dead_on_unwind noalias nofree noundef nonnull writable writeonly align 8 captures(none) dereferenceable(56) initializes((0, 1), (8, 9)) %_0, ptr noalias nofree noundef nonnull readonly align 8 captures(none) dereferenceable(200) %self) unnamed_addr #2 !guid !28 {
start:
  %_14 = load double, ptr %self, align 8, !noundef !9
  %_13 = tail call double @llvm.fabs.f64(double %_14)
  %0 = getelementptr inbounds nuw i8, ptr %self, i64 8
  %_14.1 = load double, ptr %0, align 8, !noundef !9
  %_13.1 = tail call double @llvm.fabs.f64(double %_14.1)
  %1 = fadd double %_13, %_13.1
  %2 = getelementptr inbounds nuw i8, ptr %self, i64 16
  %_14.2 = load double, ptr %2, align 8, !noundef !9
  %_13.2 = tail call double @llvm.fabs.f64(double %_14.2)
  %3 = fadd double %1, %_13.2
  %4 = getelementptr inbounds nuw i8, ptr %self, i64 24
  %_14.3 = load double, ptr %4, align 8, !noundef !9
  %_13.3 = tail call double @llvm.fabs.f64(double %_14.3)
  %5 = fadd double %3, %_13.3
  %6 = getelementptr inbounds nuw i8, ptr %self, i64 32
  %_14.4 = load double, ptr %6, align 8, !noundef !9
  %_13.4 = tail call double @llvm.fabs.f64(double %_14.4)
  %7 = fadd double %5, %_13.4
  %_24 = tail call double @llvm.fabs.f64(double %7)
  %_17 = fcmp ueq double %_24, +inf
  br i1 %_17, label %bb9, label %bb8, !prof !21

bb16:                                             ; preds = %bb9, %bb8.4
  ret void

bb9:                                              ; preds = %bb8.3, %bb8.2, %bb8.1, %bb8, %start
  %r.sroa.0.012.lcssa = phi i64 [ 0, %start ], [ 1, %bb8 ], [ 2, %bb8.1 ], [ 3, %bb8.2 ], [ 4, %bb8.3 ]
  %row.lcssa = phi ptr [ %self, %start ], [ %row.1, %bb8 ], [ %row.2, %bb8.1 ], [ %row.3, %bb8.2 ], [ %row.4, %bb8.3 ]
; call <la_stack::matrix::Matrix<5>>::norm_inf_overflow_error
  call fastcc void @_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj5_E23norm_inf_overflow_errorCs7hjGl8LVxbh_20algebraic_norm_study(ptr noalias nofree noundef align 8 captures(none) dereferenceable(56) %_0, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(40) %row.lcssa, i64 noundef %r.sroa.0.012.lcssa)
  br label %bb16

bb8:                                              ; preds = %start
  %row.1 = getelementptr inbounds nuw i8, ptr %self, i64 40
  %_14.116 = load double, ptr %row.1, align 8, !noundef !9
  %_13.117 = tail call double @llvm.fabs.f64(double %_14.116)
  %8 = getelementptr inbounds nuw i8, ptr %self, i64 48
  %_14.1.1 = load double, ptr %8, align 8, !noundef !9
  %_13.1.1 = tail call double @llvm.fabs.f64(double %_14.1.1)
  %9 = fadd double %_13.117, %_13.1.1
  %10 = getelementptr inbounds nuw i8, ptr %self, i64 56
  %_14.2.1 = load double, ptr %10, align 8, !noundef !9
  %_13.2.1 = tail call double @llvm.fabs.f64(double %_14.2.1)
  %11 = fadd double %9, %_13.2.1
  %12 = getelementptr inbounds nuw i8, ptr %self, i64 64
  %_14.3.1 = load double, ptr %12, align 8, !noundef !9
  %_13.3.1 = tail call double @llvm.fabs.f64(double %_14.3.1)
  %13 = fadd double %11, %_13.3.1
  %14 = getelementptr inbounds nuw i8, ptr %self, i64 72
  %_14.4.1 = load double, ptr %14, align 8, !noundef !9
  %_13.4.1 = tail call double @llvm.fabs.f64(double %_14.4.1)
  %15 = fadd double %13, %_13.4.1
  %_24.1 = tail call double @llvm.fabs.f64(double %15)
  %_17.1 = fcmp ueq double %_24.1, +inf
  br i1 %_17.1, label %bb9, label %bb8.1, !prof !21

bb8.1:                                            ; preds = %bb8
  %row.2 = getelementptr inbounds nuw i8, ptr %self, i64 80
  %_14.218 = load double, ptr %row.2, align 8, !noundef !9
  %_13.219 = tail call double @llvm.fabs.f64(double %_14.218)
  %16 = getelementptr inbounds nuw i8, ptr %self, i64 88
  %_14.1.2 = load double, ptr %16, align 8, !noundef !9
  %_13.1.2 = tail call double @llvm.fabs.f64(double %_14.1.2)
  %17 = fadd double %_13.219, %_13.1.2
  %18 = getelementptr inbounds nuw i8, ptr %self, i64 96
  %_14.2.2 = load double, ptr %18, align 8, !noundef !9
  %_13.2.2 = tail call double @llvm.fabs.f64(double %_14.2.2)
  %19 = fadd double %17, %_13.2.2
  %20 = getelementptr inbounds nuw i8, ptr %self, i64 104
  %_14.3.2 = load double, ptr %20, align 8, !noundef !9
  %_13.3.2 = tail call double @llvm.fabs.f64(double %_14.3.2)
  %21 = fadd double %19, %_13.3.2
  %22 = getelementptr inbounds nuw i8, ptr %self, i64 112
  %_14.4.2 = load double, ptr %22, align 8, !noundef !9
  %_13.4.2 = tail call double @llvm.fabs.f64(double %_14.4.2)
  %23 = fadd double %21, %_13.4.2
  %_24.2 = tail call double @llvm.fabs.f64(double %23)
  %_17.2 = fcmp ueq double %_24.2, +inf
  br i1 %_17.2, label %bb9, label %bb8.2, !prof !21

bb8.2:                                            ; preds = %bb8.1
  %row.3 = getelementptr inbounds nuw i8, ptr %self, i64 120
  %_14.320 = load double, ptr %row.3, align 8, !noundef !9
  %_13.321 = tail call double @llvm.fabs.f64(double %_14.320)
  %24 = getelementptr inbounds nuw i8, ptr %self, i64 128
  %_14.1.3 = load double, ptr %24, align 8, !noundef !9
  %_13.1.3 = tail call double @llvm.fabs.f64(double %_14.1.3)
  %25 = fadd double %_13.321, %_13.1.3
  %26 = getelementptr inbounds nuw i8, ptr %self, i64 136
  %_14.2.3 = load double, ptr %26, align 8, !noundef !9
  %_13.2.3 = tail call double @llvm.fabs.f64(double %_14.2.3)
  %27 = fadd double %25, %_13.2.3
  %28 = getelementptr inbounds nuw i8, ptr %self, i64 144
  %_14.3.3 = load double, ptr %28, align 8, !noundef !9
  %_13.3.3 = tail call double @llvm.fabs.f64(double %_14.3.3)
  %29 = fadd double %27, %_13.3.3
  %30 = getelementptr inbounds nuw i8, ptr %self, i64 152
  %_14.4.3 = load double, ptr %30, align 8, !noundef !9
  %_13.4.3 = tail call double @llvm.fabs.f64(double %_14.4.3)
  %31 = fadd double %29, %_13.4.3
  %_24.3 = tail call double @llvm.fabs.f64(double %31)
  %_17.3 = fcmp ueq double %_24.3, +inf
  br i1 %_17.3, label %bb9, label %bb8.3, !prof !21

bb8.3:                                            ; preds = %bb8.2
  %row.4 = getelementptr inbounds nuw i8, ptr %self, i64 160
  %_14.422 = load double, ptr %row.4, align 8, !noundef !9
  %_13.423 = tail call double @llvm.fabs.f64(double %_14.422)
  %32 = getelementptr inbounds nuw i8, ptr %self, i64 168
  %_14.1.4 = load double, ptr %32, align 8, !noundef !9
  %_13.1.4 = tail call double @llvm.fabs.f64(double %_14.1.4)
  %33 = fadd double %_13.423, %_13.1.4
  %34 = getelementptr inbounds nuw i8, ptr %self, i64 176
  %_14.2.4 = load double, ptr %34, align 8, !noundef !9
  %_13.2.4 = tail call double @llvm.fabs.f64(double %_14.2.4)
  %35 = fadd double %33, %_13.2.4
  %36 = getelementptr inbounds nuw i8, ptr %self, i64 184
  %_14.3.4 = load double, ptr %36, align 8, !noundef !9
  %_13.3.4 = tail call double @llvm.fabs.f64(double %_14.3.4)
  %37 = fadd double %35, %_13.3.4
  %38 = getelementptr inbounds nuw i8, ptr %self, i64 192
  %_14.4.4 = load double, ptr %38, align 8, !noundef !9
  %_13.4.4 = tail call double @llvm.fabs.f64(double %_14.4.4)
  %39 = fadd double %37, %_13.4.4
  %_24.4 = tail call double @llvm.fabs.f64(double %39)
  %_17.4 = fcmp ueq double %_24.4, +inf
  br i1 %_17.4, label %bb9, label %bb8.4, !prof !21

bb8.4:                                            ; preds = %bb8.3
  %_21 = fcmp ogt double %7, 0.000000e+00
  %max_row_sum.sroa.0.1 = select i1 %_21, double %7, double 0.000000e+00
  %_21.1 = fcmp ogt double %15, %max_row_sum.sroa.0.1
  %max_row_sum.sroa.0.1.1 = select i1 %_21.1, double %15, double %max_row_sum.sroa.0.1
  %_21.2 = fcmp ogt double %23, %max_row_sum.sroa.0.1.1
  %max_row_sum.sroa.0.1.2 = select i1 %_21.2, double %23, double %max_row_sum.sroa.0.1.1
  %_21.3 = fcmp ogt double %31, %max_row_sum.sroa.0.1.2
  %max_row_sum.sroa.0.1.3 = select i1 %_21.3, double %31, double %max_row_sum.sroa.0.1.2
  %_21.4 = fcmp ogt double %39, %max_row_sum.sroa.0.1.3
  %max_row_sum.sroa.0.1.4 = select i1 %_21.4, double %39, double %max_row_sum.sroa.0.1.3
  %40 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store double %max_row_sum.sroa.0.1.4, ptr %40, align 8
  store i8 -1, ptr %_0, align 8
  br label %bb16
}

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fabs.f64(double) #4

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #5

attributes #0 = { mustprogress nofree noinline norecurse nosync nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #1 = { mustprogress nofree noinline norecurse nosync nounwind willreturn memory(argmem: readwrite) uwtable "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #2 = { inlinehint mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite) uwtable "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #3 = { cold mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite) uwtable "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #4 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #6 = { inlinehint }

!llvm.module.flags = !{!0, !1}
!llvm.ident = !{!2}

!0 = !{i32 8, !"PIC Level", i32 2}
!1 = !{i32 7, !"uwtable", i32 2}
!2 = !{!"rustc version 1.99.0 (b940084d7 2026-09-28)"}
!3 = !{i64 1846869057592137691}
!4 = !{!5}
!5 = distinct !{!5, !6, !"_RINvCs7hjGl8LVxbh_20algebraic_norm_study14algebraic_normKj4_EB2_: %_0"}
!6 = distinct !{!6, !"_RINvCs7hjGl8LVxbh_20algebraic_norm_study14algebraic_normKj4_EB2_"}
!7 = !{!8}
!8 = distinct !{!8, !6, !"_RINvCs7hjGl8LVxbh_20algebraic_norm_study14algebraic_normKj4_EB2_: %matrix"}
!9 = !{}
!10 = !{!5, !8}
!11 = !{i64 3488313623337841248}
!12 = !{!13}
!13 = distinct !{!13, !14, !"_RINvCs7hjGl8LVxbh_20algebraic_norm_study14algebraic_normKj5_EB2_: %_0"}
!14 = distinct !{!14, !"_RINvCs7hjGl8LVxbh_20algebraic_norm_study14algebraic_normKj5_EB2_"}
!15 = !{!16}
!16 = distinct !{!16, !14, !"_RINvCs7hjGl8LVxbh_20algebraic_norm_study14algebraic_normKj5_EB2_: %matrix"}
!17 = !{!13, !16}
!18 = !{i64 -8482211515829609695}
!19 = !{i64 280192665929948514}
!20 = !{i64 5600963234581243325}
!21 = !{!"branch_weights", !"expected", i32 1, i32 2000}
!22 = !{!23}
!23 = distinct !{!23, !24, !"_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj4_E23norm_inf_overflow_errorCs7hjGl8LVxbh_20algebraic_norm_study: %row"}
!24 = distinct !{!24, !"_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj4_E23norm_inf_overflow_errorCs7hjGl8LVxbh_20algebraic_norm_study"}
!25 = !{!26}
!26 = distinct !{!26, !24, !"_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj4_E23norm_inf_overflow_errorCs7hjGl8LVxbh_20algebraic_norm_study: %_0"}
!27 = !{i64 6615622332635783789}
!28 = !{i64 8490630504951299541}
