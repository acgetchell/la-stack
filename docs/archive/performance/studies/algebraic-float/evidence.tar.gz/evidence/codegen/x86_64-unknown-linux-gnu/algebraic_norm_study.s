	.att_syntax
	.file	"algebraic_norm_study.54c96358e94492a9-cgu.0"
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI0_0:
	.quad	0x7fffffffffffffff
	.quad	0x7fffffffffffffff
	.section	.text._RNvCs7hjGl8LVxbh_20algebraic_norm_study12algebraic_d4,"ax",@progbits
	.globl	_RNvCs7hjGl8LVxbh_20algebraic_norm_study12algebraic_d4
	.prefalign	4, .Lfunc_end0, nop
	.type	_RNvCs7hjGl8LVxbh_20algebraic_norm_study12algebraic_d4,@function
_RNvCs7hjGl8LVxbh_20algebraic_norm_study12algebraic_d4:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	movq	%rdi, %rbx
	movapd	.LCPI0_0(%rip), %xmm1
	movsd	(%rsi), %xmm2
	movsd	8(%rsi), %xmm3
	movsd	16(%rsi), %xmm4
	movsd	24(%rsi), %xmm0
	andpd	%xmm1, %xmm2
	andpd	%xmm1, %xmm3
	addsd	%xmm2, %xmm3
	andpd	%xmm1, %xmm4
	andpd	%xmm1, %xmm0
	addsd	%xmm4, %xmm0
	addsd	%xmm3, %xmm0
	movq	%xmm0, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2047, %eax
	jae	.LBB0_1
	movsd	32(%rsi), %xmm3
	movsd	40(%rsi), %xmm4
	movsd	48(%rsi), %xmm5
	movsd	56(%rsi), %xmm2
	andpd	%xmm1, %xmm3
	andpd	%xmm1, %xmm4
	addsd	%xmm3, %xmm4
	andpd	%xmm1, %xmm5
	andpd	%xmm1, %xmm2
	addsd	%xmm5, %xmm2
	addsd	%xmm4, %xmm2
	movq	%xmm2, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	ja	.LBB0_1
	movsd	64(%rsi), %xmm4
	movsd	72(%rsi), %xmm5
	movsd	80(%rsi), %xmm6
	movsd	88(%rsi), %xmm3
	andpd	%xmm1, %xmm4
	andpd	%xmm1, %xmm5
	addsd	%xmm4, %xmm5
	andpd	%xmm1, %xmm6
	andpd	%xmm1, %xmm3
	addsd	%xmm6, %xmm3
	addsd	%xmm5, %xmm3
	movq	%xmm3, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	ja	.LBB0_1
	movsd	96(%rsi), %xmm5
	movsd	104(%rsi), %xmm6
	movsd	112(%rsi), %xmm7
	movsd	120(%rsi), %xmm4
	andpd	%xmm1, %xmm5
	andpd	%xmm1, %xmm6
	addsd	%xmm5, %xmm6
	andpd	%xmm1, %xmm7
	andpd	%xmm1, %xmm4
	addsd	%xmm7, %xmm4
	addsd	%xmm6, %xmm4
	movq	%xmm4, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	jbe	.LBB0_5
.LBB0_1:
	movq	%rbx, %rdi
	callq	_RNvMs2_NtCskno9fjIxXqy_8la_stack6matrixINtB5_6MatrixKj4_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study
	movq	%rbx, %rax
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB0_5:
	.cfi_def_cfa_offset 16
	xorpd	%xmm1, %xmm1
	maxsd	%xmm1, %xmm0
	maxsd	%xmm0, %xmm2
	maxsd	%xmm2, %xmm3
	maxsd	%xmm3, %xmm4
	movsd	%xmm4, 8(%rbx)
	movb	$-1, (%rbx)
	movq	%rbx, %rax
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end0:
	.size	_RNvCs7hjGl8LVxbh_20algebraic_norm_study12algebraic_d4, .Lfunc_end0-_RNvCs7hjGl8LVxbh_20algebraic_norm_study12algebraic_d4
	.cfi_endproc

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI1_0:
	.quad	0x7fffffffffffffff
	.quad	0x7fffffffffffffff
	.section	.text._RNvCs7hjGl8LVxbh_20algebraic_norm_study12algebraic_d5,"ax",@progbits
	.globl	_RNvCs7hjGl8LVxbh_20algebraic_norm_study12algebraic_d5
	.prefalign	4, .Lfunc_end1, nop
	.type	_RNvCs7hjGl8LVxbh_20algebraic_norm_study12algebraic_d5,@function
_RNvCs7hjGl8LVxbh_20algebraic_norm_study12algebraic_d5:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	movq	%rdi, %rbx
	movapd	.LCPI1_0(%rip), %xmm0
	movsd	(%rsi), %xmm1
	movsd	8(%rsi), %xmm2
	movsd	16(%rsi), %xmm3
	movsd	24(%rsi), %xmm4
	andpd	%xmm0, %xmm1
	andpd	%xmm0, %xmm2
	addsd	%xmm1, %xmm2
	andpd	%xmm0, %xmm3
	andpd	%xmm0, %xmm4
	addsd	%xmm3, %xmm4
	addsd	%xmm2, %xmm4
	movsd	32(%rsi), %xmm1
	andpd	%xmm0, %xmm1
	addsd	%xmm4, %xmm1
	movq	%xmm1, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2047, %eax
	jae	.LBB1_1
	movsd	40(%rsi), %xmm2
	movsd	48(%rsi), %xmm3
	movsd	56(%rsi), %xmm4
	movsd	64(%rsi), %xmm5
	andpd	%xmm0, %xmm2
	andpd	%xmm0, %xmm3
	addsd	%xmm2, %xmm3
	andpd	%xmm0, %xmm4
	andpd	%xmm0, %xmm5
	addsd	%xmm4, %xmm5
	addsd	%xmm3, %xmm5
	movsd	72(%rsi), %xmm2
	andpd	%xmm0, %xmm2
	addsd	%xmm5, %xmm2
	movq	%xmm2, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	ja	.LBB1_1
	movsd	80(%rsi), %xmm3
	movsd	88(%rsi), %xmm4
	movsd	96(%rsi), %xmm5
	movsd	104(%rsi), %xmm6
	andpd	%xmm0, %xmm3
	andpd	%xmm0, %xmm4
	addsd	%xmm3, %xmm4
	andpd	%xmm0, %xmm5
	andpd	%xmm0, %xmm6
	addsd	%xmm5, %xmm6
	addsd	%xmm4, %xmm6
	movsd	112(%rsi), %xmm3
	andpd	%xmm0, %xmm3
	addsd	%xmm6, %xmm3
	movq	%xmm3, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	ja	.LBB1_1
	movsd	120(%rsi), %xmm4
	movsd	128(%rsi), %xmm5
	movsd	136(%rsi), %xmm6
	movsd	144(%rsi), %xmm7
	andpd	%xmm0, %xmm4
	andpd	%xmm0, %xmm5
	addsd	%xmm4, %xmm5
	andpd	%xmm0, %xmm6
	andpd	%xmm0, %xmm7
	addsd	%xmm6, %xmm7
	addsd	%xmm5, %xmm7
	movsd	152(%rsi), %xmm4
	andpd	%xmm0, %xmm4
	addsd	%xmm7, %xmm4
	movq	%xmm4, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	ja	.LBB1_1
	movsd	160(%rsi), %xmm5
	movsd	168(%rsi), %xmm6
	movsd	176(%rsi), %xmm7
	movsd	184(%rsi), %xmm8
	andpd	%xmm0, %xmm5
	andpd	%xmm0, %xmm6
	addsd	%xmm5, %xmm6
	andpd	%xmm0, %xmm7
	andpd	%xmm0, %xmm8
	addsd	%xmm7, %xmm8
	addsd	%xmm6, %xmm8
	movsd	192(%rsi), %xmm5
	andpd	%xmm0, %xmm5
	addsd	%xmm8, %xmm5
	movq	%xmm5, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	jbe	.LBB1_6
.LBB1_1:
	movq	%rbx, %rdi
	callq	_RNvMs2_NtCskno9fjIxXqy_8la_stack6matrixINtB5_6MatrixKj5_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study
	movq	%rbx, %rax
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB1_6:
	.cfi_def_cfa_offset 16
	xorpd	%xmm0, %xmm0
	maxsd	%xmm0, %xmm1
	maxsd	%xmm1, %xmm2
	maxsd	%xmm2, %xmm3
	maxsd	%xmm3, %xmm4
	maxsd	%xmm4, %xmm5
	movsd	%xmm5, 8(%rbx)
	movb	$-1, (%rbx)
	movq	%rbx, %rax
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end1:
	.size	_RNvCs7hjGl8LVxbh_20algebraic_norm_study12algebraic_d5, .Lfunc_end1-_RNvCs7hjGl8LVxbh_20algebraic_norm_study12algebraic_d5
	.cfi_endproc

	.section	.text._RNvCs7hjGl8LVxbh_20algebraic_norm_study9strict_d4,"ax",@progbits
	.globl	_RNvCs7hjGl8LVxbh_20algebraic_norm_study9strict_d4
	.prefalign	4, .Lfunc_end2, nop
	.type	_RNvCs7hjGl8LVxbh_20algebraic_norm_study9strict_d4,@function
_RNvCs7hjGl8LVxbh_20algebraic_norm_study9strict_d4:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	movq	%rdi, %rbx
	callq	_RNvMs2_NtCskno9fjIxXqy_8la_stack6matrixINtB5_6MatrixKj4_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study
	movq	%rbx, %rax
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end2:
	.size	_RNvCs7hjGl8LVxbh_20algebraic_norm_study9strict_d4, .Lfunc_end2-_RNvCs7hjGl8LVxbh_20algebraic_norm_study9strict_d4
	.cfi_endproc

	.section	.text._RNvCs7hjGl8LVxbh_20algebraic_norm_study9strict_d5,"ax",@progbits
	.globl	_RNvCs7hjGl8LVxbh_20algebraic_norm_study9strict_d5
	.prefalign	4, .Lfunc_end3, nop
	.type	_RNvCs7hjGl8LVxbh_20algebraic_norm_study9strict_d5,@function
_RNvCs7hjGl8LVxbh_20algebraic_norm_study9strict_d5:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	movq	%rdi, %rbx
	callq	_RNvMs2_NtCskno9fjIxXqy_8la_stack6matrixINtB5_6MatrixKj5_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study
	movq	%rbx, %rax
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end3:
	.size	_RNvCs7hjGl8LVxbh_20algebraic_norm_study9strict_d5, .Lfunc_end3-_RNvCs7hjGl8LVxbh_20algebraic_norm_study9strict_d5
	.cfi_endproc

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI4_0:
	.quad	0x7fffffffffffffff
	.quad	0x7fffffffffffffff
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0
.LCPI4_1:
	.quad	0x7ff0000000000000
	.section	.text._RNvMs2_NtCskno9fjIxXqy_8la_stack6matrixINtB5_6MatrixKj4_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study,"ax",@progbits
	.prefalign	4, .Lfunc_end4, nop
	.type	_RNvMs2_NtCskno9fjIxXqy_8la_stack6matrixINtB5_6MatrixKj4_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study,@function
_RNvMs2_NtCskno9fjIxXqy_8la_stack6matrixINtB5_6MatrixKj4_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study:
	.cfi_startproc
	movapd	.LCPI4_0(%rip), %xmm2
	movsd	(%rsi), %xmm0
	movsd	8(%rsi), %xmm3
	movsd	16(%rsi), %xmm4
	movsd	24(%rsi), %xmm1
	andpd	%xmm2, %xmm0
	andpd	%xmm2, %xmm3
	addsd	%xmm0, %xmm3
	andpd	%xmm2, %xmm4
	addsd	%xmm3, %xmm4
	andpd	%xmm2, %xmm1
	addsd	%xmm4, %xmm1
	movq	%xmm1, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	ja	.LBB4_1
	movsd	32(%rsi), %xmm0
	movsd	40(%rsi), %xmm4
	movsd	48(%rsi), %xmm5
	movsd	56(%rsi), %xmm3
	andpd	%xmm2, %xmm0
	andpd	%xmm2, %xmm4
	addsd	%xmm0, %xmm4
	andpd	%xmm2, %xmm5
	addsd	%xmm4, %xmm5
	andpd	%xmm2, %xmm3
	addsd	%xmm5, %xmm3
	movq	%xmm3, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	ja	.LBB4_9
	movsd	64(%rsi), %xmm0
	movsd	72(%rsi), %xmm5
	movsd	80(%rsi), %xmm6
	movsd	88(%rsi), %xmm4
	andpd	%xmm2, %xmm0
	andpd	%xmm2, %xmm5
	addsd	%xmm0, %xmm5
	andpd	%xmm2, %xmm6
	addsd	%xmm5, %xmm6
	andpd	%xmm2, %xmm4
	addsd	%xmm6, %xmm4
	movq	%xmm4, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	ja	.LBB4_11
	movsd	96(%rsi), %xmm0
	movsd	104(%rsi), %xmm6
	movsd	112(%rsi), %xmm7
	movsd	120(%rsi), %xmm5
	andpd	%xmm2, %xmm0
	andpd	%xmm2, %xmm6
	addsd	%xmm0, %xmm6
	andpd	%xmm2, %xmm7
	addsd	%xmm6, %xmm7
	andpd	%xmm2, %xmm5
	addsd	%xmm7, %xmm5
	movq	%xmm5, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	ja	.LBB4_13
	xorpd	%xmm0, %xmm0
	maxsd	%xmm0, %xmm1
	maxsd	%xmm1, %xmm3
	maxsd	%xmm3, %xmm4
	maxsd	%xmm4, %xmm5
	movsd	%xmm5, 8(%rdi)
	movb	$-1, (%rdi)
	retq
.LBB4_1:
	xorl	%eax, %eax
	jmp	.LBB4_2
.LBB4_9:
	addq	$32, %rsi
	movl	$1, %eax
	jmp	.LBB4_2
.LBB4_11:
	addq	$64, %rsi
	movl	$2, %eax
	jmp	.LBB4_2
.LBB4_13:
	addq	$96, %rsi
	movl	$3, %eax
.LBB4_2:
	ucomisd	.LCPI4_1(%rip), %xmm0
	je	.LBB4_3
	movsd	8(%rsi), %xmm1
	andpd	.LCPI4_0(%rip), %xmm1
	addsd	%xmm1, %xmm0
	movq	%xmm0, %rdx
	shrq	$52, %rdx
	andl	$2047, %edx
	movl	$1, %ecx
	cmpl	$2046, %edx
	ja	.LBB4_7
	movsd	16(%rsi), %xmm1
	andpd	.LCPI4_0(%rip), %xmm1
	addsd	%xmm1, %xmm0
	movq	%xmm0, %rdx
	shrq	$52, %rdx
	andl	$2047, %edx
	movl	$2, %ecx
	cmpl	$2046, %edx
	ja	.LBB4_7
	movl	$3, %ecx
	jmp	.LBB4_7
.LBB4_3:
	xorl	%ecx, %ecx
.LBB4_7:
	movw	$4, (%rdi)
	movb	$0, 8(%rdi)
	movq	%rax, 16(%rdi)
	movq	%rcx, 24(%rdi)
	retq
.Lfunc_end4:
	.size	_RNvMs2_NtCskno9fjIxXqy_8la_stack6matrixINtB5_6MatrixKj4_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study, .Lfunc_end4-_RNvMs2_NtCskno9fjIxXqy_8la_stack6matrixINtB5_6MatrixKj4_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study
	.cfi_endproc

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI5_0:
	.quad	0x7fffffffffffffff
	.quad	0x7fffffffffffffff
	.section	.text.unlikely._RNvMs2_NtCskno9fjIxXqy_8la_stack6matrixINtB5_6MatrixKj5_E23norm_inf_overflow_errorCs7hjGl8LVxbh_20algebraic_norm_study,"ax",@progbits
	.prefalign	4, .Lfunc_end5, nop
	.type	_RNvMs2_NtCskno9fjIxXqy_8la_stack6matrixINtB5_6MatrixKj5_E23norm_inf_overflow_errorCs7hjGl8LVxbh_20algebraic_norm_study,@function
_RNvMs2_NtCskno9fjIxXqy_8la_stack6matrixINtB5_6MatrixKj5_E23norm_inf_overflow_errorCs7hjGl8LVxbh_20algebraic_norm_study:
	.cfi_startproc
	movq	(%rsi), %xmm1
	movq	%xmm1, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2047, %eax
	jb	.LBB5_3
	xorl	%eax, %eax
	jmp	.LBB5_2
.LBB5_3:
	pand	.LCPI5_0(%rip), %xmm1
	movsd	8(%rsi), %xmm0
	andpd	.LCPI5_0(%rip), %xmm0
	addsd	%xmm1, %xmm0
	movq	%xmm0, %rcx
	shrq	$52, %rcx
	andl	$2047, %ecx
	movl	$1, %eax
	cmpl	$2046, %ecx
	ja	.LBB5_2
	movsd	16(%rsi), %xmm1
	andpd	.LCPI5_0(%rip), %xmm1
	addsd	%xmm1, %xmm0
	movq	%xmm0, %rcx
	shrq	$52, %rcx
	andl	$2047, %ecx
	movl	$2, %eax
	cmpl	$2046, %ecx
	ja	.LBB5_2
	movsd	24(%rsi), %xmm1
	andpd	.LCPI5_0(%rip), %xmm1
	addsd	%xmm1, %xmm0
	movq	%xmm0, %rcx
	shrq	$52, %rcx
	andl	$2047, %ecx
	movl	$3, %eax
	cmpl	$2046, %ecx
	ja	.LBB5_2
	movl	$4, %eax
.LBB5_2:
	movb	$0, 8(%rdi)
	movq	%rdx, 16(%rdi)
	movq	%rax, 24(%rdi)
	movw	$4, (%rdi)
	retq
.Lfunc_end5:
	.size	_RNvMs2_NtCskno9fjIxXqy_8la_stack6matrixINtB5_6MatrixKj5_E23norm_inf_overflow_errorCs7hjGl8LVxbh_20algebraic_norm_study, .Lfunc_end5-_RNvMs2_NtCskno9fjIxXqy_8la_stack6matrixINtB5_6MatrixKj5_E23norm_inf_overflow_errorCs7hjGl8LVxbh_20algebraic_norm_study
	.cfi_endproc

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI6_0:
	.quad	0x7fffffffffffffff
	.quad	0x7fffffffffffffff
	.section	.text._RNvMs2_NtCskno9fjIxXqy_8la_stack6matrixINtB5_6MatrixKj5_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study,"ax",@progbits
	.prefalign	4, .Lfunc_end6, nop
	.type	_RNvMs2_NtCskno9fjIxXqy_8la_stack6matrixINtB5_6MatrixKj5_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study,@function
_RNvMs2_NtCskno9fjIxXqy_8la_stack6matrixINtB5_6MatrixKj5_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study:
	.cfi_startproc
	movapd	.LCPI6_0(%rip), %xmm0
	movsd	(%rsi), %xmm1
	movsd	8(%rsi), %xmm2
	movsd	16(%rsi), %xmm3
	movsd	24(%rsi), %xmm4
	andpd	%xmm0, %xmm1
	andpd	%xmm0, %xmm2
	addsd	%xmm1, %xmm2
	andpd	%xmm0, %xmm3
	addsd	%xmm2, %xmm3
	andpd	%xmm0, %xmm4
	addsd	%xmm3, %xmm4
	movsd	32(%rsi), %xmm1
	andpd	%xmm0, %xmm1
	addsd	%xmm4, %xmm1
	movq	%xmm1, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	ja	.LBB6_1
	movsd	40(%rsi), %xmm2
	movsd	48(%rsi), %xmm3
	movsd	56(%rsi), %xmm4
	movsd	64(%rsi), %xmm5
	andpd	%xmm0, %xmm2
	andpd	%xmm0, %xmm3
	addsd	%xmm2, %xmm3
	andpd	%xmm0, %xmm4
	addsd	%xmm3, %xmm4
	andpd	%xmm0, %xmm5
	addsd	%xmm4, %xmm5
	movsd	72(%rsi), %xmm2
	andpd	%xmm0, %xmm2
	addsd	%xmm5, %xmm2
	movq	%xmm2, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	ja	.LBB6_4
	movsd	80(%rsi), %xmm3
	movsd	88(%rsi), %xmm4
	movsd	96(%rsi), %xmm5
	movsd	104(%rsi), %xmm6
	andpd	%xmm0, %xmm3
	andpd	%xmm0, %xmm4
	addsd	%xmm3, %xmm4
	andpd	%xmm0, %xmm5
	addsd	%xmm4, %xmm5
	andpd	%xmm0, %xmm6
	addsd	%xmm5, %xmm6
	movsd	112(%rsi), %xmm3
	andpd	%xmm0, %xmm3
	addsd	%xmm6, %xmm3
	movq	%xmm3, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	ja	.LBB6_6
	movsd	120(%rsi), %xmm4
	movsd	128(%rsi), %xmm5
	movsd	136(%rsi), %xmm6
	movsd	144(%rsi), %xmm7
	andpd	%xmm0, %xmm4
	andpd	%xmm0, %xmm5
	addsd	%xmm4, %xmm5
	andpd	%xmm0, %xmm6
	addsd	%xmm5, %xmm6
	andpd	%xmm0, %xmm7
	addsd	%xmm6, %xmm7
	movsd	152(%rsi), %xmm4
	andpd	%xmm0, %xmm4
	addsd	%xmm7, %xmm4
	movq	%xmm4, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	ja	.LBB6_8
	movsd	160(%rsi), %xmm5
	movsd	168(%rsi), %xmm6
	movsd	176(%rsi), %xmm7
	movsd	184(%rsi), %xmm8
	andpd	%xmm0, %xmm5
	andpd	%xmm0, %xmm6
	addsd	%xmm5, %xmm6
	andpd	%xmm0, %xmm7
	addsd	%xmm6, %xmm7
	andpd	%xmm0, %xmm8
	addsd	%xmm7, %xmm8
	movsd	192(%rsi), %xmm5
	andpd	%xmm0, %xmm5
	addsd	%xmm8, %xmm5
	movq	%xmm5, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	ja	.LBB6_10
	xorpd	%xmm0, %xmm0
	maxsd	%xmm0, %xmm1
	maxsd	%xmm1, %xmm2
	maxsd	%xmm2, %xmm3
	maxsd	%xmm3, %xmm4
	maxsd	%xmm4, %xmm5
	movsd	%xmm5, 8(%rdi)
	movb	$-1, (%rdi)
	retq
.LBB6_1:
	xorl	%edx, %edx
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	_RNvMs2_NtCskno9fjIxXqy_8la_stack6matrixINtB5_6MatrixKj5_E23norm_inf_overflow_errorCs7hjGl8LVxbh_20algebraic_norm_study
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB6_4:
	addq	$40, %rsi
	movl	$1, %edx
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	_RNvMs2_NtCskno9fjIxXqy_8la_stack6matrixINtB5_6MatrixKj5_E23norm_inf_overflow_errorCs7hjGl8LVxbh_20algebraic_norm_study
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB6_6:
	addq	$80, %rsi
	movl	$2, %edx
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	_RNvMs2_NtCskno9fjIxXqy_8la_stack6matrixINtB5_6MatrixKj5_E23norm_inf_overflow_errorCs7hjGl8LVxbh_20algebraic_norm_study
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB6_8:
	addq	$120, %rsi
	movl	$3, %edx
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	_RNvMs2_NtCskno9fjIxXqy_8la_stack6matrixINtB5_6MatrixKj5_E23norm_inf_overflow_errorCs7hjGl8LVxbh_20algebraic_norm_study
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB6_10:
	addq	$160, %rsi
	movl	$4, %edx
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	_RNvMs2_NtCskno9fjIxXqy_8la_stack6matrixINtB5_6MatrixKj5_E23norm_inf_overflow_errorCs7hjGl8LVxbh_20algebraic_norm_study
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end6:
	.size	_RNvMs2_NtCskno9fjIxXqy_8la_stack6matrixINtB5_6MatrixKj5_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study, .Lfunc_end6-_RNvMs2_NtCskno9fjIxXqy_8la_stack6matrixINtB5_6MatrixKj5_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study
	.cfi_endproc

	.ident	"rustc version 1.99.0 (b940084d7 2026-09-28)"
	.section	".note.GNU-stack","",@progbits
