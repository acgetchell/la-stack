	.def	@feat.00;
	.scl	3;
	.type	0;
	.endef
	.globl	@feat.00
@feat.00 = 0
	.att_syntax
	.file	"algebraic_norm_study.54c96358e94492a9-cgu.0"
	.def	_RNvCs7hjGl8LVxbh_20algebraic_norm_study12algebraic_d4;
	.scl	2;
	.type	32;
	.endef
	.globl	__xmm@7fffffffffffffff7fffffffffffffff
	.section	.rdata,"dr",discard,__xmm@7fffffffffffffff7fffffffffffffff
	.p2align	4, 0x0
__xmm@7fffffffffffffff7fffffffffffffff:
	.quad	0x7fffffffffffffff
	.quad	0x7fffffffffffffff
	.section	.text,"xr",one_only,_RNvCs7hjGl8LVxbh_20algebraic_norm_study12algebraic_d4,unique,0
	.globl	_RNvCs7hjGl8LVxbh_20algebraic_norm_study12algebraic_d4
	.p2align	4
_RNvCs7hjGl8LVxbh_20algebraic_norm_study12algebraic_d4:
.seh_proc _RNvCs7hjGl8LVxbh_20algebraic_norm_study12algebraic_d4
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$64, %rsp
	.seh_stackalloc 64
	movapd	%xmm7, 48(%rsp)
	.seh_savexmm %xmm7, 48
	movapd	%xmm6, 32(%rsp)
	.seh_savexmm %xmm6, 32
	.seh_endprologue
	movq	%rcx, %rsi
	movapd	__xmm@7fffffffffffffff7fffffffffffffff(%rip), %xmm1
	movsd	(%rdx), %xmm2
	movsd	8(%rdx), %xmm3
	movsd	16(%rdx), %xmm4
	movsd	24(%rdx), %xmm0
	andpd	%xmm1, %xmm2
	andpd	%xmm1, %xmm3
	addsd	%xmm2, %xmm3
	andpd	%xmm1, %xmm4
	andpd	%xmm1, %xmm0
	addsd	%xmm4, %xmm0
	addsd	%xmm3, %xmm0
	movq	%xmm0, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2047, %eax
	jae	.LBB0_1
	movsd	32(%rdx), %xmm3
	movsd	40(%rdx), %xmm4
	movsd	48(%rdx), %xmm5
	movsd	56(%rdx), %xmm2
	andpd	%xmm1, %xmm3
	andpd	%xmm1, %xmm4
	addsd	%xmm3, %xmm4
	andpd	%xmm1, %xmm5
	andpd	%xmm1, %xmm2
	addsd	%xmm5, %xmm2
	addsd	%xmm4, %xmm2
	movq	%xmm2, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	ja	.LBB0_1
	movsd	64(%rdx), %xmm4
	movsd	72(%rdx), %xmm5
	movsd	80(%rdx), %xmm6
	movsd	88(%rdx), %xmm3
	andpd	%xmm1, %xmm4
	andpd	%xmm1, %xmm5
	addsd	%xmm4, %xmm5
	andpd	%xmm1, %xmm6
	andpd	%xmm1, %xmm3
	addsd	%xmm6, %xmm3
	addsd	%xmm5, %xmm3
	movq	%xmm3, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	ja	.LBB0_1
	movsd	96(%rdx), %xmm5
	movsd	104(%rdx), %xmm6
	movsd	112(%rdx), %xmm7
	movsd	120(%rdx), %xmm4
	andpd	%xmm1, %xmm5
	andpd	%xmm1, %xmm6
	addsd	%xmm5, %xmm6
	andpd	%xmm1, %xmm7
	andpd	%xmm1, %xmm4
	addsd	%xmm7, %xmm4
	addsd	%xmm6, %xmm4
	movq	%xmm4, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	jbe	.LBB0_5
.LBB0_1:
	movq	%rsi, %rcx
	callq	_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj4_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study
.LBB0_6:
	movq	%rsi, %rax
	movaps	32(%rsp), %xmm6
	movaps	48(%rsp), %xmm7
	.seh_startepilogue
	addq	$64, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
.LBB0_5:
	xorpd	%xmm1, %xmm1
	maxsd	%xmm1, %xmm0
	maxsd	%xmm0, %xmm2
	maxsd	%xmm2, %xmm3
	maxsd	%xmm3, %xmm4
	movsd	%xmm4, 8(%rsi)
	movb	$-1, (%rsi)
	jmp	.LBB0_6
	.seh_endproc

	.def	_RNvCs7hjGl8LVxbh_20algebraic_norm_study12algebraic_d5;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvCs7hjGl8LVxbh_20algebraic_norm_study12algebraic_d5,unique,1
	.globl	_RNvCs7hjGl8LVxbh_20algebraic_norm_study12algebraic_d5
	.p2align	4
_RNvCs7hjGl8LVxbh_20algebraic_norm_study12algebraic_d5:
.seh_proc _RNvCs7hjGl8LVxbh_20algebraic_norm_study12algebraic_d5
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$80, %rsp
	.seh_stackalloc 80
	movapd	%xmm8, 64(%rsp)
	.seh_savexmm %xmm8, 64
	movapd	%xmm7, 48(%rsp)
	.seh_savexmm %xmm7, 48
	movapd	%xmm6, 32(%rsp)
	.seh_savexmm %xmm6, 32
	.seh_endprologue
	movq	%rcx, %rsi
	movapd	__xmm@7fffffffffffffff7fffffffffffffff(%rip), %xmm0
	movsd	(%rdx), %xmm1
	movsd	8(%rdx), %xmm2
	movsd	16(%rdx), %xmm3
	movsd	24(%rdx), %xmm4
	andpd	%xmm0, %xmm1
	andpd	%xmm0, %xmm2
	addsd	%xmm1, %xmm2
	andpd	%xmm0, %xmm3
	andpd	%xmm0, %xmm4
	addsd	%xmm3, %xmm4
	addsd	%xmm2, %xmm4
	movsd	32(%rdx), %xmm1
	andpd	%xmm0, %xmm1
	addsd	%xmm4, %xmm1
	movq	%xmm1, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2047, %eax
	jae	.LBB1_1
	movsd	40(%rdx), %xmm2
	movsd	48(%rdx), %xmm3
	movsd	56(%rdx), %xmm4
	movsd	64(%rdx), %xmm5
	andpd	%xmm0, %xmm2
	andpd	%xmm0, %xmm3
	addsd	%xmm2, %xmm3
	andpd	%xmm0, %xmm4
	andpd	%xmm0, %xmm5
	addsd	%xmm4, %xmm5
	addsd	%xmm3, %xmm5
	movsd	72(%rdx), %xmm2
	andpd	%xmm0, %xmm2
	addsd	%xmm5, %xmm2
	movq	%xmm2, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	ja	.LBB1_1
	movsd	80(%rdx), %xmm3
	movsd	88(%rdx), %xmm4
	movsd	96(%rdx), %xmm5
	movsd	104(%rdx), %xmm6
	andpd	%xmm0, %xmm3
	andpd	%xmm0, %xmm4
	addsd	%xmm3, %xmm4
	andpd	%xmm0, %xmm5
	andpd	%xmm0, %xmm6
	addsd	%xmm5, %xmm6
	addsd	%xmm4, %xmm6
	movsd	112(%rdx), %xmm3
	andpd	%xmm0, %xmm3
	addsd	%xmm6, %xmm3
	movq	%xmm3, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	ja	.LBB1_1
	movsd	120(%rdx), %xmm4
	movsd	128(%rdx), %xmm5
	movsd	136(%rdx), %xmm6
	movsd	144(%rdx), %xmm7
	andpd	%xmm0, %xmm4
	andpd	%xmm0, %xmm5
	addsd	%xmm4, %xmm5
	andpd	%xmm0, %xmm6
	andpd	%xmm0, %xmm7
	addsd	%xmm6, %xmm7
	addsd	%xmm5, %xmm7
	movsd	152(%rdx), %xmm4
	andpd	%xmm0, %xmm4
	addsd	%xmm7, %xmm4
	movq	%xmm4, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	ja	.LBB1_1
	movsd	160(%rdx), %xmm5
	movsd	168(%rdx), %xmm6
	movsd	176(%rdx), %xmm7
	movsd	184(%rdx), %xmm8
	andpd	%xmm0, %xmm5
	andpd	%xmm0, %xmm6
	addsd	%xmm5, %xmm6
	andpd	%xmm0, %xmm7
	andpd	%xmm0, %xmm8
	addsd	%xmm7, %xmm8
	addsd	%xmm6, %xmm8
	movsd	192(%rdx), %xmm5
	andpd	%xmm0, %xmm5
	addsd	%xmm8, %xmm5
	movq	%xmm5, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	jbe	.LBB1_6
.LBB1_1:
	movq	%rsi, %rcx
	callq	_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj5_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study
.LBB1_7:
	movq	%rsi, %rax
	movaps	32(%rsp), %xmm6
	movaps	48(%rsp), %xmm7
	movaps	64(%rsp), %xmm8
	.seh_startepilogue
	addq	$80, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
.LBB1_6:
	xorpd	%xmm0, %xmm0
	maxsd	%xmm0, %xmm1
	maxsd	%xmm1, %xmm2
	maxsd	%xmm2, %xmm3
	maxsd	%xmm3, %xmm4
	maxsd	%xmm4, %xmm5
	movsd	%xmm5, 8(%rsi)
	movb	$-1, (%rsi)
	jmp	.LBB1_7
	.seh_endproc

	.def	_RNvCs7hjGl8LVxbh_20algebraic_norm_study9strict_d4;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvCs7hjGl8LVxbh_20algebraic_norm_study9strict_d4,unique,2
	.globl	_RNvCs7hjGl8LVxbh_20algebraic_norm_study9strict_d4
	.p2align	4
_RNvCs7hjGl8LVxbh_20algebraic_norm_study9strict_d4:
.seh_proc _RNvCs7hjGl8LVxbh_20algebraic_norm_study9strict_d4
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	%rcx, %rsi
	callq	_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj4_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_RNvCs7hjGl8LVxbh_20algebraic_norm_study9strict_d5;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvCs7hjGl8LVxbh_20algebraic_norm_study9strict_d5,unique,3
	.globl	_RNvCs7hjGl8LVxbh_20algebraic_norm_study9strict_d5
	.p2align	4
_RNvCs7hjGl8LVxbh_20algebraic_norm_study9strict_d5:
.seh_proc _RNvCs7hjGl8LVxbh_20algebraic_norm_study9strict_d5
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	%rcx, %rsi
	callq	_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj5_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj4_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study;
	.scl	3;
	.type	32;
	.endef
	.globl	__real@7ff0000000000000
	.section	.rdata,"dr",discard,__real@7ff0000000000000
	.p2align	3, 0x0
__real@7ff0000000000000:
	.quad	0x7ff0000000000000
	.section	.text,"xr",one_only,_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj4_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study,unique,4
	.p2align	4
_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj4_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study:
.seh_proc _RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj4_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study
	subq	$40, %rsp
	.seh_stackalloc 40
	movapd	%xmm7, 16(%rsp)
	.seh_savexmm %xmm7, 16
	movapd	%xmm6, (%rsp)
	.seh_savexmm %xmm6, 0
	.seh_endprologue
	movapd	__xmm@7fffffffffffffff7fffffffffffffff(%rip), %xmm2
	movsd	(%rdx), %xmm0
	movsd	8(%rdx), %xmm3
	movsd	16(%rdx), %xmm4
	movsd	24(%rdx), %xmm1
	andpd	%xmm2, %xmm0
	andpd	%xmm2, %xmm3
	addsd	%xmm0, %xmm3
	andpd	%xmm2, %xmm4
	addsd	%xmm3, %xmm4
	andpd	%xmm2, %xmm1
	addsd	%xmm4, %xmm1
	movq	%xmm1, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	ja	.LBB4_5
	movsd	32(%rdx), %xmm0
	movsd	40(%rdx), %xmm4
	movsd	48(%rdx), %xmm5
	movsd	56(%rdx), %xmm3
	andpd	%xmm2, %xmm0
	andpd	%xmm2, %xmm4
	addsd	%xmm0, %xmm4
	andpd	%xmm2, %xmm5
	addsd	%xmm4, %xmm5
	andpd	%xmm2, %xmm3
	addsd	%xmm5, %xmm3
	movq	%xmm3, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	ja	.LBB4_6
	movsd	64(%rdx), %xmm0
	movsd	72(%rdx), %xmm5
	movsd	80(%rdx), %xmm6
	movsd	88(%rdx), %xmm4
	andpd	%xmm2, %xmm0
	andpd	%xmm2, %xmm5
	addsd	%xmm0, %xmm5
	andpd	%xmm2, %xmm6
	addsd	%xmm5, %xmm6
	andpd	%xmm2, %xmm4
	addsd	%xmm6, %xmm4
	movq	%xmm4, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	ja	.LBB4_7
	movsd	96(%rdx), %xmm0
	movsd	104(%rdx), %xmm6
	movsd	112(%rdx), %xmm7
	movsd	120(%rdx), %xmm5
	andpd	%xmm2, %xmm0
	andpd	%xmm2, %xmm6
	addsd	%xmm0, %xmm6
	andpd	%xmm2, %xmm7
	addsd	%xmm6, %xmm7
	andpd	%xmm2, %xmm5
	addsd	%xmm7, %xmm5
	movq	%xmm5, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	ja	.LBB4_8
	xorpd	%xmm0, %xmm0
	maxsd	%xmm0, %xmm1
	maxsd	%xmm1, %xmm3
	maxsd	%xmm3, %xmm4
	maxsd	%xmm4, %xmm5
	movsd	%xmm5, 8(%rcx)
	movb	$-1, (%rcx)
	movaps	(%rsp), %xmm6
	movaps	16(%rsp), %xmm7
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB4_5:
	xorl	%eax, %eax
	jmp	.LBB4_9
.LBB4_6:
	addq	$32, %rdx
	movl	$1, %eax
	jmp	.LBB4_9
.LBB4_7:
	addq	$64, %rdx
	movl	$2, %eax
	jmp	.LBB4_9
.LBB4_8:
	addq	$96, %rdx
	movl	$3, %eax
.LBB4_9:
	ucomisd	__real@7ff0000000000000(%rip), %xmm0
	je	.LBB4_13
	movsd	8(%rdx), %xmm1
	andpd	__xmm@7fffffffffffffff7fffffffffffffff(%rip), %xmm1
	addsd	%xmm1, %xmm0
	movq	%xmm0, %r9
	shrq	$52, %r9
	andl	$2047, %r9d
	movl	$1, %r8d
	cmpl	$2046, %r9d
	ja	.LBB4_14
	movsd	16(%rdx), %xmm1
	andpd	__xmm@7fffffffffffffff7fffffffffffffff(%rip), %xmm1
	addsd	%xmm1, %xmm0
	movq	%xmm0, %rdx
	shrq	$52, %rdx
	andl	$2047, %edx
	movl	$2, %r8d
	cmpl	$2046, %edx
	ja	.LBB4_14
	movl	$3, %r8d
	jmp	.LBB4_14
.LBB4_13:
	xorl	%r8d, %r8d
.LBB4_14:
	movw	$4, (%rcx)
	movb	$0, 8(%rcx)
	movq	%rax, 16(%rcx)
	movq	%r8, 24(%rcx)
	movaps	(%rsp), %xmm6
	movaps	16(%rsp), %xmm7
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj5_E23norm_inf_overflow_errorCs7hjGl8LVxbh_20algebraic_norm_study;
	.scl	3;
	.type	32;
	.endef
	.section	.text$unlikely,"xr",one_only,_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj5_E23norm_inf_overflow_errorCs7hjGl8LVxbh_20algebraic_norm_study,unique,5
	.p2align	4
_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj5_E23norm_inf_overflow_errorCs7hjGl8LVxbh_20algebraic_norm_study:
	movq	(%rdx), %xmm1
	movq	%xmm1, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2047, %eax
	jb	.LBB5_3
	xorl	%eax, %eax
	jmp	.LBB5_2
.LBB5_3:
	pand	__xmm@7fffffffffffffff7fffffffffffffff(%rip), %xmm1
	movsd	8(%rdx), %xmm0
	andpd	__xmm@7fffffffffffffff7fffffffffffffff(%rip), %xmm0
	addsd	%xmm1, %xmm0
	movq	%xmm0, %r9
	shrq	$52, %r9
	andl	$2047, %r9d
	movl	$1, %eax
	cmpl	$2046, %r9d
	ja	.LBB5_2
	movsd	16(%rdx), %xmm1
	andpd	__xmm@7fffffffffffffff7fffffffffffffff(%rip), %xmm1
	addsd	%xmm1, %xmm0
	movq	%xmm0, %r9
	shrq	$52, %r9
	andl	$2047, %r9d
	movl	$2, %eax
	cmpl	$2046, %r9d
	ja	.LBB5_2
	movsd	24(%rdx), %xmm1
	andpd	__xmm@7fffffffffffffff7fffffffffffffff(%rip), %xmm1
	addsd	%xmm1, %xmm0
	movq	%xmm0, %rdx
	shrq	$52, %rdx
	andl	$2047, %edx
	movl	$3, %eax
	cmpl	$2046, %edx
	ja	.LBB5_2
	movl	$4, %eax
.LBB5_2:
	movb	$0, 8(%rcx)
	movq	%r8, 16(%rcx)
	movq	%rax, 24(%rcx)
	movw	$4, (%rcx)
	retq

	.def	_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj5_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj5_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study,unique,6
	.p2align	4
_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj5_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study:
.seh_proc _RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj5_E8norm_infCs7hjGl8LVxbh_20algebraic_norm_study
	subq	$88, %rsp
	.seh_stackalloc 88
	movapd	%xmm8, 64(%rsp)
	.seh_savexmm %xmm8, 64
	movapd	%xmm7, 48(%rsp)
	.seh_savexmm %xmm7, 48
	movapd	%xmm6, 32(%rsp)
	.seh_savexmm %xmm6, 32
	.seh_endprologue
	movapd	__xmm@7fffffffffffffff7fffffffffffffff(%rip), %xmm0
	movsd	(%rdx), %xmm1
	movsd	8(%rdx), %xmm2
	movsd	16(%rdx), %xmm3
	movsd	24(%rdx), %xmm4
	andpd	%xmm0, %xmm1
	andpd	%xmm0, %xmm2
	addsd	%xmm1, %xmm2
	andpd	%xmm0, %xmm3
	addsd	%xmm2, %xmm3
	andpd	%xmm0, %xmm4
	addsd	%xmm3, %xmm4
	movsd	32(%rdx), %xmm1
	andpd	%xmm0, %xmm1
	addsd	%xmm4, %xmm1
	movq	%xmm1, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	ja	.LBB6_1
	movsd	40(%rdx), %xmm2
	movsd	48(%rdx), %xmm3
	movsd	56(%rdx), %xmm4
	movsd	64(%rdx), %xmm5
	andpd	%xmm0, %xmm2
	andpd	%xmm0, %xmm3
	addsd	%xmm2, %xmm3
	andpd	%xmm0, %xmm4
	addsd	%xmm3, %xmm4
	andpd	%xmm0, %xmm5
	addsd	%xmm4, %xmm5
	movsd	72(%rdx), %xmm2
	andpd	%xmm0, %xmm2
	addsd	%xmm5, %xmm2
	movq	%xmm2, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	ja	.LBB6_4
	movsd	80(%rdx), %xmm3
	movsd	88(%rdx), %xmm4
	movsd	96(%rdx), %xmm5
	movsd	104(%rdx), %xmm6
	andpd	%xmm0, %xmm3
	andpd	%xmm0, %xmm4
	addsd	%xmm3, %xmm4
	andpd	%xmm0, %xmm5
	addsd	%xmm4, %xmm5
	andpd	%xmm0, %xmm6
	addsd	%xmm5, %xmm6
	movsd	112(%rdx), %xmm3
	andpd	%xmm0, %xmm3
	addsd	%xmm6, %xmm3
	movq	%xmm3, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	ja	.LBB6_6
	movsd	120(%rdx), %xmm4
	movsd	128(%rdx), %xmm5
	movsd	136(%rdx), %xmm6
	movsd	144(%rdx), %xmm7
	andpd	%xmm0, %xmm4
	andpd	%xmm0, %xmm5
	addsd	%xmm4, %xmm5
	andpd	%xmm0, %xmm6
	addsd	%xmm5, %xmm6
	andpd	%xmm0, %xmm7
	addsd	%xmm6, %xmm7
	movsd	152(%rdx), %xmm4
	andpd	%xmm0, %xmm4
	addsd	%xmm7, %xmm4
	movq	%xmm4, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	ja	.LBB6_8
	movsd	160(%rdx), %xmm5
	movsd	168(%rdx), %xmm6
	movsd	176(%rdx), %xmm7
	movsd	184(%rdx), %xmm8
	andpd	%xmm0, %xmm5
	andpd	%xmm0, %xmm6
	addsd	%xmm5, %xmm6
	andpd	%xmm0, %xmm7
	addsd	%xmm6, %xmm7
	andpd	%xmm0, %xmm8
	addsd	%xmm7, %xmm8
	movsd	192(%rdx), %xmm5
	andpd	%xmm0, %xmm5
	addsd	%xmm8, %xmm5
	movq	%xmm5, %rax
	shrq	$52, %rax
	andl	$2047, %eax
	cmpl	$2046, %eax
	ja	.LBB6_10
	xorpd	%xmm0, %xmm0
	maxsd	%xmm0, %xmm1
	maxsd	%xmm1, %xmm2
	maxsd	%xmm2, %xmm3
	maxsd	%xmm3, %xmm4
	maxsd	%xmm4, %xmm5
	movsd	%xmm5, 8(%rcx)
	movb	$-1, (%rcx)
.LBB6_12:
	movaps	32(%rsp), %xmm6
	movaps	48(%rsp), %xmm7
	movaps	64(%rsp), %xmm8
	.seh_startepilogue
	addq	$88, %rsp
	.seh_endepilogue
	retq
.LBB6_1:
	xorl	%r8d, %r8d
	callq	_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj5_E23norm_inf_overflow_errorCs7hjGl8LVxbh_20algebraic_norm_study
	jmp	.LBB6_12
.LBB6_4:
	addq	$40, %rdx
	movl	$1, %r8d
	callq	_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj5_E23norm_inf_overflow_errorCs7hjGl8LVxbh_20algebraic_norm_study
	jmp	.LBB6_12
.LBB6_6:
	addq	$80, %rdx
	movl	$2, %r8d
	callq	_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj5_E23norm_inf_overflow_errorCs7hjGl8LVxbh_20algebraic_norm_study
	jmp	.LBB6_12
.LBB6_8:
	addq	$120, %rdx
	movl	$3, %r8d
	callq	_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj5_E23norm_inf_overflow_errorCs7hjGl8LVxbh_20algebraic_norm_study
	jmp	.LBB6_12
.LBB6_10:
	addq	$160, %rdx
	movl	$4, %r8d
	callq	_RNvMs2_NtCs4UK2K2XJ2rN_8la_stack6matrixINtB5_6MatrixKj5_E23norm_inf_overflow_errorCs7hjGl8LVxbh_20algebraic_norm_study
	jmp	.LBB6_12
	.seh_endproc

	.globl	_fltused
