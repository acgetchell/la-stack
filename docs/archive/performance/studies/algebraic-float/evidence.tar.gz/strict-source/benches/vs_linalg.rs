#![forbid(unsafe_code)]

//! Benchmark comparison between la-stack and other Rust linear algebra crates.
//!
//! Goal: like-for-like comparisons of the operations la-stack supports across several
//! fixed dimensions.
//!
//! Notes:
//! - Determinant groups distinguish factorization-inclusive LU, `Matrix::det`,
//!   precomputed LU determinant queries, and precomputed LDLT/Cholesky queries.
//! - Matrix infinity norm is the maximum absolute row sum on all sides.
//! - Euclidean-norm rows include safe reference kernels as well as peer crates.

use std::hint::black_box;

use criterion::measurement::WallTime;
use criterion::{BenchmarkGroup, Criterion};
use faer::linalg::matmul::dot::inner_prod;
use faer::linalg::solvers::Solve;
use faer::mat::AsMatRef;
use faer::{Conj, Mat, Side};
use nalgebra::{Const, DimMin, SMatrix, SVector};

use la_stack::{DEFAULT_SINGULAR_TOL, Matrix, Tolerance, Vector};

#[path = "common/bench_utils.rs"]
mod bench_utils;
#[path = "common/vs_linalg.rs"]
pub mod vs_linalg_common;

use bench_utils::OrAbort;
#[cfg(not(la_stack_pre_rational_input_api))]
use vs_linalg_common::norm_scenarios;
use vs_linalg_common::{LuSolveScenario, validated_lu_solve_input};
use vs_linalg_common::{
    PreparedFaerLuDet, delaunay_scaled_norm, faer_det_from_ldlt, iterative_hypot,
    la_stack_norm_inf, la_stack_norm_squared, make_balanced_dynamic_range_rows,
    make_ill_conditioned_matrix_rows, make_matrix_rows, make_pivoting_matrix_rows,
    make_vector_array, matrix_entry, nalgebra_inf_norm, vector_entry,
};

/// Build the deterministic la-stack matrix shared by a benchmark family.
fn la_matrix<const D: usize>() -> Matrix<D> {
    Matrix::try_from_rows(make_matrix_rows()).or_abort("la_stack matrix construction")
}

/// Build a deterministic la-stack vector with the requested offset.
fn la_vector<const D: usize>(offset: f64, operation: &str) -> Vector<D> {
    Vector::try_new(make_vector_array(offset)).or_abort(operation)
}

/// Build the deterministic nalgebra matrix shared by a benchmark family.
fn nalgebra_matrix<const D: usize>() -> SMatrix<f64, D, D> {
    SMatrix::from_fn(matrix_entry::<D>)
}

/// Build a deterministic nalgebra vector with the requested offset.
fn nalgebra_vector<const D: usize>(offset: f64) -> SVector<f64, D> {
    SVector::from_fn(|i, _| vector_entry(i, offset))
}

/// Build the deterministic faer matrix shared by a benchmark family.
fn faer_matrix<const D: usize>() -> Mat<f64> {
    Mat::from_fn(D, D, matrix_entry::<D>)
}

/// Build a deterministic faer column vector with the requested offset.
fn faer_vector<const D: usize>(offset: f64) -> Mat<f64> {
    Mat::from_fn(D, 1, |i, _| vector_entry(i, offset))
}

/// Register determinant benchmarks that include factorization work.
fn register_determinant_benchmarks<const D: usize>(group: &mut BenchmarkGroup<'_, WallTime>)
where
    Const<D>: DimMin<Const<D>, Output = Const<D>>,
{
    let a = la_matrix::<D>();
    let na = nalgebra_matrix::<D>();
    let fa = faer_matrix::<D>();

    group.bench_function("la_stack_det_via_lu", |bencher| {
        bencher.iter(|| {
            let lu = black_box(a)
                .lu(DEFAULT_SINGULAR_TOL)
                .or_abort("la_stack LU factorization");
            let det = lu.det().or_abort("la_stack LU determinant");
            black_box(det);
        });
    });

    group.bench_function("nalgebra_det_via_lu", |bencher| {
        bencher.iter(|| {
            let lu = black_box(na).lu();
            let det = lu.determinant();
            black_box(det);
        });
    });

    group.bench_function("faer_det_via_lu", |bencher| {
        bencher.iter(|| {
            let lu = black_box(&fa).partial_piv_lu();
            let det = PreparedFaerLuDet::new(&lu).det();
            black_box(det);
        });
    });

    group.bench_function("la_stack_det", |bencher| {
        bencher.iter(|| {
            let det = black_box(a).det().or_abort("la_stack determinant");
            black_box(det);
        });
    });
}

/// Register LU, LDLT, and Cholesky factorization benchmarks.
fn register_factorization_benchmarks<const D: usize>(group: &mut BenchmarkGroup<'_, WallTime>)
where
    Const<D>: DimMin<Const<D>, Output = Const<D>>,
{
    let a = la_matrix::<D>();
    let na = nalgebra_matrix::<D>();
    let fa = faer_matrix::<D>();

    group.bench_function("la_stack_lu", |bencher| {
        bencher.iter(|| {
            let lu = black_box(a)
                .lu(DEFAULT_SINGULAR_TOL)
                .or_abort("la_stack LU factorization");
            let _ = black_box(lu);
        });
    });

    group.bench_function("nalgebra_lu", |bencher| {
        bencher.iter(|| {
            let lu = black_box(na).lu();
            let _ = black_box(lu);
        });
    });

    group.bench_function("faer_lu", |bencher| {
        bencher.iter(|| {
            let lu = black_box(&fa).partial_piv_lu();
            let _ = black_box(lu);
        });
    });

    group.bench_function("la_stack_ldlt", |bencher| {
        bencher.iter(|| {
            let ldlt = black_box(a)
                .ldlt(DEFAULT_SINGULAR_TOL)
                .or_abort("la_stack LDLT factorization");
            let _ = black_box(ldlt);
        });
    });

    group.bench_function("nalgebra_cholesky", |bencher| {
        bencher.iter(|| {
            let chol = black_box(na)
                .cholesky()
                .or_abort("nalgebra Cholesky factorization");
            black_box(chol);
        });
    });

    group.bench_function("faer_ldlt", |bencher| {
        bencher.iter(|| {
            let ldlt = black_box(&fa)
                .ldlt(Side::Lower)
                .or_abort("faer LDLT factorization");
            let _ = black_box(ldlt);
        });
    });
}

/// Register solves that include LU factorization work.
fn register_lu_solve_benchmarks<const D: usize>(group: &mut BenchmarkGroup<'_, WallTime>)
where
    Const<D>: DimMin<Const<D>, Output = Const<D>>,
{
    let a = la_matrix::<D>();
    let rhs = la_vector::<D>(0.0, "la_stack RHS vector construction");
    let na = nalgebra_matrix::<D>();
    let nrhs = nalgebra_vector::<D>(0.0);
    let fa = faer_matrix::<D>();
    let frhs = faer_vector::<D>(0.0);

    group.bench_function("la_stack_lu_solve", |bencher| {
        bencher.iter(|| {
            let lu = black_box(a)
                .lu(DEFAULT_SINGULAR_TOL)
                .or_abort("la_stack LU factorization");
            let x = lu.solve(black_box(rhs)).or_abort("la_stack LU solve");
            let _ = black_box(x);
        });
    });

    group.bench_function("nalgebra_lu_solve", |bencher| {
        bencher.iter(|| {
            let lu = black_box(na).lu();
            let x = lu.solve(black_box(&nrhs)).or_abort("nalgebra LU solve");
            black_box(x);
        });
    });

    group.bench_function("faer_lu_solve", |bencher| {
        bencher.iter(|| {
            let lu = black_box(&fa).partial_piv_lu();
            let x = lu.solve(black_box(&frhs));
            black_box(x);
        });
    });
}

/// Register solves that include LDLT or Cholesky factorization work.
fn register_ldlt_solve_benchmarks<const D: usize>(group: &mut BenchmarkGroup<'_, WallTime>) {
    let a = la_matrix::<D>();
    let rhs = la_vector::<D>(0.0, "la_stack RHS vector construction");
    let na = nalgebra_matrix::<D>();
    let nrhs = nalgebra_vector::<D>(0.0);
    let fa = faer_matrix::<D>();
    let frhs = faer_vector::<D>(0.0);

    group.bench_function("la_stack_ldlt_solve", |bencher| {
        bencher.iter(|| {
            let ldlt = black_box(a)
                .ldlt(DEFAULT_SINGULAR_TOL)
                .or_abort("la_stack LDLT factorization");
            let x = ldlt.solve(black_box(rhs)).or_abort("la_stack LDLT solve");
            let _ = black_box(x);
        });
    });

    group.bench_function("nalgebra_cholesky_solve", |bencher| {
        bencher.iter(|| {
            let chol = black_box(na)
                .cholesky()
                .or_abort("nalgebra Cholesky factorization");
            let x = chol.solve(black_box(&nrhs));
            black_box(x);
        });
    });

    group.bench_function("faer_ldlt_solve", |bencher| {
        bencher.iter(|| {
            let ldlt = black_box(&fa)
                .ldlt(Side::Lower)
                .or_abort("faer LDLT factorization");
            let x = ldlt.solve(black_box(&frhs));
            black_box(x);
        });
    });
}

/// Register solves using precomputed LU factorizations.
fn register_precomputed_lu_solve_benchmarks<const D: usize>(
    group: &mut BenchmarkGroup<'_, WallTime>,
) where
    Const<D>: DimMin<Const<D>, Output = Const<D>>,
{
    let a = la_matrix::<D>();
    let rhs = la_vector::<D>(0.0, "la_stack RHS vector construction");
    let na = nalgebra_matrix::<D>();
    let nrhs = nalgebra_vector::<D>(0.0);
    let fa = faer_matrix::<D>();
    let frhs = faer_vector::<D>(0.0);
    let a_lu = a
        .lu(DEFAULT_SINGULAR_TOL)
        .or_abort("precomputed la_stack LU");
    let na_lu = na.lu();
    let fa_lu = fa.partial_piv_lu();

    group.bench_function("la_stack_solve_from_lu", |bencher| {
        bencher.iter(|| {
            let x = black_box(&a_lu)
                .solve(black_box(rhs))
                .or_abort("precomputed la_stack LU solve");
            let _ = black_box(x);
        });
    });

    group.bench_function("nalgebra_solve_from_lu", |bencher| {
        bencher.iter(|| {
            let x = black_box(&na_lu)
                .solve(black_box(&nrhs))
                .or_abort("precomputed nalgebra LU solve");
            black_box(x);
        });
    });

    group.bench_function("faer_solve_from_lu", |bencher| {
        bencher.iter(|| {
            let x = black_box(&fa_lu).solve(black_box(&frhs));
            black_box(x);
        });
    });
}

/// Register solves using precomputed LDLT or Cholesky factorizations.
fn register_precomputed_ldlt_solve_benchmarks<const D: usize>(
    group: &mut BenchmarkGroup<'_, WallTime>,
) {
    let a = la_matrix::<D>();
    let rhs = la_vector::<D>(0.0, "la_stack RHS vector construction");
    let na = nalgebra_matrix::<D>();
    let nrhs = nalgebra_vector::<D>(0.0);
    let fa = faer_matrix::<D>();
    let frhs = faer_vector::<D>(0.0);
    let a_ldlt = a
        .ldlt(DEFAULT_SINGULAR_TOL)
        .or_abort("precomputed la_stack LDLT");
    let na_cholesky = na.cholesky().or_abort("precomputed nalgebra Cholesky");
    let fa_ldlt = fa.ldlt(Side::Lower).or_abort("precomputed faer LDLT");

    group.bench_function("la_stack_solve_from_ldlt", |bencher| {
        bencher.iter(|| {
            let x = black_box(&a_ldlt)
                .solve(black_box(rhs))
                .or_abort("precomputed la_stack LDLT solve");
            let _ = black_box(x);
        });
    });

    group.bench_function("nalgebra_solve_from_cholesky", |bencher| {
        bencher.iter(|| {
            let x = black_box(&na_cholesky).solve(black_box(&nrhs));
            black_box(x);
        });
    });

    group.bench_function("faer_solve_from_ldlt", |bencher| {
        bencher.iter(|| {
            let x = black_box(&fa_ldlt).solve(black_box(&frhs));
            black_box(x);
        });
    });
}

/// Register determinant queries using precomputed LU factorizations.
fn register_precomputed_lu_determinant_benchmarks<const D: usize>(
    group: &mut BenchmarkGroup<'_, WallTime>,
) where
    Const<D>: DimMin<Const<D>, Output = Const<D>>,
{
    let a = la_matrix::<D>();
    let na = nalgebra_matrix::<D>();
    let fa = faer_matrix::<D>();
    let a_lu = a
        .lu(DEFAULT_SINGULAR_TOL)
        .or_abort("precomputed la_stack LU");
    let na_lu = na.lu();
    let fa_lu = fa.partial_piv_lu();
    let fa_lu_det = PreparedFaerLuDet::new(&fa_lu);

    group.bench_function("la_stack_det_from_lu", |bencher| {
        bencher.iter(|| {
            let det = black_box(&a_lu)
                .det()
                .or_abort("precomputed la_stack LU determinant");
            black_box(det);
        });
    });

    group.bench_function("nalgebra_det_from_lu", |bencher| {
        bencher.iter(|| {
            let det = black_box(&na_lu).determinant();
            black_box(det);
        });
    });

    group.bench_function("faer_det_from_lu", |bencher| {
        bencher.iter(|| {
            let det = black_box(&fa_lu_det).det();
            black_box(det);
        });
    });
}

/// Register determinant queries using precomputed LDLT or Cholesky factorizations.
fn register_precomputed_ldlt_determinant_benchmarks<const D: usize>(
    group: &mut BenchmarkGroup<'_, WallTime>,
) {
    let a = la_matrix::<D>();
    let na = nalgebra_matrix::<D>();
    let fa = faer_matrix::<D>();
    let a_ldlt = a
        .ldlt(DEFAULT_SINGULAR_TOL)
        .or_abort("precomputed la_stack LDLT");
    let na_cholesky = na.cholesky().or_abort("precomputed nalgebra Cholesky");
    let fa_ldlt = fa.ldlt(Side::Lower).or_abort("precomputed faer LDLT");

    group.bench_function("la_stack_det_from_ldlt", |bencher| {
        bencher.iter(|| {
            let det = black_box(&a_ldlt)
                .det()
                .or_abort("precomputed la_stack LDLT determinant");
            black_box(det);
        });
    });

    group.bench_function("nalgebra_det_from_cholesky", |bencher| {
        bencher.iter(|| {
            let det = black_box(&na_cholesky).determinant();
            black_box(det);
        });
    });

    group.bench_function("faer_det_from_ldlt", |bencher| {
        bencher.iter(|| {
            let det = faer_det_from_ldlt(black_box(&fa_ldlt));
            black_box(det);
        });
    });
}

/// Register vector dot-product, squared-norm, and Euclidean-norm benchmarks.
fn register_vector_benchmarks<const D: usize>(group: &mut BenchmarkGroup<'_, WallTime>) {
    let v1 = la_vector::<D>(0.0, "la_stack vector construction");
    let v2 = la_vector::<D>(1.0, "la_stack vector construction");
    let nv1 = nalgebra_vector::<D>(0.0);
    let nv2 = nalgebra_vector::<D>(1.0);
    let fv1 = faer_vector::<D>(0.0);
    let fv2 = faer_vector::<D>(1.0);

    group.bench_function("la_stack_dot", |bencher| {
        bencher.iter(|| {
            let result = black_box(&v1).dot(black_box(&v2)).or_abort("la_stack dot");
            black_box(result);
        });
    });

    group.bench_function("nalgebra_dot", |bencher| {
        bencher.iter(|| {
            let result = black_box(&nv1).dot(black_box(&nv2));
            black_box(result);
        });
    });

    // Keep the native kernel distinct from historical scalar-loop measurements.
    group.bench_function("faer_dot_native", |bencher| {
        bencher.iter(|| {
            let a = black_box(&fv1);
            let b = black_box(&fv2);
            let result = inner_prod(a.col(0).transpose(), Conj::No, b.col(0), Conj::No);
            black_box(result);
        });
    });

    group.bench_function("la_stack_norm2_sq", |bencher| {
        bencher.iter(|| {
            let result = la_stack_norm_squared(black_box(&v1)).or_abort("la_stack norm_squared");
            black_box(result);
        });
    });

    group.bench_function("nalgebra_norm_squared", |bencher| {
        bencher.iter(|| {
            let result = black_box(&nv1).norm_squared();
            black_box(result);
        });
    });

    group.bench_function("faer_norm2_sq", |bencher| {
        bencher.iter(|| {
            let v = black_box(&fv1);
            let result = v.as_mat_ref().squared_norm_l2();
            black_box(result);
        });
    });

    #[cfg(not(la_stack_pre_rational_input_api))]
    {
        group.bench_function("la_stack_norm2", |bencher| {
            bencher.iter(|| {
                let result = black_box(&v1).norm().or_abort("la_stack norm");
                black_box(result);
            });
        });
    }

    group.bench_function("iterative_f64_hypot", |bencher| {
        bencher.iter(|| {
            let result = iterative_hypot(black_box(v1.as_array()));
            black_box(result);
        });
    });

    group.bench_function("delaunay_scaled_norm", |bencher| {
        bencher.iter(|| {
            let result = delaunay_scaled_norm(black_box(v1.as_array()));
            black_box(result);
        });
    });

    group.bench_function("nalgebra_norm", |bencher| {
        bencher.iter(|| {
            let result = black_box(&nv1).norm();
            black_box(result);
        });
    });

    group.bench_function("faer_norm_l2", |bencher| {
        bencher.iter(|| {
            let result = black_box(&fv1).as_mat_ref().norm_l2();
            black_box(result);
        });
    });
}

/// Validate and register safe Euclidean-norm kernels across branch and range profiles.
#[cfg(not(la_stack_pre_rational_input_api))]
fn register_norm_scenario_benchmarks<const D: usize>(group: &mut BenchmarkGroup<'_, WallTime>) {
    for (scenario, values) in norm_scenarios::<D>() {
        let vector = Vector::try_new(values).or_abort("norm scenario vector construction");
        let la_stack = vector.norm().or_abort("la_stack norm scenario validation");
        let hypot = iterative_hypot(&values);
        let delaunay = delaunay_scaled_norm(&values);
        let scale = la_stack.abs().max(hypot.abs()).max(delaunay.abs()).max(1.0);
        assert!(
            la_stack.is_finite()
                && hypot.is_finite()
                && delaunay.is_finite()
                && (hypot - la_stack).abs() <= 1.0e-12 * scale
                && (delaunay - la_stack).abs() <= 1.0e-12 * scale,
            "norm benchmark scenario {scenario} failed setup validation: \
             la_stack={la_stack:?}, hypot={hypot:?}, delaunay={delaunay:?}",
        );

        group.bench_function(format!("la_stack_norm2_scenario_{scenario}"), |bencher| {
            bencher.iter(|| {
                let result = black_box(&vector).norm().or_abort("la_stack norm scenario");
                black_box(result);
            });
        });

        group.bench_function(
            format!("iterative_f64_hypot_norm2_scenario_{scenario}"),
            |bencher| {
                bencher.iter(|| {
                    let result = iterative_hypot(black_box(&values));
                    black_box(result);
                });
            },
        );

        group.bench_function(
            format!("delaunay_scaled_norm_norm2_scenario_{scenario}"),
            |bencher| {
                bencher.iter(|| {
                    let result = delaunay_scaled_norm(black_box(&values));
                    black_box(result);
                });
            },
        );
    }
}

/// Register matrix infinity-norm benchmarks.
fn register_matrix_norm_benchmarks<const D: usize>(group: &mut BenchmarkGroup<'_, WallTime>) {
    let a = la_matrix::<D>();
    let na = nalgebra_matrix::<D>();
    let fa = faer_matrix::<D>();

    group.bench_function("la_stack_inf_norm", |bencher| {
        bencher.iter(|| {
            let result = la_stack_norm_inf(black_box(&a)).or_abort("la_stack norm_inf");
            black_box(result);
        });
    });

    group.bench_function("nalgebra_inf_norm", |bencher| {
        bencher.iter(|| {
            let result = nalgebra_inf_norm::<D>(black_box(&na));
            black_box(result);
        });
    });

    group.bench_function("faer_inf_norm", |bencher| {
        bencher.iter(|| {
            let m = black_box(&fa);
            let mut max_row_sum = 0.0;

            for r in 0..D {
                let mut row_sum = 0.0;
                for c in 0..D {
                    row_sum += m[(r, c)].abs();
                }
                if row_sum > max_row_sum {
                    max_row_sum = row_sum;
                }
            }

            black_box(max_row_sum);
        });
    });
}

/// Register D=8 stress cases that exercise pivoting, conditioning, and scaled products.
fn register_stress_benchmarks(group: &mut BenchmarkGroup<'_, WallTime>) {
    let zero_tolerance = Tolerance::try_new(0.0).or_abort("zero benchmark tolerance");
    let pivoting = Matrix::<8>::try_from_rows(make_pivoting_matrix_rows())
        .or_abort("pivoting benchmark matrix construction");
    let ill_conditioned = Matrix::<8>::try_from_rows(make_ill_conditioned_matrix_rows())
        .or_abort("ill-conditioned benchmark matrix construction");
    let balanced = Matrix::<8>::try_from_rows(make_balanced_dynamic_range_rows())
        .or_abort("balanced-range benchmark matrix construction");

    group.bench_function("la_stack_lu_pivoting", |bencher| {
        bencher.iter(|| {
            let lu = black_box(pivoting)
                .lu(zero_tolerance)
                .or_abort("pivoting LU factorization");
            let _ = black_box(lu);
        });
    });

    group.bench_function("la_stack_lu_ill_conditioned", |bencher| {
        bencher.iter(|| {
            let lu = black_box(ill_conditioned)
                .lu(zero_tolerance)
                .or_abort("ill-conditioned LU factorization");
            let _ = black_box(lu);
        });
    });

    group.bench_function("la_stack_ldlt_ill_conditioned", |bencher| {
        bencher.iter(|| {
            let ldlt = black_box(ill_conditioned)
                .ldlt(zero_tolerance)
                .or_abort("ill-conditioned LDLT factorization");
            let _ = black_box(ldlt);
        });
    });

    let balanced_lu = balanced
        .lu(zero_tolerance)
        .or_abort("balanced-range LU factorization");
    let balanced_ldlt = balanced
        .ldlt(zero_tolerance)
        .or_abort("balanced-range LDLT factorization");

    group.bench_function("la_stack_det_from_lu_balanced_range", |bencher| {
        bencher.iter(|| {
            let det = black_box(&balanced_lu)
                .det()
                .or_abort("balanced-range LU determinant");
            black_box(det);
        });
    });

    group.bench_function("la_stack_det_from_ldlt_balanced_range", |bencher| {
        bencher.iter(|| {
            let det = black_box(&balanced_ldlt)
                .det()
                .or_abort("balanced-range LDLT determinant");
            black_box(det);
        });
    });
}

/// Complete and reusable-factor solves on validated diagnostic systems.
fn register_lu_solve_diagnostics<const D: usize>(c: &mut Criterion)
where
    Const<D>: DimMin<Const<D>, Output = Const<D>>,
{
    for scenario in [
        LuSolveScenario::Pivoting,
        LuSolveScenario::DenseIllConditioned,
    ] {
        let input = validated_lu_solve_input::<D>(scenario);
        let a = *input.matrix();
        let rhs = input.rhs();
        let zero = Tolerance::try_new(0.0).or_abort("diagnostic tolerance");
        let lu = a.lu(zero).or_abort("diagnostic LU");
        let na = SMatrix::<f64, D, D>::from_fn(|i, j| a.as_rows()[i][j]);
        let nrhs = SVector::<f64, D>::from_fn(|i, _| rhs.as_array()[i]);
        let nlu = na.lu();
        let nx = nlu.solve(&nrhs).or_abort("diagnostic nalgebra solve");
        input.validate_solution(&std::array::from_fn(|i| nx[i]));
        let fa = Mat::from_fn(D, D, |i, j| a.as_rows()[i][j]);
        let frhs = Mat::from_fn(D, 1, |i, _| rhs.as_array()[i]);
        let flu = fa.partial_piv_lu();
        let fx = flu.solve(&frhs);
        input.validate_solution(&std::array::from_fn(|i| fx[(i, 0)]));

        let mut group = c.benchmark_group(format!("lu_solve_{}_d{D}", scenario.name()));
        group.bench_function("la_stack_lu_solve", |b| {
            b.iter(|| {
                black_box(
                    black_box(a)
                        .lu(zero)
                        .or_abort("diagnostic LU")
                        .solve(black_box(rhs))
                        .or_abort("diagnostic solve"),
                )
            });
        });
        group.bench_function("la_stack_solve_from_lu", |b| {
            b.iter(|| {
                black_box(
                    black_box(&lu)
                        .solve(black_box(rhs))
                        .or_abort("diagnostic solve"),
                )
            });
        });
        group.bench_function("nalgebra_lu_solve", |b| {
            b.iter(|| {
                black_box(
                    black_box(na)
                        .lu()
                        .solve(black_box(&nrhs))
                        .or_abort("diagnostic nalgebra solve"),
                )
            });
        });
        group.bench_function("nalgebra_solve_from_lu", |b| {
            b.iter(|| {
                black_box(
                    black_box(&nlu)
                        .solve(black_box(&nrhs))
                        .or_abort("diagnostic nalgebra solve"),
                )
            });
        });
        group.bench_function("faer_lu_solve", |b| {
            b.iter(|| black_box(black_box(&fa).partial_piv_lu().solve(black_box(&frhs))));
        });
        group.bench_function("faer_solve_from_lu", |b| {
            b.iter(|| black_box(black_box(&flu).solve(black_box(&frhs))));
        });
        group.finish();
    }
}

macro_rules! define_vs_linalg_benches_for_dim {
    ($fn_name:ident, $d:literal $(, $register_stress:ident)?) => {
        fn $fn_name(c: &mut Criterion) {
            {
                let mut group = c.benchmark_group(concat!("d", stringify!($d)));
                register_determinant_benchmarks::<$d>(&mut group);
                register_factorization_benchmarks::<$d>(&mut group);
                register_lu_solve_benchmarks::<$d>(&mut group);
                register_ldlt_solve_benchmarks::<$d>(&mut group);
                register_precomputed_lu_solve_benchmarks::<$d>(&mut group);
                register_precomputed_ldlt_solve_benchmarks::<$d>(&mut group);
                register_precomputed_lu_determinant_benchmarks::<$d>(&mut group);
                register_precomputed_ldlt_determinant_benchmarks::<$d>(&mut group);
                register_vector_benchmarks::<$d>(&mut group);
                #[cfg(not(la_stack_pre_rational_input_api))]
                register_norm_scenario_benchmarks::<$d>(&mut group);
                register_matrix_norm_benchmarks::<$d>(&mut group);
                $(
                    $register_stress(&mut group);
                )?
                group.finish();
            }
            register_lu_solve_diagnostics::<$d>(c);
        }
    };
}

define_vs_linalg_benches_for_dim!(bench_d2, 2);
define_vs_linalg_benches_for_dim!(bench_d3, 3);
define_vs_linalg_benches_for_dim!(bench_d4, 4);
define_vs_linalg_benches_for_dim!(bench_d5, 5);
define_vs_linalg_benches_for_dim!(bench_d8, 8, register_stress_benchmarks);
define_vs_linalg_benches_for_dim!(bench_d16, 16);
define_vs_linalg_benches_for_dim!(bench_d32, 32);
define_vs_linalg_benches_for_dim!(bench_d64, 64);

fn main() {
    let mut c = Criterion::default().configure_from_args();

    bench_d2(&mut c);
    bench_d3(&mut c);
    bench_d4(&mut c);
    bench_d5(&mut c);

    bench_d8(&mut c);
    bench_d16(&mut c);
    bench_d32(&mut c);
    bench_d64(&mut c);

    c.final_summary();
}
