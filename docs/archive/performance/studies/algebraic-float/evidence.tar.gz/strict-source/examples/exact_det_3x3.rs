#![forbid(unsafe_code)]

//! Exact determinant value for a near-singular 3×3 matrix.
//!
//! This example demonstrates `det_exact()` and [`ExactF64Conversion`], retaining
//! the rational determinant exact for the stored binary64 entries before
//! converting that same value without repeating exact evaluation.
//!
//! Run with: `cargo run --features exact --example exact_det_3x3`

use la_stack::prelude::*;

fn main() -> Result<(), LaError> {
    // Base matrix: rows in arithmetic progression → exactly singular (det = 0).
    //   [[1, 2, 3],
    //    [4, 5, 6],
    //    [7, 8, 9]]
    //
    // Perturb entry (0,0) by 2^-50 ≈ 8.9e-16.
    // Exact det = 2^-50 × cofactor(0,0) = 2^-50 × (5×9 − 6×8) = −3 × 2^-50.
    let perturbation = f64::from_bits(0x3CD0_0000_0000_0000); // 2^-50
    let m = Matrix::<3>::try_from_rows([
        [1.0 + perturbation, 2.0, 3.0],
        [4.0, 5.0, 6.0],
        [7.0, 8.0, 9.0],
    ])?;

    let Some(det_f64_approx) = m.det_direct()? else {
        unreachable!("D=3 is supported by det_direct");
    };
    let det_exact = m.det_exact()?;
    let det_exact_as_f64 = det_exact.try_to_f64()?;
    assert_eq!(
        det_exact,
        BigRational::new((-3).into(), (1_u64 << 50).into())
    );
    assert_eq!(det_exact_as_f64.to_bits(), (-3.0 * perturbation).to_bits());

    println!("Near-singular 3×3 matrix (perturbation = 2^-50 ≈ {perturbation:.2e}):");
    for row in m.as_rows() {
        print!("  [");
        for (col, value) in row.iter().enumerate() {
            if col > 0 {
                print!(", ");
            }
            print!("{value:22.18}");
        }
        println!("]");
    }
    println!();
    println!("f64 det_direct()   = {det_f64_approx:+.6e}");
    println!("det_exact()        = {det_exact}");
    println!("exact.try_to_f64() = {det_exact_as_f64:+.6e}");
    println!();
    println!("The exact determinant is −3/2^50 ≈ −2.66e-15.");
    Ok(())
}
