#![forbid(unsafe_code)]

//! Solve a 5×5 linear system via LU factorization (with pivoting).

use approx::assert_abs_diff_eq;

use la_stack::prelude::*;

fn main() -> Result<(), LaError> {
    // This system requires pivoting (a[0][0] = 0), so it's a good LU demo.
    // A = J - I: zeros on diagonal, ones elsewhere.
    let a = Matrix::<5>::try_from_rows([
        [0.0, 1.0, 1.0, 1.0, 1.0],
        [1.0, 0.0, 1.0, 1.0, 1.0],
        [1.0, 1.0, 0.0, 1.0, 1.0],
        [1.0, 1.0, 1.0, 0.0, 1.0],
        [1.0, 1.0, 1.0, 1.0, 0.0],
    ])?;

    // Choose x = [1, 2, 3, 4, 5]. Then b = A x = [14, 13, 12, 11, 10].
    let b = Vector::<5>::try_new([14.0, 13.0, 12.0, 11.0, 10.0])?;

    let lu = a.lu(DEFAULT_SINGULAR_TOL)?;
    let x = lu.solve(b)?.into_array();
    for (actual, expected) in x.into_iter().zip([1.0, 2.0, 3.0, 4.0, 5.0]) {
        assert_abs_diff_eq!(actual, expected, epsilon = 1.0e-12);
    }

    println!("x = {x:?}");
    Ok(())
}
