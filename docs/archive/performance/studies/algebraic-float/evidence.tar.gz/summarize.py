"""Validate and summarize retained Criterion evidence; run with la-stack's locked uv environment."""

import csv
import json
import math
import sys
from pathlib import Path

from research_repo_tools.criterion import read_estimate


def main() -> None:
    root = Path(__file__).parent / "evidence"
    writer = csv.writer(sys.stdout)
    writer.writerow([
        "phase", "case", "strict_mean_ns", "strict_lower_ns", "strict_upper_ns",
        "algebraic_mean_ns", "algebraic_lower_ns", "algebraic_upper_ns",
        "mean_change_percent", "strict_median_ns", "algebraic_median_ns", "samples",
    ])
    for phase in ("forward", "reverse"):
        for dimension in (2, 3, 4, 5, 8):
            for fixture in ("shared", "integer"):
                case = f"norm_inf_d{dimension}/{fixture}"
                folder = root / phase / case
                for variant in ("strict", "algebraic"):
                    sample = json.loads((folder / variant / "sample.json").read_bytes())
                    assert len(sample["times"]) == len(sample["iters"]) == 100
                    assert all(math.isfinite(x) and x > 0 for x in sample["times"] + sample["iters"])
                strict = read_estimate(folder / "strict/estimates.json", statistic="mean")
                algebraic = read_estimate(folder / "algebraic/estimates.json", statistic="mean")
                assert strict.confidence_level == algebraic.confidence_level == 0.95
                strict_median = read_estimate(folder / "strict/estimates.json", statistic="median")
                algebraic_median = read_estimate(folder / "algebraic/estimates.json", statistic="median")
                writer.writerow([
                    phase, case, strict.point, strict.lower, strict.upper,
                    algebraic.point, algebraic.lower, algebraic.upper,
                    100 * (algebraic.point / strict.point - 1),
                    strict_median.point, algebraic_median.point, 100,
                ])


if __name__ == "__main__":
    main()
